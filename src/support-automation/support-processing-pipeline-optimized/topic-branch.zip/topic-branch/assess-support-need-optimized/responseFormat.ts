import {formatCatalogSelection} from "./catalogSelection";

const outputContractForPrompt = buildOutputContractForPrompt();

const responseFormat = {
  type: "json_schema",
  json_schema: {
    name: "support_need_assessment",
    strict: true,
    schema: {
      type: "object",
      additionalProperties: false,
      required: ["supportNeedAssessment"],
      properties: {
        supportNeedAssessment: {
          type: "object",
          additionalProperties: false,
          required: ["supportNeed", "unclearReason", "reason"],
          properties: {
            supportNeed: {
              enum: formatCatalogSelection.supportNeeds
            },
            unclearReason: {
              anyOf: [
                {
                  enum: formatCatalogSelection.supportNeedUnclearReasons
                },
                {
                  type: "null"
                }
              ]
            },
            reason: {
              type: "string"
            }
          }
        }
      }
    }
  }
} as const;

function buildOutputContractForPrompt(): string {
  return `
Return only valid JSON with this exact top-level shape:

{
  "supportNeedAssessment": {
    "supportNeed": "<accepted_support_need>",
    "unclearReason": null,
    "reason": "<short_grounded_reason>"
  }
}

Accepted supportNeed values:
${formatCatalogSelection.supportNeeds.map((value) => `- "${value}"`).join("\n")}

Accepted unclearReason values, only when supportNeed is "unclear":
${formatCatalogSelection.supportNeedUnclearReasons.map((value) => `- "${value}"`).join("\n")}

Rules:
- If supportNeed is not "unclear", unclearReason must be null.
- If supportNeed is "unclear", unclearReason must use an accepted unclear reason value.
- reason must be short, grounded in the topic and latest source understandings.
- reason must not mention retrieval, catalogue routing, response planning, or memory updates.
`.trim();
}

export {
  outputContractForPrompt,
  responseFormat
};
