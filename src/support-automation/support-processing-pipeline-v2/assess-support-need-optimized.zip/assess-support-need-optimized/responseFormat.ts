import {formatCatalogSelection} from "./catalogSelection";

const outputJsonShapeForPrompt = buildOutputJsonShapeForPrompt();

const responseFormat = {
  type: "json_schema",
  json_schema: {
    name: "support_need_assessment",
    strict: true,
    schema: {
      type: "object",
      additionalProperties: false,
      required: ["supportNeedAssessment"],
      properties: {
        supportNeedAssessment: {
          type: "object",
          additionalProperties: false,
          required: ["supportNeed", "unclearReason", "reason"],
          properties: {
            supportNeed: {
              enum: formatCatalogSelection.supportNeeds
            },
            unclearReason: {
              anyOf: [
                {
                  enum: formatCatalogSelection.supportNeedUnclearReasons
                },
                {
                  type: "null"
                }
              ]
            },
            reason: {
              type: "string"
            }
          }
        }
      }
    }
  }
} as const;

function buildOutputJsonShapeForPrompt(): string {
  return `
{
  "supportNeedAssessment": {
    "supportNeed": "issue_resolution",
    "unclearReason": null,
    "reason": "The topic is best understood as a login problem to resolve, even though the latest message only confirms the issue continues."
  }
}
`.trim();
}

export {
  outputJsonShapeForPrompt,
  responseFormat
};
