import {broadIntentCatalog} from "../../support-catalog-optimized/supportDeep.catalog";

const key = {
  prompt: ["key"]
} as const;

const keyWithExtraction = {
  prompt: ["key", "extractionGuidance"]
} as const;

type SelectionEntry = {
  extractionGuidance?: unknown;
};

type Catalog = Record<string, SelectionEntry>;
type PromptItem = {key: string; extractionGuidance: string};

const broadIntentSelection = {
  issue: keyWithExtraction,
  faq: keyWithExtraction,
  request: keyWithExtraction,
  unclear: keyWithExtraction
} as const;

const ragRetrievalModeSelection = {
  answer: {
    extractionGuidance: "Retrieve support knowledge to answer, explain, solve, confirm known behavior, describe a policy, limitation, procedure, or useful support guidance."
  },
  answer_and_soft_probe: {
    extractionGuidance: "Retrieve a direct answer while allowing the response planner to gently ask whether the user is blocked, when a clear FAQ may hide an issue."
  }
} as const;

// Example shape:
// {
//   broadIntents: ["issue", "faq", "request", "unclear"],
//   ragRetrievalModes: ["answer", "answer_and_soft_probe"]
// }
const formatCatalogSelection = resolveFormatCatalogSelection();

// Example shape:
// {
//   broadIntents: [
//     {key: "issue", extractionGuidance: "..."},
//     {key: "faq", extractionGuidance: "..."}
//   ],
//   ragRetrievalModes: [
//     {key: "answer", extractionGuidance: "..."},
//     {key: "answer_and_soft_probe", extractionGuidance: "..."}
//   ]
// }
const promptCatalogSelection = resolvePromptCatalogSelection();

function resolveFormatCatalogSelection() {
  void key;

  return {
    broadIntents: buildCatalogKeys(broadIntentCatalog, "broad intent", broadIntentSelection),
    ragRetrievalModes: buildLocalKeys(ragRetrievalModeSelection, "RAG retrieval mode")
  };
}

function resolvePromptCatalogSelection() {
  return {
    broadIntents: buildCatalogPromptItems(broadIntentCatalog, "broad intent", broadIntentSelection),
    ragRetrievalModes: buildLocalPromptItems(ragRetrievalModeSelection, "RAG retrieval mode")
  };
}

function buildLocalKeys<TSelection extends Record<string, SelectionEntry>>(
  selection: TSelection,
  label: string
): string[] {
  return Object.keys(selection).map((selectedKey) => {
    getExtractionGuidance(selection, label, selectedKey);
    return selectedKey;
  });
}

function buildLocalPromptItems<TSelection extends Record<string, SelectionEntry>>(
  selection: TSelection,
  label: string
): PromptItem[] {
  return Object.keys(selection).map((selectedKey) => ({
    key: selectedKey,
    extractionGuidance: getExtractionGuidance(selection, label, selectedKey)
  }));
}

function buildCatalogKeys<TSelection extends Record<string, typeof keyWithExtraction>>(
  catalog: Catalog,
  label: string,
  selection: TSelection
): string[] {
  return Object.keys(selection).map((selectedKey) => getCatalogKey(catalog, label, selectedKey));
}

function buildCatalogPromptItems<TSelection extends Record<string, typeof keyWithExtraction>>(
  catalog: Catalog,
  label: string,
  selection: TSelection
): PromptItem[] {
  return Object.keys(selection).map((selectedKey) => ({
    key: getCatalogKey(catalog, label, selectedKey),
    extractionGuidance: getExtractionGuidance(catalog, label, selectedKey)
  }));
}

function getCatalogKey(catalog: Catalog, label: string, selectedKey: string): string {
  getCatalogEntry(catalog, label, selectedKey);
  return selectedKey;
}

function getExtractionGuidance(catalog: Catalog, label: string, selectedKey: string): string {
  const extractionGuidance = getCatalogEntry(catalog, label, selectedKey).extractionGuidance;

  if (typeof extractionGuidance === "string" && extractionGuidance.trim() !== "") {
    return extractionGuidance;
  }

  throw new Error(`Missing extractionGuidance for optimized knowledge enrichment ${label} ${selectedKey}`);
}

function getCatalogEntry(catalog: Catalog, label: string, selectedKey: string): SelectionEntry {
  const entry = catalog[selectedKey];

  if (entry) {
    return entry;
  }

  throw new Error(`Unknown optimized knowledge enrichment ${label} in local catalog selection: ${selectedKey}`);
}

export {
  formatCatalogSelection,
  promptCatalogSelection
};
