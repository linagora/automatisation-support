import {callLLM} from "../../../infrastructure/llm/llm-client";
import {parseLLMResponse} from "../../../infrastructure/llm/parseLLMResponse";
import {knowledgeEnrichmentFallbackReason} from "../../support-catalog-optimized/supportFallback.catalog";
import {buildPlanKnowledgeEnrichmentPrompt} from "./buildPlanKnowledgeEnrichmentPrompt";
import {responseFormat} from "./responseFormat";
import {validatePlanKnowledgeEnrichmentOutput} from "./validatePlanKnowledgeEnrichmentOutput";

import type {KnowledgeEnrichmentFallbackReason} from "../../support-catalog-optimized/supportFallback.catalog";
import type {PlanKnowledgeEnrichmentOptimizedInput} from "./buildPlanKnowledgeEnrichmentPrompt";
import type {KnowledgeEnrichmentDecision} from "./validatePlanKnowledgeEnrichmentOutput";

// Stage contract:
// Input: one optimized support topic context and recent interaction context.
// Output: broad intent and RAG retrieval decision, or a safe no-RAG fallback.
// Non-goals: no catalog field selection, no RAG query generation, no retrieval, no memory update, no response drafting.
// Validation policy: strict JSON validation, no hidden repair; fallback returns safe no-RAG decision.

type PlanKnowledgeEnrichmentAnalyzedOutput = {
  status: "analyzed";
  fallbackReason: null;
  knowledgeEnrichmentPlan: KnowledgeEnrichmentDecision;
};

type PlanKnowledgeEnrichmentFallbackOutput = {
  status: "fallback";
  fallbackReason: KnowledgeEnrichmentFallbackReason;
  knowledgeEnrichmentPlan: KnowledgeEnrichmentDecision;
};

type PlanKnowledgeEnrichmentOutput =
  | PlanKnowledgeEnrichmentAnalyzedOutput
  | PlanKnowledgeEnrichmentFallbackOutput;

async function runPlanKnowledgeEnrichment(
  input: PlanKnowledgeEnrichmentOptimizedInput
): Promise<PlanKnowledgeEnrichmentOutput> {
  const {messages} = buildPlanKnowledgeEnrichmentPrompt(input);

  try {
    const result = await callLLM(messages, {
      stage: "knowledge_enrichment_plan",
      preset: "standard",
      temperature: 0,
      maxTokens: 600,
      responseFormat
    });

    if (!result.success) {
      return buildFallbackOutput(knowledgeEnrichmentFallbackReason.llmCallFailed);
    }

    if (!result.content || result.content.trim() === "") {
      return buildFallbackOutput(knowledgeEnrichmentFallbackReason.missingLlmContent);
    }

    const parsedResponse = parseLLMResponse(result.content);

    if (!parsedResponse) {
      return buildFallbackOutput(knowledgeEnrichmentFallbackReason.invalidLlmOutput);
    }

    const knowledgeEnrichmentPlan = validatePlanKnowledgeEnrichmentOutput(parsedResponse);

    if (!knowledgeEnrichmentPlan) {
      return buildFallbackOutput(knowledgeEnrichmentFallbackReason.invalidLlmOutput);
    }

    return {
      status: "analyzed",
      fallbackReason: null,
      knowledgeEnrichmentPlan
    };
  } catch {
    return buildFallbackOutput(knowledgeEnrichmentFallbackReason.llmCallFailed);
  }
}

function buildFallbackOutput(
  reason: KnowledgeEnrichmentFallbackReason
): PlanKnowledgeEnrichmentFallbackOutput {
  return {
    status: "fallback",
    fallbackReason: reason,
    knowledgeEnrichmentPlan: buildSafeNoRagDecision(reason)
  };
}

function buildSafeNoRagDecision(reason: KnowledgeEnrichmentFallbackReason): KnowledgeEnrichmentDecision {
  return {
    broadIntent: {
      mode: "unclear",
      reason
    },
    rag: {
      shouldRetrieve: false,
      mode: null,
      reason
    }
  };
}

export {runPlanKnowledgeEnrichment};

export type {
  PlanKnowledgeEnrichmentAnalyzedOutput,
  PlanKnowledgeEnrichmentFallbackOutput,
  PlanKnowledgeEnrichmentOptimizedInput,
  PlanKnowledgeEnrichmentOutput
};
