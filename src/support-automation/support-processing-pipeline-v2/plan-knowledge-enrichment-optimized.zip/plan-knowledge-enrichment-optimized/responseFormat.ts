import {formatCatalogSelection} from "./catalogSelection";

const outputJsonShapeForPrompt = buildOutputJsonShapeForPrompt();

const responseFormat = {
  type: "json_schema",
  json_schema: {
    name: "knowledge_enrichment_plan",
    strict: true,
    schema: {
      type: "object",
      additionalProperties: false,
      required: ["broadIntent", "rag"],
      properties: {
        broadIntent: {
          type: "object",
          additionalProperties: false,
          required: ["mode", "reason"],
          properties: {
            mode: {
              enum: formatCatalogSelection.broadIntents
            },
            reason: {
              type: "string"
            }
          }
        },
        rag: {
          type: "object",
          additionalProperties: false,
          required: ["shouldRetrieve", "mode", "reason"],
          properties: {
            shouldRetrieve: {
              type: "boolean"
            },
            mode: {
              anyOf: [
                {
                  enum: formatCatalogSelection.ragRetrievalModes
                },
                {
                  type: "null"
                }
              ]
            },
            reason: {
              type: "string"
            }
          }
        }
      }
    }
  }
} as const;

function buildOutputJsonShapeForPrompt(): string {
  return `
{
  "broadIntent": {
    "mode": "issue",
    "reason": "The topic describes a concrete malfunction with enough detail."
  },
  "rag": {
    "shouldRetrieve": true,
    "mode": "answer",
    "reason": "Support knowledge may contain a known workaround or expected behavior."
  }
}
`.trim();
}

export {
  outputJsonShapeForPrompt,
  responseFormat
};
