import {promptCatalogSelection} from "./catalogSelection";
import {outputJsonShapeForPrompt} from "./responseFormat";

import type {LLMMessage} from "../../../infrastructure/llm/llm-client";
import type {AnalyzeSupportTextUnderstanding} from "../analyze-support-text-optimized/runAnalyzeSupportText";
import type {RecentInteractionContext} from "../typesSupportProcessingPipelineV2.types";

type KnowledgeEnrichmentTopicContext = {
  topicId: number | null;
  title: string | null;
  broadCategory: string | null;
  summary: string;
  previousSupportKnowledgeSummary: string | null;
  sourceUnderstandings: AnalyzeSupportTextUnderstanding[];
};

type PlanKnowledgeEnrichmentOptimizedInput = {
  topic: KnowledgeEnrichmentTopicContext;
  recentInteractionContext: RecentInteractionContext;
};

type PlanKnowledgeEnrichmentLlmRequest = {
  messages: LLMMessage[];
};

function buildPlanKnowledgeEnrichmentPrompt(
  input: PlanKnowledgeEnrichmentOptimizedInput
): PlanKnowledgeEnrichmentLlmRequest {
  const systemPrompt = `
# Role
You are the knowledge enrichment routing stage of an internal customer support pipeline.

You do not answer the customer.
You do not write the support response.
You do not select catalog fields.
You do not create the RAG query.
You do not retrieve knowledge.
You do not modify topic memory.

You only decide:
1. the broadIntent of the current topic;
2. whether RAG/support-knowledge retrieval should run now.

# Important distinction
topic.broadCategory is the topic domain/category from support memory.
broadIntent is the operational intent for support routing.
Do not confuse them.

Examples:
- A billing topic can be issue, faq, or request.
- An access/security topic can be issue, faq, or request.
- A bug category usually maps to issue, but a vague topic may still be unclear.
- A feature_request category may map to request, but can hide an issue or FAQ.

# RAG decision
RAG should run only if:
1. the topic is specific enough to produce a useful retrieval query later;
2. support knowledge may provide an answer, solution, known behavior, policy, limitation, procedure, workaround, or useful support guidance.

Set rag.shouldRetrieve = false when:
- broadIntent is unclear;
- the topic is too underqualified;
- the user only says something generic like "I have a problem" or "it does not work";
- the topic mainly needs qualification first;
- previous support knowledge was not useful and no materially new detail was added;
- the latest understanding only clarifies a previous bot question without changing retrieval usefulness.

Set rag.shouldRetrieve = true when:
- the user asks a clear FAQ/how-to/support knowledge question;
- the user reports a concrete issue with enough details to search known behavior or guidance;
- the user makes a request that could be answered by documentation, policy, availability, or support knowledge;
- a materially new detail was added after a previous weak, empty, or irrelevant retrieval.

Materially new information includes:
- exact error message or code;
- affected platform, OS, browser, product, feature, page, module, plan, or service;
- reproduction detail;
- failed attempted action;
- invoice, transaction, order, ticket, account, workspace, organization, permission, server, integration, or reference id.

# Previous support knowledge
Use topic.previousSupportKnowledgeSummary as routing signal.
If previous retrieval found no useful customer-facing knowledge, do not retry RAG unless the source understandings add materially new information.
If previous retrieval was useful, run RAG again only if the latest understandings add a new question, symptom, context, or detail that could require additional support knowledge.

# RAG mode
Use "answer" for a direct answer, solution, known behavior, policy, limitation, procedure, or support guidance.
Use "answer_and_soft_probe" only when a clear FAQ may hide an issue.
If rag.shouldRetrieve is false, mode must be null.
If broadIntent is unclear, rag.shouldRetrieve must be false and mode must be null.

# Output JSON shape
${outputJsonShapeForPrompt}

Return only JSON.
`.trim();

  const userPrompt = `
# Input

<topic>
${JSON.stringify(input.topic)}
</topic>

<recentInteractionContext>
${JSON.stringify(input.recentInteractionContext)}
</recentInteractionContext>

# Broad intent catalog
${renderPromptItems(promptCatalogSelection.broadIntents)}

# RAG retrieval modes
${renderPromptItems(promptCatalogSelection.ragRetrievalModes)}
`.trim();

  return {
    messages: [
      {role: "system", content: systemPrompt},
      {role: "user", content: userPrompt}
    ]
  };
}

function renderPromptItems(entries: Array<{key: string; extractionGuidance?: string}>): string {
  return entries.map((entry) => buildPromptLine(entry)).join("\n");
}

function buildPromptLine(entry: {key: string; extractionGuidance?: string}): string {
  return entry.extractionGuidance
    ? `* "${entry.key}": ${entry.extractionGuidance}`
    : `* "${entry.key}"`;
}

export {buildPlanKnowledgeEnrichmentPrompt};

export type {
  KnowledgeEnrichmentTopicContext,
  PlanKnowledgeEnrichmentLlmRequest,
  PlanKnowledgeEnrichmentOptimizedInput
};
