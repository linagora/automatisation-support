import {formatCatalogSelection} from "./catalogSelection";

type BroadIntentMode = typeof formatCatalogSelection.broadIntents[number];
type RagRetrievalMode = typeof formatCatalogSelection.ragRetrievalModes[number] | null;

type KnowledgeEnrichmentDecision = {
  broadIntent: {
    mode: BroadIntentMode;
    reason: string;
  };
  rag: {
    shouldRetrieve: boolean;
    mode: RagRetrievalMode;
    reason: string;
  };
};

function validatePlanKnowledgeEnrichmentOutput(
  parsedResponse: unknown
): KnowledgeEnrichmentDecision | null {
  if (!isRecord(parsedResponse)) return null;
  if (!hasOnlyKeys(parsedResponse, ["broadIntent", "rag"])) return null;

  const broadIntent = validateBroadIntent(parsedResponse.broadIntent);
  const rag = validateRag(parsedResponse.rag);

  if (!broadIntent || !rag) return null;
  if (broadIntent.mode === "unclear" && (rag.shouldRetrieve || rag.mode !== null)) return null;

  return {
    broadIntent,
    rag
  };
}

function validateBroadIntent(value: unknown): KnowledgeEnrichmentDecision["broadIntent"] | null {
  if (!isRecord(value)) return null;
  if (!hasOnlyKeys(value, ["mode", "reason"])) return null;

  const mode = validateEnumValue(value.mode, formatCatalogSelection.broadIntents);
  const reason = validateNonEmptyString(value.reason);

  if (!mode || !reason) return null;

  return {
    mode: mode as BroadIntentMode,
    reason
  };
}

function validateRag(value: unknown): KnowledgeEnrichmentDecision["rag"] | null {
  if (!isRecord(value)) return null;
  if (!hasOnlyKeys(value, ["shouldRetrieve", "mode", "reason"])) return null;
  if (typeof value.shouldRetrieve !== "boolean") return null;

  const reason = validateNonEmptyString(value.reason);
  if (!reason) return null;

  if (!value.shouldRetrieve) {
    return value.mode === null
      ? {
          shouldRetrieve: false,
          mode: null,
          reason
        }
      : null;
  }

  const mode = validateEnumValue(value.mode, formatCatalogSelection.ragRetrievalModes);
  if (!mode) return null;

  return {
    shouldRetrieve: true,
    mode: mode as Exclude<RagRetrievalMode, null>,
    reason
  };
}

function validateEnumValue(value: unknown, allowedValues: readonly string[]): string | null {
  return typeof value === "string" && allowedValues.includes(value) ? value : null;
}

function validateNonEmptyString(value: unknown): string | null {
  return typeof value === "string" && value.trim() !== "" ? value : null;
}

function hasOnlyKeys(value: Record<string, unknown>, allowedKeys: string[]): boolean {
  const allowedKeySet = new Set(allowedKeys);
  return Object.keys(value).every((key) => allowedKeySet.has(key));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export {validatePlanKnowledgeEnrichmentOutput};

export type {
  BroadIntentMode,
  KnowledgeEnrichmentDecision,
  RagRetrievalMode
};
