const commonLlmFallbackReason = {
  llmCallFailed: "llm_call_failed",
  missingLlmContent: "missing_llm_content",
  invalidLlmOutput: "invalid_llm_output"
} as const;

const textSurfaceFallbackReason = {
  emptyMessage: "empty_message",
  invalidSegmentCoverage: "invalid_segment_coverage",
  ...commonLlmFallbackReason
} as const;

type CommonLlmFallbackReason =
  typeof commonLlmFallbackReason[keyof typeof commonLlmFallbackReason];

type TextSurfaceFallbackReason =
  typeof textSurfaceFallbackReason[keyof typeof textSurfaceFallbackReason];

export {
  commonLlmFallbackReason,
  textSurfaceFallbackReason
};

export type {
  CommonLlmFallbackReason,
  TextSurfaceFallbackReason
};
