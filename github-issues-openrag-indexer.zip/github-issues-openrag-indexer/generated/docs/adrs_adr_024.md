## Status

- Date: 23/10/2025
- Status: Accepted

## Context

To support the upcoming B2B development, we need to establish a mutual, safe, and controlled method of communication with LDAP. We decided that [LDAP-REST](https://github.com/linagora/ldap-rest) will be the gateway for communicating with LDAP.

Also, our current LDAP manipulation implementation has issues with deployment complexity, scaling, and developer experience.

### Requirements

**B2C (Normal Signup):**

- Users are created in the main branch

**B2B (Organization Signup):**

- Multi-user organizations with dedicated LDAP branches
- Hierarchical structure using baseDN
- Management through the admin panel

**Consumers:**

- Registration Service (handles signup flows)
- Admin Panel (manages organizations)

## Decision

- Use [ldap-rest](https://github.com/linagora/ldap-rest) in the admin panel and Cloudery to manipulate users and organizations.
- Replace LdapTs with [ldap-rest](https://github.com/linagora/ldap-rest) -- HTTP REST API for user directory management supporting B2C and B2B.

**Key points:**

- B2C: users live in the main branch.
- B2B: users in org branch.
- Single API serves Registration Service and Admin Panel.
- An optional client library can be developed, like `@twake/ldap-rest-client` (for future JavaScript projects if needed). This is optional, not required at this stage.

### Architecture

```mermaid
flowchart TD
    Browser[Admin panel frontend]
    RegSvc[Registration Service]
    AdminPanel[Backend / cloudery]
    DB[(DATABASE)]

    Browser -->|SSO Cookie| Proxy
    RegSvc -->|HMAC Auth| LDAPREST
    AdminPanel -->|HMAC Auth| LDAPREST

    Proxy[ADMIN PANEL BACKEND]

    Proxy -.->|Validate SSO| LemonSSO[LemonLDAP SSO]
    Proxy -->|HMAC Auth| LDAPREST
    Proxy -->|manage organizations| DB

    subgraph LDAPREST[LDAP-REST Service - Not exposed to internet]
        direction TB
        AuthPlugin[Auth Plugin<br/>Validates HMAC]
        AuthzPlugin[Authz Plugin<br/>Checks Roles/Permissions]
        LDAPOps[LDAP Operations<br/>CRUD on Directory]

        AuthPlugin --> AuthzPlugin
        AuthzPlugin --> LDAPOps
    end

    AuthPlugin -.->|Verify HMAC| SecretStore[Secret Store]
    AuthzPlugin -.->|Check Role| LDAP
    LDAPOps --> LDAP[(LDAP Directory)]
```

**Architecture Components:**

1. **Reverse Proxy (can be nginx/Traefik)** -- Simple gateway that:
   - Filters routes (whitelist-based)
   - Rate limits requests
   - Logs all requests (audit trail)
   - Forwards to LDAP-REST

2. **LDAP-REST Service** -- Core API (hidden from the internet):
   - **Authentication Plugin** -- Handles two auth methods:
     - **SSO Cookie Auth** -- Validates LemonLDAP session for browser requests
     - **HMAC Signature Auth** -- Verifies request signatures for backend services
   - **Authorization Plugin** -- Role-based access control:
     - Verifies user roles in LDAP
     - Checks organization membership
     - Enforces admin-only operations
   - **LDAP Operations** -- Performs directory operations

## Authentication and Authorization

### Authentication Methods

#### 1. HMAC-Based Request Signing (Backend Services)

Backend services (Registration Service, admin panel backend, Cloudery) authenticate using HMAC-SHA256 request signing.

**Request Header:**

```
Authorization: HMAC-SHA256 service-id:timestamp:signature
```

**Signature Calculation:**

```
signature = HMAC-SHA256(
  secret,
  "METHOD|PATH|timestamp|body-hash"
)

where:
- METHOD: HTTP method (GET, POST, PATCH, DELETE)
- PATH: Request path with query string
- timestamp: Unix timestamp in milliseconds
- body-hash: SHA256(request_body) for POST/PATCH, empty string for GET/DELETE
```

<details>
<summary>Example</summary>

```bash
# Request details
METHOD="POST"
PATH="/api/v1/users?organizationId=org_123"
TIMESTAMP="1730000000000"
BODY='{"cn":"johndoe","uid":"johndoe",...}'
BODY_HASH=$(echo -n "$BODY" | sha256sum | cut -d' ' -f1)

# Create signature base string
SIG_BASE="$METHOD|$PATH|$TIMESTAMP|$BODY_HASH"

# Calculate HMAC signature
SIGNATURE=$(echo -n "$SIG_BASE" | openssl dgst -sha256 -hmac "$SERVICE_SECRET" | cut -d' ' -f2)

# Send request
curl -X POST "$PATH" \
  -H "Authorization: HMAC-SHA256 registration-service:$TIMESTAMP:$SIGNATURE" \
  -H "Content-Type: application/json" \
  -d "$BODY"
```

</details>

**Validation (LDAP-REST Auth Plugin):**

1. Extract `service-id`, `timestamp`, and `signature` from the Authorization header
2. Verify timestamp is within ~2 minutes of current time (prevent replay attacks)
3. Retrieve the service secret from the Secret Store using `service-id`
4. Recalculate the signature using the same method
5. Compare calculated signature with provided signature (constant-time comparison)
6. Reject if a mismatch or the timestamp has expired

**Registered Services:**

- `registration-service` -- Twake Registration Service
- `cloudery / other backend service` -- Can be an option in the future

#### 2. SSO Cookie Authentication (Browser Requests)

Browser requests are authenticated using LemonLDAP NG session cookies.

**Request Header:**

```
Cookie: lemonldap=<session_cookie>
```

**Validation (LDAP-REST Auth Plugin):**

1. Extract session cookie from request
2. Validate session with LemonLDAP NG
3. Extract user identity (email is the UID) from the session
4. Pass to the authorization plugin

### Authorization Policies

#### Backend Service Operations (HMAC Auth)

**Allowed Operations:**

- Create/Update/Disable/Delete users in **main branch (B2C)**
- Create organizations

**Policy:**

- HMAC authentication is sufficient
- No additional authorization checks
- Services are trusted

#### User Operations (SSO Cookie Auth)

**Allowed Operations:**

- Create/Update/Disable/Delete users in **organization branches (B2B)**
- Manage organization groups and memberships
- View organization details

**Policy:**

1. **Authentication:** Valid SSO session required
2. **Organization Extraction:** Determine the user's organization from the email domain
3. **Role Verification:** Check if the user has `admin` role in LDAP for that organization
4. **Target Validation:** Verify requested `organizationId` matches the user's organization
5. **Authorization Decision:** Allow only if the user is an admin in the target organization

**Authorization Flow:**

```mermaid
flowchart TD
    Request[Incoming Request]
    Request --> ExtractSession[Extract SSO Session]
    ExtractSession --> GetUser[Get User Identity]
    GetUser --> ExtractOrg[Find the Organization using Email]
    ExtractOrg --> GetRole[Query User Role in LDAP]
    GetRole --> CheckAdmin{Is Admin Role?}
    CheckAdmin -->|No| Deny[403 Forbidden]
    CheckAdmin -->|Yes| CheckTarget{Target Org Matches?}
    CheckTarget -->|No| Deny
    CheckTarget -->|Yes| Allow[Perform the operation]
```

## API design

LDAP-REST exposes three main resource groups with different authentication requirements based on the operation context (B2C vs B2B).

### Backend Service APIs (HMAC Authentication)

These endpoints require HMAC-SHA256 request signing and are used by trusted backend services (Registration Service, Admin Panel).

| Method | Endpoint                                              | Purpose                                                                                                                                                                    | Allowed Services     |
| ------ | ----------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- |
| POST   | `/api/v1/users`                                       | Create B2C user (main branch)                                                                                                                                              | registration-service |
| PATCH  | `/api/v1/users/:userId`                               | Update B2C user                                                                                                                                                            | registration-service |
| PATCH  | `/api/v1/users/:userId/status`                        | Enable/disable B2C user (body `{ "enabled": boolean }`)                                                                                                                    | registration-service |
| DELETE | `/api/v1/users/:userId`                               | Delete B2C user                                                                                                                                                            | registration-service |
| POST   | `/api/v1/organizations`                               | Create organization                                                                                                                                                        | registration-service |
| GET    | `/api/v1/users/check?field=:field&value=:val`         | Check availability (B2C)                                                                                                                                                   | registration-service |
| GET    | `/api/v1/organizations/check?field=:field&value=:val` | Check organization availability                                                                                                                                            | registration-service |
| POST   | `/api/v1/organizations/:id/admin`                     | Add organization admin (first admin, done by linking org to user)                                                                                                          |                      |
| POST   | `/api/v1/organizations/:id/owner`                     | Add organization owner (first owner) and link the organization to the user via the field `organizationId` in the user object. The user has to exist before doing this call |                      |
| GET    | `/api/v1/organizations/:id/owner`                     | Returns the owner of the organization                                                                                                                                      |                      |
| PUT    | `/api/v1/organizations/:id/owner`                     | Transfers ownership to another user. Only the current owner can perform this operation.                                                                                    |                      |

### User APIs (SSO Cookie Authentication)

These endpoints require valid LemonLDAP session cookies and role-based authorization. Used by browser-based clients (Admin Panel UI).

**Authentication Header:**

```
Cookie: lemonldap=<session_cookie>
```

**Authorization:** The user must have `admin` role in the target organization.

#### User Management in Organizations (B2B)

| Method | Endpoint                                                        | Purpose                                                 |
| ------ | --------------------------------------------------------------- | ------------------------------------------------------- |
| POST   | `/api/v1/organizations/:id/users`                               | Create B2B user in organization                         |
| PATCH  | `/api/v1/organizations/:id/users/:userId`                       | Update B2B user                                         |
| PATCH  | `/api/v1/organizations/:id/users/:userId/status`                | Enable/disable B2B user (body `{ "enabled": boolean }`) |
| DELETE | `/api/v1/organizations/:id/users/:userId`                       | Delete B2B user                                         |
| GET    | `/api/v1/organizations/:id/users?by=:field&value=:val`          | Get user in organization                                |
| GET    | `/api/v1/organizations/:id/users?page=:p&limit=:l`              | List users in organization                              |
| GET    | `/api/v1/organizations/:id/users/check?field=:field&value=:val` | Check user availability (phone, username, etc.)         |
| PATCH  | `/api/v1/organizations/:id/users/:userId/role`                  | Change user role (admin/moderator/member)               |

#### Organization Management

| Method    | Endpoint                    | Purpose                                      |
| --------- | --------------------------- | -------------------------------------------- |
| GET       | `/api/v1/organizations`     | Get the organizations of the connected admin |
| GET       | `/api/v1/organizations/:id` | Get organization details                     |
| ~~PATCH~~ | `/api/v1/organizations/:id` | Update organization                          |

#### Group Management

| Method | Endpoint                                                    | Purpose                      |
| ------ | ----------------------------------------------------------- | ---------------------------- |
| POST   | `/api/v1/organizations/:id/groups`                          | Create group in organization |
| GET    | `/api/v1/organizations/:id/groups`                          | List groups in organization  |
| GET    | `/api/v1/organizations/:id/groups/:groupId`                 | Get group details            |
| PATCH  | `/api/v1/organizations/:id/groups/:groupId`                 | Update group                 |
| DELETE | `/api/v1/organizations/:id/groups/:groupId`                 | Delete group                 |
| POST   | `/api/v1/organizations/:id/groups/:groupId/members`         | Add users to group           |
| DELETE | `/api/v1/organizations/:id/groups/:groupId/members/:userId` | Remove user from group       |

## API reference

### Users resource

#### Check availability

These endpoints allow checking if a user identifier (username, phone, or email) is available.

**Main branch (B2C):**

```
GET /api/v1/users/check?field=username&value=johndoe
```

**Organization branch (B2B):**

```
GET /api/v1/organizations/org_abc123/users/check?field=username&value=john.doe
```

**Query Parameters:**

- `field` (required): One of `username`, `phone`, or `email`
- `value` (required): The value to check

**Response 200 (available):**

```json
{
  "available": true
}
```

**Response 200 (not available):**

```json
{
  "available": false
}
```

**Error Responses:**

| Status | Code                     | Description                                                     |
| ------ | ------------------------ | --------------------------------------------------------------- |
| 400    | `INVALID_FIELD`          | Invalid field parameter. Must be one of: username, phone, email |
| 400    | `MISSING_PARAMETERS`     | Missing required parameters: field and value                    |
| 400    | `INVALID_PHONE_FORMAT`   | Invalid phone number format                                     |
| 400    | `INVALID_EMAIL_FORMAT`   | Invalid email format                                            |
| 404    | `ORGANIZATION_NOT_FOUND` | Organization not found (B2B only)                               |

**Notes:**

- **B2C endpoint:** Requires HMAC signature, will be used in signup flows
- **B2B endpoint:** Requires SSO cookie authentication and admin role in the target organization
- For B2C: checks against users in the main LDAP branch
- For B2B: checks against users within the specified organization branch only
- Phone numbers are validated before checking availability
- Email addresses are validated before checking availability

#### Fetch user

**Main branch (B2C):**

```
GET /api/v1/users?by=username&value=johndoe&fields=cn,mail,mobile
Cookie: lemonldap=<session_cookie>
```

**Organization branch (B2B):**

```
GET /api/v1/organizations/:id/users?by=username&value=john.doe&fields=cn,mail,mobile
Cookie: lemonldap=<session_cookie>
```

**Query Parameters:**

- `by` (required): Search field -- one of `username`, `phone`, `email`, `recoveryEmail`
- `value` (required): The value to search for
- `fields` (optional): Comma-separated list of fields to return
  - Omit for base user attributes
  - Use `all` for a complete user record
  - Use specific fields: `cn,mail,mobile,scryptN,domain,iterations`

**Response 200 (found):**

```json
{
  "cn": "johndoe",
  "sn": "Doe",
  "mobile": "+33612345678",
  "mail": "johndoe@example.com"
}
```

**Response 404:** User not found

#### Create user

**For B2C:**

```
POST /api/v1/users
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
Content-Type: application/json
```

```javascript
{
  cn: "Marie Dubois",
  sn: "Dubois",
  givenName: "Marie",
  displayName: "Marie Dubois",
  mail: "marie.dubois@twake.app",
  mobile: "+33612345678",

  // Security fields
  userPassword: "$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhW",
  scryptR: "8",
  scryptN: "16384",
  scryptP: "1",
  scryptSalt: "a1b2c3d4e5f6g7h8",
  scryptDKLength: "64",
  iterations: "10000",
  domain: "twake.app",

  // Cryptographic keys
  publicKey: "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...",
  privateKey: "-----BEGIN ENCRYPTED PRIVATE KEY-----\nMIIFHDBOBgkqhkiG9w0BBQ0wQTApBgkqhkiG9w0BBQww...",
  protectedKey: "U2FsdGVkX1+vupppZksvRf5pq5g5XjFRIipRkwB0K1Y96Qsv...",

  // Optional simple fields
  twoFactorEnabled: "true",
  workspaceUrl: "https://twake.app/workspace/acme-corp",
  recoveryEmail: "marie.dubois.backup@gmail.com",
  twakeOrganizationRole: "admin",
  twakeOrganizationLink: "org:acme-corp-12345",
  fullname: "Marie Claire Dubois",
  birthday: "1990-05-15",
  gender: "female",
  note: "Prefers communication via email.",
  birthplace: "Paris, France",
  jobTitle: "Senior Product Manager",
  company: "Twake Technologies",

  // Name object (reconstructed from flattened fields)
  name: {
    familyName: "Dubois",
    givenName: "Marie",
    additionalName: "Claire",
    namePrefix: "Mme",
    surname: "Dubois"
  },

  // Email array (parsed from JSON)
  email: [
    { address: "marie.dubois@twake.app", type: "work", label: "work", primary: "true" },
    { address: "marie.dubois.backup@gmail.com", type: "personal", label: "home" }
  ],

  // IMPP array (parsed from JSON)
  impp: [
    { uri: "sip:marie.dubois@twake.app", protocol: "SIP", label: "work", primary: "true" },
    { uri: "xmpp:marie@jabber.org", protocol: "XMPP", label: "home" }
  ],

  // Phone array (parsed from JSON with boolean conversion)
  phone: [
    { number: "+33612345678", type: "cell", label: "work", primary: true },
    { number: "+33145678901", type: "voice", label: "work" }
  ],

  // Address array (parsed from JSON with boolean conversion)
  address: [
    {
      id: "addr-work-1",
      street: "Avenue des Champs-Elysees",
      number: "123",
      city: "Paris",
      region: "Ile-de-France",
      code: "75008",
      country: "France",
      type: "Professional",
      label: "work",
      primary: true,
      extendedAddress: {
        building: "Building A",
        floor: "5",
        apartment: "501",
        entrycode: "1234A"
      },
      formattedAddress: "123 Avenue des Champs-Elysees, Building A, Floor 5, Apt 501, 75008 Paris, France",
      geo: { geo: [2.3522, 48.8566], cozyCategory: "work" }
    }
  ]
}
```

**Response 201:**

```json
{
  "success": true
}
```

**Error Response 409:**

```json
{
  "error": "Username already exists",
  "code": "USERNAME_EXISTS"
}
```

**For B2B:**

When creating a user, we create a link in the user object between the organization and the user using the field `organizationId`.

```
POST /api/v1/organizations/org_abc123/users
Cookie: lemonldap=<session_cookie>
Content-Type: application/json
```

The request body is the same as for B2C.

**Response 201:**

```json
{
  "baseDN": "ou=acme-corp,ou=users,dc=example,dc=com"
}
```

**Error Responses:**

| Status | Code                     | Description                            |
| ------ | ------------------------ | -------------------------------------- |
| 403    | `FORBIDDEN`              | Admin role required for this operation |
| 404    | `ORGANIZATION_NOT_FOUND` | Organization not found                 |
| 409    | `USERNAME_EXISTS`        | Username already exists                |

#### Update user

**For B2C:**

```
PATCH /api/v1/users/johndoe
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
Content-Type: application/json

{
  "mobile": "+33687654321"
}
```

**Response 200:**

```json
{
  "success": true
}
```

**Response 404:**

```json
{
  "error": "User not found",
  "code": "USER_NOT_FOUND"
}
```

**For B2B:**

```
PATCH /api/v1/organizations/org_abc123/users/john.doe
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{
  "mobile": "+33687654321"
}
```

**Response 200:** Returns the full updated user object.

**Response 404:**

```json
{
  "error": "User not found in organization branch",
  "code": "USER_NOT_FOUND"
}
```

**Response 400:**

```json
{
  "error": "invalid data, field1",
  "code": "INVALID_DATA"
}
```

**Commonly updated fields:**

- Password: `{ "userPassword": "...", "protectedKey": "..." }`
- Phone: `{ "mobile": "+33..." }`
- Enable 2FA: `{ "twoFactorEnabled": "1", "recoveryEmail": "..." }`
- Disable 2FA: `{ "twoFactorEnabled": null }`

#### Set user status (enable/disable)

Disabling locks the account by setting `pwdAccountLockedTime` to `"000001010000Z"` (using the LDAP PPolicy); enabling clears it. Both operations go through the same endpoint; the desired state is passed in the request body.

A request body is required: the shared HMAC middleware signs `JSON.stringify(req.body)`, so bodiless requests produce mismatched signatures between client and server.

**For B2C:**

```
PATCH /api/v1/users/johndoe/status
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
Content-Type: application/json

{ "enabled": false }
```

**Response 200:**

```json
{
  "success": true
}
```

**Response 400:** `enabled` is missing or is not a boolean.

```json
{
  "error": "enabled must be a boolean",
  "code": "INVALID_ENABLED_VALUE"
}
```

**Response 404:**

```json
{
  "error": "User not found",
  "code": "USER_NOT_FOUND"
}
```

**For B2B:**

```
PATCH /api/v1/organizations/org_abc123/users/john.doe/status
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{ "enabled": false }
```

**Response 200:** Returns the full user object.

**Response 404:**

```json
{
  "error": "User not found in organization branch",
  "code": "USER_NOT_FOUND"
}
```

**Response 403:**

```json
{
  "error": "Admin role required for this operation",
  "code": "FORBIDDEN"
}
```

#### Delete user

**For B2C:**

```
DELETE /api/v1/users/johndoe
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
```

**Response 200:**

```json
{
  "success": true
}
```

**Response 404:**

```json
{
  "error": "User not found",
  "code": "USER_NOT_FOUND"
}
```

**For B2B:**

```
DELETE /api/v1/organizations/org_abc123/users/john.doe
Cookie: lemonldap=<session_cookie>
```

**Response 200:**

```json
{
  "success": true
}
```

**Response 404:**

```json
{
  "error": "User not found in organization branch",
  "code": "USER_NOT_FOUND"
}
```

**Response 403:**

```json
{
  "error": "Admin role required for this operation",
  "code": "FORBIDDEN"
}
```

### Organization resource

#### Create organization

Organizations are created by backend services using HMAC authentication. The first admin must be linked separately using the "Create organization admin" endpoint.

```
POST /api/v1/organizations
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
Content-Type: application/json

{
  "name": "Acme Corporation",
  "domain": "acme-corp.example.com",
  "id": "org_abc123",
  "metadata": {
    "industry": "Technology",
    "size": "enterprise",
    "contact": "admin@acme-corp.example.com"
  }
}
```

**Response 201:**

```json
{
  "success": true,
  "organization": {
    "id": "org_abc123",
    "name": "Acme Corporation",
    "baseDN": "o=acme-corp,dc=example,dc=com",
    "domain": "acme-corp.example.com",
    "status": "active",
    "createdAt": "2025-01-23T10:30:00Z",
    "metadata": {
      "industry": "Technology",
      "size": "enterprise",
      "contact": "admin@acme-corp.example.com"
    }
  }
}
```

#### Get organization

```
GET /api/v1/organizations/org_abc123
Cookie: lemonldap=<session_cookie>
```

**Response 200:**

```json
{
  "id": "org_abc123",
  "name": "Acme Corporation",
  "baseDN": "o=acme-corp,dc=example,dc=com",
  "domain": "acme-corp.example.com",
  "status": "active",
  "createdAt": "2025-01-23T10:30:00Z",
  "metadata": {
    "industry": "Technology",
    "size": "enterprise",
    "contact": "admin@acme-corp.example.com"
  }
}
```

**Response 404:**

```json
{
  "error": "Organization not found",
  "code": "ORGANIZATION_NOT_FOUND"
}
```

#### Get the list of organizations

```
GET /api/v1/organizations
Cookie: lemonldap=<session_cookie>
```

**Response 200:**

```json
[
  {
    "id": "org_abc123",
    "name": "Acme Corporation",
    "baseDN": "o=acme-corp,dc=example,dc=com",
    "domain": "acme-corp.example.com",
    "status": "active",
    "createdAt": "2025-01-23T10:30:00Z",
    "metadata": {
      "industry": "Technology",
      "size": "enterprise",
      "contact": "admin@acme-corp.example.com"
    }
  }
]
```

#### List users in the organization

```
GET /api/v1/organizations/org_abc123/users?page=1&limit=20&status=active&search=john
Cookie: lemonldap=<session_cookie>
```

**Query Parameters:**

- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20, max: 100)
- `status` (optional): Filter by status (`active`, `disabled`)
- `search` (optional): Search by username, email, or name (min 2 characters)
- `sortBy` (optional): Field to sort by (`username`, `createdAt`, `mail`)
- `sortOrder` (optional): `asc` or `desc` (default: `asc`)
- `isTechnical` (optional): `true` or `false` (default: `false`) -- filter technical status

**Response 200:**

```json
{
  "users": [
    {
      "uid": "john.doe",
      "cn": "john.doe",
      "givenName": "John",
      "sn": "Doe",
      "mail": "john.doe@acme-corp.example.com",
      "mobile": "+33612345678"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "totalPages": 3,
    "hasNextPage": true,
    "hasPreviousPage": false
  }
}
```

**Response 400 (invalid search):**

```json
{
  "error": "Search query must be at least 2 characters",
  "code": "INVALID_SEARCH_QUERY"
}
```

#### Update organization

```
PATCH /api/v1/organizations/org_abc123
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{
  "name": "new org name",
  "status": "suspended"
}
```

**Response 200:**

```json
{
  "success": true
}
```

#### Create organization admin (links admin user to organization)

This endpoint links an existing user as an admin to an organization. This is typically used when setting up a new organization to assign the first admin.

```
POST /api/v1/organizations/org_abc123/admin
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
Content-Type: application/json

{
  "username": "john.doe",
  "mail": "john.doe@acme-corp.example.com"
}
```

**Response 200:**

```json
{
  "success": true
}
```

**Error Responses:**

| Status | Code                     | Description                                   |
| ------ | ------------------------ | --------------------------------------------- |
| 404    | `USER_NOT_FOUND`         | User not found                                |
| 404    | `ORGANIZATION_NOT_FOUND` | Organization not found                        |
| 409    | `USER_ALREADY_ADMIN`     | User is already an admin of this organization |

#### Get organization owner

```
GET /api/v1/organizations/:id/owner
```

**Response 200:**

```json
{
  "owner": {
    "username": "john.doe",
    "mail": "john.doe@acme.example.com",
    "displayName": "John Doe"
  }
}
```

If no owner is set:

```json
{ "owner": null }
```

#### Create organization owner (links the owner user to the organization)

This endpoint links an existing user as an owner to an organization. This is typically used when setting up a new organization to assign the first owner.

```
POST /api/v1/organizations/:id/owner
Authorization: HMAC-SHA256 registration-service:1730000000000:a1b2c3d4e5f6...
Content-Type: application/json

{
  "mail": "john.doe@acme-corp.example.com"
}
```

**Response 200:**

```json
{
  "success": true
}
```

**Error Responses:**

| Status | Code                     | Description            |
| ------ | ------------------------ | ---------------------- |
| 404    | `USER_NOT_FOUND`         | User not found         |
| 404    | `ORGANIZATION_NOT_FOUND` | Organization not found |

#### Change user role in organization

Changes the role of a user within an organization. Available roles: `admin`, `moderator`, `member`.

```
PATCH /api/v1/organizations/org_abc123/users/john.doe/role
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{
  "role": "admin"
}
```

**Response 200:**

```json
{
  "success": true
}
```

**Error Responses:**

| Status | Code                      | Description                                            |
| ------ | ------------------------- | ------------------------------------------------------ |
| 400    | `INVALID_ROLE`            | Invalid role. Must be one of: admin, moderator, member |
| 403    | `SELF_DEMOTION_FORBIDDEN` | Cannot change your own role                            |
| 403    | `LAST_ADMIN_PROTECTION`   | Cannot remove the last admin of the organization       |
| 404    | `USER_NOT_FOUND`          | User not found in organization                         |

**Notes:**

- Must have last admin protection
- Should not allow self-demotion

#### Transfer organization ownership

Transfers ownership to another user. Only the current owner can perform this operation.

```
PUT /api/v1/organizations/:id/owner
Content-Type: application/json

{
  "owner": "jane.smith"
}
```

**Response 200:**

```json
{ "success": true }
```

**Error 403 (`OWNERSHIP_TRANSFER_FORBIDDEN`):** Only the current owner or SaaS tools can transfer ownership.

### Groups resource

#### Create a group

```
POST /api/v1/organizations/org_abc123/groups
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{
  "name": "engineering",
  "description": "Engineering team"
}
```

#### List groups

```
GET /api/v1/organizations/org_abc123/groups?page=1&limit=20
Cookie: lemonldap=<session_cookie>
```

**Response 200:**

```json
{
  "organizationId": "org_abc123",
  "groups": [
    {
      "id": "grp_xyz789",
      "cn": "engineering",
      "description": "Engineering team",
      "members": ["john.doe", "jane.smith"],
      "createdAt": "2025-01-23T11:00:00Z"
    },
    {
      "id": "grp_abc456",
      "cn": "sales",
      "description": "Sales team",
      "members": ["bob.wilson"],
      "createdAt": "2025-01-23T11:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 2,
    "totalPages": 1
  }
}
```

#### Fetch a group

```
GET /api/v1/organizations/org_abc123/groups/grp_xyz789
Cookie: lemonldap=<session_cookie>
```

**Response 200:**

```json
{
  "id": "grp_xyz789",
  "cn": "engineering",
  "description": "Engineering team",
  "organizationId": "org_abc123",
  "baseDN": "cn=engineering,o=acme-corp,dc=example,dc=com",
  "members": ["john.doe", "jane.smith"],
  "createdAt": "2025-01-23T11:00:00Z"
}
```

#### Update group

```
PATCH /api/v1/organizations/org_abc123/groups/grp_xyz789
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{
  "description": "Engineering team - updated"
}
```

#### Add users to a group

```
POST /api/v1/organizations/org_abc123/groups/grp_xyz789/members
Cookie: lemonldap=<session_cookie>
Content-Type: application/json

{
  "usernames": ["alice.johnson", "bob.wilson"]
}
```

#### Remove users from a group

```
DELETE /api/v1/organizations/org_abc123/groups/grp_xyz789/members/bob.wilson
Cookie: lemonldap=<session_cookie>
```

#### Delete a group

```
DELETE /api/v1/organizations/org_abc123/groups/grp_xyz789
Cookie: lemonldap=<session_cookie>
```

## Security Measures

### Network Layer

1. **Network Isolation** -- LDAP-REST not exposed to the internet, only via reverse proxy
2. **TLS Everywhere** -- All communication over HTTPS/TLS

### Reverse Proxy Layer

1. **Route Filtering** -- Whitelist-based, only expose necessary endpoints
2. **Rate Limiting** -- Per-IP and per-service limits to prevent abuse
3. **Audit Logging** -- All requests logged with:
   - Timestamp
   - Request ID
   - Client IP address
   - Authentication method (HMAC service-id or SSO user email)
   - HTTP method and path
   - Response status code
   - Response time (ms)
   - Error details (if applicable)

### LDAP-REST Service Layer

1. **HMAC Authentication** -- Request signature validation
   - **Replay Attack Prevention** -- Timestamp validation (2-minute window)
   - **Request Signature Binding** -- Signature includes method, path, timestamp, body
   - **Constant-Time Comparison** -- Prevents timing attacks
2. **SSO Authentication** -- LemonLDAP session validation
   - **Session Validation** -- Each request validates the session with LemonLDAP
3. **Role-Based Authorization** -- Organization admin checks
   - **Organization Isolation** -- Users can only manage their own organization
   - **Role Verification** -- Queries LDAP for user roles
   - **Operation Gating** -- Admin role required for all B2B operations

### Rate limiting

We should have DDoS and brute force protection by rate limiting, for example:

- SSO users: 50 requests/min
- HMAC clients: 10 requests/sec

### Logging and tracing

Each request via the proxy should include: `X-Request-Id: <uuid>` that is logged and propagated through LDAP-REST for full audit correlation.

### Health Check Endpoint

```
GET /health
```

Returns service status and dependency health:

```json
{
  "status": "healthy",
  "timestamp": "2025-01-23T10:00:00Z",
  "dependencies": {
    "ldap": "healthy",
    "lemonldap": "healthy"
  }
}
```

## Alternatives Considered

### Alternative 1: TOTP (Time-based One-Time Password)

**Approach:**

- Backend services share a secret with LDAP-REST
- Generate TOTP code (6 digits, 30-second window)
- Send code in `Authorization: TOTP <code>` header

**Rejected because:**

- **Time synchronization issues** -- Requires accurate clocks on all services
- **Replay window vulnerability** -- Same token valid for 30-60 seconds across multiple requests
- **No request binding** -- Token not tied to specific request content, method, or path
- **Limited token space** -- Only 1 million possible codes, easier to brute force
- **Credential stuffing risk** -- Intercepted token can be reused within the validity window

### Alternative 2: Static API Token

**Approach:**

- Generate long-lived API tokens (UUID/random string)
- Backend services send a token in `Authorization: Bearer <token>` header
- LDAP-REST validates token against database/config

**Rejected because:**

- **Token exposure risk** -- If leaked, it remains valid until manually revoked
- **No request integrity** -- Attacker with a token can craft any request
- **Credential theft** -- Single token compromise grants full access
- **No expiry** -- Tokens don't automatically expire
- **Logging/audit complexity** -- Harder to detect token reuse attacks

### Alternative 3: Mutual TLS (mTLS)

**Approach:**

- Issue X.509 certificates to each backend service
- Services present a certificate during the TLS handshake
- LDAP-REST validates the certificate chain

**Not chosen because:**

- **Certificate management complexity** -- Requires PKI infrastructure, rotation, and revocation
- **Deployment overhead** -- Certificate distribution, renewal automation
- **Debugging difficulty** -- TLS errors are harder to troubleshoot than HTTP auth errors
- **Overkill for internal services** -- HMAC provides sufficient security with less complexity

## Future Considerations

### Potential Enhancements

**1. Typescript Client Library:**

- Develop `@twake/ldap-rest-client` npm package for JavaScript/TypeScript consumers
- Handles HMAC signature generation automatically
- Type-safe API with TypeScript definitions
- Retry logic and error handling

**2. Request Nonce for Enhanced Security:**

- Add a unique nonce to each HMAC request to prevent replay attacks within the 2-minute window

### Performance Optimization

**Caching Strategy:**

- Cache organization metadata (TTL: 5 minutes)
- Cache user role lookups (TTL: 2 minutes)
- Invalidate cache on updates
- Use Redis for distributed caching
