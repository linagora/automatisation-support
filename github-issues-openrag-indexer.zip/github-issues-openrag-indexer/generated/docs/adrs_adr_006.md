# ADR 006: TDrive / TMail Integration

## Status

- **Date**: 28/06/2024
- **Status**: Writing

## Context

Integrating email and drive is the most basic integration expected from a productivity suite.

Features:

- **Attachment action -- add to my drive**: If clicked, the attachment is added to the drive. A "flag" is used to remember this decision.
- **Large attachment warning**: Attaching files > 2MB triggers a warning (can be disabled) and proposes instead to host the file in TDrive. If agreed, the file is uploaded into "My drive", shared as a public link, and referenced in the mail (structured header + HTML widget).
- **TDrive button in composer**: If clicked, a TDrive popup opens. The user selects a file (search, my drive, shared drive). TMail will generate a public link for that file. A structured email header provides nicer presentation, along with an HTML widget within the mail body.

## Decision

Add TDrive audience to all TMail access tokens.

TMail backend advertises TDrive presence via the application endpoint.

If the TDrive endpoint can be discovered, TMail will display TDrive actions (activate the TDrive module).

This is an example of a **frontend integration** as described in [ADR 001](./adr-001).

## Consequences

- Write a TDrive Dart client for the TMail frontend.
- We expect a reduction in email size for large attachments.
- **Security considerations**: Leaking TDrive public links means leaking data. They need to be hard to guess. There should be no API to list public links. DOS prevention: many 404 responses should trigger CrowdSec to ban the IP.
