# ADR 041: Applicative accounts for password-based protocols

Date: 25/04/2026
Updated: 30/06/2026
Status: `accepted`

## Context

Twake Workplace ships a mail app but does not expose IMAP in SaaS mode. This was deliberate:

- Reduce overall risk.
- Keep users on our own clients.
- Deny spammers the ability to reuse their existing IMAP tooling.

We now want to open IMAP to paying users without giving up that safety.

IMAP interoperability relies on PLAIN AUTH, which is fundamentally insecure: a client reusing the primary user password directly is exposed to brute force. On top of that, the primary password cannot be used for protocol binds at all. It is hashed on the client during signup, so the value stored on the user entry is a derivation the directory cannot verify on a simple bind (see [LDAP Password Policy](../overview/ldap-password-policy)). Mail, calendar, and contacts servers authenticate by binding with the password the client sends, so they have no way to check a user against that credential.

The answer is dedicated per-device credentials, generated server-side and hashed by the directory, that a simple bind can verify. The same gap applies to CalDAV and CardDAV, so the mechanism is shared across all password-based protocols, not IMAP alone.

## Decision

Expose IMAP (and SMTP, CalDAV, CardDAV) to paying users through **applicative accounts**: per-device credentials a user creates for external clients, each revocable on its own so that losing a device or removing an app never forces a primary password reset.

A page in Twake Mail settings lets the user list, create, and delete these credentials. The credential is shown only once, at creation time, and is generated server-side. Each carries a user-supplied description. The page consumes the `appAccountsApi` HMAC endpoints described below.

### LDAP structure

Applicative accounts live in a single flat branch, `ou=appAccounts`, alongside the user tree. They are not a projection of the user branch and there is no separate backup branch.

```
dc=twake,dc=app
|
+-- ou=users
+-- ou=b2b
+-- ou=appAccounts
    +-- uid=johndoe@example.com           # principal: one userPassword per device
    +-- uid=johndoe_c04729183             # one device
    +-- uid=johndoe_c09812345             # another device
```

Two kinds of entry exist, both `inetOrgPerson`:

| Entry     | DN form                      | Holds                                                 | Purpose                                                                        |
| --------- | ---------------------------- | ----------------------------------------------------- | ------------------------------------------------------------------------------ |
| Principal | `uid=<mail>`                 | one `userPassword` value per device                   | single bind point for the user; any device credential authenticates against it |
| Device    | `uid=<username>_c<8 digits>` | a single `userPassword` and an optional `description` | one revocable credential per device                                            |

```
uid=johndoe@example.com,ou=appAccounts,dc=twake,dc=app   # principal
  objectClass: inetOrgPerson
  uid: johndoe@example.com
  mail: johndoe@example.com
  cn: John Doe
  sn: Doe
  userPassword: {SSHA}...        # credential for device 1
  userPassword: {SSHA}...        # credential for device 2

uid=johndoe_c04729183,ou=appAccounts,dc=twake,dc=app     # one device
  objectClass: inetOrgPerson
  uid: johndoe_c04729183
  mail: johndoe@example.com
  description: Work laptop
  userPassword: {SSHA}...
```

Several passwords coexist on the principal entry because the `ppolicy` overlay rejects more than one `userPassword` per write operation but does not cap the total: each device credential is added in its own operation. This requires OpenLDAP 2.6 or later, where rapid successive writes with password history enabled no longer collide. See [LDAP Password Policy](../overview/ldap-password-policy) for the details and the version constraint.

Twake Mail and the CalDAV/CardDAV servers bind against `ou=appAccounts`, never against the user entry.

### Lifecycle

Two ldap-rest plugins own the branch:

- **`appAccountsConsistency`** reacts to user change hooks. It creates the principal `uid=<mail>` when a user's mail is set, renames it when the mail changes, and removes all of a user's applicative accounts when the user is deleted. The principal copies the user's attributes minus operational and end-to-end encryption key material, so `userPassword` and key attributes are never duplicated from the user entry.
- **`appAccountsApi`** exposes the HMAC endpoints that list, create, and delete device accounts. Creating one generates the `uid` and a one-time password, copies `cn`, `sn`, `givenName`, `mail`, and `displayName` from the user, returns the cleartext password once, and adds it to the principal entry.

### API

The settings page drives three HMAC-authenticated endpoints. The branch base DN is configurable (`DM_APPLICATIVE_ACCOUNT_BASE`), and the number of device accounts per user is capped (`DM_MAX_APP_ACCOUNTS`, default 5).

| Method   | Path                                    | Effect                                                                                 |
| -------- | --------------------------------------- | -------------------------------------------------------------------------------------- |
| `GET`    | `/api/v1/users/:user/app-accounts`      | List device accounts (the principal entry is excluded)                                 |
| `POST`   | `/api/v1/users/:user/app-accounts`      | Create a device account; returns the cleartext `pwd` once, fails at the per-user limit |
| `DELETE` | `/api/v1/users/:user/app-accounts/:uid` | Delete a device account and drop its password from the principal entry (idempotent)    |

The full API and lifecycle live with the plugin in the ldap-rest repository (see References).

### Premium gating

Only paying users are meant to use IMAP. Rather than build a freeze/restore flow now, the gate lives at enrolment: the applicative-accounts enrolment form is shown to paying users only (today, B2B users, who are paying by default), so a non-paying user cannot create credentials in the first place.

A subscription downgrade does not revoke existing applicative accounts. The only case where a non-paying user keeps working IMAP access is having enrolled while paying and then downgrading, and we deliberately leave those credentials in place. Showing the form to paying users only covers over 95% of the gate at close to no cost, and we accept the downgrade carryover.

Downgrade-gating is deferred: there is no `imapAccountsBackups` branch and no freeze/restore flow, and how a lapsed subscription should disable credentials and how renewal should restore them (revoke versus suspend versus delete) is out of scope for this ADR.

## Consequences

Applicative accounts follow the directory's established per-device password pattern and reuse the standard `inetOrgPerson` schema rather than custom branches.

The single-branch model drops the projection and backup branches from the original proposal: no `imapUsers` mirror to recompute and no `imapAccountsBackups` to keep in sync. Consistency is handled by hooks in `appAccountsConsistency` instead of explicit per-event resequencing.

Authentication is more secure for the user: a compromised device credential is revoked in isolation and never exposes the primary password.

OpenLDAP 2.6 or later becomes a hard requirement because of the multi-value password writes.

User experience is slightly more complex. Credential creation must be explicit about how to configure a device and which password to use, since the password is shown only once.

Premium gating is enforced at enrolment: the form is shown to paying users only. The single path to IMAP for a non-paying user is a subscription downgrade, which deliberately does not revoke existing credentials. Tightening that downgrade path is deferred (see above).

## References

- [LDAP Structure](../overview/ldap-structure)
- [LDAP Password Policy](../overview/ldap-password-policy)
- [Applicative Accounts API and lifecycle](https://github.com/linagora/twake-workplace-private/tree/main/twake-ldap-rest/docs/api/app-accounts.md)
