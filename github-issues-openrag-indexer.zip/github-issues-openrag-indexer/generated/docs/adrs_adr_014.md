# ADR 014: Automation of the Regression Test Suite

## Context

We have a regression test suite that we run before deploying each Twake Workplace release. The test suite needs to run against different environments: dev, staging, production, SaaS, and CNB. Each test suite should be configurable with:

- User name and password
- Auth schema (for Drive it could be local login as well as Twake Mail)
- URLs (to applications)
- List of features to test (they differ per environment -- for example, "manage access" is disabled for Twake Drive SaaS)

The tests must run via GitHub CI inside the `twake-workplace-private` repository manually. The next step would be to automatically run them on release tags inside product repositories.

## Proposal

### Testing strategy: selectors

Use a dedicated class name to uniquely identify UI elements. Ideally, use the opportunity to improve accessibility -- though not in a language-specific way.

Fragile selectors like `.upload_drop_zone.h-full.overflow-hidden .flex.flex-row.items-center.border.cursor-pointer` must be avoided.

### Next steps

**Out of band concerns:**

- Special routes, for example:
  - Confirm 2FA as if the user had received the SMS
  - Retrieve any sent emails for a given user
- Credential-per-environment storage and sharing

**Push up abstractions (sync with QA):**

- Consider Cucumber-style BDD descriptors

**Output review system:**

A passing test is not enough. Screenshots and video recordings should be reviewed for each combination of:

- Browser
- Light/dark mode
- Language and timezone settings
- Viewport: mobile, tablet, desktop (and orientation)
