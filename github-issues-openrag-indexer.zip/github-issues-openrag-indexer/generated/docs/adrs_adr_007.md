# ADR 007: Common Documentation

## Status

- **Date**: 26/06/2024
- **Status**: Proposed

## Context

Twake Workplace is composed of a galaxy of applications, each managing their own documentation. Those include:

- Documentation for sysadmins to deploy our products
- Documentation for users presenting features of our products

As a united product, Twake Workplace needs to provide united documentation.

## Decision

Adopt a common technology for writing documentation: [Antora](https://antora.org/).

Adopt a common structured documentation for each product:

- **Motivation and product overview** as an introduction
- **Administration documentation**: how to deploy, configuration settings, operation documentation
- **User documentation**: present features
- **Integrator documentation**

We would write three modules per project: user documentation, admin documentation, and integrator documentation.

We would propose several documentation entry points fed from the above modules:

| Entry point                  | URL                             |
| ---------------------------- | ------------------------------- |
| Admin documentation          | `admin.doc.twake-workplace.app` |
| User documentation           | `user.doc.twake-workplace.app`  |
| Integrator documentation     | `dev.doc.twake-workplace.app`   |
| Unified documentation portal | `doc.twake-workplace.app`       |

The unified documentation portal links to the three specialized entry points above.

## Consequences

We could also propose one documentation page per product aggregating product documentation (all Twake Mail documentation, etc.).

Teams need to dedicate sprint time for Antora adoption and configuration completeness.

## References

- [Antora](https://antora.org/)
