# ADR 039: Cozy Stack Sharing via CouchDB Replication

Date: 08/04/2026
Status: `accepted`

## Context

Cozy is designed around data sovereignty: users own their data on their own instance. When users need to share documents or folders with each other, the platform must support collaboration without centralizing data on a third-party server.

## Decision

Sharing between Cozy instances uses **CouchDB replication** as the synchronization mechanism. When a user shares a folder or set of documents:

1. The stack creates a **sharing document** (`io.cozy.sharings`) that describes the shared resources, participants, and permissions (read-only or read-write).
2. The stack sets up **bidirectional CouchDB replication** between the two instances for the shared doctypes.
3. Changes made on either side are automatically propagated through CouchDB's replication protocol.

This means shared data is **duplicated on both instances**. Each participant has a full copy that they control.

An alternative model, **Shared Drives**, provides a centralized shared space without duplication for cases where data sovereignty is less important than storage efficiency.

## Consequences

- No central server is needed for sharing: two self-hosted Cozy instances can share directly
- Each participant retains a full copy of shared data, preserving the self-hosted philosophy
- Storage usage increases proportionally with the number of sharing participants
- Conflict resolution follows CouchDB's revision-based model (deterministic winner selection)
- Shared Drives offer a lighter alternative when full replication is not needed
- The sharing protocol requires both instances to be reachable by each other (network connectivity)
