# ADR 003: Common Settings V1

## Status

- **Date**: 24/06/2024
- **Status**: Proposed
- **Superseded by**: [ADR 015](./adr-015)

## Context

Twake Workplace is composed of a galaxy of applications, each managing their own settings. Ideally, each application is designed to be deployed as a standalone entity.

However, given the overlap in settings (time zone, theme settings, etc.), it is necessary to consider the following:

- A method to synchronize settings across applications
- A common place to visualize "common settings"

### Flows

Common settings are given by 2 flows:

- **During OIDC authentication**: the SSO will provide a "twake" scope which contains all common settings. When an app receives it, it must override all previous values with these ones.
- **The MQ events**: one by one, the event queue contains changes. Only events given after the OIDC flow should be used to update. _Possible implementation: read all events before consuming "twake" scope._

## Decision

- Establish a common registry for settings (JSON structure: name as string associated with a JSON object).
- Use a common event bus based on RabbitMQ to propagate setting changes.
- As part of the Twake Workplace signup page.

This is a **Backend synchronization** process described within [ADR 001 Principle of cross products integrations](./adr-001).

Applications need to obey [ADR 002 RabbitMQ best practices](./adr-002).

**Architecture overview**: The system uses a topic exchange where each application publishes setting change events. Each consuming application binds its own durable quorum queue to the exchange and processes updates independently, applying them to its internal settings model.

### Message format

Format of the messages to be sent:

```json
{
  "source": "twake-mail",
  "nickname": "btellier",
  "request_id": "uuid",
  "timestamp": 176248374356283752,
  "payload": {
    "language": "fr",
    "timezone": "GMT+2",
    "last_name": "Tellier"
  }
}
```

| Field        | Required | Description                                       |
| ------------ | -------- | ------------------------------------------------- |
| `source`     | Yes      | Identifier of the application emitting the change |
| `nickname`   | Yes      | Username of the user whose settings changed       |
| `request_id` | Yes      | UUID for tracing the request                      |
| `timestamp`  | Yes      | UNIX timestamp of the change                      |
| `payload`    | Yes      | JSON object containing the changed settings       |

The payload fields (`language`, `timezone`, `last_name`, etc.) are all optional -- only changed settings need to be included.

## Consequences

Each application can still manage its settings independently but stays in sync through the bus. See [ADR 015](./adr-015) for the updated version of this approach.
