# ADR 005: Common Search

## Status

- **Date**: 24/06/2024
- **Status**: Proposed

## Context

Twake Workplace is composed of a galaxy of applications, each managing their own search. Ideally, each application is meant to potentially be deployed standalone and needs to work in an independent fashion. But we wish as a company to offer an integrated, cross-product search experience.

## Decision

Each application will implement its own search on top of an OpenSearch index.

Each application will document its mapping structure (JSON format).

We will build a common search application aggregating search results. We will integrate the common search onto the signin-signup page.

**Architecture overview**: Each application maintains its own OpenSearch index with a documented, static mapping. The common search application queries each application's index and aggregates the results for display. Each application is responsible for documenting how to construct a deep link from a search result back to the actual resource.

## Consequences

We need to document mapping fields used by the common search in order to provide stability for it.

All applications need to adopt static mappings (avoid dynamic mappings).

All applications need to document how to build from a search result a link to the actual resource.

## Alternatives considered

### The OpenPaaS way

OpenPaaS had all components serving directly the aggregated search in all applications, which was invasive and did lead to unmaintainable features. We do not wish to repeat OpenPaaS pitfalls.

### The micro-service approach

The current architecture relies on cross-DB access. Simple to implement and cheaper in terms of storage, yet it creates coupling.

Another harder to implement, more expensive to operate but more robust implementation would be to actually have a separated mapping for common search that would project all search data of all applications and operate autonomously on that projection, that it would maintain behind an asynchronous bus.

## References

- [Common search implementation](https://github.com/linagora/ToM-server/pull/12/files)
