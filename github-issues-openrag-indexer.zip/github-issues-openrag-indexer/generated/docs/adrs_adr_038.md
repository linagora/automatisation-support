# ADR 038: Cozy Stack Per-Instance Data Isolation

Date: 08/04/2026
Status: `accepted`

## Context

Cozy Stack is a multi-tenant platform where a single process manages many user instances. User data must be strictly isolated: no user should ever be able to access another user's documents, files, or settings, even if the stack process is shared.

## Decision

Each Cozy instance gets **fully isolated storage**:

- **CouchDB databases** are prefixed with a hash of the instance domain. Each doctype (e.g., `io.cozy.files`, `io.cozy.contacts`) gets its own database per instance (e.g., `<prefix>/io-cozy-files`).
- **File storage** uses a separate directory (local filesystem) or container (OpenStack Swift) per instance.
- **Session secrets** are unique per instance, so tokens from one instance cannot be used on another.
- **Disk quotas** are enforced per instance.

The stack resolves the target instance from the `Host` header on every request. All database and file operations are scoped to that instance. There is no shared data namespace between instances.

## Consequences

- Data isolation is enforced at the storage level, not just the application level
- CouchDB must handle many small databases rather than a few large ones (requires CouchDB clustering for scale)
- Instance creation and deletion involves creating/dropping a full set of databases and storage directories
- Horizontal scaling is straightforward: the stack is stateless, so multiple nodes can serve the same set of instances if they share CouchDB and file storage
