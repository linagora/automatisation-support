# ADR 011: N8N Integration

## Status

- Date: 28/06/2024
- Status: Proposed

## Context

N8N is a powerful workflow engine integrated with numerous digital solutions. A common need from potential customers is to easily integrate Twake Workplace components as part of complex workflows involving numerous third-party applications. We need to demonstrate the possibility of integrating the Twake Workplace into such workflows.

## Decision

Provide integrations for the Twake Workplace into N8N. Those will include:

- Authentication for Twake Workplace
- TDrive primitives
- JMAP primitives

Leverage "open standards" existing integrations:

- Matrix N8N integration
- IMAP / SMTP integration

Provide examples demonstrating end-to-end workflows.

## Consequences

- Possibility to sell technical assistance and expertise around N8N integrations for the Twake Workplace.
- Unlock advanced use cases that could also be interesting for new customers.
