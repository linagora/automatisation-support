# ADR 023: Get Platform URL

## Status

- Date: 11/03/2025
- Status: Writing

## Context

We currently don't know exactly how to build links to "Common Settings" or "Paywall" URLs.

We are relying on very fragile foundations, such as `https://$username.twake.app` or other overly static setups. This causes two issues:

1. The username is not necessarily equal to the API address, especially if the username contains a `.`. So the link is broken for this kind of user.
2. The `twake.app` part needs to be much more dynamic; otherwise, with the upcoming B2B SaaS, we will be stuck.

## Solution

Since, at TWP creation time, **Signup** stores the workplace URL in LDAP, we will make sure the **SSO claims** expose this field. That way, frontend applications, when calling the `user_info` endpoint, will be able to retrieve this **workplaceFqdn**.

**New claim exposed by LemonLDAP:** `workplaceFqdn`

From there:

- If the frontend needs to call the API (for example, to link to the Premium service), it can simply use this `workplaceFqdn` as-is (prepending `https://`).
- If it needs to generate a link to the Settings app, then it must build it from `workplaceFqdn`. For example, if `workplaceFqdn` = `quentin.twake.app`, the generated link should be `https://quentin-settings.twake.app` (because `settings` is the slug of the application -- in a few weeks, we will create links to drive or other apps this way).

You can take inspiration from [cozy-client's urlHelper](https://github.com/cozy/cozy-client/blob/b92c3cdbd84d99e9289104918df55d9fd2fa0c14/packages/cozy-client/src/helpers/urlHelper.spec.js#L20-L32) (only use the **flat** case, not the **nested** one -- we don't use that anymore at Twake).

If the field is not available, then continue with the current implementation.

Note that we will need this in both **Mail** and **Chat**, so it would be a good idea to **mutualize** this work.

These changes have been made on TWP Prod, TWP stg, and TWP dev.

## Limitation of the solution

This solution will not work at the moment for "external SSO". By external SSO, we mean for instance LNG. But in the future, we will have another LemonLDAP in front of the LemonLDAP for LNG to merge data from the "platform" and from the external LDAP.

## Archive: current implementation

A few things have been done, but they will not work once our B2B custom domains are there.

We need to distinguish two things:

- "API" call to the "platform backend"
- URL for a specific app on the platform

We cannot build something from the username since the platform can do work to clean this username or otherwise transform it.

So the idea is to expose this `workplaceFQDN` from the `/user_info` SSO response. Once we have this FQDN, front-end applications need to "build" a URL to an application if needed, by adding for instance `-settings`.

We need to change the behavior from Mail and Chat. We also need to work on Signup/Lemon to merge information between external SSO and "users data".
