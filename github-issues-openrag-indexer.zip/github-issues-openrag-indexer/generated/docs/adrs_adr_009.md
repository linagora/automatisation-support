# ADR 009: Security for the Public Platform

## Status

- Date: 26/06/2024
- Status: Proposed

## Context

Exposing a public platform exposes us to additional risks.

A full risk analysis was conducted as part of the June 2024 software barcamp.

## Decision

Apply the following security measures in two stages:

### Stage 1: Closed Beta

- Anti-spam and antivirus on incoming mail traffic.
- Firewall rules.
- Dedicated network.
- Security groups.
- Do not expose IMAP/SMTP submissions.
- Backups with basic monitoring and alerting.
- Log retention: 15 months for mail, 1 month for technical logs.
- Architecture documentation.
- Restricted and minimal database rights for applications.

### Stage 2: Open Beta

- Captcha on signup.
- Propose 2FA options in LemonLDAP.
- Anti-spam and antivirus on outgoing mail traffic.
- Security audit.
- Bastion access over VPN.

## Consequences

- Configuration and deployment of the public platform needs to be adapted accordingly.
- A dedicated security lead will own security-related topics.
- The IT team will conduct an internal security audit.
