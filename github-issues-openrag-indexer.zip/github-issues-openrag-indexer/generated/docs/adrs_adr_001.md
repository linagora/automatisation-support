# ADR 001: Cross Products Integrations

## Status

- **Date**: 24/06/2024
- **Status**: Proposed

## Context

Twake Workplace is composed of a galaxy of applications, each managing their own settings. Ideally, each application is meant to potentially be deployed standalone and needs to work in an independent fashion.

The previous platform, OpenPaaS, succeeded in delivering cross-feature integration but failed because it was too coupled -- it relied on having all features within the same frontend acting on top of the same monolith.

Yet as part of the Twake Workplace we need to deliver numerous cross-platform integrations. Non-exclusive list of cross-product features:

- Common setting page
- Common search
- Common groups
- Calendars into mails
- Working on mail attachments with Twake Drive
- Discuss a mail on Twake Chat

## Proposal

Create a Twake channel dedicated to Twake Workplace topics.

Each cross-product integration needs to be described as part of an architecture decision record, written in Notion, and advertised on the channel.

Each ADR would need to minimize cross-product coupling and isolate it from the core code of the product.

We need to identify and document generic integration schemes between products. Those include:

- **Frontend integration**: Application frontend A calls application B
- **Backend synchronization**: Use RabbitMQ bus to propagate and synchronize duplicated data

### Frontend integration

It relies on an extended OIDC audience so that application A can silently reuse its tokens to call application B (except Twake Chat due to Matrix constraints, which would need other workarounds like exchange of tokens).

Team of application B needs to hand over documentation of the API calls needed by team of application A to perform its tasks and support them throughout the process. APIs used cross-application would need to be versioned.

Team of application A needs to expose through a configurable endpoint the location of application B to its frontend.

Team of application A needs to implement this frontend integration in a module that is not core product and needs to work without product B.

A good candidate for such integration is Twake Mail / Twake Drive integration.

### Backend synchronization

A good example is the common settings: see [ADR 003 Common Settings](./adr-003).

Each application manages its subset of the data which is duplicated in each application, with possible overlap.

Data is initialized upon each connection to the application based on OIDC "twake" scope content.

We define a registry of the exchanged data.

Each application sends a RabbitMQ message notifying other applications of the update and each application updates its internal model based on this message.

Each application needs to respect RabbitMQ best practices defined in [ADR 002](./adr-002).

## Consequences

This vocabulary can be reused in subsequent ADRs where relevant and would guide the teams toward implementing robust integrations that minimize cross-application coupling.
