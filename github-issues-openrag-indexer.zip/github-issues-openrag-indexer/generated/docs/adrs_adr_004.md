# ADR 004: Cross Application Groups

## Status

- **Date**: 24/06/2024
- **Status**: Proposed

## Context

Twake Workplace is composed of a galaxy of applications. Each of them would benefit from automatically managing groups that we call "teams". Yet the management of these groups is mostly not unified and relevant features are mostly unused:

- **Twake Chat** defined a group management mechanism based on LDAP attributes, creating a group chat based on LDAP settings.
- **Twake Mail** implemented Team mailboxes but requires as of today extensive manual webadmin calls.
- **Twake Drive** does not propose any "group folders" and this would need to be implemented.

## Decision

As part of the Twake Workplace, use LDAP groups to pilot group ownership. All applications will synchronize their internal groups with LDAP groups.

Implement a dedicated administration page for each domain administrator to define groups, using LinID.

Groups might then be defined within LinID or inferred and populated by LinID based on more complex LDAP filters (one LDAP filter for each group).

**Architecture overview**: LinID serves as the central group administration interface. Domain administrators define groups either directly or through LDAP filters. Each application synchronizes its internal group representation with the LDAP directory, using tools like LSC (LDAP Synchronization Connector) to keep their local state consistent.

## Consequences

Each application would need to synchronize LDAP with its internal group system, for instance through the use of LSC. LinID becomes the central administration point for group management.
