# ADR 021: B2B RabbitMQ Communications

## Status

- Date: 16/09/2025
- Status: Writing

## Context

We need real-time communication between all Twake apps and platforms (e.g., TMail, Signup, Cloudery, Stack) during the signup phase and premium plan changes for domains (see [ADR 019](./adr-019) for more details) and it seems appropriate to use Twake's RabbitMQ to do so.

## Decision

The Signup/admin panel will notify other apps when a domain is successfully registered. It will also notify other apps when a domain's plan is modified (same payload as the latest payload).

Note that the domain is immutable.

## RabbitMQ messages

### Organization created

- **Exchange:** `b2b`
- **Routing key:** `organization.created`

```json
{
  "organization": "evil corp",
  "organizationId": "evilcorp123",
  "domain": "organization.com"
}
```

### Organization deleted

- **Exchange:** `b2b`
- **Routing key:** `domain.organization.deleted`

```json
{
  "emitter": "admin-panel",
  "type": "organization.deleted",
  "organizationId": "<orgId>",
  "domain": "<org domain>",
  "reason": "organization deleted"
}
```

### Organization user deleted

- **Exchange:** `b2b`
- **Routing key:** `domain.user.deleted`

```json
{
  "emitter": "admin-panel",
  "type": "organization.deleted",
  "organizationId": "<orgId>",
  "domain": "<org domain>",
  "reason": "organization deleted"
}
```

### DomainSubscriptionChanged

- **Exchange:** `billing`
- **Routing key:** `domain.subscription.changed`

Management of the SaaS domain subscription (defines limits on the scope of a domain).

```json
{
  "domain": "linagora.com",
  "isPaying": true,
  "canUpgrade": true,
  "features": {
    "mail": {
      "storageQuota": 12334534,
      "mailsSentPerMinute": 100,
      "mailsSentPerHour": 1000,
      "mailsSentPerDay": 2000,
      "mailsReceivedPerMinute": -1,
      "mailsReceivedPerHour": -1,
      "mailsReceivedPerDay": -1
    }
  }
}
```

| Field             | Type    | Description                                      |
| ----------------- | ------- | ------------------------------------------------ |
| `domain`          | string  | The organization domain                          |
| `isPaying`        | boolean | Compulsory                                       |
| `canUpgrade`      | boolean | Compulsory                                       |
| `features`        | object  | Compulsory, per-app feature limits               |
| `features.mail`   | object  | Optional, mail-specific limits                   |
| Rate limit fields | integer | `-1` means unlimited, positive integer otherwise |

If defined, user limits defined in [ADR 019](./adr-019) take precedence and override domain limits. The admin panel would take charge of billing for those exceptions, if applicable.

### DomainDnsConfigurationStatus

- **Exchange:** `configuration`
- **Routing key:** `domain.dns.configuration.status`

Once the mail domain validation is done, the SaaS console will push the information to the mail server/chat server.

```json
{
  "domain": "linagora.com",
  "organizationId": "orgid123",
  "dnsOwnershipValidated": true,
  "mailDnsConfigurationValidated": true,
  "chatDnsConfigurationValidated": true
}
```

| Field                           | Type    | Description                                                                                              |
| ------------------------------- | ------- | -------------------------------------------------------------------------------------------------------- |
| `domain`                        | string  | The organization domain                                                                                  |
| `organizationId`                | string  | The organization identifier                                                                              |
| `dnsOwnershipValidated`         | boolean | Compulsory. TXT challenge done                                                                           |
| `mailDnsConfigurationValidated` | boolean | Compulsory. Correct SPF, DKIM, DMARC value as well as a custom TXT record check proving domain ownership |
| `chatDnsConfigurationValidated` | boolean | Correct CNAME for all 3 chat subdomains: `chat.example.com`, `tom.example.com`, `matrix.example.com`     |

**Activation rules:**

- For all TWP apps, `dnsOwnershipValidated` is enough to activate the service.
- Mail expects both `dnsOwnershipValidated` and `mailDnsConfigurationValidated` to be `true`.
