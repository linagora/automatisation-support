# ADR 013: OIDC Token Exchange

## Goal

The goal is to be able to query another TWP backend from an app (e.g., query TDrive from TMail).

## Possible Solutions

The [yadd/lemonldap-ng-\*](https://github.com/guimard/llng-docker/) images have 3 mechanisms available for such issues:

- Extend OIDC "audience" in LemonLDAP-NG configuration to always include the other service.
- Obtain an `access_token` for the second app using the "internal token exchange" (see [MR](https://gitlab.ow2.org/lemonldap-ng/lemonldap-ng/-/merge_requests/501/diffs) until [doc](https://lemonldap-ng.org/documentation/latest/oidctokenexchange) is released).
- Obtain an `access_token` using a Matrix `access_token` (see below).

## Decisions

Here is the system to be used for each connection:

| from/to               | **Twake-Mail back (Apisix)** | **Twake-Chat back (Synapse / ToM)** | **Twake-Drive**       |
| --------------------- | ---------------------------- | ----------------------------------- | --------------------- |
| **Twake-Mail front**  | -                            |                                     | Extended audience     |
| **Twake-Chat front**  |                              | -                                   | Matrix token exchange |
| **Twake-Drive front** |                              |                                     | -                     |
