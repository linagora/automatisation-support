# ADR 035: Back-Channel Logout

## Status

Date: 19/02/2026
Status: Proposed

## Context

Twake Workplace consists of multiple applications, each managing its own session system. All are connected via OpenID Connect.

## Proposal

All applications MUST implement [Back-Channel-Logout](https://openid.net/specs/openid-connect-backchannel-1_0.html) (with `sid` required). This ensures users who disconnect are truly logged out everywhere.

## Exceptions

- **Offline sessions (like mobile applications):** Users who want to disconnect use the app's "logout" button.
- **Matrix: Temporary exception** due to Matrix's particular behavior:
  - The current Matrix BCL implementation is "destroy this device" (i.e., remove keys).
  - A user with no device (for example, when disconnecting their session in a single browser) will continue to receive messages, but encrypted only with the sender's key.
  - Even if recovery keys are stored on the server, messages received during this period cannot be deciphered using them.
  - An MR exists to fix this behavior, not yet accepted.
