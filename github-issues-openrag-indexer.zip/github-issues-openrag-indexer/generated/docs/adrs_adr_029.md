# ADR 029: Convert Folder to Shared Drive

## Status

Proposed

## Context

Cozy-Stack currently supports two types of collaborative file sharing:

- Files are replicated between Cozy instances. Each member has a local copy that syncs bidirectionally.
- Files are stored only on the owner's instance. Members access files via HTTP proxy (no local copies).

Currently, shared drives can only be **created fresh** via the `/sharings/drives` API. There is no way to convert an existing folder (with files) into a shared drive and migrate existing synchronized sharing members to shared drive mode.

## Proposal

The feature is split into separate APIs:

### Create a drive from an unshared folder

`POST /sharings/drives`

```json
{
  "data": {
    "type": "io.cozy.sharings",
    "attributes": {
      "description": "Project Documents",
      "folder_id": "directory-id"
    },
    "relationships": {
      "recipients": {
        "data": [{ "type": "io.cozy.contacts", "id": "alice.example.com" }]
      },
      "read_only_recipients": {
        "data": [{ "type": "io.cozy.contacts", "id": "bob.example.com" }]
      }
    }
  }
}
```

### Batch migration

Background job worker:

```bash
cozy-stack jobs run sharing-migration \
  --domain cozy.example.com \
  --json '{"action": "convert-to-drives", "dry_run": true}'
```

### Manual conversion from "sync" to "shared" mode

`POST /sharings/:id/convert-to-drive`

```json
{
  "data": {
    "type": "io.cozy.sharings.conversion",
    "attributes": {
      "notify_members": true
    }
  }
}
```

First, remove the existing sync triggers by deleting the track replicate, and upload (share-upload worker) triggers, and by clearing the Triggers struct in the sharing document. Next, enable Drive Realtime by generating a DriveToken for each member's credential, allowing members to connect to `/sharings/drives/:id/realtime`, and exposing the changes feed at `/sharings/drives/:id/_changes`. Then, notify recipients by sending a real-time "sharing mode changed" event, having recipient apps reconnect using the drive endpoints, and optionally sending an email explaining the change. Finally, on the recipient side, stop polling via share-replicate, switch to a WebSocket subscription, and note that locally synced files will remain available but will no longer receive updates.

### Info

User removes all members from a shared drive -- it should automatically become a regular folder. At this moment, we remove the `io.cozy.sharings` document entirely.

No changes to DirDoc; we rely solely on `Sharing.Drive` flag. The existing `ReferencedBy` relationship links folders to sharings.

## Alternatives

### One endpoint handles all cases (unshared folder, existing sharing)

| Pros                | Cons                     |
| ------------------- | ------------------------ |
| Simpler API surface | Complex request handling |
