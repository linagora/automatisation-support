# ADR 019: B2C Premium Plans Communications

## Status

- Date: 29/08/2025
- Status: Writing

## Context

We want to add "Plans" to TwakeAI for our B2C customers. The platform already handles the purchase, but this ADR is about how the platform communicates the plan to other apps.

We already have some kind of communication between the platform and the apps (for [ADR 020](./adr-020) for instance) where we use RabbitMQ to send messages. We will use the same kind of mechanism.

At the time of writing, the "Cloudery" does not use the RabbitMQ mechanism and the Cloudery is not within the same (OVH) network as the rest of the applications.

### Reflection

A "plan" is an offer. A plan gives access to some features and storage limits. We will have several plans and we should be able to modify plans in the future or even create a new one.

When a user chooses a "plan" on the Cloudery, the Cloudery will send a message with the dedicated content of the plan. The idea is that only the Cloudery defines what is in the plan, so we only have one source of truth to handle plans.

The structure of the message will be:

- At the root, a few generic fields.
- One entry per application.

**Breaking change rules:**

- If the Cloudery decides to remove or rename attributes at the root, it should be considered a breaking change and we should communicate with all the concerned teams.
- If the Cloudery decides to remove or rename attributes at the application layer, then it should only be considered a breaking change for the concerned application.
- The Cloudery can change at any time the value of the attributes. This is the source of truth; the application should apply them without question.
- The Cloudery can add attributes at every level. If the Cloudery adds an attribute at the root level, it means all applications should be concerned (for example `hasAccessToAI`). If it adds an attribute at the app level, it is only for that app.

## Decision

Let's say a user buys a "middle" plan and we only have mail dealing with Premium, then the message will be:

```json
{
  "twakeId": "btellier",
  "internalEmail": "btellier@twake.app",
  "isPaying": true,
  "canUpgrade": true,
  "features": {
    "mail": {
      "storageQuota": 12334534,
      "mailsSentPerMinute": 100,
      "mailsSentPerHour": 1000,
      "mailsSentPerDay": 2000,
      "mailsReceivedPerMinute": -1,
      "mailsReceivedPerHour": -1,
      "mailsReceivedPerDay": -1
    }
  }
}
```

**Field descriptions:**

- `isPaying` (boolean) -- Whether the user pays something or not. Used to suppress banners like "You're on a free plan".
- `canUpgrade` (boolean) -- Whether the user can take a more expensive plan with more features. Used to display "See more plans" for instance.
- `internalEmail` -- The email of the user.

**Plan change behavior:**

- If a user makes a change to their plan, the Cloudery will send the full message again.
- If the company decides to make a change to a plan, the Cloudery will send the full message for each user impacted by the plan (can be a lot).

See [ADR 020](./adr-020) for more details on the RabbitMQ message format.

## How to make the Cloudery communicate with RabbitMQ

Twake's RabbitMQ node will be exposed to Cozy IPs including the stack and the Cloudery. The Cloudery can then implement a RabbitMQ client targeting Twake's node and publish messages with the appropriate payload to the appropriate exchanges and queues.

See [ADR 020](./adr-020) for more details.

## How to access the premium manager page from clients

Clients such as Twake Mail can display links to the `/settings/premium` path of the user's Twake Workplace instance.

For example, if a workplace exists at `https://alice.twake.app` then a link to `https://alice.twake.app/settings/premium` will redirect the user to its Cloudery's premium management page. If the instance does not have any manager setup then the route will return an error page with a `404` status code instead.

Since this is the first time a "standalone app" has to get access to the workplace URL, we need to find a way to get this URL.

**Constraints:**

- We cannot use DOM injection, because it will only work for the web version, not the mobile one.
- We cannot have a static URL, because each user has a dedicated URL.

**Solution:** Write the workplace URL into the JWT Token (not just the `sub`, but the whole URL -- we cannot just put the `sub` because sometimes the platform will have to do some work on it).
