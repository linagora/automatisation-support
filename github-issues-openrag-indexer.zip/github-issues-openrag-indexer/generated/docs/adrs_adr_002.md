# ADR 002: RabbitMQ Best Practices

## Status

- **Date**: 24/06/2024
- **Status**: Proposed

## Context

RabbitMQ is to be used by all applications of the Twake Workplace as part of the **Backend synchronization** process described within [ADR 001 Principle of cross products integrations](./adr-001).

Some of them rely on it for critical features. We thus need to define rules that would guide teams toward implementing reliable messaging.

## Decision

- Message producers create the exchanges.
- Queue consumers create the queues and bind them to the relevant exchanges.
- Queue consumers need to eventually acknowledge the messages, non-acknowledge with requeue (to retry), or non-acknowledge without requeue (discard).
- Message producers need to mark messages as durable. Queue consumers need to declare durable queues.
- Use quorum queues with 3 replicas.
- Set up dead lettering. Dead letter queues need to be monitored and messages falling in them need to be investigated as this is either a software bug or infrastructure incident.
- We recommend also monitoring the count of active consumers on critical queues and alerting in case of either no consumers or a growing number of messages.
- We recommend exchanging messages in a readable JSON format.

### Queue Naming Convention

```
<exchange>.<message_type>.<consumer_identifier>

Examples:
- user.settings.updates.domainA
- user.settings.updates.domainB
```

### Exchange Configuration

```yaml
name: user.settings
type: topic
durable: true
auto_delete: false
internal: false
```

### Queue Configuration (ADR-Compliant)

```yaml
durable: true # Required
exclusive: false
auto_delete: false
arguments:
  x-queue-type: quorum # Required: Use quorum queues
  x-quorum-initial-group-size: 3 # Required: 3 replicas
  x-message-ttl: 86400000 # Optional: 24h message expiry
  x-dead-letter-exchange: user.settings.dlx # Required: DLX
  x-dead-letter-routing-key: <domain>
```

### Consumer Configuration (ADR-Compliant)

```yaml
prefetch: 10 # Process 10 messages at a time
no_ack: false # Required: Manual ACK only
exclusive: false # Allow multiple consumers per queue
```

## Consequences

Hopefully better developer guidance would help faster developments and allow having homogeneous usage of RabbitMQ.

## References

- [Quorum Queues](https://www.rabbitmq.com/docs/quorum-queues)
- [Poison Message Handling](https://www.rabbitmq.com/docs/quorum-queues#poison-message-handling)
- [Dead Letter Exchanges](https://www.rabbitmq.com/docs/dlx)
- [Durability](https://www.rabbitmq.com/docs/queues#durability) and [Storage](https://www.rabbitmq.com/docs/queues#storage)
