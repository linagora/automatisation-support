# ADR 026: B2B Organization Domain Validation

## Status

Writing (25/11/2025)

## Context

We want to offer B2B customers the ability to use their own domain to access their Twake Workplace, send/receive e-mails (i.e. have `user@myorg.com` addresses instead of `user.myorg@twake.app`) and have a dedicated Matrix ID: `@user:myorg.com`.

For that we need to make sure that:

- The customer owns the domain
- The domain's DNS records are properly set to direct emails to our servers
- The domain's DNS records are properly set to send emails for this domain from our servers with security (i.e. don't end up in spam folders and ruin our servers' reputation)
- The domain's DNS records are properly set for Matrix

This will be done in 3 steps:

1. Validate that the customer owns the domain when adding it to its organization in the Admin Panel (and prevent the use of the organization until the validation is successful)
2. Validate the email related DNS records before allowing the customer to send emails from TMail
3. Validate the matrix DNS records before allowing the customer to run/have a chat instance deployed

### DNS records validation

Checks for the presence and expected value of DNS records for a given domain can be performed using a DNS resolver to list DNS records and compare, if present, the value of the given type (e.g. CNAME or MX) against the expected value.

For example, using NodeJS' API: [DNS | Node.js Documentation](https://nodejs.org/docs/latest/api/dns.html#dnsresolveanyhostname-callback)

This should probably be performed asynchronously in a background job as DNS propagation can take a while.

## Data model

### CNAME

Validate ownership of the domain by looking for the presence of a CNAME record with a given value. This also allows redirecting from the custom subdomain to the organization's Twake.

- `cname_label` : string
- `cname_content` : string
- `cname_validated_at` : DateString

### Mail records

These are necessary for receiving and sending emails with the user's own domain.

- `primary_mx_content` : string
- `primary_mx_validated_at` : DateString
- `secondary_mx_content` : string
- `secondary_mx_validated_at` : DateString
- `spf_content` : string
- `spf_validated_at` : DateString
- `dkim_label` : string
- `dkim_content` : string
- `dkim_validated_at` : DateString
- `dmarc_label` : string
- `dmarc_content` : string
- `dmarc_validated_at` : DateString

### Matrix organization

Each customer must be able to reach the chat UI and the Matrix federation endpoints via a custom sub-domain of their own domain, e.g.:

- `matrix.<custom-domain-name>`
- `tom.<customer-domain-name>`
- `chat.<customer-domain-name>`
- `admin.<customer-domain-name>` (optional)

The only requirement for these sub-domains is HTTP(S) traffic; no email (MX/SPF/DKIM/DMARC) is sent from them.

| SUB-DOMAIN                      | DNS RECORD TYPE       | RECORD LABEL | RECORD TARGET         |
| ------------------------------- | --------------------- | ------------ | --------------------- |
| `matrix.<customer-domain-name>` | **CNAME** (preferred) | `matrix`     | `lb-b2b.linagora.com` |
| `tom.<customer-domain-name>`    | **CNAME** (preferred) | `tom`        | `lb-b2b.linagora.com` |
| `chat.<customer-domain-name>`   | **CNAME** (preferred) | `chat`       | `lb-b2b.linagora.com` |

## Validation

- Separate background jobs for CNAME and Mail records as they can be setup at different times
  - When do we start the job? When the user clicks a button?
  - How many retries?
  - We need a way to check the status of the job to update the UI
  - Send a notification email once the check is complete (only if successful?)
- Schedule a daily background job to make sure the configuration stays correct over time?

## Security considerations

For chat B2B, `lb-b2b.linagora.com` should match the user domain to internal cluster services, and we should never let the backends resolve the user domain (i.e. TOM).
