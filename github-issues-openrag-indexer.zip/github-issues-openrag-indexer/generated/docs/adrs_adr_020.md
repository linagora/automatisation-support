# ADR 020: Communication Between Apps Using RabbitMQ

## Status

- Date: 04/09/2025
- Status: Validated

## Context

We need real-time communication between all Twake apps and platforms (e.g. TMail, Signup, Cloudery, Stack) during the signup phase and premium plan changes (see [ADR 019](./adr-019) for more details) and it seems appropriate to use Twake's RabbitMQ to do so.

## Infrastructure requirements

Since our RabbitMQ server and Cloudery and Stack live in different networks, they cannot communicate together for now. This is why it has been decided to whitelist Cozy's servers to give them access to RabbitMQ.

## RabbitMQ messages

We want to avoid having a giant exchange where all messages are published and every app is subscribed to for different reasons (security, separation of concerns, metrics, etc.). We propose creating two new exchanges for the new signup and premium messages.

### Signup

We will create a new `auth` topic exchange for everything related to user authentication changes with the following topics:

#### `user.password.updated`

Emitted by Signup when the user changes their password.

**Message payload:**

```json
{
  "twakeId": "string",
  "iterations": "number",
  "hash": "string",
  "publicKey": "string",
  "privateKey": "string",
  "key": "string",
  "domain": "string",
  "timestamp": "number",
  "workplaceFqdn": "string"
}
```

| Field           | Description                                           |
| --------------- | ----------------------------------------------------- |
| `twakeId`       | The user identifier                                   |
| `iterations`    | The PBKDF2 iterations used in hashing                 |
| `hash`          | The Scrypt hash (in base64)                           |
| `publicKey`     | The public key (base64)                               |
| `privateKey`    | [ENCRYPTED] the private key                           |
| `key`           | [ENCRYPTED] the AES-CBC encryption key (cipherString) |
| `domain`        | The domain used to signup (usually `twake.app`)       |
| `timestamp`     | When this message was sent                            |
| `workplaceFqdn` | The user workplace FQDN                               |

**Example:**

```json
{
  "twakeId": "kferjani14",
  "hash": "c2NyeXB0JDMyNzY4JDgkMSQ5NTQ3ZjZjYmMwODc2N2MyNTg1NWI3ZGNlNzkwMDIyZCRiMzIxOTY0NWE0YjVkNjlmZTY4ZTc3YjM4NDY2MjM1YWQzMDU0NWUxMmFlNzVmN2NmNTA2ZjdlODdkYTJmYmM1",
  "iterations": 650000,
  "key": "0.Wd1hvBnkcm+NqSyg+nFzTQ==:ah10C2XHnS5cxYLSf0OLGWpeiXMMzWKiKvm8MVqfMaxcUUW7imJ/JK18HFHGcIj9aPDdIrIgFPz7GJ3PTa80ozoVUyLX0q7JvhpkSta51GQ=",
  "publicKey": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAweLPcDOiSNxc9glzrAga6Ih7A7HCnP8JqotFuUIm+u83c9r1jkZDAfZvGmTqmHxLCZFUVN/mQpfD0oU85C4Z5pSRMth283XJeC1jTFOB6nst1fYyyQYxnzIzyQRsvG0TIYWYkEfrTL2CtA+7BbxdyZvfHL81h5aYRhha4yvrqczzZLh+1gz5mliKn5LwZqCYtF+7+ZZpHrUs9yhfVSEzTwZV9Z+ln12NPtA96IDva2AoaGNEbNbfN0uEmO1Kl62DjmvRwI2ifSXjE9TPYwuYDBJXGiGGG2Quix7ZrG5rfwmvVuy4JTytR6m6mGv9emW6odLm6vVhra72usTLrxbSHQIDAQAB",
  "privateKey": "2.O5dwhcHZpln9VYrw+PJ5lw==|v4yq4F9OY/OWV2fzYWGmS/...",
  "timestamp": 1757002525828,
  "workplaceFqdn": "kferjani14.stg.lin-saas.com"
}
```

#### `user.created`

Emitted by Signup when the user has been created.

**Message payload:**

```json
{
  "twakeId": "string",
  "mobile": "string",
  "internalEmail": "string",
  "domain": "string",
  "iterations": "number",
  "hash": "string",
  "publicKey": "string",
  "privateKey": "string",
  "key": "string",
  "timestamp": "number",
  "organizationId": "string",
  "organizationDomain": "string"
}
```

| Field                | Description                                           |
| -------------------- | ----------------------------------------------------- |
| `twakeId`            | The user identifier                                   |
| `mobile`             | The user phone number used to signup                  |
| `internalEmail`      | The user Twake email                                  |
| `domain`             | The domain where the user is registered               |
| `iterations`         | The PBKDF2 iterations used in hashing                 |
| `hash`               | The Scrypt hash (in base64)                           |
| `publicKey`          | The public key (base64)                               |
| `privateKey`         | [ENCRYPTED] the private key                           |
| `key`                | [ENCRYPTED] the AES-CBC encryption key (cipherString) |
| `timestamp`          | When this message was sent                            |
| `organizationId`     | OPTIONAL: only for B2B                                |
| `organizationDomain` | OPTIONAL: only for B2B                                |

**Example:**

```json
{
  "twakeId": "kferjani14",
  "internalEmail": "kferjani14@twake.app",
  "mobile": "+33700000017",
  "domain": "twake.app",
  "iterations": 650000,
  "hash": "c2NyeXB0JDMyNzY4JDgkMSQ5NTQ3ZjZjYmMwODc2N2MyNTg1NWI3ZGNlNzkwMDIyZCRlZWQ1MDVhZDNhMzljODUwNDVkNWY3MGE2Y2E1MDQ1OTk0M2MzOWRhYTFkNWI2NWZiMGFkOTNjOTlkNTQ4MDZk",
  "privateKey": "2.b6fLelrpL/BBcrRaeTpLtQ==|wEmpoBxqSM2Di+ipbInx6g4o1XZ4i21juCVvmBQj3Shth535M5df+5U+...",
  "key": "0.YbNnsP4/5F8K6efh7VECdA==:xrjgyhk8GXDI+LFhg4cmzOte4wBEEv3BQ/3j2JPaF1VeXcmPB9uZS6ugB0zXURUwdL9QTLQfVtIWFnds6t0Xofci6fmIEd3i+5WUg4IpsX4=",
  "publicKey": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvuL6nSRQZQ0RZmWr+jL2PXSauMNzrg7h+grsqg7OtP/PpNLpoh9r52uiL1iXqidacvF8aEtpym+Na4ltZaA62LmX2N26WbllurXY8e+7q5oUd5Bt64L6w/Q3qxFRGua7VVh8IbOh6E9DTfkm824UfapDJ8LjTsxvHv/8kBs8UCe1zR7zx/7/6sSOh4romVP9oAOrQ31WKZUj4zo8FJ1lwFypm0DzaJjtJS+cEiGApJBnFwkq2b5glUfr0brrVe3HYGG3LJLA+feo5Y/T9bZfnLTv7asLVS7MwaXMeixPE9HF3HgJNKwL9n+CShnGsYX3o6ffr3wiXva9dg4wP5gbUQIDAQAB",
  "timestamp": 1757001969652
}
```

#### `workplace.created`

Emitted by Cloudery when the workplace has been created.

**Message payload:**

```json
{
  "twakeId": "string",
  "internalEmail": "string",
  "workplaceFqdn": "string"
}
```

| Field           | Description                          |
| --------------- | ------------------------------------ |
| `twakeId`       | The user identifier                  |
| `internalEmail` | The user Twake email                 |
| `workplaceFqdn` | The fully qualified workplace domain |

**Example:**

```json
{
  "twakeId": "kferjani14",
  "internalEmail": "kferjani14@twake.app",
  "workplaceFqdn": "kferjani14.twake.app"
}
```

#### `user.phone.updated`

Emitted by Signup when the user updates their phone number.

**Example payload:**

```json
{
  "twakeId": "kferjani14",
  "mobile": "+33700000018",
  "internalEmail": "kferjani14@twake.app",
  "workplaceFqdn": "kferjani14.twake.app"
}
```

### Premium

We will create a new `billing` topic exchange for everything related to premium subscription changes with the following topics:

#### `subscription.changed`

Emitted by Cloudery when the user subscribes to a new plan (including changes from a free plan).

**Message payload:**

```json
{
  "twakeId": "string",
  "internalEmail": "string",
  "isPaying": "boolean",
  "canUpgrade": "boolean",
  "features": {
    "mail": {
      "storageQuota": "integer",
      "mailsSentPerMinute": "integer",
      "mailsSentPerHour": "integer",
      "mailsSentPerDay": "integer",
      "mailsReceivedPerMinute": "integer",
      "mailsReceivedPerHour": "integer",
      "mailsReceivedPerDay": "integer"
    }
  }
}
```

| Field                                  | Description                                        |
| -------------------------------------- | -------------------------------------------------- |
| `twakeId`                              | The user identifier                                |
| `internalEmail`                        | The user Twake email                               |
| `isPaying`                             | Whether the user has a premium subscription or not |
| `canUpgrade`                           | Whether a better premium plan exists or not        |
| `features.mail.storageQuota`           | In bytes; `-1` for unlimited                       |
| `features.mail.mailsSentPerMinute`     | `-1` for unlimited                                 |
| `features.mail.mailsSentPerHour`       | `-1` for unlimited                                 |
| `features.mail.mailsSentPerDay`        | `-1` for unlimited                                 |
| `features.mail.mailsReceivedPerMinute` | `-1` for unlimited                                 |
| `features.mail.mailsReceivedPerHour`   | `-1` for unlimited                                 |
| `features.mail.mailsReceivedPerDay`    | `-1` for unlimited                                 |

**Example:**

```json
{
  "twakeId": "kferjani14",
  "internalEmail": "kferjani14@twake.app",
  "isPaying": true,
  "canUpgrade": true,
  "features": {
    "mail": {
      "storageQuota": 12334534,
      "mailsSentPerMinute": 100,
      "mailsSentPerHour": 1000,
      "mailsSentPerDay": 2000,
      "mailsReceivedPerMinute": -1,
      "mailsReceivedPerHour": -1,
      "mailsReceivedPerDay": -1
    }
  }
}
```

## Technical considerations

Per ADR 002 (RabbitMQ best practices), applications consuming these messages are responsible for creating their own queues. The type of queues is left to be decided by the developers but, so far, queues used by Signup and cozy-stack to store these messages are quorum queues with dead lettering.

The exchanges and queues used for dead lettering need to be created by each consumer application as well.
