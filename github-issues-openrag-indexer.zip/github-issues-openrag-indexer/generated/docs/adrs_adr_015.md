# ADR 015: Common Settings V2.0

## Status

- Date: 25/05/2025
- Status: Approved

## Context

Twake Workplace is composed of a galaxy of applications, each managing their own settings. Ideally each application is meant to potentially be deployed standalone and needs to work independently. But as there is some overlap in settings (timezone, theme settings, etc.) we need:

- A way to synchronize settings across applications
- A common place to visualize "common settings"

The "Golden Source" of the user settings in Twake Workplace should be our IAM system (currently the registration application). All the application user databases should be considered as caches, synced with IAM LDAP.

## Flows

Common settings follow these flows:

### The "Settings" application updates user settings

- **Cozy Stack** prepares the settings update payload.
- **Cozy Stack** makes an HTTP call to **IAM API** via its exposed public endpoint `PUT /admin/user/settings`.
- IAM API:
  - Validates and updates the data.
  - Writes the update to the Common Settings DB (PostgreSQL).
  - Sends a message to **RabbitMQ** for downstream app caches to update.
- **Cloudery** updates the locally cached settings and version when the API responds with success.

```mermaid
sequenceDiagram
    participant Cloudery
    participant IAM API
    participant DB as CS DB
    participant RabbitMQ
    participant Other Apps

    Cloudery->>IAM API: PUT /admin/user/settings (settings payload)
    IAM API ->>IAM API: Validate and process data
    IAM API ->>DB: Update user settings
    IAM API ->>RabbitMQ: Publish update event
    IAM API ->>Cloudery: Return HTTP response (confirmation)
    RabbitMQ ->>Other Apps: Notify of settings update
```

## Summary of APIs Needed in IAM

- `POST /admin/user/settings` -- Creates the user settings for the first time.
- `GET /admin/user/settings/:userId` -- Get current settings from DB.
- `PUT /admin/user/settings/:userId` -- Update settings and write to DB.
- `POST /admin/user/settings/sync` -- Optional: force sync to all applications.
- `POST /admin/external/settings-update` -- For Cloudery, to send settings via IAM proxy (for support purposes).

### Failure in RabbitMQ or Event Handling

**Scenario:**

- The Settings application updates a setting.
- IAM writes to LDAP and publishes an event to RabbitMQ.
- Mail does not receive the event due to a network partition or consumer crash.

**Risk:** Mail continues using stale cached settings.

**Mitigation:**

- Implement retryable sync jobs or fallback periodic reconciliation via IAM API.
- RabbitMQ monitoring and alerts to detect dropped, delayed, or unconsumed messages:
  - **Required**: `rabbitmq_exporter`
  - `rabbitmq_queue_messages_ready`
  - `rabbitmq_queue_messages_unacknowledged` (app crashed or stuck)
  - `rabbitmq_queue_consumers` (app instance went down or unsubscribed)
  - Dead letter queues

## Decision

- Establish a common registry for settings (JSON structure: name as a string associated with a JSON object).
- Use a common event bus based on RabbitMQ to propagate setting changes.
- This is a **backend synchronization** process described within [ADR 001](./adr-001).
- Applications need to obey the event contract.
- Since there is only one point of making changes to user settings (the Settings application), we do not need to implement optimistic locking with version on the very first step.
- All settings will be stored as plain strings inside LDAP.
- No need to implement an HTTP callback "on settings changed" to Cloudery because it is the only place where we can change settings (except initial user creation).

## Consequences

Each application can still manage its own settings, but must subscribe to and respect changes propagated through RabbitMQ.

## Annexes

### Message format

```json
{
  "source": "IAM",
  "nickname": "johndoe",
  "request_id": "req_1234567890",
  "timestamp": 1718897400000,
  "version": 1,
  "payload": {
    "language": "en",
    "timezone": "Europe/Paris",
    "avatar": "https://example.com/avatar.png",
    "last_name": "Doe",
    "first_name": "John",
    "email": "john.doe@example.com",
    "phone": "+33612345678",
    "matrix_id": "@johndoe:matrix.org",
    "display_name": "John Doe"
  }
}
```

### Alternative flows (not implemented)

#### Client application updates settings through HTTP API

- User opens a settings page in a client app (e.g., Mail).
- User modifies a setting (e.g., timezone, language).
- App sends a `PUT /admin/user/settings` HTTP request to the IAM API.
- IAM API validates, updates LDAP, publishes to RabbitMQ, and sends an HTTP event to Cloudery.
- App updates its local cache. Other apps listen to RabbitMQ or refresh via IAM API.

```mermaid
sequenceDiagram
    participant User
    participant App (Mail/Chat)
    participant IAM API (Registration)
    participant LDAP
    participant RabbitMQ
    participant Cloudery
    participant Other Apps

    User->>App (Mail/Chat): Open settings page
    User->>App (Mail/Chat): Modify settings (e.g., timezone)
    App (Mail/Chat)->>IAM API (Registration): PUT /admin/user/settings
    IAM API (Registration)->>IAM API (Registration): Validate & process data
    IAM API (Registration)->>LDAP: Update user settings
    IAM API (Registration)->>RabbitMQ: Publish update event
    IAM API (Registration)-->>App (Mail/Chat): Success response
    IAM API (Registration)->>Cloudery: Send HTTP event
    App (Mail/Chat)->>App (Mail/Chat): Update local cache
    RabbitMQ-->>Other Apps: Notify of settings update
    Other Apps->>IAM API (Registration): Optionally fetch latest settings
```

#### Client application updates settings through RabbitMQ

- User modifies a setting in a client app.
- App publishes a message to a RabbitMQ exchange.
- IAM consumes the message, validates, updates LDAP, and sends an HTTP event to Cloudery.
- Other apps listen to RabbitMQ or refresh via IAM API.

```mermaid
sequenceDiagram
    participant User
    participant App (Mail/Chat)
    participant RabbitMQ
    participant IAM (Registration)
    participant LDAP
    participant Cloudery
    participant Other Apps

    User->>App (Mail/Chat): Open settings page
    User->>App (Mail/Chat): Modify settings (e.g., timezone, language)
    App (Mail/Chat)->>RabbitMQ: Publish message to exchange with new settings
    RabbitMQ-->>IAM (Registration): Message routed to queue and consumed
    IAM (Registration)->>IAM (Registration): Validate and process data
    IAM (Registration)->>LDAP: Update user settings
    IAM (Registration)->>Cloudery: Send HTTP event with update info
    RabbitMQ-->>Other Apps: Notify of settings update
    Other Apps->>IAM (Registration): Optionally fetch latest settings
```

#### During OIDC authentication

The SSO provides a "twake" scope which contains all common settings. When an app receives it, it must override all previous values with these ones if the version of the settings on OIDC scope is greater than it is inside the application.

```mermaid
sequenceDiagram
    participant User
    participant SSO / OIDC Provider
    participant App

    User->>App: Initiates login
    App->>SSO / OIDC Provider: Redirects for authentication
    SSO / OIDC Provider-->>App: Returns ID token with "twake" scope (including settings + version)
    App->>App: Parse "twake" scope from token
    App->>App: Compare version from OIDC vs. local settings version
    alt OIDC version > Local version
        App->>App: Override local settings with values from OIDC
    else OIDC version <= Local version
        App->>App: Keep existing local settings
    end
```

### Potential conflict scenarios

#### Race condition between OIDC scope and local update

**Scenario:**

- User logs in and app receives `twake` scope with version `v2`.
- The user modifies a setting in the app and sends an update to IAM.
- The local app may override the just-updated settings with stale OIDC values (`v2`) before the IAM response returns (which would be version `v3`).

**Risk:** New user data is lost due to accepting a stale version from the login token.

**Mitigation:** Always confirm latest version with IAM after login if recent changes are expected.

## Side notes

### Common settings for on-premise customers

We need common settings for B2B customers. Questions to resolve:

- Where do we store common settings if we don't have an LDAP for on-premise?
- We need to restrict the list of settings that can be edited inside the settings application.

### Authentication flows

#### Authentication in public Platform / SaaS

**User initiates login from a TWP app using OIDC:**

```mermaid
sequenceDiagram
    participant User
    participant App
    participant IAM
    participant LemonLDAP
    participant LDAP

    User->>App: Attempt to login
    App->>IAM: Initiate SSO flow
    IAM->>IAM: Check if user is already connected
    alt User not connected
        IAM->>User: Display login form (with redirectBackUrl)
        User->>IAM: Submit credentials via form
        IAM->>LemonLDAP: Proxy request initial request
        LemonLDAP->>LDAP: Bind user for authentication
        LDAP-->>LemonLDAP: Authentication success/failure
        LemonLDAP-->>IAM: Return auth response
    end
    IAM-->>App: Return final response (success/failure)
```

**User initiates login from the signup IAM:**

```mermaid
sequenceDiagram
    participant User
    participant Browser
    participant IAM
    participant LDAP
    participant LemonLDAP

    User->>IAM: Open IAM (signup)
    IAM->>IAM: Check if user is connected
    alt User not connected
        IAM->>User: Display login/signup form
        User->>IAM: Submit credentials
        IAM->>LDAP: Fetch user (phone/email/username)
        alt User does not exist
            LDAP-->>IAM: User not found
            IAM-->>User: Login failure
        else User exists
            LDAP-->>IAM: User found
            IAM->>LemonLDAP: HTTP login request with user credentials
            LemonLDAP->>LDAP: Bind user for authentication
            LDAP-->>LemonLDAP: Authentication success
            LemonLDAP-->>IAM: Return session token (cookie)
            IAM->>Browser: Set session cookie in response
        end
    end
```

**Backend services using IAM admin APIs:**

```mermaid
sequenceDiagram
    participant BackendService
    participant IAM

    BackendService->>IAM: Call admin API with access token
    IAM->>IAM: Validate token against static configured token
    alt Token is valid
        IAM-->>BackendService: Handle request and return response
    else Token is invalid
        IAM-->>BackendService: Return unauthorized error
    end
```

#### Authentication in the Linagora platform (without registration IAM)

**User initiates login from a TWP app:**

```mermaid
sequenceDiagram
    participant User
    participant App
    participant LemonLDAP
    participant LDAP

    User->>App: Open App
    App->>LemonLDAP: Start OIDC flow (auth request)
    LemonLDAP->>User: Display login form
    User->>LemonLDAP: Submit credentials
    LemonLDAP->>LDAP: Bind and fetch user
    LDAP-->>LemonLDAP: Authentication success
    LemonLDAP-->>App: Redirect back with token (ID/access token)
```

**User initiates login from LemonLDAP:**

```mermaid
sequenceDiagram
    participant User
    participant LemonLDAP
    participant LDAP

    User->>LemonLDAP: Open SSO login page
    LemonLDAP->>User: Display login form
    User->>LemonLDAP: Submit credentials
    LemonLDAP->>LDAP: Bind user with credentials
    LDAP-->>LemonLDAP: Authentication success
    LemonLDAP->>LemonLDAP: Create session
    LemonLDAP->>User: Set session cookie
```
