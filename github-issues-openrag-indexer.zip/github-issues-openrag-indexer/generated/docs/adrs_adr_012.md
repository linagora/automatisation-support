# ADR 012: TDrive / TChat Integration

## Status

- Date: 28/06/2024
- Status: Writing

## Context

Integrating chat and drive is a basic integration expected from users. The following features are planned:

- **Attachment action -- add to my drive**: if clicked, the attachment is added to the drive. A flag is used to remember this decision.
- **Large file warning**: sharing files larger than 2MB triggers a warning (can be disabled) and proposes instead to host the file in TDrive. If agreed, the file is uploaded into "My Drive", shared as a public link, and the link is shared in the channel with a thumbnail preview.
- **TDrive button in composer**: clicking it opens a TDrive popup. The user selects a file (search, my drive, shared drive). Twake Chat generates a public link for that file. The link is shared in the channel with a thumbnail preview.

## Decision

- Twake Chat can obtain a temporary TDrive access token using the OIDC exchange token system.
- Twake Chat backend advertises TDrive presence via Matrix metadata.
- If the TDrive endpoint can be discovered, Twake Chat will display TDrive actions (activate the TDrive module).
- This is an example of a **frontend integration** pattern.

## Consequences

- A TDrive Dart client library must be written (shared with TMail).
- We expect a reduction in file transfer size within chat.
- **Security concern**: leaking TDrive public links means leaking data. Links need to be hard to guess. There must be no API to list public links. DOS prevention: many 404 responses should trigger CrowdSec to ban the offending IP.
