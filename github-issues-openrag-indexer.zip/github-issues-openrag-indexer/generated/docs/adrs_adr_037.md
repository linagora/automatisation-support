# ADR 037: Cozy Stack Subdomain-Based Application Routing

Date: 08/04/2026
Status: `accepted`

## Context

Cozy Stack serves multiple JavaScript web applications (Drive, Mail, Contacts, Notes, etc.) for each user instance. These apps need isolation from each other for security (different origins prevent cross-app DOM access and cookie leakage), and each app needs to make authenticated API calls to the stack on behalf of the user.

## Decision

Applications are served via **subdomain routing**. Each installed app gets its own subdomain derived from the user's instance domain.

Two subdomain models are supported:

- **Flat**: `<instance>-<app>.<domain>` (e.g., `alice-drive.twake.app`)
- **Nested**: `<app>.<instance>.<domain>` (e.g., `drive.alice.twake.app`)

The stack inspects the `Host` header on every incoming request, extracts the app slug, and either serves the app's static files from the VFS or routes to the REST API.

Authentication is handled by injecting a JWT token into the HTML served to the browser. The app uses this token for subsequent API calls. Each app's `manifest.webapp` declares which permissions it needs, and the token is scoped to those permissions only.

Production deployments use the **flat** model. The **nested** model is typically used for local development.

## Consequences

- Each app runs in a separate browser origin, providing strong security isolation
- The reverse proxy must route all app subdomains to the stack (wildcard DNS or explicit entries)
- App permissions are enforced at the API boundary via the scoped JWT, not at the network level
- Adding a new app to a user's instance only requires installing its manifest and files in the VFS
