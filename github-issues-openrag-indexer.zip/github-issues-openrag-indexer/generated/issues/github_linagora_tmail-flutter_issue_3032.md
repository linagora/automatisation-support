# GitHub issue #3032: [Bug] Counters aren't updated

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3032
State: closed
Author: tprudentova
Created at: 2024-07-24T08:24:29Z
Updated at: 2025-05-07T20:15:43Z
Closed at: 2024-08-30T05:15:07Z
Labels: bug, TWP, staging, blocker
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/3032

## Issue body

0.12.1 tested on Android, Firefox, Opera; mail.stg.lin-saas.com

1. Open Twake Mail  
2. Receive some messages
3. The counters aren't updated

<img width="1280" alt="Screenshot 2024-07-24 at 11 19 33" src="https://github.com/user-attachments/assets/412955f9-2334-4937-980d-a4ac6e7531ca">

![photo_2024-07-24_11-24-00](https://github.com/user-attachments/assets/8f90847d-1118-405d-8f71-96865c11f393)

![photo_2024-07-24_11-23-55](https://github.com/user-attachments/assets/080890f0-7295-48ae-a9ac-dfd936535946)

## Comments

### Comment by chibenwa at 2024-07-24T09:19:09Z

This is a plateform related bug, diagnosed and fixed on 

![image](https://github.com/user-attachments/assets/583b19b4-9167-47df-ba92-c5b890148c31)

JMAP event processing is then not updated by IMAP pods 

VS  

![image](https://github.com/user-attachments/assets/d7cebfce-d22a-4c02-92eb-3e6c05fa35a4)

here are the PRs to the relevant HELM chart changes

 - tmail-backend main: https://ci.linagora.com/linagora/lrs/saas/tools/helm-charts/tmail-backend/-/merge_requests/58
 - tmail-backend 5.0: https://ci.linagora.com/linagora/lrs/saas/tools/helm-charts/tmail-backend/-/merge_requests/57

I will rely on @ducnm0711 for updating preprod + prod. Here is the relevant OPS ticket. https://ci.linagora.com/linagora/lrs/saas/devops/-/issues/576

### Comment by chibenwa at 2024-07-25T07:54:25Z

Solved for reading mails.

@hoangdat 

![image](https://github.com/user-attachments/assets/ff3e49cf-5969-48ce-ad19-2ff14c675e14)
![image](https://github.com/user-attachments/assets/d3796f35-0fe4-4e18-bdf5-171f7df1e7ff)


Those are the requests done to resynchronise, after receiving an email.

Why the heck doesn't it does `Mailbox/changes` stuff?

### Comment by chibenwa at 2024-07-25T07:57:50Z

This is a **regression**

![image](https://github.com/user-attachments/assets/cecaced2-678d-4293-9676-b8860b03b0a4)

tmail.linagora.com works great. `linagora/tmail-web:v0.11.4003`

I propose we revert. I propose we QA more before releasing.

### Comment by hoangdat at 2024-07-25T07:59:27Z

no f*** regression here, still work in our side. not understand what are you saying



![Image](https://github.com/user-attachments/assets/bc13f573-e59d-4bdc-80e3-6888d282297c)

### Comment by chibenwa at 2024-07-25T08:24:08Z

> no f*** regression here

Innapropriate language.

It is specifically when receiving emails.

Also, the issue is **with the refresh button** that only refreshes emails while it should refresh mailboxes also!

CF


https://github.com/user-attachments/assets/819253a7-b44a-4c8e-b174-55075c93711e

(So IMO still a regression)

### Comment by hoangdat at 2024-07-25T08:30:54Z

Maybe configuration issue, not found configuration file for fcm in client side

### Comment by hoangdat at 2024-07-25T08:31:21Z

> (So IMO still a regression)

By the way, what is the definition of `regression`?

### Comment by chibenwa at 2024-07-25T08:35:15Z

![image](https://github.com/user-attachments/assets/dfe51d49-604f-4675-b383-6f7467492b1c)

IE it worked before and now not any longer

### Comment by chibenwa at 2024-07-25T08:36:06Z

> Maybe configuration issue, not found configuration file for fcm in client side

We should resync mailboxes when I click that button, **regardless of FCM**. So this is still an issue.

BTW there's likely something with FCM too, yes.

### Comment by hoangdat at 2024-07-25T08:40:24Z

> We should resync mailboxes when I click that button, regardless of FCM. So this is still an issue.

ahh, it is in purpose from the beginning of tmail, only refresh current mailbox list (the same with scroll to refresh in mobile). Not a regression.

### Comment by hoangdat at 2024-07-25T11:16:15Z

> We should resync mailboxes when I click that button, regardless of FCM. So this is still an issue.

I will separate this into other `improvement` ticket, not a regression: https://github.com/linagora/tmail-flutter/issues/3050


> BTW there's likely something with FCM too, yes.

Real time update is under investigating. A weird behavior between canary and staging (same front-end version)

### Comment by hoangdat at 2024-07-25T11:55:46Z

hi @chibenwa , please enable `com:linagora:params:jmap:firebase:push` capability for STG + Prod of TWP. We will unblock this issue

### Comment by chibenwa at 2024-07-25T21:41:19Z

hi @ducnm0711 (with maybe help of @quantranhong1999 )  , please enable com:linagora:params:jmap:firebase:push capability for STG + Prod of TWP. We will unblock this issue

### Comment by hoangdat at 2024-07-26T04:44:21Z

Clear the cache. Well fixed. @tprudentova please verify and close the issue

### Comment by tprudentova at 2024-08-12T09:51:25Z

email.linagora.com

https://github.com/user-attachments/assets/b269809c-fb3d-43f0-ab47-f5dc4d0a4993

IMO we need to refresh counters when user clicks on the Refresh button. Why is this considered a feature?.. Looks like a bug to me

### Comment by hoangdat at 2024-08-12T10:20:36Z

Maybe a brand-new browser, you still not have permission for this. Please check notification  settings

### Comment by tprudentova at 2024-08-12T11:24:34Z

https://github.com/user-attachments/assets/58813e37-f222-45d5-bbb7-b396132927d2

I've used this browser for like 6 years on this laptop, but the counters are still not updated. How are the counters connected to the notification settings though?..

### Comment by tprudentova at 2024-08-26T09:33:26Z

Expected behaviour: 
When I click the Refresh button, the counters are updated as well as the letters feed
