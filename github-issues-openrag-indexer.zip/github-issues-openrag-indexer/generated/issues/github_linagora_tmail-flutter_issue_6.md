# GitHub issue #6: [Story] As an user, i want to choose a mailbox and see mail list inside

## Metadata

Repository: linagora/tmail-flutter
Issue number: 6
State: closed
Author: dieptran88
Created at: 2021-06-21T10:32:44Z
Updated at: 2022-01-04T23:08:42Z
Closed at: 2022-01-04T23:08:42Z
Labels: 
Assignees: dieptran88
URL: https://github.com/linagora/tmail-flutter/issues/6

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Technical issues](#technical-issues)
* [Misc](#misc)

## Related EPIC

## Definition

- Given that i am a Tmail user and i already had an account (John Doe).
- Given that i log-in successfully to the Tmail app.
- I can see the default view  is Inbox mail list.
- I click on Inbox title, the list of mailboxes screen will be opened. 
- I can select another mailbox and the list of mail inside that mailbox will be opened.

   - For "Draft" mailbox: The mail listing rule is as same as Inbox #9 except that on each email i can see a label "Draft" 
   - For "Sent:The mail listing rule is as same as Inbox #9   
   - For "Trash": The mail listing rule is as same as Inbox #9   
   - For "Spam": The mail listing rule is as same as Inbox #9   
   - For Created mailboxes : The mail listing rule is as same as Inbox #9   

- When an mailbox is opened, the folder's name will be displayed on top of screen. If that mailbox has a counter for unseen message, the number will be displayed next to Folder's name.
- The email list should be refreshed real time: When an email is deleted or added, it will be reflected instantly on listing mail screen. 

[Back to Summary](#summary)

## UI Design

#### Mockups

#### Final design
![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/3b6baff8-62be-43c1-9046-9a805b025f04)


[Back to Summary](#summary)

## Technical issues

[Back to Summary](#summary)

## Misc

[Back to Summary](#summary)

## Comments

### Comment by hoangdat at 2021-08-02T01:45:59Z

@chibenwa Can you help us to write the Jmap call for this story?

### Comment by chibenwa at 2021-08-02T02:04:39Z

Sure. Let me 5 minutes ;-)

### Comment by chibenwa at 2021-08-02T02:12:40Z

In short, chain:

 - `Mailbox/query` to get the mailbox id - not needed when browising the mailbox list but useful to do single request page load <3
 - `Email/query` to the the email list - `inMailbox` filter supports backreference
 - `Email/get` to retrieve display information - be carefull not to specify something expensive in the properties!

### Comment by chibenwa at 2021-08-02T02:20:57Z

## When the user clicks on a mailbox of the mailbox view

You already have the mailbox id so we just do `Email/query` and `Email/get`.

Example:

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
  "methodCalls": [[
    "Email/query",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "limit": 20,
      "filter": {
        "inMailbox": "36"
      },
      "sort": [{
        "property":"sentAt",
        "isAscending": false
      }]
    },
    "c2"], [
     "Email/get",
     {
       "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
       "properties": ["id", "subject", "from", "to", "cc", "bcc", "keywords", "size", "receivedAt", "sentAt", "replyTo", "preview", "hasAttachment"],
       "#ids": {
         "resultOf":"c2",
         "name":"Email/query",
         "path":"ids/*"
       }
     },
     "c3"]]
}
```

Will return:

```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/query",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "queryState": "583c65ef",
                "canCalculateChanges": false,
                "ids": [
                    "47",
                    "45",
                    "44"
                ],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "notFound": [],
                "state": "50e0db67-038c-48f0-9746-20b9248f9dcf",
                "list": [
                    {
                        "preview": "have you found out anything on this trade? thanks Kerri Thompson 02/02/2001 04:48 PM To: Kate Symes/PDX/ECT@ECT cc: Subject: Re: apb checkout she says tom, i guess we can wait until monday..... Kate Symes @ ECT 02/02/2001 04:38 PM To: Kerri Thompson/Corp/E",
                        "hasAttachment": false,
                        "size": 2056,
                        "keywords": {
                            "nonjunk": true
                        },
                        "subject": "Re: apb checkout",
                        "sentAt": "2001-02-05T17:37:00Z",
                        "id": "47",
                        "receivedAt": "2021-08-02T02:48:14Z"
                    },
                    {
                        "preview": "Kim, By the time you get this reply e:mail, it is my hope that you will have received an e:mail from Gerald Nemec forwarding you the limited response that we were independently making to the data request (answering Question 19 of Pan Alberta's Data Request",
                        "hasAttachment": false,
                        "size": 2161,
                        "keywords": {
                            "nonjunk": true
                        },
                        "subject": "Re: Data Responses",
                        "sentAt": "2000-05-20T03:10:00Z",
                        "id": "45",
                        "to": [
                            {
                                "name": "Kim Clark",
                                "email": "kclark@jhenergy.com"
                            }
                        ],
                        "receivedAt": "2021-08-02T02:48:12Z"
                    },
                    {
                        "preview": "I am for the normal draft - same as last year. PL *********** EDRM Enron Email Data Set has been produced in EML, PST and NSF format by ZL Technologies, Inc. This Data Set is licensed under a Creative Commons Attribution 3.0 United States License <http://c",
                        "hasAttachment": false,
                        "size": 1403,
                        "keywords": {
                            "nonjunk": true
                        },
                        "subject": "Re: Draft info",
                        "sentAt": "2000-07-05T17:35:00Z",
                        "id": "44",
                        "receivedAt": "2021-08-02T02:48:11Z"
                    }
                ]
            },
            "c3"
        ]
    ]
}
```

## You want to load the content of INBOX upon app opening in a single request!

Here we need to add `Mailbox/query` to the mix:

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
  "methodCalls": [[
    "Mailbox/query",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "filter": {"role":"Inbox"}
    },
    "c1"],[
    "Email/query",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "limit": 20,
      "filter": {
        "#inMailbox": {
         "resultOf":"c1",
         "name":"Mailbox/query",
         "path":"ids[0]"
       }
      },
      "sort": [{
        "property":"sentAt",
        "isAscending": false
      }]
    },
    "c2"], [
     "Email/get",
     {
       "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
       "properties": ["id", "subject", "from", "to", "cc", "bcc", "keywords", "size", "receivedAt", "sentAt", "replyTo", "preview", "hasAttachment"],
       "#ids": {
         "resultOf":"c2",
         "name":"Email/query",
         "path":"ids/*"
       }
     },
     "c3"]]
}
```

Will return:

```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Mailbox/query",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "queryState": "5370e2ed",
                "canCalculateChanges": false,
                "ids": [
                    "2"
                ],
                "position": 0,
                "limit": 256
            },
            "c1"
        ],
        [
            "Email/query",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "queryState": "583c65ef",
                "canCalculateChanges": false,
                "ids": [
                    "47",
                    "45",
                    "44"
                ],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "notFound": [],
                "state": "50e0db67-038c-48f0-9746-20b9248f9dcf",
                "list": [
                    {
                        "preview": "have you found out anything on this trade? thanks Kerri Thompson 02/02/2001 04:48 PM To: Kate Symes/PDX/ECT@ECT cc: Subject: Re: apb checkout she says tom, i guess we can wait until monday..... Kate Symes @ ECT 02/02/2001 04:38 PM To: Kerri Thompson/Corp/E",
                        "hasAttachment": false,
                        "size": 2056,
                        "keywords": {
                            "nonjunk": true
                        },
                        "subject": "Re: apb checkout",
                        "sentAt": "2001-02-05T17:37:00Z",
                        "id": "47",
                        "receivedAt": "2021-08-02T02:48:14Z"
                    },
                    {
                        "preview": "Kim, By the time you get this reply e:mail, it is my hope that you will have received an e:mail from Gerald Nemec forwarding you the limited response that we were independently making to the data request (answering Question 19 of Pan Alberta's Data Request",
                        "hasAttachment": false,
                        "size": 2161,
                        "keywords": {
                            "nonjunk": true
                        },
                        "subject": "Re: Data Responses",
                        "sentAt": "2000-05-20T03:10:00Z",
                        "id": "45",
                        "to": [
                            {
                                "name": "Kim Clark",
                                "email": "kclark@jhenergy.com"
                            }
                        ],
                        "receivedAt": "2021-08-02T02:48:12Z"
                    },
                    {
                        "preview": "I am for the normal draft - same as last year. PL *********** EDRM Enron Email Data Set has been produced in EML, PST and NSF format by ZL Technologies, Inc. This Data Set is licensed under a Creative Commons Attribution 3.0 United States License <http://c",
                        "hasAttachment": false,
                        "size": 1403,
                        "keywords": {
                            "nonjunk": true
                        },
                        "subject": "Re: Draft info",
                        "sentAt": "2000-07-05T17:35:00Z",
                        "id": "44",
                        "receivedAt": "2021-08-02T02:48:11Z"
                    }
                ]
            },
            "c3"
        ]
    ]
}
```

### Comment by hoangdat at 2021-08-05T09:17:57Z

@chibenwa why we not set the arguments `collapseThreads = true` in this query method?

### Comment by chibenwa at 2021-08-05T09:19:55Z

collapseThreads is not supported by James

### Comment by hoangdat at 2021-08-05T09:22:40Z

After user scroll all the `limit` how to get more?

### Comment by chibenwa at 2021-08-05T09:25:34Z

Use position + limit

Request one:
 - position 0 limit 20
 Request 2:
 - position 20 limit 20
 Etc...

### Comment by hoangdat at 2021-08-05T09:29:55Z

Perfect. Srr, I only glance read the specs 🙏

### Comment by chibenwa at 2021-08-05T13:31:48Z

No problem, I'm here or that!

### Comment by hoangdat at 2021-08-17T09:26:35Z

@chibenwa 
I requested
```json
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail"
    ],
    "methodCalls": [
        [
            "Email/query",
            {
                "accountId": "{{accountId}}",
                "limit": 20,
                "filter": {
                    "inMailbox": "aba7e8d0-18d9-11eb-a677-2990b970028d"
                },
                "sort": [{
                  "property":"sentAt",
                  "isAscending": false
                }],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "{{accountId}}",
                "properties": [
                    "subject",
                    "from",
                    "receivedAt",
                    "sentAt",
                    "preview",
                    "hasAttachment"
                ],
                "#ids": {
                    "resultOf": "c2",
                    "name": "Email/query",
                    "path": "ids/*"
                }
            },
            "c3"
        ]
    ]
}
```
But the list in `c3` is not follow the order of `ids` from `c2` response.

### Comment by hoangdat at 2021-08-17T09:47:07Z

> Use position + limit
> 
> Request one:
> 
> * position 0 limit 20
>   Request 2:
> * position 20 limit 20
>   Etc...

It quite not success:
```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail"
    ],
    "methodCalls": [
        [
            "Email/query",
            {
                "accountId": "{{accountId}}",
                "limit": 20,
                "filter": {
                    "inMailbox": "aba7e8d0-18d9-11eb-a677-2990b970028d"
                },
                "sort": [{
                  "property":"sentAt",
                  "isAscending": false
                }],
                "position": 20
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "{{accountId}}",
                "properties": [
                    "id",
                    "subject",
                    "from",
                    "receivedAt",
                    "sentAt",
                    "preview",
                    "hasAttachment"
                ],
                "#ids": {
                    "resultOf": "c2",
                    "name": "Email/query",
                    "path": "ids/*"
                }
            },
            "c3"
        ]
    ]
}
```
response:
```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/query",
            {
                "accountId": "3ce33c876a726662c627746eb9537a1d13c2338193ef27bd051a3ce5c0fe5b12",
                "queryState": "00000000",
                "canCalculateChanges": false,
                "ids": [],
                "position": 20
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "3ce33c876a726662c627746eb9537a1d13c2338193ef27bd051a3ce5c0fe5b12",
                "notFound": [],
                "state": "ceb36d20-ff3f-11eb-a9c2-2fef1ee78d9e",
                "list": []
            },
            "c3"
        ]
    ]
}
```
and the specs said:
![image](https://user-images.githubusercontent.com/6462404/129703800-9340ebb2-20bd-4540-b4b6-021f3df28a14.png)

### Comment by chibenwa at 2021-08-17T10:02:43Z

> Use position + limit

Let me have a look

### Comment by chibenwa at 2021-08-17T10:05:42Z

> But the list in c3 is not follow the order of ids from c2 response.

https://jmap.io/spec-core.html#get

```
list: [...]  The results MAY be in a different order to the ids in the request arguments. 
```

To be spec compliant @hoangdat you need to sort them yourself (more precisely manually enforce the order returned by `/query` )

### Comment by Arsnael at 2021-08-17T10:14:15Z

I know it sounds like a stupid question but... how many mails in your mailbox? The specs saying that if your position is higher than the number of mails then you get an empty list and it's not an error. 

I could double check but can you confirm if it's the case or not @hoangdat ?

### Comment by hoangdat at 2021-08-17T10:23:06Z

haha. Yes, that the problem. 

We want to `paging` the request, so we set limit is 20, position = 0. It is ok for the first request. But then, we need to get more, limit = 20, position = 20. It is empty :(. (Mailbox have nearly 1000 mails)

So the question now is, `How to support paging request?`

### Comment by Arsnael at 2021-08-17T10:33:18Z

Ok @hoangdat I just reproduced it on preprod, I got the same as you bug confirmed! 

Also played around, it seems something is wrong with param `limit`. If I put it at 20 with position 20, 0 ids, limit at 30 and position 20, I get 10 ids, limit at 40 and position 20 and I get the 20 wanted ids. It seems limit always starts from 0 for some reasons... Will fix :)

Thanks for pointing that to us^^

### Comment by chibenwa at 2021-08-17T10:40:37Z

Ok, got the bug,

@hoangdat  which environment ?

When using email query view, we request only `limit` messages before doing manually the filtering. Hence the bug.

You should not encounter this issue using the local memory image. Correct?

### Comment by hoangdat at 2021-08-17T10:42:51Z

> which environment ?

https://dev.open-paas.org

@dab246 Did you have the same issue in Memory docker?

### Comment by Arsnael at 2021-08-17T10:48:40Z

https://github.com/linagora/james-project/issues/4375

### Comment by chibenwa at 2021-08-17T11:05:49Z

@Arsnael can you disable EmailQueryView on the DEV environment to unlock the mobile team?

### Comment by Arsnael at 2021-08-17T11:16:16Z

> @Arsnael can you disable EmailQueryView on the DEV environment to unlock the mobile team?

First thing in the morning

### Comment by chibenwa at 2021-08-17T11:24:38Z

The integration test reproducing the defect and the fix (with <3) https://github.com/apache/james-project/pull/603

### Comment by Arsnael at 2021-08-18T03:12:03Z

> > @Arsnael can you disable EmailQueryView on the DEV environment to unlock the mobile team?
> 
> First thing in the morning

Done

### Comment by chibenwa at 2021-08-18T03:42:57Z

@dab246 @hoangdat  can you confirm this fixed the issue?

### Comment by hoangdat at 2021-08-18T07:23:21Z

Confirmed. It works. Many thanks
