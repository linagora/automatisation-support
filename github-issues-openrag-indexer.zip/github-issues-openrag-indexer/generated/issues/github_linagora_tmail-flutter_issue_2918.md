# GitHub issue #2918: Cache bug is back

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2918
State: closed
Author: guimard
Created at: 2024-06-10T02:34:13Z
Updated at: 2026-04-06T07:48:51Z
Closed at: 2026-04-06T07:48:51Z
Labels: bug, cache
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/2918

## Issue body

### Description

Same as #2453, back for a week

Version 0.11.4001

## Comments

### Comment by chibenwa at 2024-06-13T13:34:13Z

Xavier, ca se produit toujours? Ou c'est fixe?

### Comment by guimard at 2024-06-13T13:37:05Z

> Xavier, ca se produit toujours? Ou c'est fixe?

Bug still active, message deleted or read on Thunderbird are still present in mobile app as "unread". I disconnect and reconnect, bug is still there with new messages

### Comment by hoangdat at 2024-06-14T01:54:47Z

- [x] Can not reproduce in iOS: cache and list of message in mailbox are updated well after delete or read message in Thunderbird
- [ ] Android

### Comment by dab246 at 2024-06-14T10:10:23Z

> * [x]  Can not reproduce in iOS: cache and list of message in mailbox are updated well after delete or read message in Thunderbird
> * [x]  Android

Tested on mobile platform (iOS: 17.5.1 | Android Emulator 14). The problem cannot be reproduced. It still synchronizes well when performing `mark as read/ move/ delete` emails

### Comment by guimard at 2024-06-15T03:57:34Z

> > * [x]   Can not reproduce in iOS: cache and list of message in mailbox are updated well after delete or read message in Thunderbird
> > * [x]   Android
> 
> Tested on mobile platform (iOS: 17.5.1 | Android Emulator 14). The problem cannot be reproduced. It still synchronizes well when performing `mark as read/ move/ delete` emails

Most of the problem comes when Thunderbird executes automatic filters (deleting notifications from migration). When there is a lot, problem appear.

Let's keep this issue behind the scene to see if it come back for someone else

### Comment by dab246 at 2024-06-17T02:14:37Z

> > > * [x]    Can not reproduce in iOS: cache and list of message in mailbox are updated well after delete or read message in Thunderbird
> > > * [x]    Android
> > 
> > 
> > Tested on mobile platform (iOS: 17.5.1 | Android Emulator 14). The problem cannot be reproduced. It still synchronizes well when performing `mark as read/ move/ delete` emails
> 
> Most of the problem comes when Thunderbird executes automatic filters (deleting notifications from migration). When there is a lot, problem appear.
> 
> Let's keep this issue behind the scene to see if it come back for someone else

Yes, I also think so, this problem can be caused by many accompanying conditions so we need time to research it.

### Comment by guimard at 2024-08-21T03:52:35Z

Hi, I still have this issue, this render Tmail app difficult to use

### Comment by hoangdat at 2024-08-21T04:08:56Z

Hi @guimard,
- Can you describe more details on your setup in Thunderbird? And your behavior, you always do with it? I will try to do the same in my local

You said:
> I disconnect and reconnect, bug is still there with new messages

What is disconnect? You mean: close the app and open again, or log out?

### Comment by guimard at 2024-08-21T04:49:08Z

Really nothing special. I'm connected using Thunderbird and my phone, nothing else.

It seems that when phone app is off (sleeping), part of messages deleted during this period using Thunderbird stay inside Tmail cache and then continue to appear.

I just changed phone, same issue. Only disconnect/reconnect purges messages.

When I open such message on app, their state never change (stays unread, unable to delete,...)

### Comment by guimard at 2024-08-21T05:14:36Z

I think @chibenwa encountered the same issue

### Comment by hoangdat at 2024-08-27T02:35:08Z

Try to reproduce:
- enable rule filter of Thunderbird
- join in app in mobile device
- send mail to this account
- testing more the synchronization of app,

### Comment by hoangdat at 2024-10-18T14:13:30Z

hi @guimard , you also have the `message filter` in Thunderbird like below and have issue. Am I right? 
![Image](https://github.com/user-attachments/assets/e8841f86-db73-427a-bb7f-c576f6cc7034)

### Comment by guimard at 2024-10-18T15:10:57Z

> hi @guimard , you also have the `message filter` in Thunderbird like below and have issue. Am I right?

Hi @hoangdat : no more filter but still the bug

### Comment by hoangdat at 2024-12-18T07:29:09Z

> new message comes, you will expunge it in thunderbird, then open tmail mobile -> this email still be in Inbox with unread state

### Comment by guimard at 2024-12-18T07:30:51Z

Not all deleted messages, part of them only. But then I can't delete them on app, neither mark them as read. They stay until I disconnect mobile app

### Comment by hoangdat at 2025-04-28T02:58:56Z

Sometimes , a lot of changes occur, so `Email/get` can not get all the thing, so cache will be not update well. 
And mobile app will have a hard refresh to make cache will be reset to synchronize again. 
All the details were addressed here https://github.com/linagora/tmail-flutter/issues/3507#issuecomment-2771327788. Please try and feedback about it.

### Comment by chibenwa at 2025-07-03T07:43:48Z

@hoangdat update the status of this ticket here please.

### Comment by hoangdat at 2025-07-03T07:49:04Z

Changed DB to well handled multiple access on Hive (local DB)
Under testing in Internal Test of store: v0.16.4

### Comment by guimard at 2025-07-04T16:23:33Z

Bug still exists in 0.16.4

### Comment by hoangdat at 2025-07-04T16:28:26Z

> Bug still exists in 0.16.4

What is the case of missing in mobile? Or still available in mobile but not in web?

### Comment by guimard at 2025-07-05T06:25:25Z

> > Bug still exists in 0.16.4
> 
> What is the case of missing in mobile? Or still available in mobile but not in web?

Dropped with Thunderbird, OK with web, still present in mobile app

### Comment by hoangdat at 2025-07-05T06:37:58Z

You still not see the update if you open app again?

Does it always? Or sometime?

Mobile app in background or foreground when you drop things in thunderbird?

In mobile, we tried to debounce (2s) refreshing app realtime. When you open app again, maybe take a little time to see the updating.

### Comment by guimard at 2025-07-05T10:18:37Z

> You still not see the update if you open app again?

No, but behavior changed a little. Inside mobile app:
- I can see some mails deleted by Thunderbird (not all, looks random)
- When opening such deleted messages, they are marked as read
- When restarting mobile app, this message is no more marked as read
- When click on "trash", message isn't deleted and I'm back to Inbox display

> Does it always? Or sometime?

Often but not for all deleted messages

> Mobile app in background or foreground when you drop things in thunderbird?

Bug happens only when app in background

> In mobile, we tried to debounce (2s) refreshing app realtime. When you open app again, maybe take a little time to see the updating.

Even after 1 day, still same bug. This is totally stable, when a mail is buggy displayed, it will be displayed always

### Comment by chibenwa at 2025-10-03T10:32:54Z

@guimard fixed? Can be closed?

### Comment by guimard at 2025-10-03T14:13:21Z

> [@guimard](https://github.com/guimard) fixed? Can be closed?

Not fixed but behavior change. After few days, mailbox on phone is OK, so bug happens around each week and disappear around each week...

### Comment by guimard at 2025-10-06T08:41:22Z

Today, Tmail app shows more than 20 unread mails that are all deleted for more than one day
