# GitHub issue #1201: Right click to open mailbox in a new TAB

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1201
State: closed
Author: chibenwa
Created at: 2022-11-14T04:51:34Z
Updated at: 2023-03-29T19:37:21Z
Closed at: 2023-03-29T19:37:21Z
Labels: Minor, UX
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1201

## Issue body

# Summary

https://user-images.githubusercontent.com/6928740/201577935-ee8927d9-4de9-40df-b811-544b35b17633.mp4

## Comments

### Comment by dab246 at 2022-11-14T04:55:07Z

@chibenwa  Do we support `right mouse click` in mailbox search mode?

### Comment by chibenwa at 2022-11-14T05:03:40Z

IMO yes, I think so.

### Comment by hoangdat at 2022-11-14T06:07:59Z

Every where we have context menu actions for mailbox, we should support it (except mobile/tablet)

### Comment by chibenwa at 2023-03-06T10:33:00Z

Done?

### Comment by dab246 at 2023-03-06T11:01:33Z

@chibenwa  
- We now support opening `Open new tab` with app's `context menu` for each mailbox.

<img width="456" alt="Screenshot 2023-03-06 at 18 01 56" src="https://user-images.githubusercontent.com/80730648/223092615-95eacad2-5995-43c2-b512-3e6749f671f8.png">


- If you want us to add support for the browser's `right mouse click` feature to open the `context menu` then please reopen this issue so we can implement it.

<img width="127" alt="Screenshot 2023-03-06 at 18 00 58" src="https://user-images.githubusercontent.com/80730648/223092450-c420f3b2-aac2-431d-8916-d997aa3f3599.png">

### Comment by chibenwa at 2023-03-06T11:07:20Z

Limitation from underlying library right?

### Comment by dab246 at 2023-03-06T11:12:19Z

That's right. But IMO, we have a way to implement it. I think It is quite necessary for a browser.

### Comment by dab246 at 2023-03-21T07:19:24Z

`Right mouse click` is not supported due to browser web view issue. #1634
