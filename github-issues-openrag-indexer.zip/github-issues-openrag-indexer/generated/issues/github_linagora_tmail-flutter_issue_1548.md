# GitHub issue #1548: [Manage Account] [Fowarding] User cannot switch off a swipe button named Keep a copy of the email in inbox

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1548
State: closed
Author: QuangHoang1210
Created at: 2023-03-06T10:21:12Z
Updated at: 2023-03-29T19:38:40Z
Closed at: 2023-03-29T19:38:40Z
Labels: bug, Minor
Assignees: nqhhdev
URL: https://github.com/linagora/tmail-flutter/issues/1548

## Issue body

User cannot switch off the swipe button

![Image](https://user-images.githubusercontent.com/124866146/223082963-9eaed3f8-a42f-44a3-91ed-1d4bc379f9de.png)

## Comments

### Comment by chibenwa at 2023-03-06T10:34:39Z

If you add a forward user, are you able to change this option?

### Comment by QuangHoang1210 at 2023-03-06T10:36:52Z

@chibenwa  Yes I can swipe off if I already add a foward user 🗡

### Comment by chibenwa at 2023-03-06T10:57:22Z

How about hiding "keep local copy" when the list of forward is empty?

(only show the icon when it is "actionnable")

### Comment by nqhhdev at 2023-03-16T03:29:05Z

I'm using account: 29

Step 1 : I call `Forward/get` and received a response 
Request
```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "com:linagora:params:jmap:forward"
    ],
    "methodCalls": [
        [
            "Forward/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "ids": [
                    "singleton"
                ]
            },
            "c0"
        ]
    ]
}
```
Response
```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Forward/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "notFound": [],
                "state": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
                "list": [
                    {
                        "id": "singleton",
                        "localCopy": true,
                        "forwards": []
                    }
                ]
            },
            "c0"
        ]
    ]
}
``` 

Step 2: I set `localCopy = false` by `Forward/set` then call `Forward/get`

Request 
```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "com:linagora:params:jmap:forward"
    ],
    "methodCalls": [
        [
            "Forward/set",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "update": {
                    "singleton": {
                        "id": "singleton",
                        "localCopy": false,
                        "forwards": []
                    }
                }
            },
            "c0"
        ],
        [
            "Forward/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "ids": [
                    "singleton"
                ]
            },
            "c1"
        ]
    ]
}
```

Response 

```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Forward/set",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "newState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
                "updated": {
                    "singleton": {}
                }
            },
            "c0"
        ],
        [
            "Forward/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "notFound": [],
                "state": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
                "list": [
                    {
                        "id": "singleton",
                        "localCopy": true,
                        "forwards": []
                    }
                ]
            },
            "c1"
        ]
    ]
}
```

cc: @Arsnael  Help me check it, thanks u so much

### Comment by Arsnael at 2023-03-16T04:01:48Z

@nqhhdev Hi!

I took a look, so I can confirm this behavior. But I can tell you as well that, according to our doc, this behavior is expected: https://github.com/linagora/tmail-backend/blob/master/docs/modules/ROOT/pages/tmail-backend/jmap-extensions/forwards.adoc#forward-object

Quote : "If the forwards list is empty the feature is considered disabled and no rewriting takes place."

So as long as forwards list is empty, the backend consider this as disabled. 

Two solutions here:
- you adapt the front to match the definition of the jmap spec written and established on the back (aka list empty? button is disabled)
- or you think this behavior is wrong but then please see with the PO @chibenwa  first for taking such a decision (cc @hoangdat as well)

Thanks :)

### Comment by nqhhdev at 2023-03-16T04:46:41Z

@Arsnael thanks u, @QuangHoang1210 check it broo

### Comment by dab246 at 2023-03-16T04:56:23Z

> @nqhhdev Hi!
> 
> I took a look, so I can confirm this behavior. But I can tell you as well that, according to our doc, this behavior is expected: https://github.com/linagora/tmail-backend/blob/master/docs/modules/ROOT/pages/tmail-backend/jmap-extensions/forwards.adoc#forward-object
> 
> Quote : "If the forwards list is empty the feature is considered disabled and no rewriting takes place."
> 
> So as long as forwards list is empty, the backend consider this as disabled.
> 
> Two solutions here:
> 
> * you adapt the front to match the definition of the jmap spec written and established on the back (aka list empty? button is disabled)
> * or you think this behavior is wrong but then please see with the PO @chibenwa  first for taking such a decision (cc @hoangdat as well)
> 
> Thanks :)

So why when `forwards` list is empty but we still get `localCopy` as true, when we make api call `Forward/get`. 
IMO, We should reconsider this. @Arsnael 

Request: 
```json
{
    "using": [
        "urn:ietf:params:jmap:core",
        "com:linagora:params:jmap:forward"
    ],
    "methodCalls": [
        [
            "Forward/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "ids": [
                    "singleton"
                ]
            },
            "c0"
        ]
    ]
}
```

Response:
```json
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Forward/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "notFound": [],
                "state": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
                "list": [
                    {
                        "id": "singleton",
                        "localCopy": true,
                        "forwards": []
                    }
                ]
            },
            "c0"
        ]
    ]
}
```

### Comment by Arsnael at 2023-03-16T05:09:01Z

@dab246 Read again the doc I quoted:

"If the forwards list is empty the feature is considered disabled and no rewriting takes place."

No rewriting taking place meaning we don't update as we consider this disabled anyways with the list empty.

And as said, this is how we defined it initially with the PO, if not happy with it, ask the PO @chibenwa , not me, if it's not more logical to change it, as I'm not responsible for such a decision

And you would be kind to stop making me repeating myself x times on things I already clarified, thanks

### Comment by dab246 at 2023-03-16T06:36:10Z

I've read `DOCS` and it doesn't make sense because of your implementation. I only suggest for you to consider. If you find it annoying then ignore it, it doesn't have to be so stressful. To me it's too simple. To make a good product, it is necessary to first absorb the opinions of users, the community, and other developers. THANKS

### Comment by Arsnael at 2023-03-17T03:32:01Z

> I've read `DOCS` and it doesn't make sense because of your implementation. I only suggest for you to consider. If you find it annoying then ignore it, it doesn't have to be so stressful. To me it's too simple. To make a good product, it is necessary to first absorb the opinions of users, the community, and other developers. THANKS

The way you present that is not really open minded either IMO? I don't say your suggestion is stupid, but saying that ours "doesn't make sense" is over exaggerated as well?

Sure we could change that behavior... But what @chibenwa suggested above (knowing the current behavior he validated)  https://github.com/linagora/tmail-flutter/issues/1548#issuecomment-1455912493 makes sense too?

> How about hiding "keep local copy" when the list of forward is empty?
> (only show the icon when it is "actionnable")

I mean... that the local copy is enabled, or not... At the end of the day it's only valid if your forward list is not empty... as long as it's empty, no local copy correct? Because no forward... So hiding the option in this case makes sense too IMO.

Honestly in my point of view, both current behavior and your suggestion make sense in their own way. You are the only one that seems to have a big problem somehow with the current behavior, thinking "it doesn't make sense".

My 2 cents.

### Comment by chibenwa at 2023-03-17T06:09:09Z

Please @dab246 make concrete api evolution proposals, i would happily review and validate those.

Also api topic is orthogonal to the ux ui topics. I insist on the ux enhancement: when there is no forwards, we cant turn off local copy... cause we always want the emails to be delivered.

Now, lets be humble, i am not  a ba expert so @dieptran88 please make a proposal.

Last, but far from least, we all need to step down, and adopt open minded, controlled, non violent written discussion. Example: forbid yourself to use "you" as it antagonize. Use "we" instead.

Finally, there are more urgent things that a config button. I would hapily target more urgent topics first.
