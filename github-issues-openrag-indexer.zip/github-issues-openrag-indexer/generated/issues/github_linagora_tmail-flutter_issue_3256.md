# GitHub issue #3256: Web App is very slow to load due to misconfiguration of cache-control

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3256
State: closed
Author: guimard
Created at: 2024-11-06T06:40:34Z
Updated at: 2025-01-07T07:35:49Z
Closed at: 2025-01-07T07:35:48Z
Labels: bug
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/3256

## Issue body

### Description

When starting Tmail-Web on a new window (not private), all content is reloaded without using HTTP-304 mechanism. 

### Expected result

Use cache or update headers to allow HTTP-304 mechanism

### Current behavior

![Tmail-net](https://github.com/user-attachments/assets/865ebaaa-4c5a-438f-b220-dd4e8339f3fe)

### Context

Firefox (same with Chrome)

### Additional information

Render app unusable inside customer network

## Comments

### Comment by dab246 at 2024-11-06T07:03:48Z

IMO, Also related https://github.com/linagora/tmail-flutter/issues/1507#issuecomment-1543678315

### Comment by chibenwa at 2024-11-06T07:15:00Z

Relevant config files:
 - NGINX default conf https://github.com/linagora/tmail-flutter/blob/b2bf317742cc193f3eb7884742f05d130d88be97/server/nginx.conf#L24
 - File to override is `/etc/nginx/nginx.conf` CF https://github.com/linagora/tmail-flutter/blob/b2bf317742cc193f3eb7884742f05d130d88be97/Dockerfile#L19

What chatGPT says about

```
    add_header Cache-Control "no-cache";
    etag on;
```

![image](https://github.com/user-attachments/assets/ae6fbe85-d868-49aa-9265-2e16b6c79bf1)

### Comment by chibenwa at 2024-11-06T07:19:01Z

![image](https://github.com/user-attachments/assets/cd8a0b20-31f5-4b7e-822b-d95c28ee841f)

### Comment by guimard at 2024-11-06T10:14:05Z

> Relevant config files:
> 
>     * NGINX default conf https://github.com/linagora/tmail-flutter/blob/b2bf317742cc193f3eb7884742f05d130d88be97/server/nginx.conf#L24
> 
>     * File to override is `/etc/nginx/nginx.conf` CF https://github.com/linagora/tmail-flutter/blob/b2bf317742cc193f3eb7884742f05d130d88be97/Dockerfile#L19
> 
> 
> What chatGPT says about
> 
> ```
>     add_header Cache-Control "no-cache";
>     etag on;

The current experience shows that in SSL context, even with Etag, the "Cache-Control: no-cache" disallow the 304 mechanism

### Comment by chibenwa at 2024-11-06T14:39:55Z

@guimard which evolution to the nginx conf file would you suggest?

### Comment by guimard at 2024-11-07T02:19:30Z

> @guimard which evolution to the nginx conf file would you suggest?

For all JS/TTF/CSS : `Cache-Control: public`. But then it could be better to add version in JS to help upgrades.

Maybe the problem is in Service-Worker ?

### Comment by dab246 at 2024-11-07T04:21:47Z

We are currently using Flutter's default caching mechanism via Service Worker. Flutter Web automatically creates a Service Worker file (`flutter_service_worker.js`) when building the project with the command `flutter build web`. This file will manage caching for the application's resources.

- So when Service Worker is working properly, the user reloads the page or closes and reopens the tab, the resources will be loaded from the cache.

<img width="1367" alt="Screenshot 2024-11-07 at 11 02 14" src="https://github.com/user-attachments/assets/e3085164-7ca0-4ffd-ba96-0773546fd92c">


- When Service Worker is turned off, the resources will be loaded from the network

<img width="1363" alt="Screenshot 2024-11-07 at 11 04 17" src="https://github.com/user-attachments/assets/3b5619e6-df89-4092-a2ba-29fc5ff439a6">



In addition, we have now added the parameter `flutter_service_worker_version` to `flutter_service_worker.js` to manage the version of Service Worker and help the browser recognize when there is a change.

<img width="729" alt="Screenshot 2024-11-07 at 11 14 18" src="https://github.com/user-attachments/assets/615440a1-d1ea-4dbd-9a79-752aa248c7a9">



So by using `flutter_service_worker.js` we have almost managed most of the caching. But we can still add Cache-Control on the NGINX server) to provide caching instructions for other resources.

### Comment by guimard at 2024-11-07T04:43:04Z

> We are currently using Flutter's default caching mechanism via Service Worker. Flutter Web automatically creates a Service Worker file (`flutter_service_worker.js`) when building the project with the command `flutter build web`. This file will manage caching for the application's resources.
> 
>     * So when Service Worker is working properly, the user reloads the page or closes and reopens the tab, the resources will be loaded from the cache.

SO either the service worker doesn't work properly, either Fluter promise is a lie...

>     * When Service Worker is turned off, the resources will be loaded from the network

> So by using `flutter_service_worker.js` we have almost managed most of the caching. But we can still add Cache-Control on the NGINX server) to provide caching instructions for other resources.

The experience proves that the cache is never used at least with Firefox and Chromium _(also with Linagora Tmail)_

### Comment by tddang-linagora at 2024-11-08T04:17:14Z

>The experience proves that the cache is never used at least with Firefox and Chromium (also with Linagora Tmail)

https://github.com/user-attachments/assets/9b03ca2d-1578-4712-8c59-2352bb3562ec

@guimard Cache is, in fact, used as shown above. So does it matter if the response code is 200 or 304 if the resources are loaded from the cache anyway?

### Comment by guimard at 2024-11-08T04:44:04Z

> > The experience proves that the cache is never used at least with Firefox and Chromium (also with Linagora Tmail)
> 
> Screen.Recording.2024-11-08.at.11.15.12.mov
> 
> @guimard Cache is, in fact, used as shown above. So does it matter if the response code is 200 or 304 if the resources are loaded from the cache anyway?

In Firefox devtools, 200 are grey _(or hidden)_ when used from cache. Here we can see server response, so each 200 non-grey is a real query

### Comment by tddang-linagora at 2024-11-08T06:12:08Z

>In Firefox devtools, 200 are grey (or hidden) when used from cache.

This site begs to differ.
https://firefox-source-docs.mozilla.org/devtools-user/application/service_workers/index.html#testing-a-service-worker-cache

![Screenshot 2024-11-08 at 13 11 50](https://github.com/user-attachments/assets/efd34436-bac5-4288-b3d2-143d2e7fccf7)

### Comment by guimard at 2024-11-08T06:29:08Z

> > In Firefox devtools, 200 are grey (or hidden) when used from cache.
> 
> This site begs to differ. https://firefox-source-docs.mozilla.org/devtools-user/application/service_workers/index.html#testing-a-service-worker-cache

You're right, the service worker uses the cache. So why is it sometimes so slow ?

### Comment by tddang-linagora at 2024-11-08T06:36:49Z

>SO why is it sometimes so slow ?

Without any solid evidence, I can't confirm anything. But one thing is true, the slow you're "sometimes" experiencing is not about the cache.

### Comment by guimard at 2024-11-09T05:16:10Z

> > SO why is it sometimes so slow ?
> 
> Without any solid evidence, I can't confirm anything. But one thing is true, the slow you're "sometimes" experiencing is not about the cache.

Hi,

looking at tmail-web logs, I can see that all service-worker requests are all pushed to the server, then the service-worker seems to never use the cache. If you need "evidences", I can share the logs

### Comment by tddang-linagora at 2024-11-11T02:02:10Z

>If you need "evidences", I can share the logs

Please send me an email with the logs. You can reach me at tddang@linagora.com

### Comment by tddang-linagora at 2024-11-11T09:56:48Z

>I can see that all service-worker requests are all pushed to the server

Yes, because we are using `no-cache` in `Cache-Control` header? According to:

https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control#directives

"If you want caches to **always check for content updates** while **reusing stored content**, no-cache is the directive to use."

>then the service-worker seems to never use the cache

Again, may not be true. I already said above that cache is indeed used.

### Comment by guimard at 2024-11-12T02:27:15Z

The logs I shared to you show that JS _(such as main_dart)_ and TTF files are downloaded at each connection from the server using a 200, not a 304 response. So where do you see any use of the cache for this ?

### Comment by chibenwa at 2024-11-14T07:01:55Z

For the record this is static content

```
# docker exec -ti tmail-web ls -lah /usr/share/nginx/html/ 
total 9M     
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 .
drwxr-xr-x    1 root     root        4.0K Oct  3 00:58 ..
-rw-r--r--    1 root     root          32 Oct 24 11:15 .last_build_id
-rw-r--r--    1 root     root          67 Oct 24 11:15 .last_build_id.gz
-rw-r--r--    1 root     root         497 Oct  2 16:07 50x.html
-rw-r--r--    1 root     root         350 Oct  2 16:07 50x.html.gz
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 assets
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 canvaskit
-rw-r--r--    1 root     root        1.8K Oct 24 11:15 favicon.svg
-rw-r--r--    1 root     root         860 Oct 24 11:15 favicon.svg.gz
-rw-r--r--    1 root     root         730 Oct 24 11:15 firebase-messaging-sw.js
-rw-r--r--    1 root     root         384 Oct 24 11:15 firebase-messaging-sw.js.gz
-rw-r--r--    1 root     root        7.6K Oct 24 11:14 flutter.js
-rw-r--r--    1 root     root        2.9K Oct 24 11:14 flutter.js.gz
-rw-r--r--    1 root     root        7.9K Oct 24 11:14 flutter_bootstrap.js
-rw-r--r--    1 root     root        3.1K Oct 24 11:14 flutter_bootstrap.js.gz
-rw-r--r--    1 root     root       33.1K Oct 24 11:15 flutter_service_worker.js
-rw-r--r--    1 root     root       11.6K Oct 24 11:15 flutter_service_worker.js.gz
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 i18n
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 icons
-rw-r--r--    1 root     root        5.4K Oct 24 11:14 index.html
-rw-r--r--    1 root     root        1.6K Oct 24 11:14 index.html.gz
-rw-r--r--    1 root     root        1.1K Oct 24 11:15 login-callback.html
-rw-r--r--    1 root     root         524 Oct 24 11:15 login-callback.html.gz
-rw-r--r--    1 root     root         662 Oct 24 11:15 logout-callback.html
-rw-r--r--    1 root     root         337 Oct 24 11:15 logout-callback.html.gz
-rw-r--r--    1 root     root        6.4M Oct 24 11:15 main.dart.js
-rw-r--r--    1 root     root        1.8M Oct 24 11:15 main.dart.js.gz
-rw-r--r--    1 root     root       14.8K Oct 24 11:15 main.dart.js_1.part.js
-rw-r--r--    1 root     root        5.1K Oct 24 11:15 main.dart.js_1.part.js.gz
-rw-r--r--    1 root     root        1.9K Oct 24 11:15 main.dart.js_2.part.js
-rw-r--r--    1 root     root         984 Oct 24 11:15 main.dart.js_2.part.js.gz
-rw-r--r--    1 root     root         459 Oct 24 11:15 main.dart.js_3.part.js
-rw-r--r--    1 root     root         320 Oct 24 11:15 main.dart.js_3.part.js.gz
-rw-r--r--    1 root     root      331.8K Oct 24 11:15 main.dart.js_4.part.js
-rw-r--r--    1 root     root       86.5K Oct 24 11:15 main.dart.js_4.part.js.gz
-rw-r--r--    1 root     root       23.0K Oct 24 11:15 main.dart.js_5.part.js
-rw-r--r--    1 root     root        8.2K Oct 24 11:15 main.dart.js_5.part.js.gz
-rw-r--r--    1 root     root         712 Oct 24 11:15 main.dart.js_6.part.js
-rw-r--r--    1 root     root         474 Oct 24 11:15 main.dart.js_6.part.js.gz
-rw-r--r--    1 root     root       95.5K Oct 24 11:15 main.dart.js_7.part.js
-rw-r--r--    1 root     root       25.6K Oct 24 11:15 main.dart.js_7.part.js.gz
-rw-r--r--    1 root     root         447 Oct 24 11:15 main.dart.js_8.part.js
-rw-r--r--    1 root     root         322 Oct 24 11:15 main.dart.js_8.part.js.gz
-rw-r--r--    1 root     root         943 Oct 24 11:15 manifest.json
-rw-r--r--    1 root     root         315 Oct 24 11:15 manifest.json.gz
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 splash
-rw-r--r--    1 root     root          78 Oct 24 11:15 version.json
-rw-r--r--    1 root     root          89 Oct 24 11:15 version.json.gz
drwxr-xr-x    1 root     root        4.0K Nov 13 15:43 worker_service
```

### Comment by hoangdat at 2024-11-15T10:45:37Z

hi @guimard 
cc @chibenwa 
PR: https://github.com/linagora/tmail-flutter/pull/3263 

We deployed the fixed for cache in `https://mail.lin-saas.dev/`. 
If you can, please ping me and verify this.

Thanks

### Comment by hoangdat at 2025-01-07T07:35:48Z

- disabled service worker in v0.14.7
