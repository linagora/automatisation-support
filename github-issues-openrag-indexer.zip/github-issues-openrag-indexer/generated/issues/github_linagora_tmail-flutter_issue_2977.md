# GitHub issue #2977: [🔥Blocking 🔥] Integration_test for Twake Mail project

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2977
State: closed
Author: hoangdat
Created at: 2024-07-03T07:49:08Z
Updated at: 2025-04-28T03:03:31Z
Closed at: 2025-04-28T03:03:31Z
Labels: improvement, integration-test
Assignees: dab246, tddang-linagora
URL: https://github.com/linagora/tmail-flutter/issues/2977

## Issue body

### Desc:
At the moment we don't have a test framework for all platform which can interact with 'native' component also. So we need to have separated test suits for Mobile and Web.

#### Mobile:
- [x] Make the comparison between: Patrol and Maetro 
- [ ] ADR
- [x] How to integrate with CICD?
- [ ] Any other extra fee? yes, with small test cases we can choose with Firebase 

#### Web:
- can not use `Flutter Drive` because it does not support interact with web component (Fx: SSO)
- [x] setup Selenium
- [x] ADR
- [x] How to integrate with CICD?

- [ ] [Blocking 🔥 🔥 🔥] Semantic not work well with PortalTarget (https://pub.dev/packages/flutter_portal): can not close overlay when click outside overlay.

## Comments

### Comment by hoangdat at 2024-07-05T02:39:02Z

### Selenium:
- [x] Run same test case for multiple platform (WebDriver)? Log in each run?
- [ ] CICD: 
  - how to run without GUI?
  - how to set up CICD? Schedule? Only `master`?

### Comment by hoangdat at 2024-07-05T02:42:01Z

### Compare between Patrol vs Maestro
- [x] try to run Maestro
- [x] Compare in writing test-case?
- [x] Patrol: install new app in every test case 
- [x] Maestro: install only app? how to isolate test?
- [x] how to install in CICD

### Comment by hoangdat at 2024-07-05T02:46:46Z

- [x] setup integration_test for web
- [x] setup integration_test for mobile (Android/iOS)

### Comment by hoangdat at 2024-07-10T02:19:58Z

- [x] @tk-nguyen is supporting in CICD https://github.com/linagora/tmail-flutter/issues/2990

### Comment by hoangdat at 2024-07-10T02:22:54Z

- [ ] document about selenium
  - ADR
  - prepare for workshop of selenium

### Comment by tddang-linagora at 2024-07-19T03:09:28Z

@quantranhong1999 

- [ ] Setup test container for TMail backend & frontend

### Comment by tddang-linagora at 2024-07-19T03:15:43Z

@tddang-linagora 

- [x] Write test case using basic auth with local Docker container

### Comment by tddang-linagora at 2024-07-23T02:42:47Z

Drop Maestro
- Cannot work with Webview
- Tap actions are 99% position base, very unreliable

### Comment by hoangdat at 2024-07-23T03:12:35Z

- POC for mobile: #2953

### Comment by hoangdat at 2024-08-09T02:28:18Z

@dab246 continue to handle blocking point in overlay widget with semantic

### Comment by hoangdat at 2024-08-13T02:56:53Z

### investigating: 
- ❌ use `OverlayPortal` to replace `PortalTarget` -> Not go this way
- 🔥  NOT WORK WELL: `TextField` of Advanced Search, Composer was miss focus
- ✅ Popup: click item will work well
- ✅ Context menu: same as pop up
- ✅ Text field in some dialog: rename, contact view loss focus

### Comment by hoangdat at 2025-04-28T03:03:31Z

Latest update:
- dont ensure semantic by default in Flutter side, will enable it when running test in browser.
- try to wrap Semantic widget base on the request from QA team.
- Integration tests are adding in: https://github.com/linagora/twake-workplace-private/tree/main/e2e/tests
