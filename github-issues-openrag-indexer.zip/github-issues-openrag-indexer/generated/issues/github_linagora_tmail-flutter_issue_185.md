# GitHub issue #185: [Bug] Can not display all parts of email which have multiple html part

## Metadata

Repository: linagora/tmail-flutter
Issue number: 185
State: closed
Author: hoangdat
Created at: 2021-10-15T02:07:00Z
Updated at: 2021-10-17T22:59:16Z
Closed at: 2021-10-17T22:59:16Z
Labels: bug
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/185

## Issue body

### Description

### Current behavior

![image.png](https://images.zenhubusercontent.com/5f7d8ef759d36aecc684e2a4/9cdfaac2-74a9-4992-8758-33be5e981f39)![image.png](https://images.zenhubusercontent.com/5f7d8ef759d36aecc684e2a4/16e87840-e0e9-42be-9777-d24a212fa325)

### Expected result

All parts of email are displayed well

## Comments

### Comment by chibenwa at 2021-10-15T02:13:56Z

![Screenshot from 2021-10-15 09-13-22](https://user-images.githubusercontent.com/6928740/137421480-f69cf4da-1303-40d6-bdb1-218ce88425ec.png)


In thunderbird

### Comment by dab246 at 2021-10-15T02:39:31Z

Forward such error emails to me.

### Comment by chibenwa at 2021-10-15T02:54:42Z

> Forward such error emails to me.

Done (upload + Email/import + EmailSubmission/set)

### Comment by dab246 at 2021-10-15T03:12:03Z

![Screen Shot 2021-10-15 at 10.11.06.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/f206b48a-3bfd-490e-8d8c-dbcac0466051)

Why only 1 body. The email you tested has 2 bodies error??

### Comment by chibenwa at 2021-10-15T03:16:00Z

> Why only 1 body. The email you tested has 2 bodies error??

This is a long term bug of OpenPaaS that cannot be solved with the JMAP Draft specification.

One good opportunity to be better than OpenPaaS - there will be many more!

### Comment by dab246 at 2021-10-15T03:19:58Z

Oh, Please email the error to userb@qa.open-paas.org for me.

### Comment by chibenwa at 2021-10-15T04:03:00Z

![Screenshot from 2021-10-15 11-02-20](https://user-images.githubusercontent.com/6928740/137430345-62e27ffc-7b57-4686-a5f8-f5bac749c8bd.png)

Done

### Comment by hoangdat at 2021-10-15T04:25:06Z

How to create multiple-part email, I tried but not success @chibenwa 
```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail",
        "urn:ietf:params:jmap:submission"
    ],
    "methodCalls": [
        [
            "Email/set",
            {
                "accountId": "{{accountId}}",
                "create": {
                    "aaaaaa": {
                        "mailboxIds": {
                            "5dfb3290-0a14-11ec-b57c-2fef1ee78d9e": true
                        },
                        "from":[{
                            "email":"userb@qa.open-paas.org"
                        }],
                        "to":[{
                            "email":"userd@qa.open-paas.org"
                        }],
                        "Subject":"test onSuccessUpdateEmail",
                        "htmlBody": [
                            {
                                "partId": "mmm",
                                "type": "text/html"
                            },
                            {
                                "partId": "mmm1",
                                "type": "text/html"
                            }
                        ],
                        "bodyValues": {
                            "mmm": {
                                "value": "<!DOCTYPE html> <html> <body> <p><b>body 1</b></p><br><br></body> </html>",
                                "isTruncated": false,
                                "isEncodingProblem": false
                            },
                            "mmm1": {
                                "value": "<!DOCTYPE html> <html> <body> <p><b>body 2</b></p><br><br></body> </html>",
                                "isTruncated": false,
                                "isEncodingProblem": false
                            }
                        }
                    }
                }
            },
            "c1"
        ],
        [
            "EmailSubmission/set",
            {
                "accountId": "{{accountId}}",
                "create": {
                    "a1234": {
                        "emailId": "#aaaaaa",
                        "envelope": {
                            "mailFrom": {
                                "email": "userb@qa.open-paas.org"
                            },
                            "rcptTo": [{
                                "email": "userd@qa.open-paas.org"
                            }]
						}
                    }
                },
                "onSuccessUpdateEmail": {
                    "#a1234": {
                        "mailboxIds": {
                            "abb99c10-18d9-11eb-a677-2990b970028d": true
                        }
                    }
                }
            },
            "c2"
        ]
    ]
}
```

### Comment by chibenwa at 2021-10-15T04:31:11Z

`POST https://jmap.linagora.com/upload/accountId`

With body 

```
Return-Path: <btellier@linagora.com>
To: btellier@linagora.com
From: "btellier@linagora.com" <btellier@linagora.com>
Subject: r
Message-ID: <d16692ec-1ca2-c0cf-cd24-5a170d5fbd7b@linagora.com>
Date: Thu, 14 Oct 2021 22:55:39 +0700
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101
 Thunderbird/78.13.0
MIME-Version: 1.0
Content-Type: multipart/mixed;
 boundary="------------2E953A9FBDA2E6E028197ABC"
Content-Language: en-US

This is a multi-part message in MIME format.
--------------2E953A9FBDA2E6E028197ABC
Content-Type: text/html; charset=utf-8
Content-Transfer-Encoding: 7bit

<p>body 1</p>

--------------2E953A9FBDA2E6E028197ABC
Content-Type: text/html; charset=utf-8
Content-Transfer-Encoding: 7bit

<p>body 2</p>

--------------2E953A9FBDA2E6E028197ABC--

```

Then `POST https://jmap.linagora.com/jmap`

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
  "methodCalls": [
    ["Email/import",
      {
        "accountId": "account id",
        "emails": {
           "C42": {
             "blobId": "blobId of the uploaded blob",
             "mailboxIds": {
               "mailbox id of your inbox": true
             },
             "keywords": {},
             "receivedAt": "2021-11-13T15:08:56Z"
           }
         }
      },
      "c1"]
  ]
}
```

### Comment by chibenwa at 2021-10-15T04:31:43Z

We do not need to be able to create them. Reading them is enough.
