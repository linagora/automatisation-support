# GitHub issue #315: Unicode character is not supported (vietnamese)

## Metadata

Repository: linagora/tmail-flutter
Issue number: 315
State: closed
Author: hoangdat
Created at: 2022-03-09T03:46:12Z
Updated at: 2022-03-30T04:52:42Z
Closed at: 2022-03-30T04:11:35Z
Labels: 
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/315

## Issue body

<img width="267" alt="image" src="https://user-images.githubusercontent.com/6462404/157368900-a1fb8cac-01be-4e84-9880-d3317e8fb25e.png">

### DoD:

why text string is not support Vietnamese. 'Trả lời' - 'Chuyển tiếp'

## Comments

### Comment by chibenwa at 2022-03-09T05:14:03Z

I saw that one too...

Can you please share the JMAP requests you used to send the mail?

### Comment by hoangdat at 2022-03-09T07:30:56Z

> I saw that one too...
> 
> Can you please share the JMAP requests you used to send the mail?

you mention about the cause of undelivered mail?

I mention about the text in Vietnamese "Trả lời" and "Chuyển tiếp"

### Comment by chibenwa at 2022-03-09T08:46:16Z

I succeed to send myself a mail with text `Trả lời" and "Chuyển tiếp`...

### Comment by chibenwa at 2022-03-14T03:42:32Z

Up!

Can you please try to share with me the JMAP exchanges that lead to this bug?

### Comment by hoangdat at 2022-03-14T03:45:21Z

no no, only the problem related to internationalize for non-ascii character. Maybe this kind of issue occurred after applied Web-late

### Comment by chibenwa at 2022-03-14T03:48:16Z

> no no, only the problem related to internationalize for non-ascii character. Maybe this kind of issue occurred after applied Web-late

Mmhhh what ever the messing up on mobile dise, we did end up trying to send an invalid mail, this means that the JMAP James stack likely have non - complients behavour.

Please enable a debug mode where you log all JMAP requests / responses, so that if it happens to you again you could look at the logs and share with me the exact JMAP requests...

### Comment by dab246 at 2022-03-30T04:00:19Z

This error no longer appears. It is possible that the fonts in use do not support unicode. Currently we only use the only font Inter. 

![Simulator Screen Shot - iPhone 11 Pro Max - 2022-03-30 at 10.58.01.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/2d2d77fd-3d4d-4cd1-8b8b-d9170e1cdac6)

### Comment by chibenwa at 2022-03-30T04:11:35Z

Unrelated to the mobile app, this is indeed a backend problem: attachments were not encoded in base64 when sent.

See https://github.com/apache/james-project/pull/927

### Comment by hoangdat at 2022-03-30T04:31:54Z

yes, maybe `Inter` font is better than `SF pro`.

nothing related to back-end :)

### Comment by chibenwa at 2022-03-30T04:52:01Z

I'm speaking of 

<img width="267" alt="157368900-a1fb8cac-01be-4e84-9880-d3317e8fb25e" src="https://user-images.githubusercontent.com/6928740/160753893-b53549b0-8429-4b2c-87f4-cd90f64f72c8.png">


Nothing to do with font!
