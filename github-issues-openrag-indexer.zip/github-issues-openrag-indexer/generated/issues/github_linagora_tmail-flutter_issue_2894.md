# GitHub issue #2894: IMAP Mailbox Name Attributes for Spam folder is Junk

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2894
State: closed
Author: jip149
Created at: 2024-05-26T00:59:02Z
Updated at: 2024-07-17T00:25:21Z
Closed at: 2024-07-16T03:21:08Z
Labels: bug, interoperability
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/2894

## Issue body

### Description

JMAP spec states that mailboxes role must be one of [IMAP Mailbox Name Attributes](https://www.iana.org/assignments/imap-mailbox-name-attributes/imap-mailbox-name-attributes.xhtml)

According to this link, the attribute name for Junk/Spam folder is Junk and not Spam.

As a consequence, the mailbox used by the server is ignored, and a Spam folder is created instead.

This can be reproduced by connecting to a Stalwart server.

## Comments

### Comment by chibenwa at 2024-05-27T07:52:51Z

Hi,

Thanks for spotting this: indeed on point!

As early adopters of the JMAP specification, LINAGORA used the `spam` role instead. We would need a smooth transition to `Junk` I thus believe.... In order to ease this transition, Twake Mail frontend should interprete both roles `Junk` and `Spam` the same way....

@jip149 would you like to give such a contribution a go?

### Comment by chibenwa at 2024-05-27T07:58:56Z

CF https://issues.apache.org/jira/browse/JAMES-4040

### Comment by jip149 at 2024-05-29T18:08:20Z

If I understand correctly: both JAMES and twake incorrectly implement the JMAP RFC. Since they are mostly used together, it works as expected for most users.

So what needs to be done:
- update twake mail to use both the correct `Junk` role and `Spam` role to work with both correct and incorrect servers
- update JAMES to use the correct `Junk` role
- maybe wait a few years for all servers to use the correct role, and delete support for incorrect `Spam` role

I'm willing to spend a bit of time trying to fix tmail-flutter. I suppose `jmap-dart-client` needs to be fixed as well. I'll let you know if I manage to send a PR. That might take a bit of time as I need to set up the dev environment and get a hang of the codebase.

I must admit I cannot make sense of your last comment. I don't see how this is related to scaling and channel number.

### Comment by chibenwa at 2024-05-29T20:05:38Z

> I must admit I cannot make sense of your last comment. I don't see how this is related to scaling and channel number.

Deleted, I likely commented on the wrong PR, sorry.

### Comment by chibenwa at 2024-06-13T13:35:13Z

Please @hoangdat do not forget to work on this.
Interoperability is a must.

### Comment by jip149 at 2024-06-30T18:42:37Z

Hello @chibenwa, @hoangdat,

I've started working on this. I published a PR in jmap-dart-client, however, I have not yet managed to compile TwakeMail to fully test this.

I believe it is because the flutter sdk version I have installed is too recent. Could you tell me what flutter sdk version do you use?

### Comment by dab246 at 2024-07-01T02:38:04Z

> Hello @chibenwa, @hoangdat,
> 
> I've started working on this. I published a PR in jmap-dart-client, however, I have not yet managed to compile TwakeMail to fully test this.
> 
> I believe it is because the flutter sdk version I have installed is too recent. Could you tell me what flutter sdk version do you use?

Currently, TwakeMail is working on flutter sdk version `3.16.0`

### Comment by jip149 at 2024-07-01T16:07:21Z

The #2969 PR is not needed to fix this if PR#89 for `jmap-dart-client` is merged, but I believe it should still use the correct role in the source code, even if `jmap-dart-client` does the conversion.

### Comment by jip149 at 2024-07-01T16:08:03Z

Please let me know if there's something else I need to do on the matter.
