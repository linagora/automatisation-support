# GitHub issue #87: [Story] As an user, i want to preview attached file in message 

## Metadata

Repository: linagora/tmail-flutter
Issue number: 87
State: closed
Author: dieptran88
Created at: 2021-09-13T09:52:28Z
Updated at: 2023-04-05T02:51:56Z
Closed at: 2023-04-05T02:51:55Z
Labels: story:writing
Assignees: dieptran88
URL: https://github.com/linagora/tmail-flutter/issues/87

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition

- Given that I am a Tmail app user 
- After logged-in successfully to the app, I open an email with attachments 
- I can see the list of attachment above the email body part
- Each attached file will contain information: File name, file size, file icon and an download button
- When I tap on an attachment, the file is downloaded in temporary folder with an downloading icon on the file:
   -  If a file is not already downloaded to temporary folder, there is the download icon in the attachment
   - If a file is being downloaded  to temporary folder, there is the loading icon in the attachment
   - If a file is downloaded  to temporary folder, there is the "file" icon in the attachment: In this case when I tap the attachment, the preview is opened without waiting to download. 
- When the downloading to temporary is completed, it will open a preview of the selected attachment in full-screen
- If the file format is not supported to preview, it will display in a blank page with a message :"Cannot preview file".
- I can see download button on the top right of preview screen to download file 
- I can click button Close on top left of the preview screen to come back previous screen 


[Back to Summary](#summary)

## Screenshots

![download attachment](https://user-images.githubusercontent.com/68209176/158120042-8bf99d67-8296-41f8-9cdd-f8b4bf50f5e0.png)  ![Group 101 (1)](https://user-images.githubusercontent.com/68209176/158120082-5bbd4e16-e7b7-4c0c-afcb-ade1b79d0cf5.png)

![Group 102 (1)](https://user-images.githubusercontent.com/68209176/158120136-0a6138d5-07f2-4636-860b-3225e7e920af.png) ![image 5 (1)](https://user-images.githubusercontent.com/68209176/158120278-62f11d9b-e5ff-4e92-99f1-be8ea0f52e3c.png)

## Design ticket

https://ci.linagora.com/linagora/lgs/design/-/issues/157

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by dieptran88 at 2022-03-14T06:56:39Z

@hoangdat please review this story

### Comment by chibenwa at 2022-03-14T06:59:36Z

Attachment preview is IMO not a priority.

Thumbnails needs to be handled on the server side, would likely need a JMAP extension, is complex and expensive to operate. IMO we should not even add this to the roadmap.

(its a bad idea)

@dieptran88 do you have **any** email client webmail showing attachment previews in mind?

### Comment by dieptran88 at 2022-03-14T07:06:51Z

Other apps like Gmail or Outlook also have this feature, on mobile app

### Comment by chibenwa at 2022-03-14T07:11:12Z

> Other apps like Gmail or Outlook also have this feature

Other apps like GMail or Outlook have hundreds on engineer working on their email offers.

As a PO it's my responsibility to say `"be careful, that optionnal feature is potentially very dangerous, we likely shoud leave without it for the time being"`.

### Comment by dieptran88 at 2022-03-14T07:13:46Z

Yeah sure, I worked on the MOSCOW priority and seem like we have not had a same agreement here @hoangdat

### Comment by hoangdat at 2022-03-14T07:23:43Z

Agree on Benoit's opinion on the priority of this function. But, for this function, we only modify a bit from the flow in UI (logic are still keep like the download), for that reason, I push Diep create this story to get feedback from designer also

### Comment by chibenwa at 2022-03-14T07:25:59Z

> When the downloading to temporary is completed, it will open  a preview of the selected attachment in full-screen

How about proposing a system application for opening the attachment instead ?

(Favor composition in design, it might prevent us from writing a big bloated app that embed PDF, word etc readers....)

### Comment by dieptran88 at 2022-03-14T07:32:37Z

Yes, I thought most of other apps do the same : They open file by using system application

### Comment by chibenwa at 2022-03-14T07:52:12Z

Ok then the term `preview` is not appropriate.

### Comment by hoangdat at 2022-07-29T04:49:27Z

@QA: please verify that story:
```
As a user, I want to open the attachment when I click on it in Email View
```

### Comment by chibenwa at 2023-04-05T02:51:55Z

Thumbnail story https://github.com/linagora/tmail-flutter/issues/1198

I'm closing this story that is in writing mode for 1.5 year now :-)
