# GitHub issue #3782: Bad OIDC error management resulting loosing valid refresh_tokens (mobile app)

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3782
State: closed
Author: guimard
Created at: 2025-06-02T08:11:00Z
Updated at: 2026-04-06T07:41:02Z
Closed at: 2026-04-06T07:41:02Z
Labels: bug, customer
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/3782

## Issue body

### Description

I opened a new issue since I didn't find this known bug into [issues](https://github.com/linagora/tmail-flutter/issues) _(logs provided using debug mode 1 or 2 years ago)_.

### Expected result

When a refresh token exists even is there were network errors since last app use and when user opens Tmail, before prompting user for re-connection, try to reconnect using the current refresh token.

### Current behavior

* User is connected and has a long-term `refresh_token`
* User has network problems without using Tmail app
* Later user opens Tmail-App and is prompted for re-authentication

### Context

Android 14 and android 15 at least, also with other devices _(see smartsla bugs)_

### Additional information

Variable frequency, maybe once per week, maybe 1 per 3/4 months _(but always when using Dubai's airport network)_

## Comments

### Comment by hoangdat at 2025-06-27T02:09:17Z

### Analysis

#### Context
At the moment, we have 2 cases relate to `user be disconnected from mobile app`
- Case 1: Randomly user be disconnected
- Case 2: Relate to 500 response from SSO. It will be addressed in https://github.com/linagora/tmail-flutter/issues/3833

We will focus on Case 1 first, Case 2 is under validation

#### Randomly user be disconnected 
- Flutter, built on Dart, is a single-threaded framework. Dart code runs within isolates, which are similar to threads but with their own isolated memory spaces, communicating via message passing. 
- Our current local DB is [Hive](https://pub.dev/packages/hive). It is not support multi-isolate

- Why need to support `multi-isolate`?
Whenever FCM coming, it will trigger to run an instance of isolate. It will open the DB to get `currentState`, `token` to call JMAP request to show notification. So, sometime multiple FCM make multiple instance access DB (even we debounce 30s). It makes our DB conflict and lost data, write and read operation are not well scheduled. Then whenever user open app, it will also run other isolate, it checks token in DB, sometimes no problem, sometimes data loss.

By the way, multiple isolate access DB also make the inconsistent in email cache -> error in synchronization email

I attached log below. In log, you will see FCM still get the token well around 09.11 AM, but when user opens the app around 09.13 AM, token was not found (even no log between it relate to token)

<details>
    <summary>Log</summary>
<pre>
(2025-06-03, 09:11:34): FcmMessageController::_handleSuccessViewState(): GetAuthenticatedAccountSuccess 
(2025-06-03, 09:11:34): FcmMessageController::_handleSuccessViewState(): LoadingState 
(2025-06-03, 09:11:34): TokenOidcCacheManager::getTokenOidc(): tokenIdHash: 51906823 
(2025-06-03, 09:11:34): HiveCacheConfig::getEncryptionKey(): encryptionKey: AQlFAE7W/NtzJl9nWrtwlOk2oxedIp0VZvQvN/JEh/4= 
(2025-06-03, 09:11:34): TokenOidcCacheManager::getTokenOidc(): tokenCache: TokenOidcCache(eyJhbGciOiJSU..............5N5gVEifmpJbndUa6Xgh_Fot0u53yVF0vIGcw, eyJraWQiO............BvemSfFbwQ, 2025-06-03 15:49:53.086, b0caf04d61f8de8f2f173b8ea938482beb929c6f2524f8defdf90efe79b13245) 
(2025-06-03, 09:11:34): HiveCacheConfig::getEncryptionKey(): encryptionKey: AQlFAE7W/NtzJl9nWrtwlOk2oxedIp0VZvQvN/JEh/4= 
(2025-06-03, 09:11:34): GetStoredTokenOidcInteractor::execute(): TokenOIDC(eyJhbGciOiJSU..............5N5gVEifmpJbndUa6Xgh_Fot0u53yVF0vIGcw, TokenId(eyJraWQiO............BvemSfFbwQ), 2025-06-03 15:49:53.086, b0caf04d61f8de8f2f173b8ea938482beb929c6f2524f8defdf90efe79b13245) 
(2025-06-03, 09:11:35): GetStoredTokenOidcInteractor::execute(): oidcConfiguration: OIDCConfiguration(https://sso.linagora.com, teammail-mobile, [openid, profile, email, offline_access], false) 
(2025-06-03, 09:11:35): FcmMessageController::_handleSuccessViewState(): GetStoredTokenOidcSuccess 

// other logs ....

(2025-06-03, 09:13:23): HomeController::handleSuccessViewState():Success = LoadingState 
(2025-06-03, 09:13:23): AccountCacheManager::getCurrentAccount::allAccounts(): [AccountCache(51906823, oidc, true, 94db052675894262fb8644f9517aaf25e8246c5c2eae08b34da40b748f30ec0b, https://jmap.linagora.com/jmap, dphamhoang@linagora.com), AccountCache(573692412, oidc, true, 94db052675894262fb8644f9517aaf25e8246c5c2eae08b34da40b748f30ec0b, https://jmap.linagora.com/jmap, dphamhoang@linagora.com)] 
(2025-06-03, 09:13:23): AccountCacheManager::getCurrentAccount::accountCache(): AccountCache(51906823, oidc, true, 94db052675894262fb8644f9517aaf25e8246c5c2eae08b34da40b748f30ec0b, https://jmap.linagora.com/jmap, dphamhoang@linagora.com) 
(2025-06-03, 09:13:23): HomeController::handleSuccessViewState():Success = GetAuthenticatedAccountSuccess 
(2025-06-03, 09:13:23): HomeController::handleSuccessViewState():Success = LoadingState 
(2025-06-03, 09:13:23): TokenOidcCacheManager::getTokenOidc(): tokenIdHash: 51906823 
(2025-06-03, 09:13:23): HiveCacheConfig::getEncryptionKey(): encryptionKey: AQlFAE7W/NtzJl9nWrtwlOk2oxedIp0VZvQvN/JEh/4= 
(2025-06-03, 09:13:23): HiveCacheConfig::getEncryptionKey(): encryptionKey: AQlFAE7W/NtzJl9nWrtwlOk2oxedIp0VZvQvN/JEh/4= 
(2025-06-03, 09:13:23): TokenOidcCacheManager::getTokenOidc(): tokenCache: null 
(2025-06-03, 09:13:23): [ERROR] CacheExceptionThrower::throwException():error: Instance of 'NotFoundStoredTokenException' | stackTrace: #0      TokenOidcCacheManager.getTokenOidc (package:tmail_ui_user/features/login/data/local/token_oidc_cache_manager.dart:18:7)
<asynchronous suspension>
#1      AuthenticationOIDCDataSourceImpl.getStoredTokenOIDC.<anonymous closure> (package:tmail_ui_user/features/login/data/datasource_impl/authentication_oidc_datasource_impl.dart:58:14)
<asynchronous suspension>
#2      Future.wait.<anonymous closure> (dart:async/future.dart:534:21)
<asynchronous suspension>
#3      GetStoredTokenOidcInteractor.execute (package:tmail_ui_user/features/login/domain/usecases/get_stored_token_oidc_interactor.dart:27:27)
<asynchronous suspension>
#4      GetAuthenticatedAccountInteractor.execute (package:tmail_ui_user/features/login/domain/usecases/get_authenticated_account_interactor.dart:28:9)
<asynchronous suspension>
#5      BaseController.onData (package:tmail_ui_user/features/base/base_controller.dart:138:3)
<asynchronous suspension>
(2025-06-03, 09:13:23): GetStoredTokenOidcInteractor::execute(): Instance of 'NotFoundStoredTokenException' 
(2025-06-03, 09:13:23): HomeController::onDataFailureViewState:failure = GetStoredTokenOidcFailure 
(2025-06-03, 09:13:23): DeepLinksManager::getDeepLinkData:uriLink = null 
(2025-06-03, 09:13:23): TwakeWelcomeController::_handlePendingDeepLinkDataStream:DeepLinkData = null 
(2025-06-03, 09:13:23): TwakeWelcomeController::_handlePendingDeepLinkDataStream:DeepLinkData = null 
(2025-06-03, 09:13:23): LoginController::_handlePendingDeepLinkDataStream:DeepLinkData = null 
(2025-06-03, 09:13:23): ApplicationManager::getPackageInto: PackageInfo(appName: Twake Mail, buildNumber: 1, packageName: com.linagora.android.teammail, version: 0.15.5, buildSignature: 48FEEE1175A3F98D1A08DB10C70FE631EAC1DFD3, installerStore: null) 
(2025-06-03, 09:13:23): ApplicationManager::getVersion: 0.15.5 
(2025-06-03, 09:13:23): LoginController::selectUsernameFromSuggestion():recentLoginUsername: RecentLoginUsername(dphamhoang@linagora.com, 2025-05-30 17:12:58.971) 
(2025-06-03, 09:13:23): LoginController::invokeDNSLookupToGetJmapUrl:_username UserName(dphamhoang@linagora.com) 
</pre>
</details>

### Solution:
- Changing local DB: [Hive-CE](https://pub.dev/packages/hive_ce)
- Which support multiple isolate access to DB
- PR: https://github.com/linagora/tmail-flutter/pull/3750
- Your apk was applied it

### Sequence:
- all user will be logout if update new version which change DB

### Comment by chibenwa at 2025-06-27T05:57:34Z

> all user will be logout if update new version which change DB

The way to handle that might be to fallback to old storage if the new db is empty, then populate the new db with the old one (on the fly migration).

Is this doable?

### Comment by guimard at 2025-06-27T06:23:49Z

Will this change need to reconnect on update ?

### Comment by hoangdat at 2025-06-27T07:12:19Z

> Is this doable?

Let us try, but 2 dependencies are in conflict at the moment.

### Comment by hoangdat at 2025-06-27T07:13:34Z

> Will this change need to reconnect on update ?

yes

### Comment by guimard at 2025-06-27T09:41:32Z

> > Will this change need to reconnect on update ?
> 
> yes

We already had disconnections on updates. For users who have transparent updates in their smartphone, it looks like a bug. Can we avoid perturbing users on each update ?

### Comment by hoangdat at 2025-06-27T09:50:49Z

> > > Will this change need to reconnect on update ?
> > 
> > yes
> 
> We already had disconnections on updates. For users who have transparent updates in their smartphone, it looks like a bug. Can we avoid perturbing users on each update ?

Can you provide more information about it? Because we always test upgrade step in every release. Not have it.

### Comment by guimard at 2025-06-27T10:06:55Z

> > > > Will this change need to reconnect on update ?
> > > 
> > > 
> > > yes
> > 
> > 
> > We already had disconnections on updates. For users who have transparent updates in their smartphone, it looks like a bug. Can we avoid perturbing users on each update ?
> 
> Can you provide more information about it? Because we always test upgrade step in every release. Not have it.

I asked if this will perturb users with disconnection and you answered "yes", so I asked to avoid this

### Comment by hoangdat at 2025-06-27T10:09:27Z

ah, yes, happen only if we agree with changing DB. But, we are finding a way to avoid it.

### Comment by chibenwa at 2025-07-03T07:43:45Z

@hoangdat update the status of this ticket here please.

### Comment by hoangdat at 2025-07-03T07:49:08Z

Changed DB to well handled multiple access on Hive (local DB)
Under testing in Internal Test of store: v0.16.4
