# GitHub issue #2425: Event attendance should be backed by DAV

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2425
State: closed
Author: chibenwa
Created at: 2024-01-03T15:49:32Z
Updated at: 2024-06-10T08:39:25Z
Closed at: 2024-06-10T08:39:25Z
Labels: enhancement, customer
Assignees: tddang-linagora
URL: https://github.com/linagora/tmail-flutter/issues/2425

## Issue body

# Why

Do like blue bar in OpenPaaS INBOX.

Exact synch between calendar and TMail. 

 - I should see my attendance status
 - Updates should work for all invitations, not just OpenPaaS ones.

No longer rely on HTML parsing...

# Summary

 - Tmail backend should advertize a DAV URL using https://github.com/linagora/tmail-backend/issues/588 here `https://dav.linagora.com`
 - Tmail backend should advertize an OpenPaaS backend URL using https://github.com/linagora/tmail-backend/issues/588 here `https://openpaas.linagora.com`
 - TMail frontend given an EML will query the DAV URL in order to retrieve attendance status and update it if necessary

# Request breakdown

Same creds than Tmail shall be used with the DAV server.

Request 1: Get  the OpenPaaS identifier

```
$ curl -H 'Authorization: Bearer XXX' 
    -X GET https://openpaas.linagora.com/api/users?email=btellier@linagora.com | jq '.[]._id'

"5f50a663bdaffe002629099c"
```

Request 2: fron the `` header lookup the event on the calendar

```
REPORT https://dav.linagora.com/calendars/{userId}.json
   -H 'Accept: application/json' 
   -H 'Content-Type: application/json' 
   -H 'Authorization: Bearer XXX'

Payload: {"uid":"xyz"}"

{"_links":{"self":{"href":"\/calendars\/5f50a663bdaffe002629099c.json"}},"_embedded":{"dav:item":[{"_links":{"self":{"href":"\/calendars\/5f50a663bdaffe002629099c\/5f50a663bdaffe002629099c\/sabredav-75da98a6-3b1b-437f-84aa-418f491c6c8b.ics"}},"etag":"\"9a53fbd47d1bc61c18c7cedde2eeb34c\"","data":["vcalendar",[["version",{},"text","2.0"],["prodid",{},"text","-\/\/Sabre\/\/Sabre VObject 4.1.3\/\/EN"],["calscale",{},"text","GREGORIAN"]],[["vtimezone",[["tzid",{},"text","Europe\/Paris"]],[["daylight",[["tzoffsetfrom",{},"utc-offset","+01:00"],["tzoffsetto",{},"utc-offset","+02:00"],["tzname",{},"text","CEST"],["dtstart",{},"date-time","1970-03-29T02:00:00"],["rrule",{},"recur",{"freq":"YEARLY","bymonth":"3","byday":"-1SU"}]],[]],["standard",[["tzoffsetfrom",{},"utc-offset","+02:00"],["tzoffsetto",{},"utc-offset","+01:00"],["tzname",{},"text","CET"],["dtstart",{},"date-time","1970-10-25T03:00:00"],["rrule",{},"recur",{"freq":"YEARLY","bymonth":"10","byday":"-1SU"}]],[]]]],["vevent",[["uid",{},"text","b8fa32db-1551-4e9f-baea-c646f1526c3a"],["transp",{},"text","OPAQUE"],["dtstart",{},"date","2024-04-17"],["dtend",{},"date","2024-04-20"],["class",{},"text","PUBLIC"],["x-openpaas-videoconference",{},"unknown",""],["summary",{},"text","DEVOXX 2024"],["organizer",{"cn":"Fr\u00e9d\u00e9ric HERMELIN"},"cal-address","mailto:fhermelin@linagora.com"],["dtstamp",{},"date-time","2023-10-09T14:16:09Z"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Alexandre ZAPOLSKY"},"cal-address","mailto:azapolsky@linagora.com"],["attendee",{"partstat":"ACCEPTED","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Michel-Marie MAUDET"},"cal-address","mailto:mmaudet@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Raoul DELPECH"},"cal-address","mailto:rdelpech@linagora.com"],["attendee",{"partstat":"ACCEPTED","rsvp":"FALSE","role":"CHAIR","cutype":"INDIVIDUAL","cn":"Fr\u00e9d\u00e9ric HERMELIN"},"cal-address","mailto:fhermelin@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Capucine WALTER"},"cal-address","mailto:cwalter@linagora.com"],["attendee",{"partstat":"TENTATIVE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Pascal VILAREM"},"cal-address","mailto:pvilarem@linagora.com"],["attendee",{"partstat":"ACCEPTED","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Beno\u00eet TELLIER"},"cal-address","mailto:btellier@linagora.com"],["attendee",{"partstat":"ACCEPTED","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Florian DANIEL"},"cal-address","mailto:fdaniel@linagora.com"],["attendee",{"partstat":"ACCEPTED","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Nicolas CHRISTODOULOU"},"cal-address","mailto:nchristodoulou@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Bertrand ESCUDIE"},"cal-address","mailto:bescudie@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Damien LAINE"},"cal-address","mailto:dlaine@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Ga\u00ebl LAGO"},"cal-address","mailto:glago@linagora.com"],["sequence",{},"integer",0]],[]]]],"status":200}]}}
```

Request 3: Manage participant status

Copy the JSON, patch participation status for only the local user (here btellier "partstat":"ACCEPTED" -> "partstat":"TENTATIVE")
 
Note: the self link can be obtained by parsing the event above (href).

```
PUT https://dav.linagora.com/calendars/5f50a663bdaffe002629099c/5f50a663bdaffe002629099c/sabredav-75da98a6-3b1b-437f-84aa-418f491c6c8b.ics

["vcalendar",[["version",{},"text","2.0"],["prodid",{},"text","-//Sabre//Sabre VObject 4.1.3//EN"],["calscale",{},"text","GREGORIAN"]],[["vtimezone",[["tzid",{},"text","Europe/Paris"]],[["daylight",[["tzoffsetfrom",{},"utc-offset","+01:00"],["tzoffsetto",{},"utc-offset","+02:00"],["tzname",{},"text","CEST"],["dtstart",{},"date-time","1970-03-29T02:00:00"],["rrule",{},"recur",{"freq":"YEARLY","bymonth":"3","byday":"-1SU"}]],[]],["standard",[["tzoffsetfrom",{},"utc-offset","+02:00"],["tzoffsetto",{},"utc-offset","+01:00"],["tzname",{},"text","CET"],["dtstart",{},"date-time","1970-10-25T03:00:00"],["rrule",{},"recur",{"freq":"YEARLY","bymonth":"10","byday":"-1SU"}]],[]]]],["vevent",[["uid",{},"text","b8fa32db-1551-4e9f-baea-c646f1526c3a"],["transp",{},"text","OPAQUE"],["dtstart",{},"date","2024-04-17"],["dtend",{},"date","2024-04-20"],["class",{},"text","PUBLIC"],["x-openpaas-videoconference",{},"unknown",""],["summary",{},"text","DEVOXX 2024"],["organizer",{"cn":"Frédéric HERMELIN"},"cal-address","mailto:fhermelin@linagora.com"],["dtstamp",{},"date-time","2023-10-09T14:16:09Z"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Alexandre ZAPOLSKY"},"cal-address","mailto:azapolsky@linagora.com"],["attendee",{"partstat":"ACCEPTED","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Michel-Marie MAUDET"},"cal-address","mailto:mmaudet@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Raoul DELPECH"},"cal-address","mailto:rdelpech@linagora.com"],["attendee",{"partstat":"ACCEPTED","rsvp":"FALSE","role":"CHAIR","cutype":"INDIVIDUAL","cn":"Frédéric HERMELIN"},"cal-address","mailto:fhermelin@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Capucine WALTER"},"cal-address","mailto:cwalter@linagora.com"],["attendee",{"partstat":"TENTATIVE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Pascal VILAREM"},"cal-address","mailto:pvilarem@linagora.com"],["attendee",{"partstat":"TENTATIVE","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Benoît TELLIER"},"cal-address","mailto:btellier@linagora.com"],["attendee",{"partstat":"ACCEPTED","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Florian DANIEL"},"cal-address","mailto:fdaniel@linagora.com"],["attendee",{"partstat":"ACCEPTED","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Nicolas CHRISTODOULOU"},"cal-address","mailto:nchristodoulou@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Bertrand ESCUDIE"},"cal-address","mailto:bescudie@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Damien LAINE"},"cal-address","mailto:dlaine@linagora.com"],["attendee",{"partstat":"NEEDS-ACTION","rsvp":"TRUE","role":"REQ-PARTICIPANT","cutype":"INDIVIDUAL","cn":"Gaël LAGO"},"cal-address","mailto:glago@linagora.com"],["sequence",{},"integer",0]],[]]]]

=> 204
```

**TODO**
- [x] #2796
- [x] #2800
- [x] #2802
- [x] #2812
- [x] #2837
- [x] #2838
- [x] #2840
- [ ] CalendarEvent/reject - Integrate UI
- [x] #2818
- [x] #2819
- [x] #2821
- [x] #2823

## Comments

### Comment by Arsnael at 2024-01-04T02:28:04Z

@chibenwa : so we should be able to advertize multiple DAV urls with discovery endpoint correct? Separated let's say by commas? Or was it a copy/paste mistake, cause I don't see the point... one should be enough as it is the same dav system in the end.

Like:

```
davApiUrls=https://dav.linagora.com,https://openpaas.linagora.com
```

Or just:

```
davApiUrl=https://dav.linagora.com
```

After confirmation I will create the task on the backend backlog :)

### Comment by chibenwa at 2024-01-04T06:58:30Z

No, it is a mistake on my side.

We shall advertize link to OpenPaaS backend AND the DAV URL...

### Comment by Arsnael at 2024-01-04T07:37:05Z

FYI: https://github.com/linagora/tmail-backend/issues/887

### Comment by dab246 at 2024-02-15T04:11:56Z

@hoangdat Do we have a design that has it yet?

### Comment by chibenwa at 2024-02-22T21:01:44Z

Closed in favor of https://github.com/linagora/tmail-flutter/issues/2425 . No DAV invovled.

The design would be the same as today with OpenPaaS invites OpenPaaS.

We just need to add a `Reply sent`confirmation message.

### Comment by hoangdat at 2024-04-08T03:59:54Z

### Docs: 

https://github.com/linagora/tmail-backend/blob/master/docs/modules/ROOT/pages/tmail-backend/jmap-extensions/calendarEventReply.adoc

https://github.com/linagora/tmail-backend/blob/master/tmail-backend/integration-tests/jmap/jmap-integration-tests-common/src/main/scala/com/linagora/tmail/james/common/LinagoraCalendarEventAcceptMethodContract.scala#L28

### Comment by tddang-linagora at 2024-04-11T09:47:50Z

Blocked by:
- https://github.com/linagora/tmail-backend/issues/1006

### Comment by Arsnael at 2024-04-15T09:18:05Z

> Blocked by:
> 
> * [CalendarEvent reply extension throw serverFail error tmail-backend#1006](https://github.com/linagora/tmail-backend/issues/1006)

@hoangdat @tddang-linagora fix regarding this issue deployed on staging. Please test again and tell us if it resolves your blocking point or not. Thanks
