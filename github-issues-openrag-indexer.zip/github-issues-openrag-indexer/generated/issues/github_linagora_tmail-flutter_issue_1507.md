# GitHub issue #1507: Force Client web app to upgrade with new version

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1507
State: closed
Author: hoangdat
Created at: 2023-02-27T03:39:45Z
Updated at: 2023-06-28T09:13:44Z
Closed at: 2023-06-28T04:14:50Z
Labels: web, Critical
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1507

## Issue body

### Desc:

- Some fixed in UI component were not deployed in upgrade version 

### Expected:

- fixed in UI must be deployed in upgrade version in client side without any user's action

### DoD:
- [ ] fixed in UI must be deployed in upgrade version in client side without any user's action
- [ ] test case for upgrade web

## Comments

### Comment by chibenwa at 2023-04-05T05:48:12Z

How about serving files under the version number in NGinx and redirecting everything to that versionnumber?

IE versionning of frontend assets (via base folder).

EG

```
GET index.html => GET vxxx/index.html
GET vxxx/whatever no rewrite
```

We could attempt to configure it easily directly into the NGinx docker container?

### Comment by quantranhong1999 at 2023-05-11T09:42:45Z

## Rationale of issue
The rationale for the current issue: `Cache-Control: max-age=86400` => Browser only revalidates cache (using `If-None-Match` header) after 1 day. => User can be delayed a maximum of 1 day to get the update from release.

## Potential solutions
Some solutions for this:
1. **Decrease max-age** e.g 1 hour
    Pros:
      - No need to send HTTP conditional request to revalidate cache in 1 hour
     
    Cons:
      - Client may need maximum 1 hour to update new release -> Acceptable IMO

2. **Force `Cache-Control: no-cache`** -> always re-validate cache before reuse
    Pros:
      - Client can get new release immediately
      
    Cons:
      - Client needs to send HTTP conditional request to revalidate cache every time load static files -> which reduces a bit of performance

3. **Versioning static files** e.g `tmail.linagora.com/v0.8.0/main.dart.js`
    Pros:
      - Client is forced to get new releases immediately (upon new version)
      - No need to re-validate cache before reuse -> Better performance
      
    Cons:
      - The mobile team needs to pay attention to changing the versioning of static files e.g versioning directory in nginx before every release
      - Dev/Tester can encounter outdated static assets issue on staging env (the same version for a developing version. But this is the same with today's behavior anyway)

## Progress

I tried solution 1/2. They are trivial and fix the issue.

However, I think versioning files should be the best practice here. But I did not succeed to make it work yet on NGINX side (I am still new/noob to nginx location directive :p will need to try more).

BTW if we do versioning static files we may need to add the version path of javascript code e.g in index.html?
Today:
```index.html
scriptTag.src = 'main.dart.js';
```
then the browser will load `http://localhost:8080/main.dart.js` and forget about versioning.

@hoangdat opinion about this? Is it costly to change the JS path every release?

### Comment by chibenwa at 2023-05-11T09:56:58Z

> However, I think versioning files should be the best practice here.

+1

Can't we do the versionning with a clever trick at the NGinx level upon packaging the mobile app?

Eg:

 - Step 1: put **EVERYTHING** in `https://tmail.linagora.com/v0.7.9`
 - Step 2: redirect `https://tmail.linagora.com/index.html` to `https://tmail.linagora.com/v0.7.9/index.html` (not a proxy pass but an HTTP 301)
 
 ? 
 
 Would this look like a solution?
 
 > Dev/Tester can encounter outdated static assets issue on staging env (the same version for a developing version. But this is the same with today's behavior anyway)
 
 Not a PB: they know dealing with that...

### Comment by quantranhong1999 at 2023-05-12T09:49:16Z

I succeeded with solution 3: serve versioned static files as Benoit suggested.
Commit: https://github.com/linagora/tmail-flutter/commit/5537354eb8031657e7e50e902a0fed41184c1da3
![demo versioning static files](https://github.com/linagora/tmail-flutter/assets/55171818/36db0fb5-6eb5-439a-a2c1-e308f5edbcd8)

However, I see 2 cons of this way:
- The mobile team needs to update the version in the image build every release
- The very first TMail loading would be slower with 2 round trips for each static file (1 redirect and 1 actual load request). Then next times, 1 round trip (redirect request) for each file.

To be really optimized which avoids a redirecting request for every static file, we would need to add the version path in the source code - which I am not sure we would take.

So I propose using solution 2 (force browser re-validate cache before reuse):
- Simple solution, no need to update version every release.
- The very first TMail loading would be expected as usual with only 1 round trip for each static file. Then next times, 1 round trip (re-validate request) for each file.
![demo revalidate static files](https://github.com/linagora/tmail-flutter/assets/55171818/48eaec77-80dc-4437-b3c3-dd74569aefd0)

PR: https://github.com/linagora/tmail-flutter/pull/1840

### Comment by hoangdat at 2023-06-27T13:13:40Z

It is still not resolved

### Comment by quantranhong1999 at 2023-06-28T02:28:16Z

> It is still not resolved

Can someone describe more the details?

### Comment by quantranhong1999 at 2023-06-28T05:25:32Z

[Screencast 2023-06-28 12:21:10.webm](https://github.com/linagora/tmail-flutter/assets/55171818/016913c7-5ab8-48fa-9f72-322850e01035)

Verified the case locally: When changing nginx assets (e.g. app grid icon) on the fly => Browser does load new assets.

### Comment by quantranhong1999 at 2023-06-28T06:49:48Z

But not worked for `app_dashboard.json` changes. I will check more on this.

### Comment by quantranhong1999 at 2023-06-28T09:13:44Z

It is true that `app_dashboard.json` change is not applied if we hot modify it directly on the TMail Web container.

But the change is applied perfectly if we build the new TMail Web image:

https://github.com/linagora/tmail-flutter/assets/55171818/8fe55de8-a585-409b-a49e-b6a59a4b6158


So please do not make changes on the fly, as long as we commit the change and let CI build our new image, we are good with the browser cache issue!
