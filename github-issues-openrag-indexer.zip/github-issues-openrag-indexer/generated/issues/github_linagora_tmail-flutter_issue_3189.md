# GitHub issue #3189: JAMES-3945 - front end support for subaddressing

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3189
State: closed
Author: florentos17
Created at: 2024-10-02T08:05:46Z
Updated at: 2024-12-04T22:54:47Z
Closed at: 2024-12-04T22:54:47Z
Labels: 
Assignees: florentos17
URL: https://github.com/linagora/tmail-flutter/issues/3189

## Issue body

refs:
- [wikipédia for Sub-addressing](https://en.wikipedia.org/wiki/Email_address#Sub-addressing)
- [RFC5233 for subaddress extension](https://rfc-editor.org/rfc/rfc5233)
- [the jira ticket](https://issues.apache.org/jira/browse/JAMES-3945)
- [the github issue for rights positioning on the backend side](https://github.com/linagora/james-project/issues/5289)

# Why ?
the work on the backend side is well underway, now we need front end support:

# What ?
after creating a subfolder, the `p` right is set by default to no one
when right clicking on the subfolder, add a "mailbox action" in order to set the `p` right for anyone (or remove it)

# How ?
for crafting the JMAP query, use the [jmap dart client](https://github.com/linagora/jmap-dart-client)

## Comments

### Comment by hoangdat at 2024-10-02T09:20:29Z

Hi, 
Can you reference docs for this topic? I still not clear about the use-case in front-end app.

Btw, If `subaddressing` is an extension, please add it as a new module in `tmail-flutter`.

Thanks

### Comment by chibenwa at 2024-10-02T14:31:01Z

Hello Dat

It's an extension.

CF COSOFT if you send mail to btellier+Spam@linagor.com then it ends up in my spam mailbox.

In the UI we would need:

 - First to have an action for remote senders to address my folder with subaddressing
 
  - Then potentially work on possibility to have subaddresses into identities `replyTo`...

### Comment by florentos17 at 2024-10-21T08:00:16Z

[slides-subaddressing-frontend-support.pdf](https://github.com/user-attachments/files/17457190/subaddressing-frontend-support.pdf)

here is a description of each feature, please see the slides for details and mockups:
- [x]  slides 3&4: in the three dot menu next to a folder name, add a menu option to grant posting right if denied, and deny posting right if granted
- [x]  slide 5: when granting the right, add a confirmation popup, with buttons to copy the mail subaddress, and allow or cancel the granting
- [x]  slide 6: in the same menu, add option to copy the mail subaddress if right is granted
- [x]  slides 7&8: when writing a new mail, add a field “reply to” to set the address to which the reply will be sent
- [ ]  slide 9: when creating/editing an identity, add options for the existing subaddresses for the fields “email” and “reply to”
- [x]  slide 10: when writing a new mail, add suggestions for mail subaddresses to which a mail has already been sent/from which a mail has already been received. this has more to do with the backend than the front end
- [x]  slide 11: when an address has been entered,  add subaddressing details (see the mockup)

### Comment by chibenwa at 2024-10-21T11:12:58Z

Slide 9: IMO We can let the `Reply To` field as a free text input and manage today drop-down-list as suggestions?|

Overwize +1

### Comment by florentos17 at 2024-10-24T07:17:14Z

why not, i quickly mentioned the idea to bob, he said he liked the dropdown better

### Comment by florentos17 at 2024-11-04T16:15:24Z

so what should we do about the `email` and `reply to` fields of identity editing ?
1. dropdown or free text input with suggestions ?
2. for dropdown options/suggestions, i suggest to include subaddresses for every folder of the user, even those for which subaddressing is not allowed. that way, the user can turn on and off subaddressing without affecting the identities.

moreover, i had an other thought: if a user sets up an identity with a subaddress for a specific folder, and then changes the name of that folder, i feel like it would make sense to make it so that the identity gets automatically updated with the new subaddress ?

### Comment by chibenwa at 2024-11-06T15:25:33Z

> so what should we do about the email and reply to fields of identity editing ?

Please open a new ticket for the subpart of that story 

We have a design for it?

### Comment by florentos17 at 2024-12-04T08:48:55Z

all features have been implemented and merged, except for the one related to identities discussed just above.

i feel like this is really a minor feature since the user can fill the new `reply to` field directly in the composer when writing a mail instead of first setting up an identity, then manually change the `from` address in the composer.
thus i feel like the identity feature does not bring much to the UX for most users and it is not that straightforward to implement (cf my previous comment).

> Please open a new ticket for the subpart of that story

i am going to close the current issue anyway, but should i still open a new one for the identity feature as suggested, or let's forget about it and move on ?
