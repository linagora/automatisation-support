# GitHub issue #4293: Release new version v0.24.x

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4293
State: closed
Author: hoangdat
Created at: 2026-02-02T02:31:13Z
Updated at: 2026-06-15T04:44:39Z
Closed at: 2026-06-15T04:44:39Z
Labels: releasing
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/4293

## Issue body

### DoD:
- [x] Request translating in weblate and merge to branch
- [x] Test in all platforms base on the check-list case: [tnr-tmail-template_20Mar.ods](https://github.com/user-attachments/files/19358057/tnr-tmail-template_20Mar.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [x] Memory leak verifycation
  - View emails with heavy inline
  - Send multiple emails with heavy inline image and attachment
  - Create identity with heavy image
- [x] Tag new version
- [x] Push new docker image
- [x] iOS - Release app in Test Flight
- [x] Android - Release app in Internal Test

## Comments

### Comment by coderabbitai[bot] at 2026-02-02T02:31:41Z

<!-- This is an auto-generated issue plan by CodeRabbit -->
<details>
<summary>🔗 Related PRs</summary>

linagora/tmail-flutter#4226 - TF-4223 Fix welcome email is not well displayed [merged]
linagora/tmail-flutter#4295 - HOTFIX Create identity memory leak [merged]
linagora/tmail-flutter#4298 - HOTFIX Integration test 0.24.8 [merged]
</details>

---
<details>
<summary>📝 Issue Planner</summary>

<sub>Check the box below or use the `@coderabbitai plan` command to generate an implementation plan and prompts that you can use with your favorite coding assistant.</sub>

- [ ] <!-- {"checkboxId": "8d4f2b9c-3e1a-4f7c-a9b2-d5e8f1c4a7b9"} --> Create Plan
</details>


---
<details>
<summary> 🧪 Issue enrichment is currently in open beta.</summary>


You can configure auto-planning by selecting labels in the issue_enrichment configuration.

To disable automatic issue enrichment, add the following to your `.coderabbit.yaml`:
```yaml
issue_enrichment:
  auto_enrich:
    enabled: false
```
</details>

💬 Have feedback or questions? Drop into our [discord](https://discord.gg/coderabbit)!

### Comment by hoangdat at 2026-02-02T02:33:41Z

@tddang-linagora 
- [x] memory leak
- [x] run patrol test 
- [x] firefox, ios

[0.24.8-firefox-ios.ods](https://github.com/user-attachments/files/25060582/0.24.8-firefox-ios.ods)

@dab246 
- [x] android 
- [x] safari
- [x] edge

[tnr-tmail-v0.24.8-safari-edge-android.ods](https://github.com/user-attachments/files/25040085/tnr-tmail-v0.24.8.ods)

@hoangdat 
- [x] chrome
- [x] iOS 

[tnr-tmail-0.24.x.ods](https://github.com/user-attachments/files/25041868/tnr-tmail-0.24.x.ods)

### Comment by dab246 at 2026-02-02T05:15:55Z

- [x] Always show checkbox icon in Label Quick search dropdown
- [x] Show label search filter only when label list is not empty

### Comment by dab246 at 2026-02-02T05:16:21Z

> * [x]  Always show checkbox icon in Label Quick search dropdown
> * [x]  Show label search filter only when label list is not empty

Fixed at https://github.com/linagora/tmail-flutter/pull/4294

### Comment by tddang-linagora at 2026-02-02T08:35:38Z

## Memory leak verification
### View emails with heavy inline ✅
#### Mobile

<img width="4064" height="2384" alt="Image" src="https://github.com/user-attachments/assets/a655c8cf-78fc-463c-a857-18445c43f036" />

#### Web

<img width="1552" height="1012" alt="Image" src="https://github.com/user-attachments/assets/44e50414-9893-4855-814c-581f44d338f1" />

### Send multiple emails with heavy inline image and attachment ✅
#### Mobile

<img width="4064" height="2384" alt="Image" src="https://github.com/user-attachments/assets/5c50d4a2-f81e-48ce-b2a6-6d0250950563" />

#### 

<img width="1552" height="1012" alt="Image" src="https://github.com/user-attachments/assets/68e90448-2462-41df-bd17-030fc874b886" />

### Create identity with heavy image ❌
- https://github.com/linagora/tmail-flutter/pull/4295

### Comment by hoangdat at 2026-02-26T02:39:26Z

please test again for v0.24.13 in canary
- [x] @dab246 chrome, edge

[tnr-tmail-v0.24.13-chrome-edge.ods](https://github.com/user-attachments/files/25567763/tnr-tmail-v0.24.13-chrome-edge.ods)

- @hoangdat 
  - [x] firefox
  - [x] safari

[tnr-tmail-v0.24.13-firefox-safari.ods](https://github.com/user-attachments/files/25572154/tnr-tmail-v0.24.13-firefox-safari.ods)

- [x] @tddang-linagora memory leak, e2e tests

### Comment by tddang-linagora at 2026-02-26T03:53:46Z

## Memory leak verification
### View emails with heavy inline ✅
#### Mobile

<img width="4064" height="2384" alt="Image" src="https://github.com/user-attachments/assets/0cfc66db-a1e7-4b96-b5b5-98d9873a288d" />

#### Web

<img width="1082" height="745" alt="Image" src="https://github.com/user-attachments/assets/84c44ab7-c214-4006-962c-4e96d3bcbbe9" />

### Send multiple emails with heavy inline image and attachment ✅
#### Mobile

<img width="4064" height="2384" alt="Image" src="https://github.com/user-attachments/assets/95e7eb1b-7f32-4e78-85f4-abae34755327" />

#### Web

<img width="1082" height="745" alt="Image" src="https://github.com/user-attachments/assets/91b67327-3a60-4b39-b484-6bd5cd392174" />

### Create identity with heavy image ✅
#### Mobile

<img width="4064" height="2384" alt="Image" src="https://github.com/user-attachments/assets/18044063-93d9-4677-a11e-4d3e1aa17d5a" />

#### Web

<img width="1082" height="745" alt="Image" src="https://github.com/user-attachments/assets/141d6bfb-666d-4105-a943-f35131489619" />

### Comment by hoangdat at 2026-02-26T10:01:00Z

app work well in all browser: chrome, safari, firefox, edge. One issue
- [x] focus in safari was not able in the first click when open html view? (no pb in Chrome, Firefox, Edge)

### Comment by hoangdat at 2026-02-27T09:54:32Z

Completed non-regression test. Detail report in https://github.com/linagora/tmail-flutter/issues/4293#issuecomment-3963613825
Version 0.24.14 was built and deploy to STG.

@chibenwa @poupotte
