# GitHub issue #3894: Blank email content when opening email

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3894
State: closed
Author: Gictorbit
Created at: 2025-07-21T07:13:19Z
Updated at: 2025-09-06T06:47:57Z
Closed at: 2025-09-06T06:47:57Z
Labels: bug, stalwart
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/3894

## Issue body

### Description
When I click on an email from the email list, the email opens but the content area is completely blank. The email list itself loads correctly and shows senders, subjects, and previews without issue.

### Expected result
After clicking on an email, the email content should be fully displayed, including text, attachments, and formatting.

### Current behavior
The email content area shows up blank after clicking on an email, even though the email list displays correctly.

### Preconditions (optional)
+ Logged in as a valid user
- Emails are properly synced and visible in the list

#### Reproduction Steps
1. Open the app and go to the inbox
2. Wait until the list of emails loads
3. Click on any email from the list
4. Observe that the email content is not displayed

### Acceptance criteria
 + Email content is shown correctly after clicking on an email
 - No blank content area is observed
 + Email body, formatting, and attachments are properly rendered

### Context
docker image: `linagora/tmail-web:v0.17.0`

### Additional information

<img width="1220" height="756" alt="Image" src="https://github.com/user-attachments/assets/54b68224-71ba-4dbc-8476-d743e775410f" />

## Comments

### Comment by hoangdat at 2025-07-21T07:16:39Z

thank for reporting, we are investigating on it

### Comment by hoangdat at 2025-07-21T09:20:19Z

you had blank email all the time or sometimes? we can not reproduce it in web app? can you more detail on this topic?

### Comment by Gictorbit at 2025-07-21T11:19:25Z

Hi, just to clarify — before the new release everything was working perfectly and email content displayed correctly. After the latest update, opening emails shows a blank content area.

I'm using Twake Mail with Stalwart as the backend. Let me know if you need any logs or more details to help troubleshoot this.

### Comment by Gictorbit at 2025-07-21T11:27:18Z

When I open an email, this JMAP request is triggered:

```sh
curl 'https://mail.example.com/jmap/' \
  -H 'accept: application/json;jmapVersion=rfc-8621' \
  -H 'authorization: Bearer [redacted]' \
  --data-raw '{"using":["urn:ietf:params:jmap:core","urn:ietf:params:jmap:mail"],"methodCalls":[["Email/get",{"accountId":"c","ids":["daaaaaa3"],"properties":["bodyValues","htmlBody","attachments","headers","keywords","mailboxIds","messageId","references","header:X-SMIME-Status:asText"],"fetchHTMLBodyValues":true},"c0"]]}'
```

The API response actually contains the correct email content, but it doesn’t show up in the application interface.

### Comment by chibenwa at 2025-07-21T12:01:03Z

Can you please share the EML of the underlying email?

Please also share your browser version.

### Comment by Gictorbit at 2025-07-21T15:10:12Z

I'm using Google chrome `Version 138.0.7204.157 (Official Build) (64-bit)`
how can I get EML file?

### Comment by chibenwa at 2025-07-21T15:23:14Z

<img width="3436" height="1274" alt="Image" src="https://github.com/user-attachments/assets/cd44782c-ffff-4426-842d-362d9c7acc0c" />

Easy: there is a button hidden in the interface to that end.

### Comment by Gictorbit at 2025-07-21T17:18:52Z

When I click on an email in my inbox and open it, I only see a blank page. There’s no content shown and the 3-dot menu button is also missing, so I’m unable to download the EML file.

### Comment by chibenwa at 2025-07-21T18:41:02Z

Ok then `Ctrl + U` opening the very same email with Thunderbird...

### Comment by Gictorbit at 2025-07-21T19:38:18Z

OK, I’ve rolled back to the previous stable version of TMail and downloaded one of my emails as an EML file.
Here it is

```eml
Delivered-To: demo@yourdomain.com
Received: from mail-demo-fake.google.com (mail-demo-fake.google.com [203.0.113.54] (AS15169 Google LLC, US))
	(using TLSv1.3 with cipher TLS13_AES_256_GCM_SHA384)
	by smtp.yourdomain.com (Stalwart SMTP) with ESMTPS id ABCDE12345;
	Tue, 8 Jul 2025 10:12:11 +0000
Authentication-Results: smtp.yourdomain.com;
	dkim=pass header.d=gmail.com header.s=20230601 header.b=FAKEdkimSignature;
	spf=pass (smtp.yourdomain.com: domain of sender@gmail.com designates 203.0.113.54 as permitted sender);
	iprev=pass policy.iprev=203.0.113.54;
	dmarc=pass header.from=gmail.com policy.dmarc=none
Received-SPF: pass (smtp.yourdomain.com: domain of sender@gmail.com designates 203.0.113.54 as permitted sender)
	receiver=smtp.yourdomain.com; client-ip=203.0.113.54; envelope-from="sender@gmail.com"; helo=mail-demo-fake.google.com;
ARC-Seal: i=1; a=rsa-sha256; s=202506r; d=yourdomain.com; cv=none; b=fakeARCseal==
ARC-Message-Signature: i=1; a=rsa-sha256; s=202506r; d=yourdomain.com; c=relaxed/relaxed; h=To:Subject:Date:From; b=fakeARCmessage==
ARC-Authentication-Results: i=1; smtp.yourdomain.com; dkim=pass; spf=pass; dmarc=pass
X-Spam-Status: No, score=-5.00
Return-Path: <sender@gmail.com>
Received: by mail-demo-fake.google.com with SMTP id DEMOID12345;
        for <demo@yourdomain.com>; Tue, 08 Jul 2025 03:12:11 -0700 (PDT)
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=gmail.com; s=20230601; t=1751969531; bh=fakedkimhash==; b=fakedkim==
X-Google-DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=1e100.net; s=20230601; bh=fakedkimhash==; b=fakegoogledkim==
X-Gm-Message-State: fake-state-string
MIME-Version: 1.0
From: "Demo Sender" <sender@gmail.com>
Date: Tue, 8 Jul 2025 13:41:59 +0330
Message-ID: <fake-message-id@mail.gmail.com>
Subject: Test Email for Firebase Demo
To: demo@yourdomain.com
Content-Type: multipart/alternative; boundary="demo-boundary-123456"

--demo-boundary-123456
Content-Type: text/plain; charset="UTF-8"

Hello, this is a test email for Firebase integration demo.

--demo-boundary-123456
Content-Type: text/html; charset="UTF-8"

<div dir="ltr">Hello, this is a <b>test email</b> for Firebase integration demo.</div>

--demo-boundary-123456--


```

### Comment by Gictorbit at 2025-07-21T19:41:31Z

if you need original eml file I can share it with you on telegram feel free to text me thanks `t.me/vixtorexy`

### Comment by Gictorbit at 2025-07-21T19:46:44Z

in prevoius version everything was ok without any issue as you can see no blank content

<img width="847" height="473" alt="Image" src="https://github.com/user-attachments/assets/4b1b0776-b083-448c-b15b-753fdce3b993" />

### Comment by dab246 at 2025-07-22T05:45:53Z

@Gictorbit  We've fixed this issue on the `bugfix/tf-3894-blank-email-content-when-opening-email` branch. You can use that branch to test on your server while we merge it into the master branch. Thanks

### Comment by Gictorbit at 2025-07-22T08:28:36Z

thank you so much I will test it

### Comment by Bananas-Are-Yellow at 2025-08-02T10:30:37Z

I have the same problem. I'm using `v0.17.2` with Stalwart. The HTTP response contains the email body, but nothing gets displayed, just a blank grey area.

### Comment by dab246 at 2025-08-04T09:38:29Z

> I have the same problem. I'm using `v0.17.2` with Stalwart. The HTTP response contains the email body, but nothing gets displayed, just a blank grey area.

Hi @Bananas-Are-Yellow 

We have fixed this bug in PR https://github.com/linagora/tmail-flutter/pull/3896. You can use branch `bugfix/tf-3894-blank-email-content-when-opening-email` while we wait for merge to master and release next version

### Comment by Gictorbit at 2025-08-06T10:23:57Z

Could you please merge it sooner so we can test this fix along with the other new features? 🙏

### Comment by dab246 at 2025-09-04T03:07:29Z

> Could you please merge it sooner so we can test this fix along with the other new features? 🙏

Hi @Gictorbit, we have merged the PR that fixes this issue into the master branch. You can now use the master branch for your project. Thanks for waiting.

### Comment by Gictorbit at 2025-09-06T06:46:15Z

I updated to the latest version and the issue is fixed, thank you!
