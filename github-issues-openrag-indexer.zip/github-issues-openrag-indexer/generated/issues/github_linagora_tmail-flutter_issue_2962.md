# GitHub issue #2962: Speller checker for Safari not work

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2962
State: closed
Author: hoangdat
Created at: 2024-06-27T06:34:30Z
Updated at: 2025-10-03T10:37:41Z
Closed at: 2025-10-03T10:37:41Z
Labels: bug, composer
Assignees: tddang-linagora
URL: https://github.com/linagora/tmail-flutter/issues/2962

## Issue body

### Desc:

not see the spell checker in composer (Language Tools)

### DoD:
- [ ] enable for safari also
- [ ] verify with some other speller checker in Safari too

## Comments

### Comment by dab246 at 2024-07-26T03:13:57Z

- Speller check not work `HtmlElementView` of Flutter Web but it work on html native web of Safari

### Comment by tddang-linagora at 2024-09-10T04:48:52Z

> * Speller check not work `HtmlElementView` of Flutter Web but it work on html native web of Safari

https://github.com/user-attachments/assets/fcf8dac6-9e82-4186-8e08-13eeddae5042

It works fine?

### Comment by dab246 at 2024-09-10T05:03:23Z

> > * Speller check not work `HtmlElementView` of Flutter Web but it work on html native web of Safari
> 
>  Screen.Recording.2024-09-10.at.11.47.15.mov 
> It works fine?

What you see underlined is not `Speller check`. It is `autocorrect`, please install speller check extension to check.

### Comment by tddang-linagora at 2024-09-10T06:23:50Z

>What you see underlined is not `Speller check`

https://github.com/user-attachments/assets/79cac88e-b86a-47cc-976a-92145fe0a89a

The browser says it is spelling though.

### Comment by dab246 at 2024-09-10T06:59:04Z

> > What you see underlined is not `Speller check`
> 
>  Screen.Recording.2024-09-10.at.13.22.31.mov 
> The browser says it is spelling though.

I think you should take a closer look. Use the LanguageTool extension to check.

### Comment by tddang-linagora at 2024-09-10T08:05:52Z

Upon further inspection, LanguageTools spell checker isn't work at all if the text editor is inside the `iframe`. You can try this code snippet below in Safari.

```html
<!DOCTYPE html>
<html>
  <head>
    <title>Page Title</title>
  </head>
  <body>
    <p>This will check spelling</p>
    <div contenteditable="true" spellcheck="true" style="border:1px solid grey;"></div>
    <br>
    <iframe srcdoc="<!DOCTYPE html>
      <html>
      <head>
      <title>Page Title</title>
      </head>
      <body>
      <p>This will NOT check spelling</p>
      <div contenteditable='true' spellcheck='true' style='border:1px solid grey;'></div>
      </body>
      </html>
      "/>
  </body>
</html>
```

Related information
- https://github.com/languagetool-org/languagetool/issues/1356
- https://developer.apple.com/forums/thread/653307

Conclusion
I need to update my Macbook to the latest version, in order to install latest beta Safari. It's likely to be fixed there. Will update with more info after further testing

### Comment by tddang-linagora at 2024-09-11T02:49:16Z

This is an issue of LanguageTools https://forum.languagetool.org/t/lt-doesnt-work-on-latest-safari/10421

### Comment by dab246 at 2024-09-11T03:09:08Z

> This is an issue of LanguageTools https://forum.languagetool.org/t/lt-doesnt-work-on-latest-safari/10421

Please research other Speller check extensions for comparison.
