# GitHub issue #811: Autocomplete doesn't suggest correctly when searching recipients

## Metadata

Repository: linagora/tmail-flutter
Issue number: 811
State: closed
Author: tuanlc
Created at: 2022-08-08T03:32:16Z
Updated at: 2023-02-07T14:44:46Z
Closed at: 2023-02-07T14:44:46Z
Labels: bug
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/811

## Issue body

### Description
When composing a new email, and enter recipient's email, the suggestions from the app are not correct

### Expected result
Suggest the results that close with the search terms

#### Reproduction Steps

https://user-images.githubusercontent.com/7950991/183332948-0ae29c94-9574-4db6-890c-f5ea21760528.mp4

### Context

- Devices: Desktop
- OS: Arch linux
- Browser: Firefox 102.0.1 (64-bit)

## Comments

### Comment by chibenwa at 2022-08-08T03:55:12Z

Configuration issue, 

Also we might consider n-graming only the local part?

### Comment by hoangdat at 2022-08-08T04:04:13Z

What is `n-gramming`?

### Comment by chibenwa at 2022-08-08T04:06:17Z

Basically for search we cut `vnhr@linagora.com` in 3-grams (ie 3 letters) (so `vnh` `nhr` hr@` .... `com`) and index those (build a reverse index & search.

### Comment by hoangdat at 2022-08-08T04:23:12Z

You mean: 
- Client should cut the input text to `n-gram` to make `autocomplete/get` request?

### Comment by tuanlc at 2022-08-08T08:22:36Z

@chibenwa 

> Also we might consider n-graming only the local part?

It's good to start and see the feedback from users

### Comment by tuanlc at 2022-08-22T04:18:16Z

The issue isn't fixed and it seems even worse. The autocomplete feature doesn't work now :cry:

### Comment by hoangdat at 2022-08-22T05:11:19Z

Hi @chibenwa any update for this ticket and #812 also

### Comment by chibenwa at 2022-08-22T05:35:28Z

Not a (code) bug but more a configuration limitation.

I do not have LDAP schemas details, hence cannot help on this.

### Comment by hoangdat at 2022-08-22T07:01:51Z

okie, so I open this ticket to keep it on radar.
