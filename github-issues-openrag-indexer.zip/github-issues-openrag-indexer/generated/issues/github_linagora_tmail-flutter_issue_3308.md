# GitHub issue #3308: Drag and drop text within the coposer

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3308
State: closed
Author: chibenwa
Created at: 2024-11-25T10:56:55Z
Updated at: 2026-04-06T07:48:16Z
Closed at: 2026-04-06T07:48:16Z
Labels: 
Assignees: tddang-linagora
URL: https://github.com/linagora/tmail-flutter/issues/3308

## Issue body

### Description

I can drag n drop text in the body

Not in subject, to, cc bcc

Make it that I can drag and drop text where I can input text

https://github.com/user-attachments/assets/7ae4e4e7-fdfa-47d7-adbe-7b3aa644de49

## Comments

### Comment by hoangdat at 2024-11-25T11:20:44Z

not a bug. New function

### Comment by chibenwa at 2024-11-25T13:28:03Z

I 'd expect it to be a default feature of any text field.

Missing basic expectations is a category of bugs.

### Comment by hoangdat at 2024-11-27T03:19:07Z

> Missing basic expectations is a category of bugs.

Agree in some cases. But in an aspect of Flutter, it is not a built-in function for text field. 
WE MUST SPEND A LOT OF EFFORT FOR THIS.

NOT A BUG.

### Comment by chibenwa at 2024-11-27T07:54:18Z

>  it is not a built-in function for text field

Regular users expects it to be a built in feature of text fields....

Anyway let's stop arguing and let's plan work on this.

### Comment by tddang-linagora at 2024-11-29T08:08:08Z

- [ ] Implement [super_drag_and_drop](https://pub.dev/packages/super_drag_and_drop), implement `TextDropZone`
- [ ] Integrate `TextDropZone` into `TagEditor`
- [ ] Integrate `TextDropZone` into `TextFieldBuilder`

### Comment by hoangdat at 2024-12-02T02:22:57Z

try to test carefully in all platforms and common browsers

### Comment by tddang-linagora at 2024-12-03T02:50:40Z

Would break drag & drop for inline images and attachments. Need further investigate.

### Comment by hoangdat at 2024-12-04T03:26:23Z

POC:
- [ ] replace `desktop_drop` dependency with `super_drag_and_drop`
- [ ] handle both case of drag n drop text or file
