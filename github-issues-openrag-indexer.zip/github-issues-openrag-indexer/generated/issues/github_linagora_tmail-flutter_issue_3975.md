# GitHub issue #3975: Release new version 0.18.2

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3975
State: closed
Author: hoangdat
Created at: 2025-08-22T09:48:51Z
Updated at: 2025-08-29T08:54:15Z
Closed at: 2025-08-29T08:54:15Z
Labels: releasing
Assignees: hoangdat, dab246, tddang-linagora
URL: https://github.com/linagora/tmail-flutter/issues/3975

## Issue body

### DoD:
- [x] Request translating in weblate and merge to branch
- [x] Test in all platforms base on the check-list case: [tnr-tmail-template_20Mar.ods](https://github.com/user-attachments/files/19358057/tnr-tmail-template_20Mar.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [x] Memory leak verifycation
  - View emails with heavy inline
  - Send multiple emails with heavy inline image and attachment
  - Create identity with heavy image
- [x] Tag new version
- [x] Push new docker image
- [x] iOS - Release app in Test Flight
- [x] Android - Release app in Internal Test

## Comments

### Comment by hoangdat at 2025-08-22T09:52:02Z

@dab246 
- [x] iOS
- [x] Safari

[tmail-0.18.2-safari-ios.ods](https://github.com/user-attachments/files/21983925/tmail-0.18.2-safari-ios.ods)

@tddang-linagora 
- [x] firefox
- [x] chrome

[firefox-chrome-0.18.2.ods](https://github.com/user-attachments/files/22000734/firefox-chrome-0.18.2.ods)

@hoangdat 
- [ ] android
- [x] edge 

[tnr-tmail-v0.18.2-edge.ods](https://github.com/user-attachments/files/21966543/tnr-tmail-v0.18.2.ods)

### Comment by tddang-linagora at 2025-08-25T02:55:12Z

### Memory leak verification
✅ View emails with heavy inline

<img width="1348" height="774" alt="Image" src="https://github.com/user-attachments/assets/fe77159c-fd40-4c22-abd9-25c5ed47981e" />

✅ Send multiple emails with heavy inline image and attachment

<img width="1348" height="774" alt="Image" src="https://github.com/user-attachments/assets/d695ad83-1e98-4aad-936a-77338817112a" />

✅ Create identity with heavy image

<img width="1348" height="774" alt="Image" src="https://github.com/user-attachments/assets/9a38318c-5e26-497c-b423-031441b3b627" />

### Comment by tddang-linagora at 2025-08-25T03:14:54Z

## Composer - Focus is not handled properly
### Steps to reproduce
- Open composer
- Click on composer content field ONCE
- Verify that the caret is still inside the `To` field
- Type something

### Expected behavior
Text appear where the caret is when typing

### Actual behavior
No text appears when typing

### Env
Firefox - `mail.stg.lin-saas.com`

### Comment by tddang-linagora at 2025-08-25T04:28:25Z

## Search - Keyword search is not kept after sort
### Step to reproduce
- Search by keyword
- Select sort (different from current sort)

### Expected behavior
Search result by keyword is kept

### Actual behavior
Search result by keyword is discarded

### Env
Mobile - `mail.stg.lin-saas.com`

### Reproduced video

https://github.com/user-attachments/assets/71523b9c-4485-41af-9536-483aa4cb6d6e

### Comment by tddang-linagora at 2025-08-25T07:22:22Z

## Setting - Forward recipients error handling
### Steps to reproduce
- Go to settings - forward section
- Add own email and an external email to the recipients field
- Click "Add recipients", verify that an error toast is shown and no recipient is shown
- Leave settings screen then come back to settings - forward section
- Verify that the external email is shown

### Expect behavior
If server returns any successfully added recipients, the app should show those recipients right away

<img width="751" height="494" alt="Image" src="https://github.com/user-attachments/assets/64f77e00-e493-48cd-a7a4-b5725ae54ac3" />

### Actual behavior
No recipient is shown at the moment of adding, but only shown after the forwarding recipients is loaded again.

### Reproduce video

https://github.com/user-attachments/assets/cfd4c026-aab5-4c48-970f-eb336f9f0ae1

### Comment by hoangdat at 2025-08-25T10:21:55Z

- [x] delete a rule in `Email Rules`, screen jump back to dashboard 
- [x] delete an identity, screen jump back to dashboard

### Comment by dab246 at 2025-08-26T01:46:35Z

> ## Setting - Forward recipients error handling
>  

Fixed at https://github.com/linagora/tmail-flutter/pull/3978

### Comment by tddang-linagora at 2025-08-26T02:12:09Z

>Search - Keyword search is not kept after sort

Fixed at https://github.com/linagora/tmail-flutter/pull/3980

### Comment by dab246 at 2025-08-26T02:20:30Z

- [x] Cannot close color picker when click outside in composer 

<img width="1438" height="691" alt="Image" src="https://github.com/user-attachments/assets/7172d408-b444-457e-a621-5730bf07a073" />

### Comment by dab246 at 2025-08-26T02:34:29Z

- [x] [Safari] When the input is still focused, double click to edit recipient in composer

https://github.com/user-attachments/assets/241a464e-ac56-4bd0-8f0c-5ec44fc3760c

### Comment by dab246 at 2025-08-26T02:39:14Z

- [x]  Incorrect action color and position in upload confirm dialog

<img width="1263" height="693" alt="Image" src="https://github.com/user-attachments/assets/69e48086-2e17-4b4d-89cd-2abb03a1f8e5" />

### Comment by dab246 at 2025-08-26T02:59:29Z

- [x] Sort not synchronized between Advanced Search dialog and Dashboard screen when clicking clear filter

https://github.com/user-attachments/assets/3abb60ec-0305-48c8-8421-36d796f6567a

### Comment by dab246 at 2025-08-26T03:16:39Z

- [x] Do not return to the search screen when opening an email from search then clicking `Clear Filter` in the Advanced Search dialog

https://github.com/user-attachments/assets/b8529dc5-31e9-4ca8-b6f5-158b5e6912c4

### Comment by dab246 at 2025-08-26T11:30:44Z

> * [x]  Cannot close color picker when click outside in composer
> 
> * [x]   Incorrect action color and position in upload confirm dialog
> 
> * [x]  Do not return to the search screen when opening an email from search then clicking `Clear Filter` in the Advanced Search dialog
> 
> * [x]  Sort not synchronized between Advanced Search dialog and Dashboard screen when clicking clear filter
> 
> * [x]  [Safari] When the input is still focused, double click to edit recipient in composer
> 


Fixed at https://github.com/linagora/tmail-flutter/pull/3981
