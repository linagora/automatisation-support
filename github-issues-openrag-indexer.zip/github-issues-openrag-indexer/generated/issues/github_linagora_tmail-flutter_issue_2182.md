# GitHub issue #2182: [BLUE-BAR] No blue bar for Office 365 events

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2182
State: closed
Author: chibenwa
Created at: 2023-09-28T09:04:51Z
Updated at: 2023-10-16T23:58:23Z
Closed at: 2023-10-16T23:58:21Z
Labels: bug, Medium, back-end implementing, calendar
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/2182

## Issue body

[event.eml.txt](https://github.com/linagora/tmail-flutter/files/12747664/event.eml.txt)

![Screenshot from 2023-09-28 15-59-19](https://github.com/linagora/tmail-flutter/assets/6928740/fc71266b-6de1-4d78-bc72-8a006fff2a53)
![Screenshot from 2023-09-28 15-59-43](https://github.com/linagora/tmail-flutter/assets/6928740/45216f7e-b71b-4c32-ac81-818c0a3f1be1)

```
X-MEETING-METHOD: REQUEST
X-MEETING-UID: 040000008200E00074C5B7101A82E00800000000602312E836EDD90100000000000000001000000009C40B24EBC55C49B5E76D3C60DFC74F
X-MEETING-SEQUENCE: 0
X-MEETING-DTSTAMP: 20230922T072808Z
```

## Comments

### Comment by hoangdat at 2023-10-04T04:04:48Z

All the things from our calendar have the same problem

<img width="960" alt="image" src="https://github.com/linagora/tmail-flutter/assets/6462404/14563fa1-3cfe-4a0b-9fc0-59372810ab94">

### Comment by hoangdat at 2023-10-04T05:02:38Z

we based on the old version:
https://github.com/linagora/tmail-backend/blob/a17a3051ee3176f93714b46f89f7b8c3ffc42961/tmail-backend/integration-tests/jmap/jmap-integration-tests-common/src/main/scala/com/linagora/tmail/james/common/LinagoraCalendarEventParseMethodContract.scala

The problem is miss communication of the upgrade. @chibenwa @Arsnael. Hope we can find the solution to not have this.

### Comment by hoangdat at 2023-10-04T05:03:42Z

And @QuangHoang1210 : please very careful when you press the button of release.

### Comment by dab246 at 2023-10-04T11:54:35Z

### 1. Event from Microsoft Outlook application on desktop

- Not parsing file `.ics`


https://github.com/linagora/tmail-flutter/assets/80730648/083456c9-db6a-42a7-87bb-48a6d881275e


### 2. Event from `Microsoft Teams meeting`

- Not found file `.ics`. Only file with type `text/calendar`
- Not parsing file with type `text/calendar`




https://github.com/linagora/tmail-flutter/assets/80730648/f1a307d3-4e00-47ab-b26f-2ac5b2d6ab3f

### EML file

- 1. [Outlook calendar event send.eml.zip](https://github.com/linagora/tmail-flutter/files/12803603/Outlook.calendar.event.send.eml.zip)

- 2. [Test Wang Wangg.eml.zip](https://github.com/linagora/tmail-flutter/files/12803608/Test.Wang.Wangg.eml.zip)

### Comment by chibenwa at 2023-10-04T15:31:41Z

Ok. Backend bug.

### Comment by QuangHoang1210 at 2023-10-10T16:38:45Z

Reopened this ticket:

1, Google Calendar event -> Passed

![Image](https://github.com/linagora/tmail-flutter/assets/124866146/2b1259f1-df33-4eaf-846b-4ef5405f3269)

2, Outlook Calendar event -> Failed

![Image](https://github.com/linagora/tmail-flutter/assets/124866146/968411a2-58a2-4779-9e36-4632616aa196)

### Comment by QuangHoang1210 at 2023-10-16T19:29:59Z

1, Google calendar -> Passed

2, Outlook calendar -> Failed -- Missing blue bar

![Image](https://github.com/linagora/tmail-flutter/assets/124866146/19bb9471-2252-486d-8f69-0500e423f1d5)

### Comment by chibenwa at 2023-10-16T23:58:22Z

Sure that is getting fixed on backend side
