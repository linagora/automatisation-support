# GitHub issue #1941: [Story] As a user, I want to have more options when filtering messages 

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1941
State: closed
Author: dieptran88
Created at: 2023-06-15T10:17:27Z
Updated at: 2025-10-03T09:57:04Z
Closed at: 2025-10-03T09:57:04Z
Labels: 
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1941

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

https://github.com/linagora/tmail-flutter/issues/1902

## Definition

- Given that I am a Tmail user 
- After logged in successfully, I click on my avatar, hen Select Manage account => Email rules 
- I click on button Add rule, screen Create new rule will be opened 
- I enter rule's name, input conditions then select actions 
- I can select multiple conditions by clicking on button "Add condition" 
-  When I click on button "Add condition" for the first time, there will be 2 radio buttons appears : 
   - All condition: Default selected. It means this filtering rule will be executed if all conditions are satisfied  
   - At least one condition: It means this filtering rule will executed if one of the condition is satisfied  
-  I can select multiple actions by clicking on button "Add action" 
- The the action list includes : 
   - Move message to mailbox - I need to select a mailbox to move message to
   - Mark as seen
   - Star it 
   - Reject it
   - Label as (not implemented yet now)
   - Mark as spam
   - Forward to- I need to input at least 1 email address 
- When I select action "Reject it", other actions will be removed and un-selectable 
- When an action is already selected, when I click on button "Add action", it will not be in the action list
- After select actions, I click button Create, beside current validations, system will check:
   - If no condition is selected, there will be an error message 
   - If no action is selected, there will be an error message
   - If I select action "Move message to mailbox"/"Label as"/ "Forwarding" and not input the box next to each action, there will be an error message 
   - If there is no error, the new rule is created successfully and there is a notification toast message 
 - When a new email arrives, it will be filtered by the rules with the priority from top to bottom.
  
[Back to Summary](#summary)

## Screenshots

![Group 853 (2)](https://github.com/linagora/tmail-flutter/assets/68209176/5ecef2f7-9dfd-46a5-9d4e-a7e8d7a84ba7)

![Group 868](https://github.com/linagora/tmail-flutter/assets/68209176/b08e99a7-1a81-4e9b-9a01-22dbc38edc32)

![Group 869](https://github.com/linagora/tmail-flutter/assets/68209176/68a46c57-fbf1-4850-bfa8-d73320a0f93e)


[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by dieptran88 at 2023-06-16T04:33:08Z

@hoangdat @chibenwa Please help me to review

### Comment by hoangdat at 2023-06-16T04:44:24Z

Hi @chibenwa @Arsnael Can we combine many conditions?

### Comment by Arsnael at 2023-06-19T04:43:12Z

@hoangdat As written in the epic, yes we can combine several conditions. Except if "Reject" is selected, it should not be possible to combine it with other filters

### Comment by hoangdat at 2023-06-19T06:47:45Z

> @hoangdat As written in the epic, yes we can combine several conditions. Except if "Reject" is selected, it should not be possible to combine it with other filters

@dieptran88, we need to modify the mockup for it. Thanks

### Comment by dieptran88 at 2023-06-19T06:55:00Z

hi @Arsnael I think @hoangdat asked about the "Conditions" not "Actions".
![image](https://github.com/linagora/tmail-flutter/assets/68209176/0f5d0f35-ed02-45ed-8fec-d9771ae0f875)

So we can combine multiple conditions and multiple actions in one filter rule, right ?

### Comment by Arsnael at 2023-06-19T07:09:19Z

Misunderstood, my bad!

I don't think we have more than one condition for now, that would make things too complex.

### Comment by chibenwa at 2023-07-10T08:28:57Z

![download](https://github.com/linagora/tmail-flutter/assets/6928740/f619e447-adde-4133-a7bd-3efbb84a24ec)

New design proposal.

Note: `And / Or` option should be shown only with 2+ conditions. With 1 condition we should keep the design like today (with addition of `+`)

### Comment by hoangdat at 2023-08-04T02:39:23Z

- docs: https://github.com/linagora/tmail-backend/blob/master/docs/modules/ROOT/pages/tmail-backend/jmap-extensions/jmapFilters.adoc
