# GitHub issue #2387: Starting page for mobile Tmail app 

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2387
State: closed
Author: dieptran88
Created at: 2023-12-06T09:53:02Z
Updated at: 2025-08-18T02:38:53Z
Closed at: 2025-03-10T10:35:31Z
Labels: TWP
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/2387

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition
- Given that I have  downloaded Tmail mobile app but have not logged in 
- When I open app the first time, I can see the screen Starting pages:
![Frame 171](https://github.com/linagora/tmail-flutter/assets/68209176/ced60be2-691c-42dd-ab82-178137f1ead4)
- I switch from the 1st onboarding page to the 2nd by clicking Get Started.
- On 2nd screen, There are 3 buttons:
   - Create Twake ID
   - Sign-in 
   - Use company server 
1. When I click button Create Twake Id, it redirects me to the Sign up tab of the Twake ID page.
2.  When I click on button Sign-in, it redirects me to the Sign in tab of the Twake ID page
3.  When I click on button Use company server,  it redirects me to the page for entering the email address 

![Frame 172 (1)](https://github.com/linagora/tmail-flutter/assets/68209176/1c128cec-be34-458a-82bc-10ae45ba340b)

- After input email address, the system will detect if there is SSO configuration: 
   - IF SSO is discovered, then it redirects me to the page for entering the password:
 
![Frame 173](https://github.com/linagora/tmail-flutter/assets/68209176/3b7a4c45-f91c-4b17-8d59-133bbed03ff8)

   - If SSO is not discovered,  then it redirects me to the page for entering the JMAP server
 
![Frame 174](https://github.com/linagora/tmail-flutter/assets/68209176/e4702eed-2bbd-407f-9048-b4e2e61536fe)

- After  entering the JMAP server, If the URL is not valid, there will be an error message. If the URL us valid, it redirects me to the page with  email and password fields. Email field is automatically pre-filled with the one that I inputed in previous step:

![Frame 175](https://github.com/linagora/tmail-flutter/assets/68209176/e5663f05-b117-4e19-9fe5-e4d333c01c49)



[Back to Summary](#summary)

## Screenshots

None

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by dieptran88 at 2023-12-06T09:54:04Z

@hoangdat @chibenwa Please take a look

### Comment by hoangdat at 2023-12-06T12:36:47Z

it is ok for me, but only the term `Use company server`. WDYT @chibenwa?

### Comment by chibenwa at 2023-12-06T22:25:34Z

Ok with me

### Comment by chibenwa at 2023-12-06T22:25:55Z

Maybe `Use another server` ?

### Comment by dab246 at 2024-08-23T05:12:34Z

## Technical

- Cherry pick commnits starting with `TF-2387....` in the `starting-page` branch
- Design from Figma: https://www.figma.com/design/XqLqMINlZw09BdEHI8yLb9/Teammail---1.1?node-id=1451-29590&t=O3cz2MXW5VQlXEwP-1

### Comment by hoangdat at 2024-08-28T02:53:02Z

- [ ] how to get token response?
- [ ] how to integrate with signup page?

### Comment by dpurnam at 2025-08-14T11:02:29Z

I'm unsure I follow the idea of locking the Server URL page behind User email address Page, then Password Page et al.

I've a custom JMAP server URL (different from my MX server address) and I cannot get past the Password Page with 403 error.

Why can't all 3 fields be on a single page? that's how a lot of apps are designed (for ex. Bitwarden Mail App with Custom/Self-hosted Instance)

### Comment by hoangdat at 2025-08-18T02:38:53Z

hi @dpurnam ,
We have the pages for email address because we support some kinds of login: SSO, basic authentication. With this, we can be easier to redirect use to any configured way to login.

What is the screenshot when you get 403 error? How about record a video or capture screen when it happen?

Thanks
