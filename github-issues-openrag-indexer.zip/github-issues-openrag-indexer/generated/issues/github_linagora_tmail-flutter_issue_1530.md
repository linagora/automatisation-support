# GitHub issue #1530: Many attachments: some attachments not displayed

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1530
State: closed
Author: chibenwa
Created at: 2023-03-03T09:14:52Z
Updated at: 2023-10-16T18:10:33Z
Closed at: 2023-10-16T18:10:33Z
Labels: UX, customer, friction
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1530

## Issue body

### Description

Given a mail with many attachment I can just see the first 3 or 4

![Screenshot from 2023-03-03 16-11-10](https://user-images.githubusercontent.com/6928740/222680186-f0abc7f4-9f0b-46ca-a6bd-12335f32c3f5.png)
![Screenshot from 2023-03-03 16-11-28](https://user-images.githubusercontent.com/6928740/222680200-12007d99-4def-4947-b150-e45b97401374.png)
![Screenshot from 2023-03-03 16-12-45](https://user-images.githubusercontent.com/6928740/222680206-bb60b783-590c-4a5f-85c8-68badc37b643.png)

Give me a way to see all the attachments of the emails, when I expand them.

tmail.linagora.com v0.7.1 Firefox 99.0.1

## Comments

### Comment by dab246 at 2023-03-03T09:30:44Z

You can scroll horizontally to see them.

### Comment by hoangdat at 2023-03-03T09:35:58Z

yes, but you can not scroll? @chibenwa

### Comment by hoangdat at 2023-03-03T09:39:43Z

https://user-images.githubusercontent.com/6462404/222686135-b0113da9-c969-43ca-b7ea-2d2073828eb5.mov

### Comment by chibenwa at 2023-03-03T10:07:27Z

> yes, but you can not scroll? @chibenwa

Not clear enough!

If I can not find it by instinct and feel the need to fill a ticket, it means there is a UX problem! Mme Michu and other regular users would also never find it...

### Comment by chibenwa at 2023-03-03T14:57:17Z

We should get an explicit horizontal scroll-bar?

Please have a designer / BA thinking at how to make this more explicit and have a look to other platforms.

Cc @dieptran88

### Comment by dieptran88 at 2023-03-08T10:46:11Z

Most of other apps will show all attachments, why dont we also show all attachments after uploading them and have button hide/show like when opening an email that contains multiple attachments

### Comment by dab246 at 2023-09-13T11:34:01Z

Improvement at #2116

### Comment by QuangHoang1210 at 2023-10-16T18:10:17Z

Passed on 0.10.1

![Image](https://github.com/linagora/tmail-flutter/assets/124866146/c5d5979a-538d-4891-b5fc-969b0f01108f)
