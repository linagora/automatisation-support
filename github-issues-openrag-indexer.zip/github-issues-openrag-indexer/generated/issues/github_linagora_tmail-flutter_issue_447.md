# GitHub issue #447: [EPIC] Sender Identity

## Metadata

Repository: linagora/tmail-flutter
Issue number: 447
State: closed
Author: hoangdat
Created at: 2022-04-04T07:48:48Z
Updated at: 2022-11-28T08:03:00Z
Closed at: 2022-11-28T08:03:00Z
Labels: Epic
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/447

## Issue body

_No body_

## Comments

### Comment by chibenwa at 2022-04-04T07:49:57Z

https://jmap.io/spec-mail.html#identities

 -> One setting page to read, update, delete, create new identity
 -> Identity selector when sending an email

### Comment by hoangdat at 2022-04-26T11:23:20Z

@chibenwa can you show us the request to create/edit identity, we try with `/set` but it is not successfully

### Comment by chibenwa at 2022-04-27T01:36:30Z

```
{
	"using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:submission"],
	"methodCalls": [
		[
			"Identity/set",
			{
				"accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
				"create": {
					"4f29": {
						"name": "Bob",
						"email": "bob@domain.tld",
						"replyTo": [{
							"name": "Alice",
							"email": "alice@domain.tld"
						}],
						"bcc": [{
							"name": "David",
							"email": "david@domain.tld"
						}],
						"textSignature": "Some text signature",
						"htmlSignature": "<p>Some html signature</p>"
					}
				}
			},
			"c1"
		],
		["Identity/get",
			{
				"accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
				"ids": null
			}, "c2"
		]

	]
}
```

For instance. Please note that the email needs to be the mail address of the user or a valid alias. Valid aliases can be obtained by Identity/get .

> we try with /set but it is not successfully

If possible share your errors...

### Comment by dab246 at 2022-05-06T06:02:23Z

@chibenwa . I'm doing the edit identity feature. I use SetMethod but get this error

<img width="1008" alt="Screen Shot 2022-05-06 at 12 49 32" src="https://user-images.githubusercontent.com/80730648/167075436-3189f021-fd5a-4598-8ddb-9036944ee130.png">.

### Comment by chibenwa at 2022-05-06T08:33:33Z

https://github.com/apache/james-project/pull/992 fixes this.

We will deploy a hotfix next monday on preprod.

### Comment by dab246 at 2022-05-09T09:05:28Z

Don't know if this bug has been fixed yet @chibenwa. I still get this error when I execute

### Comment by chibenwa at 2022-05-10T01:46:03Z

> Don't know if this bug has been fixed yet @chibenwa. I still get this error when I execute

Yes, merged but not deployed yet. Hang on...

### Comment by chibenwa at 2022-05-10T05:22:10Z

I deployed the fix on preprod

### Comment by chibenwa at 2022-05-10T05:22:31Z

Wait tmail backend 0.6.0 to be released for openpaas.linagpra.com
