# GitHub issue #43: [Story] As an user, i can reply or forward email with simple text

## Metadata

Repository: linagora/tmail-flutter
Issue number: 43
State: closed
Author: hoangdat
Created at: 2021-08-20T02:13:30Z
Updated at: 2022-01-04T23:12:34Z
Closed at: 2022-01-04T23:12:34Z
Labels: story:ready
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/43

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

[[Basic] Write mails](https://app.zenhub.com/workspaces/tmail-flutter-60d039db6ef62a0013432c14/issues/linagora/tmail-flutter/27)

## Definition
**UC1. Reply with simple text **

- GIVEN that  I open an from Bob in of of the mailboxes (except for Draft)
- I can see at the bottom of the email content a button "Reply"
- I click on this button then the composer will be opened
- In this new view i can see:
   - The email header fields:
      - The Subject is autofilled with the format: "Re:[original subject]". I can edit this field
      - "From": My name + email address . I cannot edit this field 
      - "To" : Autofilled with value of `replyTo` property of the original email. I can add or remove recipients by name or email address in this field
   - The email body: 
     - In the email body, i can see the list of original emails quoted with the order "latest sent-date".  Each email in this list is displayed with the date, time, sender's email address and the text content 
      - The input sections is appeared above of the quoted sections. 
      - I can write text in the input section and click button Send, if there is at least one recipient, the email is sent and the composer is closed. The email is moved to mailbox Sent 
- If there is no recipient and i click button Send, there will be an error message 
- If i  click button Cancel,  the email will be removed

** UC2: User forward an email with simple text**

- GIVEN that I open an from Bob in of of the mailboxes (except for Draft)
- I can see at the bottom of the email content a button "Forward"
- I click on this button, then the composer will be opened
   - The email header fields:
      - The Subject is autofilled with the format: "Fwd: [original subject]". I can edit this field
      - "From": My name + email address . I cannot edit this field 
      - "To" /"CC"/"BCC": There fields are empty, i can input recipient here by name or email address
   - The email body: 
      - In the email body, i can see the list of original emails quoted with the order "lastest sent-date".  Each email in this list is displayed with the date, time, sender's email address and the text content 
     - The input sections is appeared above of the quoted sections. 
     - I can write text in the input section and click button Send, if there is at least one recipient, the email is sent and the composer is closed. The email is moved to mailbox Sent 
- If there is no recipient and i click button Send, there will be an error message 
- If i  click button Cancel,  the email will be removed

[Back to Summary](#summary)

## Screenshots
![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/127df18d-af61-48b9-830d-d38bb0e3dda4)

![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/d72aaba3-fea9-41c4-92b7-a448152f2da0)

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by hoangdat at 2021-08-20T02:35:15Z

@chibenwa please help us some methods to execute both of this use case.

### Comment by hoangdat at 2021-08-20T02:37:25Z

@dieptran88 please help us on review. We need some user stories for next week. Then try to write some more user stories if needed

### Comment by chibenwa at 2021-08-20T03:10:43Z

Is that OK if I handle that on monday?

### Comment by chibenwa at 2021-08-23T04:11:56Z

## Sending an email

2 requests nested in one:

 - upload potential attachments
 - save the message in the outbox
 - send the email from the outbox...
 
## Upload potential attachments

```
POST http://172.17.0.2:80/upload/{accountId}

PAYLOAD
```

Will return:

```
{
    "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
    "blobId": "uploads-d54aa2fe-64f4-4ec3-9a35-66abc42f5999",
    "type": "application/json",
    "size": 46
}
```

Note that the `type` value will depend from the `Content-Type` header you specify as part of the upload...

## Creating and sending the email in one pass

```
{
	"using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail", "urn:ietf:params:jmap:submission"],
	"methodCalls": [
		["Email/set",
			{
				"accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
				"create": {
					"aaaaaa": {
						"subject": "I am a dreamer",
						"replyTo": [{
							"email": "bob@localhost"
						}],
						"from": [{
							"email": "bob@localhost"
						}],
						"sender": [{
							"email": "bob@localhost"
						}],
						"to": [{
							"email": "alice@localhost"
						}],
						"cc": [{
							"email": "alice@localhost"
						}],
						"bcc": [{
							"email": "alice@localhost"
						}],
						"sentAt": "2021-08-23T03:47:28Z",
						"mailboxIds": {
							"40": true
						},
						"htmlBody": [{
							"partId": "a49d",
							"type": "text/html"
						}],
						"bodyValues": {
							"a49d": {
								"value": "<html><head><title></title></head><body><div>I have the most <b>brilliant</b> plan. Let me tell you all about it. What we do is, we</div></body></html>",
								"isTruncated": false,
								"isEncodingProblem": false
							}
						},
						"attachments": [{
								"blobId": "uploads-d54aa2fe-64f4-4ec3-9a35-66abc42f5999",
								"filename": "att.txt",
								"type": "text/plain",
								"charset": "UTF-8",
								"disposition": "attachment"
							},
							{
								"blobId": "uploads-d54aa2fe-64f4-4ec3-9a35-66abc42f5999",
								"filename": "att2.txt",
								"type": "text/plain",
								"charset": "UTF-8",
								"disposition": "inline",
								"cid": "ewewr"
							}
						]
					}
				}
			}, "c2"

		],
		["EmailSubmission/set",
			{
				"accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
				"create": {
					"k1490": {
						"emailId": "#aaaaaa",
						"envelope": {
							"mailFrom": {
								"email": "bob@localhost"
							},
							"rcptTo": [{
								"email": "alice@localhost"
							}]
						}
					}
				}
			},
			"c3"
		]
	]
}
```

With return:

```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/set",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "oldState": "d45a3fe6-55b8-4945-8fb9-c6cc78dbf821",
                "newState": "ad754333-a8a0-4efa-954f-1ff296d8d369",
                "created": {
                    "aaaaaa": {
                        "id": "2155",
                        "blobId": "2155",
                        "threadId": "2155",
                        "size": 1765
                    }
                }
            },
            "c2"
        ],
        [
            "EmailSubmission/set",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "newState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
                "created": {
                    "k1490": "7dd740cc-7977-4f87-83db-71f535256c9e"
                }
            },
            "c3"
        ]
    ]
}
```

**TODO** document `onSuccessUpdateEmail` usage to move the mail from `Outbox` to `Sent`.

### Comment by chibenwa at 2021-08-23T04:46:39Z

```
{
	"using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail", "urn:ietf:params:jmap:submission"],
	"methodCalls": [
		["Email/set",
			{
				"accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
				"create": {
					"aaaaaa": {
						"mailboxIds": {
							"40": true
						}
					}
				}
			}, "c2"
		],
		["EmailSubmission/set",
			{
				"accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
				"create": {
					"k1490": {
						"emailId": "2211",
						"envelope": {
							"mailFrom": {
								"email": "bob@localhost"
							},
							"rcptTo": [{
								"email": "bob@localhost"
							}]
						}
					}
				},
                "onSuccessUpdateEmail": {
                    "#k1490": {
						"keywords": {
							"40": true
						}
                    }
                }
			},
			"c3"
		]
	]
}
```

To  move the mail from `outbox` to `sent`

### Comment by hoangdat at 2021-09-01T02:48:18Z

@chibenwa for compose/reply/foward email, we always:
1. `Email/set` to Outbox then `EmailSummission/set` and listen `onSuccessUpdateEmail`
2. `Email/set` to Sent

Am I right?

### Comment by hoangdat at 2021-09-01T08:56:11Z

Hi, @chibenwa I send request like that:
```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail",
        "urn:apache:james:params:jmap:mail:shares",
        "urn:ietf:params:jmap:submission"
    ],
    "methodCalls": [
        [
            "Email/set",
            {
                "accountId": "{{accountId}}",
                "create": {
                    "aaaaaa": {
                        "mailboxIds": {
                            "5dfb3290-0a14-11ec-b57c-2fef1ee78d9e": true
                        },
                        "from":[{
                            "email":"userb@qa.open-paas.org"
                        }],
                        "to":[{
                            "email":"userd@qa.open-paas.org"
                        }],
                        "Subject":"test onSuccessUpdateEmail",
                        "htmlBody": [
                            {
                                "partId": "mmm",
                                "blobId":"aaaa",
                                "type": "text/html"
                            }
                        ],
                        "bodyValues": {
                            "mmm": {
                                "value":"<!DOCTYPE html> <html> <body> <p><b> 3 -need to be in user d and sent of user b</b></p><br><br></body> </html>"
                            }
                        }
                    }
                }
            },
            "c1"
        ],
        [
            "EmailSubmission/set",
            {
                "accountId": "{{accountId}}",
                "create": {
                    "a1234": {
                        "emailId": "#aaaaaa",
                        "envelope": {
                            "mailFrom": {
                                "email": "userb@qa.open-paas.org"
                            },
                            "rcptTo": [{
                                "email": "userd@qa.open-paas.org"
                            }]
						}
                    }
                },
                "onSuccessUpdateEmail": {
                    "#a1234": {
                        "mailboxIds": {
                            "abb99c10-18d9-11eb-a677-2990b970028d": true
                        }
                    }
                }
            },
            "c2"
        ]
    ]
}
```
Why the new email not belong to both 2 mailboxes? I did not see any request to delete this email out of  `5dfb3290-0a14-11ec-b57c-2fef1ee78d9e`.

### Comment by chibenwa at 2021-09-01T09:41:21Z

Environment?

### Comment by hoangdat at 2021-09-01T09:50:31Z

Dev environment

### Comment by chibenwa at 2021-09-01T09:56:00Z

:+1:

### Comment by chibenwa at 2021-09-01T10:23:58Z

```
Why the new email not belong to both 2 mailboxes? I did not see any request to delete this email out of 5dfb3290-0a14-11ec-b57c-2fef1ee78d9e.
```

In fact:

```
                "onSuccessUpdateEmail": {
                    "#a1234": {
                        "mailboxIds": {
                            "abb99c10-18d9-11eb-a677-2990b970028d": true
                        }
                    }
                }
```

Means **reset the mailboxes to 5dfb3290-0a14-11ec-b57c-2fef1ee78d9e**. (sent) as we move the message from outbox to sent.

Does it answer your question @hoangdat ?
