# GitHub issue #2083: [Filtering rule] Add/remove `condition`s in UI

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2083
State: closed
Author: hoangdat
Created at: 2023-08-11T02:12:53Z
Updated at: 2023-12-07T14:39:55Z
Closed at: 2023-12-07T14:39:55Z
Labels: 
Assignees: Arsnael, hieutbui
URL: https://github.com/linagora/tmail-flutter/issues/2083

## Issue body

### Desc:
- Design:

![Image](https://user-images.githubusercontent.com/6462404/259908011-9b1d3727-3938-4021-a716-8dfc2ae56e82.png)

#### Model:
- `RuleCondition`: rule_filter/lib/rule_filter/rule_condition.dart

#### View:
- `RuleFilterCreatorView`: lib/features/rules_filter_creator/presentation/rules_filter_creator_view.dart
- `RulesFilterCreatorController`: lib/features/rules_filter_creator/presentation/rules_filter_creator_controller.dart

#### Requirements:
- Try to reuse `condition` widget

![Image](https://user-images.githubusercontent.com/6462404/259909438-59433de1-7fd2-4800-bf3a-a7e6efdf05f8.png)

### Technical

- Create new StatelessWidget `RuleFilterConditionWidget` class. To display

![Image](https://user-images.githubusercontent.com/6462404/259909438-59433de1-7fd2-4800-bf3a-a7e6efdf05f8.png)

`RuleFilterConditionWidget` included: 
  - `DropDownButtonWidget`: Widget that displays a list of `Field`
  - `DropDownButtonWidget`: Widget showing the list of `Comparator`
  - `RulesFilterInputField`: Input the value `Condition`

- In `RulesFilterCreatorController`,  replace `ruleConditionFieldSelected` and `ruleConditionComparatorSelected` to `listRuleCondition`: List of conditions
```
final listRuleCondition = RxList<RuleCondition>();
```

Every time `+ Add condition` is clicked add an element to `listRuleCondition`

Trigger variable `listRuleCondition` in `RuleFilterCreatorView` 

```
Obx(() {
 return ListView.builder(
      itemCount: listRuleCondition.length,
      itemBuilder: (context, index) => RuleFilterConditionWidget(listRuleCondition[index]),
    );
})
```

### DoD:
- [ ] can click `+` to add more condition
- [ ] can click `-` to remove condition
- [ ] demo for all mobile/tablet/web

## Comments

### Comment by Arsnael at 2023-08-11T03:47:20Z

Not related to the ticket, but regarding the design, just the `+ Add condition` on the actions section should be `+ Add action` instead :)

But thanks for the ticket @hoangdat I will try to get starting on it today

### Comment by hoangdat at 2023-08-11T03:57:01Z

> + Add condition on the actions section should be + Add action instead :)

Raised to design team.

### Comment by hoangdat at 2023-08-25T02:52:04Z

@dab246 please more detail in technical description

### Comment by Arsnael at 2023-08-25T03:16:44Z

@hoangdat I think we concluded yesterday this isn't a good first issue?

All the logic layers, from the view, passing to the controller, all the way down to the API level, are all based on one unique condition in the code. Allowing multiple requires quite the refactoring I believe, and a bit of a complex one. (would be probably true for the ticket allowing multiple actions as well)

### Comment by hoangdat at 2023-08-25T04:03:40Z

ok, I will assign it to @hieutbui , and hope you can follow it to review and help him :)))

### Comment by Arsnael at 2023-08-25T04:40:32Z

Newcomer? I feel bad for him now ^^'

### Comment by hieutbui at 2023-08-25T05:01:16Z

IM worry :_(

### Comment by dab246 at 2023-08-31T02:33:36Z

https://www.figma.com/file/XqLqMINlZw09BdEHI8yLb9/Teammail---1.1?type=design&node-id=284%3A34937&mode=design&t=KirVajmGVX5Vd2sd-1
