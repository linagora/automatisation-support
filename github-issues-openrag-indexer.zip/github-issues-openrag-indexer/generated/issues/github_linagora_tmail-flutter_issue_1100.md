# GitHub issue #1100: Display Answered / Forwarded keywords

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1100
State: closed
Author: chibenwa
Created at: 2022-10-21T07:16:14Z
Updated at: 2023-04-25T02:28:48Z
Closed at: 2023-04-25T02:28:48Z
Labels: Critical, UX
Assignees: nqhhdev
URL: https://github.com/linagora/tmail-flutter/issues/1100

## Issue body

### Description

As a user I want to see which emails I answered or forwarded from the EmailList.

Today not done with TMail.

Here is what Thunderbird looks like as a reference:

![Screenshot from 2022-10-21 14-08-00](https://user-images.githubusercontent.com/6928740/197135828-4e4980d1-4530-45af-9208-0742512d1122.png)

Suggestions, at least for TMail Web:

![Screenshot from 2022-10-21 14-05-07](https://user-images.githubusercontent.com/6928740/197135884-989d2c4d-c6b6-4dbe-81f2-3bd9dd7cc051.png)


Cc @dieptran88 do a design for it.

## Comments

### Comment by hoangdat at 2022-10-21T07:33:35Z

@hknguyen91, please take a look and then create the prototype with it. From my aspect, it is useful, but maybe mess the view. I am a big fan of minimalism :)

### Comment by chibenwa at 2022-10-21T07:44:14Z

> @hknguyen91, please take a look and then create the prototype with it. From my aspect, it is useful, but maybe mess the view. I am a big fan of minimalism :)

At the very least on "Web" view

### Comment by chibenwa at 2022-10-21T07:48:15Z

![Screenshot_20221021-144441_Email](https://user-images.githubusercontent.com/6928740/197142116-756bd7cd-3edf-4997-98a2-666ceec7932b.jpg)

Here is an example of samsung mail app that also displays it.

### Comment by hknguyen91 at 2022-10-24T02:46:56Z

@hoangdat @chibenwa You should make a ticket with this involving cases such as the first time you replied, it'll show up the back arrow icon, what happens when this discussion come up with multiple mailings? The same with forward.
And actually, this came up with a pre-word like this:https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=2654%3A159609

And I believed Dat already implement this.

### Comment by chibenwa at 2022-10-24T05:30:33Z

> what happens when this discussion come up with multiple mailings? 

I do not understand the question

> And actually, this came up with a pre-word like this:https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=2654%3A159609

I do not see anything related to Forward / reply in this figma...

### Comment by chibenwa at 2022-10-24T06:55:27Z

We could be having a little display next to the attachment icon

CF 

![Screenshot from 2022-10-24 13-53-22](https://user-images.githubusercontent.com/6928740/197465427-4a3fbdc5-92bd-478a-89ba-35beae8bfc20.png)

BTW this is what the samsung email client is currently doing.

### Comment by hknguyen91 at 2022-10-24T07:32:57Z

I mean what was this icon represent? If this icon indicates you have answered an email yet or not, then what happens if I get an email (1), then I answered that email ( the arrow icon display)(2), and then the sender replied to it (3), so now (3), does the icon appear, still? and this time, if I reply to this discussion (4), then what is this icon represent? For the case of (4) or (2)?

=> What was this icon(4) represent? A discussion or only that you have replied to this?

### Comment by chibenwa at 2022-10-24T07:49:15Z

If YOU replied to this email, the icon appears.

We do not care about the sender replying to your reply and so on and so on.

There is currently no notion of "conversation".

### Comment by hoangdat at 2022-10-25T04:26:54Z

To be applied

### Comment by hoangdat at 2022-10-25T04:27:23Z

@dieptran88 please create design ticket

### Comment by chibenwa at 2023-03-30T01:14:50Z

@dieptran88 do we have a design ticket for this?

### Comment by dieptran88 at 2023-03-30T01:54:42Z

Yes, we discussed about this with Khanh

### Comment by dieptran88 at 2023-03-30T02:13:46Z

The design is validated: 
![image](https://user-images.githubusercontent.com/68209176/228710195-f6285ec8-dc0c-446c-a5d6-f2ff76aa8849.png)

### Comment by chibenwa at 2023-03-30T05:08:20Z

@hoangdat can we add this to the backlog?

@dieptran88 what do we do when the mail is both answered **and** forwarded?

### Comment by dieptran88 at 2023-03-30T06:46:37Z

If an email has been replied to (1) and then forwarded (2), the icon will update to the newest state (2)

### Comment by chibenwa at 2023-03-30T08:30:12Z

> If an email has been replied to (1) and then forwarded (2), the icon will update to the newest state (2)

No there is no notion of "latest state" in email flag storage, Diep.

Anyway the behaviour of other mail apps is to show both (2 icons, or 1 icon combining both arrow).

Can you add this case in the visual?

### Comment by chibenwa at 2023-04-03T04:57:38Z

@dieptran88

### Comment by dieptran88 at 2023-04-03T12:05:03Z

the design is updated 
![image](https://user-images.githubusercontent.com/68209176/229503880-37b065b0-dc27-4c35-8c49-71aa17abca1c.png)

### Comment by nqhhdev at 2023-04-10T03:58:38Z

Hi @chibenwa @Arsnael 

I'm trying this case, I replied to an email from another account then I checked the response that email
I don't see `keywords`: `answered` or `forwarded`. Could you help me support this case?
Thanks all

`Request`

```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:apache:james:params:jmap:mail:shares"
  ],
  "methodCalls": [
    [
      "Email/get",
      {
        "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
        "ids": [
          "7c884da0-d74b-11ed-85d9-2f62cdc4d454"
        ],
        "properties": [
          "bodyValues",
          "htmlBody",
          "attachments",
          "headers",
          "keywords",
          "mailboxIds"
        ],
        "fetchHTMLBodyValues": true
      },
      "c0"
    ]
  ]
}
```

`Response`
```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/get",
            {
                "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
                "notFound": [],
                "state": "eab51b50-d74b-11ed-85d9-2f62cdc4d454",
                "list": [
                    {
                        "id": "7c884da0-d74b-11ed-85d9-2f62cdc4d454",
                        "keywords": {
                            "$seen": true
                        },
                        "headers": [
                            {
                                "name": "Return-Path",
                                "value": " <firstname23.surname23@upn.integration-open-paas.org>"
                            },
                            {
                                "name": "org.apache.james.rspamd.flag",
                                "value": " NO"
                            },
                            {
                                "name": "org.apache.james.rspamd.status",
                                "value": " No, actions=no action score=2.0 requiredScore=15.0"
                            },
                            {
                                "name": "Received",
                                "value": " from postfix-in-0.postfix-in.tenant-upn.svc.cluster.local (EHLO incoming.upn.integration-open-paas.org) ([10.2.1.11])\r\n          by smtp.upn.integration-open-paas.org (JAMES SMTP Server ) with ESMTP ID 44037389\r\n          for <firstname29.surname29@upn.integration-open-paas.org>;\r\n          Mon, 10 Apr 2023 02:57:41 +0000 (UTC)"
                            },
                            {
                                "name": "Received",
                                "value": " from smtp.upn.integration-open-paas.org (unknown [10.2.2.0])\r\n\tby incoming.upn.integration-open-paas.org (Postfix) with ESMTPS id 1B9013A\r\n\tfor <firstname29.surname29@upn.integration-open-paas.org>; Mon, 10 Apr 2023 02:57:40 +0000 (UTC)"
                            },
                            {
                                "name": "Received",
                                "value": " from [192.168.1.34] (unknown [222.252.23.73])\r\n\tby smtp.upn.integration-open-paas.org (Postfix) with ESMTPSA id C05A021032\r\n\tfor <firstname29.surname29@upn.integration-open-paas.org>; Mon, 10 Apr 2023 02:57:39 +0000 (UTC)"
                            },
                            {
                                "name": "Message-ID",
                                "value": " <8db6533a-33aa-a6e0-d5b4-4c1b269817d3@upn.integration-open-paas.org>"
                            },
                            {
                                "name": "Date",
                                "value": " Mon, 10 Apr 2023 09:57:33 +0700"
                            },
                            {
                                "name": "MIME-Version",
                                "value": " 1.0"
                            },
                            {
                                "name": "User-Agent",
                                "value": " Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:102.0)\r\n Gecko/20100101 Thunderbird/102.9.0"
                            },
                            {
                                "name": "Content-Language",
                                "value": " en-US"
                            },
                            {
                                "name": "To",
                                "value": " firstname29.surname29@upn.integration-open-paas.org"
                            },
                            {
                                "name": "From",
                                "value": " 23 <firstname23.surname23@upn.integration-open-paas.org>"
                            },
                            {
                                "name": "Content-Type",
                                "value": " text/plain; charset=UTF-8; format=flowed"
                            },
                            {
                                "name": "Content-Transfer-Encoding",
                                "value": " 7bit"
                            }
                        ],
                        "attachments": [],
                        "htmlBody": [
                            {
                                "charset": "UTF-8",
                                "size": 14,
                                "partId": "1",
                                "blobId": "7c884da0-d74b-11ed-85d9-2f62cdc4d454_1",
                                "language": [
                                    "en-US"
                                ],
                                "type": "text/plain"
                            }
                        ],
                        "mailboxIds": {
                            "fcc1fcf0-30a9-11eb-9a8d-254ee97830fe": true
                        },
                        "bodyValues": {
                            "1": {
                                "value": "anh Dat 23\r\n\r\n",
                                "isEncodingProblem": false,
                                "isTruncated": false
                            }
                        }
                    }
                ]
            },
            "c0"
        ]
    ]
}
```

### Comment by Arsnael at 2023-04-10T05:13:09Z

@nqhhdev is the user firstname29.surname29?

Other question: does Tmail flutter sets up those keywords? Like when you read a mail you update the keyword seen to true, if yo don't add those keywords after doing a forward or sent? I would think likely in the `onSuccessUpdateEmail` part when doing the "EmailSubmission/set" method call, where you can set those keywords when email is sent successfully.

If you do that and it does not work, then we might investigate on backend. If you don't do that yet, please try :)

### Comment by Arsnael at 2023-04-10T05:14:34Z

Just paste me your "EmailSubmission/set" method when sending a mail (answering and forwarding). If the keywords are not set in the `onSuccessUpdateEmail` then that's likely the root of the issue

### Comment by chibenwa at 2023-04-10T05:21:43Z

> I'm trying this case, I replied to an email from another account then I checked the response that email

Answered / Forwarded only applies to your account. They are set on your mails when you reply / forward.

### Comment by chibenwa at 2023-04-10T05:30:34Z

```
$ curl -XPOST https://jmap.linagora.com/jmap -H "Accept: application/json;jmapVersion=rfc-8621" -H "Authorization: Basic zzzzzzz" -d '{"using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],"methodCalls": [  [  "Email/get",  { "accountId": "50fb9073ba109901291988b0d78e8a602a6fcd96fbde033eb46ca308779f8fac", "ids": ["bc37ec80-d75f-11ed-be1d-93359ff9f82c"], "properties": ["keywords"]},"c0" ] ]}   ' | jq .
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   643  100   367  100   276    393    295 --:--:-- --:--:-- --:--:--   689
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/get",
      {
        "accountId": "50fb9073ba109901291988b0d78e8a602a6fcd96fbde033eb46ca308779f8fac",
        "notFound": [],
        "state": "6e4066a0-d760-11ed-be1d-93359ff9f82c",
        "list": [
          {
            "id": "bc37ec80-d75f-11ed-be1d-93359ff9f82c",
            "keywords": {
              "nonjunk": true,
              "$forwarded": true,
              "$seen": true,
              "$answered": true
            }
          }
        ]
      },
      "c0"
    ]
  ]
}
```
