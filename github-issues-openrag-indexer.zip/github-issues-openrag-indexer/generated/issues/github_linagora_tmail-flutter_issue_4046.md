# GitHub issue #4046: Can not search with `from` fields in TWP

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4046
State: closed
Author: hoangdat
Created at: 2025-09-24T04:57:23Z
Updated at: 2025-11-25T09:37:27Z
Closed at: 2025-11-25T09:37:27Z
Labels: bug
Assignees: chibenwa, quantranhong1999
URL: https://github.com/linagora/tmail-flutter/issues/4046

## Issue body

### Desc
```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:apache:james:params:jmap:mail:shares"
  ],
  "methodCalls": [
    [
      "Email/query",
      {
        "accountId": "750b7391d4e9be0de1e251cc3664761fed57bc92be1db6ed4bb2050a98189338",
        "position": 0,
        "filter": {
          "from": "datoct@stg.lin-saas.com"
        },
        "limit": 20
      },
      "c0"
    ],
    [
      "SearchSnippet/get",
      {
        "accountId": "750b7391d4e9be0de1e251cc3664761fed57bc92be1db6ed4bb2050a98189338",
        "filter": {
          "from": "datoct@stg.lin-saas.com"
        },
        "#emailIds": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        }
      },
      "c1"
    ],
    [
      "Email/get",
      {
        "accountId": "750b7391d4e9be0de1e251cc3664761fed57bc92be1db6ed4bb2050a98189338",
        "#ids": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        },
        "properties": [
          "id",
          "blobId",
          "subject",
          "from",
          ....
          "header:List-Unsubscribe:asText",
          "header:X-MEETING-UID:asText"
        ]
      },
      "c2"
    ]
  ]
}
```
No result responses, even have a lot of email from this guy

## Comments

### Comment by hoangdat at 2025-09-24T04:58:01Z

hi @Arsnael , please take a look on it. 
We can reproduce it in twp-staging
Cc @thuyenh1081

### Comment by dab246 at 2025-09-29T02:18:52Z

I have retested it on the staging environment, and it’s working well now.

https://github.com/user-attachments/assets/51e7986d-f5b2-49da-a490-fec973764726

### Comment by Arsnael at 2025-09-29T03:15:29Z

Note that the saas team was heavily redeploying/testing things last week, some services (like opensearch?) could have been disrupted when you tested?

If it works now I will not investigate, please confirm @hoangdat

### Comment by hoangdat at 2025-09-29T06:17:12Z

@Arsnael @thuyenh1081 please verify again in your side too. I still have problem from my side.

### Comment by Arsnael at 2025-09-29T06:48:24Z

I checked quickly I could find with a search... You gonna need to give me a test account where you reproduce such an issue if you want me to have a proper look

### Comment by chibenwa at 2025-09-29T11:38:09Z

I think we did not reindex the staging environment after adopting the new mappings.

Which means that historic emails were likely not to be indexed. No issues on new mail.

I did trigger a reindexing on twp staging. Does it solves the issue @hoangdat ?

Is there other platforms where we need to run such a reindexing?

### Comment by chibenwa at 2025-10-31T09:53:53Z

Happens on @linagora.com

### Comment by Arsnael at 2025-11-03T04:37:56Z

> Happens on @linagora.com

I remember we did the reindex => https://github.com/linagora/james-project-private/issues/1084

Something else happening? Let me check logs...

### Comment by Arsnael at 2025-11-03T04:38:32Z

Should we remove the mailbox_v2 index in linagora.com while we are at it too?

### Comment by Arsnael at 2025-11-03T06:42:44Z

As discussed with @chibenwa , maybe a tokenization issue? Some search with mail addresses with a dot for example seem to return nothing (like yann.biez@....)

Likely a regression since ngram. Needs to be investigated deeper

### Comment by quantranhong1999 at 2025-11-05T02:46:21Z

> Some search with mail addresses with a dot for example seem to return nothing (like yann.biez@....)

I just give a quick try, e.g., I want to search email from `quan.tranhong1999@gmail.com`.

- input `quan.tranhong1999@gmail.com` => it works
- input `quan.tranhong` (but search quickly, so frontend does not resolve the full address using TMail/autocomplete yet) => backend returns none.
- input `quan.tranhong` (but search a bit slowly, so frontend resolves the full address `quan.tranhong1999@gmail.com` using TMail/autocomplete yet) => it works.

> Likely a regression since ngram.

We apply ngram for subject and attachment filename only, and we keep the same mapping for the `from` header. Not sure it is related. Could it be a long-existing issue instead?

### Comment by quantranhong1999 at 2025-11-25T09:19:05Z

I confirm it works well with the latest backend release 1.0.12.

Before, a few rare cases with the address having the hyphen `-` character inside would result in an empty search.
https://github.com/apache/james-project/pull/2860 fixed the issue.

I add a few related tests, and avoid the same issue for attachment filename, as filename can contain arbitrary characters (query string chars like `-`, `(`, `)`, `*`,...) in https://github.com/linagora/tmail-backend/pull/2029. cc @chibenwa

### Comment by chibenwa at 2025-11-25T09:31:15Z

I think TMail backend 1.0.12 did fix this: 

<img width="1944" height="699" alt="Image" src="https://github.com/user-attachments/assets/f2497444-c38e-4e0c-a46d-cc4c42cd397d" />

(I was not having results before, it is linked with the heuristic recent changes)

### Comment by chibenwa at 2025-11-25T09:37:27Z

Thanks for your work on this @quantranhong1999
