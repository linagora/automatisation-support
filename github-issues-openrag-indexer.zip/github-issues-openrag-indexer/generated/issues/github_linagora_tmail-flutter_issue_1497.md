# GitHub issue #1497: [Outbox] Reloading function is not working correctly

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1497
State: closed
Author: QuangHoang1210
Created at: 2023-02-22T10:49:31Z
Updated at: 2023-05-15T03:22:51Z
Closed at: 2023-05-15T03:22:51Z
Labels: bug, Critical
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1497

## Issue body

OS: Android/ IOS / Window
Device: Mobile / Laptop
TMail version: 0.7.0

*Precondition: Outbox having email

*Reproduce step:
1, User scroll to reload the Outbox screen

Actual: System display less mail more than before
Expected: System should reload the screen and update the Outbox listing once user have new outbox. If not, the listing is keeping same.


https://user-images.githubusercontent.com/124866146/220598679-ae7d54ef-fbf1-41cc-9ef1-2a7cee061f56.mp4

## Comments

### Comment by nqhhdev at 2023-02-27T00:54:52Z

Have you tested on prod environment?
What happened?
My demo : ver 0.7.1
https://user-images.githubusercontent.com/99852347/221449076-6ad9eb97-cf7b-4b92-9361-b76b12b7467f.MOV

### Comment by QuangHoang1210 at 2023-02-28T02:29:59Z

@nqhhdev  It not happen on prod env. But it still being on preprod Ver 0.7.1

https://user-images.githubusercontent.com/124866146/221737896-05bed199-ce9b-407a-9f8a-930af8cf309e.mp4

### Comment by nqhhdev at 2023-03-01T05:46:56Z

@chibenwa 
I use account : firstname200.surname200@upn.integration-open-paas.org

I got all email filters by `OutBox` role with `mailboxId: bb6b69d0-32cf-11eb-995c-a3ae66e9f96a` 

`Header`

![Image](https://user-images.githubusercontent.com/99852347/222087449-7eb4dbf5-112b-4c22-953a-676eb1b593ed.png)

then received response 

![Image](https://user-images.githubusercontent.com/99852347/222056036-3e9340a1-841f-427e-968a-2fad036e404f.png)


I think `mailboxId` from response is not correct, help me check it

### Comment by chibenwa at 2023-03-01T17:11:25Z

Cc @Arsnael

### Comment by Arsnael at 2023-03-02T03:25:47Z

@nqhhdev can you actually paste the request json so we can try that on our side? I'm not spending half an hour recopying it manually from a screenshot :)

### Comment by nqhhdev at 2023-03-02T03:34:59Z

Account : firsname200.surname200@upn.integration-open-paas.org

`Get all mailbox`

```

{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail",
        "urn:apache:james:params:jmap:mail:shares"
    ],
    "methodCalls": [
        [
            "Mailbox/get",
            {
                "accountId": "59ecb678c68f69e90d50b580d14512b6c2ec520afe5a3c522113b100235df799"
            },
            "c0"
        ]
    ]
}

```
`Get all email`

```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail"
    ],
    "methodCalls": [
        [
            "Email/query",
            {
                "accountId": "59ecb678c68f69e90d50b580d14512b6c2ec520afe5a3c522113b100235df799",
                "filter": {
                    "inMailbox": "bb6b69d0-32cf-11eb-995c-a3ae66e9f96a"
                },
                "sort": [
                    {
                        "isAscending": false,
                        "property": "receivedAt"
                    }
                ],
                "limit": 20
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "59ecb678c68f69e90d50b580d14512b6c2ec520afe5a3c522113b100235df799",
                "#ids": {
                    "resultOf": "c2",
                    "name": "Email/query",
                    "path": "ids/*"
                }
            },
            "c3"
        ]
    ]
}
```

cc: @Arsnael

### Comment by chibenwa at 2023-03-02T09:02:13Z

Ok i got it, that is a classic data race.
The unexpected mailbox id there should be the sent mailbox.

Normal sequence is:

 - users sends the email thus saves it in outbox
 - populate email query view is populated for outbox
 - system moves the email into sent box
 - populate email query view is populated for sent

What actually happens is:

 - users sends the email thus saves it in outbox
 - system moves the email into sent box
 - populate email query view is populated for sent
 - populate email query view is populated for outbox

1: @hoangdat  front should filter out unrelated email and handle this case.

2: @Arsnael create a back ticket. My bet is that we can create a system based on keywords to solve this.

If the message is created in outbox, be extra careful before triggering the change. Re read the mailbox ids from db do ensure this is still outbox.

Similar pb for sure happens with opensearch indexing.

### Comment by Arsnael at 2023-03-02T10:30:26Z

https://github.com/linagora/james-project/issues/4736

### Comment by chibenwa at 2023-03-02T12:18:02Z

@hoangdat 

> 1: @hoangdat front should filter out unrelated email and handle this case.

Is that clear to you and your team?

### Comment by hoangdat at 2023-03-02T12:32:51Z

Still not understand your point. But for sure, we only show the emails which have the `mailboxId` matched the selected mailbox. But as the QA want to eliminate is the blink blink when user jump into `Outbox`

### Comment by dab246 at 2023-03-31T03:03:46Z

Check more after change `Team-Mailbox` capability

### Comment by QuangHoang1210 at 2023-04-03T15:01:39Z

@dab246 it still happen on Tmail 0.7.6


### Evidence:

https://user-images.githubusercontent.com/124866146/229549017-0e379f15-fb0c-40a6-bf99-d538073bf89d.mp4


### Request payload:
```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:apache:james:params:jmap:mail:shares"
  ],
  "methodCalls": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "filter": {
          "inMailbox": "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a"
        },
        "sort": [
          {
            "isAscending": false,
            "property": "receivedAt"
          }
        ],
        "limit": 20
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "#ids": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        },
        "properties": [
          "id",
          "subject",
          "from",
          "to",
          "cc",
          "bcc",
          "keywords",
          "size",
          "receivedAt",
          "sentAt",
          "preview",
          "hasAttachment",
          "replyTo",
          "mailboxIds"
        ]
      },
      "c1"
    ]
  ]
}
```




### Response payload:
```
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "queryState": "c62ed5e5",
        "canCalculateChanges": false,
        "ids": [
          "6e7151d0-c300-11ed-b286-674033c03e6f",
          "5bd18400-b40f-11ed-acb8-2f989b3f0bd9",
          "4f0b1970-b40f-11ed-acb8-2f989b3f0bd9",
          "ef96a730-dd76-11ec-8a54-9548d40d5682",
          "8d2bd0d0-da5f-11ec-8371-2f1b2459e17b",
          "b0345b60-8b18-11ec-bf40-dd94b3d6a7a7",
          "44064ce0-f839-11eb-85e8-e1029c1737f1",
          "cbdd3000-f4e9-11eb-868e-458341e8a258",
          "8b160170-f4e7-11eb-8f4d-db0c8139b4b9",
          "27cc41c0-de11-11eb-91ba-b3d6bfcf4bc8",
          "a5de89c0-de10-11eb-91ba-b3d6bfcf4bc8",
          "a0692361-de10-11eb-91ba-b3d6bfcf4bc8",
          "61adade0-de0f-11eb-bbc4-01054eff6c02",
          "78ca6b20-d28f-11eb-9e9f-65386462f7c8",
          "229e4ef0-d00b-11eb-bc1e-efba5dd6657f",
          "3598ecd0-ccba-11eb-93fc-61e7c1d86a65",
          "6cd51830-c5d6-11eb-aeaf-b904d4d394ad",
          "99e3a890-c5d2-11eb-8221-e13ec9072152",
          "4bd38190-c4d6-11eb-85d7-7323a53e2418",
          "a153a7f0-c489-11eb-8ba9-0b039b674140"
        ],
        "position": 0
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "57921fd0-d20f-11ed-85e6-d19eaa167fb4",
        "list": [
          {
            "preview": "7fc404ab-00a4-46f8-bd23-6e626827ce17",
            "to": [
              {
                "name": "firstname17928.surname17928@upn.integration-open-paas.org",
                "email": "firstname17928.surname17928@upn.integration-open-paas.org"
              }
            ],
            "id": "27cc41c0-de11-11eb-91ba-b3d6bfcf4bc8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:18:02Z",
            "sentAt": "2021-07-06T04:18:02Z",
            "hasAttachment": false,
            "subject": "07e86f92-129c-4cf4-8478-06d31d9b20e7",
            "size": 678
          },
          {
            "preview": "71db0513-ba4b-4264-815f-72c3ba457a5b",
            "to": [
              {
                "name": "firstname5638.surname5638@upn.integration-open-paas.org",
                "email": "firstname5638.surname5638@upn.integration-open-paas.org"
              }
            ],
            "id": "a153a7f0-c489-11eb-8ba9-0b039b674140",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2021-06-03T16:34:56Z",
            "sentAt": "2021-06-03T16:34:56Z",
            "hasAttachment": false,
            "subject": "6148c32e-e2d7-4ab5-98de-d00171bc2976",
            "size": 675
          },
          {
            "preview": "f8098b68-f333-4a3f-a401-9d5c267e6fcd",
            "to": [
              {
                "name": "firstname2245.surname2245@upn.integration-open-paas.org",
                "email": "firstname2245.surname2245@upn.integration-open-paas.org"
              }
            ],
            "id": "a5de89c0-de10-11eb-91ba-b3d6bfcf4bc8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:14:24Z",
            "sentAt": "2021-07-06T04:14:24Z",
            "hasAttachment": false,
            "subject": "ba69a8dd-a20b-41e4-91d6-c9c60a72be63",
            "size": 674
          },
          {
            "preview": "51d7d6fc-3858-437f-8329-b8019b2b60ff",
            "to": [
              {
                "name": "firstname5821.surname5821@upn.integration-open-paas.org",
                "email": "firstname5821.surname5821@upn.integration-open-paas.org"
              }
            ],
            "id": "8b160170-f4e7-11eb-8f4d-db0c8139b4b9",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-08-04T05:48:07Z",
            "sentAt": "2021-08-04T05:48:07Z",
            "hasAttachment": false,
            "subject": "262576a1-86f5-4695-9864-7556a19556c2",
            "size": 675
          },
          {
            "preview": "973b2914-d05e-44c4-b7d6-5064a736d645",
            "to": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "6e7151d0-c300-11ed-b286-674033c03e6f",
            "mailboxIds": {
              "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname2423.surname2423@upn.integration-open-paas.org",
                "email": "firstname2423.surname2423@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2023-03-15T07:10:13Z",
            "sentAt": "2023-03-15T07:01:43Z",
            "hasAttachment": false,
            "subject": "08b04089-eacd-4d08-adba-f2a6f8d9fd84",
            "size": 874
          },
          {
            "preview": "14c78e76-da99-457f-b098-59f91e6439af",
            "to": [
              {
                "name": "firstname486.surname486@upn.integration-open-paas.org",
                "email": "firstname486.surname486@upn.integration-open-paas.org"
              }
            ],
            "id": "6cd51830-c5d6-11eb-aeaf-b904d4d394ad",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-05T08:17:10Z",
            "sentAt": "2021-06-05T08:17:10Z",
            "hasAttachment": false,
            "subject": "ba65d9b5-1f94-428f-bee6-d8df60d58e25",
            "size": 672
          },
          {
            "preview": "7284ff59-e26f-4cce-839d-9784bc22bb6e",
            "to": [
              {
                "name": "firstname7090.surname7090@upn.integration-open-paas.org",
                "email": "firstname7090.surname7090@upn.integration-open-paas.org"
              }
            ],
            "id": "99e3a890-c5d2-11eb-8221-e13ec9072152",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-05T07:49:48Z",
            "sentAt": "2021-06-05T07:49:48Z",
            "hasAttachment": false,
            "subject": "e383ab5c-1cb9-4833-a839-6c29027452db",
            "size": 674
          },
          {
            "preview": "30794a1c-060a-4ff3-a73b-2b481c8afb38",
            "to": [
              {
                "name": "firstname14905.surname14905@upn.integration-open-paas.org",
                "email": "firstname14905.surname14905@upn.integration-open-paas.org"
              }
            ],
            "id": "4bd38190-c4d6-11eb-85d7-7323a53e2418",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-04T01:43:43Z",
            "sentAt": "2021-06-04T01:43:43Z",
            "hasAttachment": false,
            "subject": "6a9376e8-8501-4d12-b9f3-a881d1fd3619",
            "size": 679
          },
          {
            "preview": "d580177b-7b51-4a5e-878d-26680eefaec9",
            "to": [
              {
                "name": "firstname18133.surname18133@upn.integration-open-paas.org",
                "email": "firstname18133.surname18133@upn.integration-open-paas.org"
              }
            ],
            "id": "3598ecd0-ccba-11eb-93fc-61e7c1d86a65",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-14T02:42:50Z",
            "sentAt": "2021-06-14T02:42:50Z",
            "hasAttachment": false,
            "subject": "a8b68085-a3ce-4de2-902b-8185be7878b1",
            "size": 680
          },
          {
            "replyTo": [
              {
                "email": "expeditor@linagora.com"
              }
            ],
            "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
            "to": [
              {
                "name": "Recipient",
                "email": "recipient@linagora.com"
              }
            ],
            "id": "5bd18400-b40f-11ed-acb8-2f989b3f0bd9",
            "mailboxIds": {
              "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Tuan PHAM",
                "email": "expeditor@linagora.com"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-24T06:49:17Z",
            "sentAt": "2022-04-26T02:27:54Z",
            "hasAttachment": false,
            "subject": "test subject",
            "size": 5104
          },
          {
            "preview": "f6b7a7de-373e-4c4e-937c-a75e6bf17dd1",
            "to": [
              {
                "name": "firstname6763.surname6763@upn.integration-open-paas.org",
                "email": "firstname6763.surname6763@upn.integration-open-paas.org"
              }
            ],
            "id": "61adade0-de0f-11eb-bbc4-01054eff6c02",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:05:20Z",
            "sentAt": "2021-07-06T04:05:20Z",
            "hasAttachment": false,
            "subject": "684ee87d-9ea0-4e9c-a03f-fa51e542b5bf",
            "size": 675
          },
          {
            "preview": "1a072acb-3a94-4fd8-bfbf-bd7238edb64e",
            "to": [
              {
                "name": "firstname1172.surname1172@upn.integration-open-paas.org",
                "email": "firstname1172.surname1172@upn.integration-open-paas.org"
              }
            ],
            "id": "8d2bd0d0-da5f-11ec-8371-2f1b2459e17b",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2022-05-23T06:14:06Z",
            "sentAt": "2022-05-23T06:14:06Z",
            "hasAttachment": false,
            "subject": "072f1e42-a3f6-4bea-9193-9b5467390747",
            "size": 674
          },
          {
            "preview": "fe1595c2-2cca-45ba-93a4-c6be9ec2f3ee",
            "to": [
              {
                "name": "firstname6098.surname6098@upn.integration-open-paas.org",
                "email": "firstname6098.surname6098@upn.integration-open-paas.org"
              }
            ],
            "id": "44064ce0-f839-11eb-85e8-e1029c1737f1",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-08-08T11:10:38Z",
            "sentAt": "2021-08-08T11:10:38Z",
            "hasAttachment": false,
            "subject": "59b1b3ce-e2aa-48e2-9db9-0b9dd182b8e8",
            "size": 675
          },
          {
            "preview": "e62669ff-a917-4ec8-8c1a-e984ce6d4c53",
            "to": [
              {
                "name": "firstname9186.surname9186@upn.integration-open-paas.org",
                "email": "firstname9186.surname9186@upn.integration-open-paas.org"
              }
            ],
            "id": "b0345b60-8b18-11ec-bf40-dd94b3d6a7a7",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2022-02-11T08:57:49Z",
            "sentAt": "2022-02-11T08:57:49Z",
            "hasAttachment": false,
            "subject": "8c46879c-fe13-45ee-8b78-6b979f71f32f",
            "size": 675
          },
          {
            "preview": "56a7bdb5-77e4-4015-9e90-00792ede710e",
            "to": [
              {
                "name": "firstname4429.surname4429@upn.integration-open-paas.org",
                "email": "firstname4429.surname4429@upn.integration-open-paas.org"
              }
            ],
            "id": "ef96a730-dd76-11ec-8a54-9548d40d5682",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2022-05-27T04:39:03Z",
            "sentAt": "2022-05-27T04:39:03Z",
            "hasAttachment": false,
            "subject": "4cd05113-c38d-49cd-8fa2-e94e90346264",
            "size": 675
          },
          {
            "preview": "a8ce3690-03ed-482c-bc67-0f4380e45f70",
            "to": [
              {
                "name": "firstname9019.surname9019@upn.integration-open-paas.org",
                "email": "firstname9019.surname9019@upn.integration-open-paas.org"
              }
            ],
            "id": "cbdd3000-f4e9-11eb-868e-458341e8a258",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2021-08-04T06:04:14Z",
            "sentAt": "2021-08-04T06:04:14Z",
            "hasAttachment": false,
            "subject": "5a488898-3c56-4c46-9229-46ba0298c3c8",
            "size": 674
          },
          {
            "preview": "c09c34f5-10a0-4647-affc-12ddb65119b6",
            "to": [
              {
                "name": "firstname15868.surname15868@upn.integration-open-paas.org",
                "email": "firstname15868.surname15868@upn.integration-open-paas.org"
              }
            ],
            "id": "78ca6b20-d28f-11eb-9e9f-65386462f7c8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-21T12:52:00Z",
            "sentAt": "2021-06-21T12:52:00Z",
            "hasAttachment": false,
            "subject": "4a8e5d0d-4f94-490f-806b-ec2de251dd34",
            "size": 680
          },
          {
            "replyTo": [
              {
                "email": "expeditor@linagora.com"
              }
            ],
            "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
            "to": [
              {
                "name": "Recipient",
                "email": "recipient@linagora.com"
              }
            ],
            "id": "4f0b1970-b40f-11ed-acb8-2f989b3f0bd9",
            "mailboxIds": {
              "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Tuan PHAM",
                "email": "expeditor@linagora.com"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2023-02-24T06:48:56Z",
            "sentAt": "2022-04-26T02:27:54Z",
            "hasAttachment": false,
            "subject": "test subject",
            "size": 5104
          },
          {
            "preview": "97106bc0-8f6c-4809-bdd6-be83e9fb5a91",
            "to": [
              {
                "name": "firstname7821.surname7821@upn.integration-open-paas.org",
                "email": "firstname7821.surname7821@upn.integration-open-paas.org"
              }
            ],
            "id": "a0692361-de10-11eb-91ba-b3d6bfcf4bc8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:14:15Z",
            "sentAt": "2021-07-06T04:14:15Z",
            "hasAttachment": false,
            "subject": "df64ad0c-19ec-4801-ae35-8005691f1ea6",
            "size": 674
          },
          {
            "preview": "1195a88f-2b8e-4597-b762-fa3503612e76",
            "to": [
              {
                "name": "firstname4173.surname4173@upn.integration-open-paas.org",
                "email": "firstname4173.surname4173@upn.integration-open-paas.org"
              }
            ],
            "id": "229e4ef0-d00b-11eb-bc1e-efba5dd6657f",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2021-06-18T07:59:40Z",
            "sentAt": "2021-06-18T07:59:40Z",
            "hasAttachment": false,
            "subject": "6bce5b56-6f5c-4379-98d8-983e1dc1632a",
            "size": 673
          }
        ]
      },
      "c1"
    ]
  ]
}
```

### Comment by dab246 at 2023-04-04T02:20:02Z

> @dab246 it still happen on Tmail 0.7.6
> 
> ### Evidence:
> ### Request payload:
> ```
> {
>   "using": [
>     "urn:ietf:params:jmap:core",
>     "urn:ietf:params:jmap:mail",
>     "urn:apache:james:params:jmap:mail:shares"
>   ],
>   "methodCalls": [
>     [
>       "Email/query",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "filter": {
>           "inMailbox": "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a"
>         },
>         "sort": [
>           {
>             "isAscending": false,
>             "property": "receivedAt"
>           }
>         ],
>         "limit": 20
>       },
>       "c0"
>     ],
>     [
>       "Email/get",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "#ids": {
>           "resultOf": "c0",
>           "name": "Email/query",
>           "path": "/ids/*"
>         },
>         "properties": [
>           "id",
>           "subject",
>           "from",
>           "to",
>           "cc",
>           "bcc",
>           "keywords",
>           "size",
>           "receivedAt",
>           "sentAt",
>           "preview",
>           "hasAttachment",
>           "replyTo",
>           "mailboxIds"
>         ]
>       },
>       "c1"
>     ]
>   ]
> }
> ```
> 
> ### Response payload:
> ```
> {
>   "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
>   "methodResponses": [
>     [
>       "Email/query",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "queryState": "c62ed5e5",
>         "canCalculateChanges": false,
>         "ids": [
>           "6e7151d0-c300-11ed-b286-674033c03e6f",
>           "5bd18400-b40f-11ed-acb8-2f989b3f0bd9",
>           "4f0b1970-b40f-11ed-acb8-2f989b3f0bd9",
>           "ef96a730-dd76-11ec-8a54-9548d40d5682",
>           "8d2bd0d0-da5f-11ec-8371-2f1b2459e17b",
>           "b0345b60-8b18-11ec-bf40-dd94b3d6a7a7",
>           "44064ce0-f839-11eb-85e8-e1029c1737f1",
>           "cbdd3000-f4e9-11eb-868e-458341e8a258",
>           "8b160170-f4e7-11eb-8f4d-db0c8139b4b9",
>           "27cc41c0-de11-11eb-91ba-b3d6bfcf4bc8",
>           "a5de89c0-de10-11eb-91ba-b3d6bfcf4bc8",
>           "a0692361-de10-11eb-91ba-b3d6bfcf4bc8",
>           "61adade0-de0f-11eb-bbc4-01054eff6c02",
>           "78ca6b20-d28f-11eb-9e9f-65386462f7c8",
>           "229e4ef0-d00b-11eb-bc1e-efba5dd6657f",
>           "3598ecd0-ccba-11eb-93fc-61e7c1d86a65",
>           "6cd51830-c5d6-11eb-aeaf-b904d4d394ad",
>           "99e3a890-c5d2-11eb-8221-e13ec9072152",
>           "4bd38190-c4d6-11eb-85d7-7323a53e2418",
>           "a153a7f0-c489-11eb-8ba9-0b039b674140"
>         ],
>         "position": 0
>       },
>       "c0"
>     ],
>     [
>       "Email/get",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "notFound": [],
>         "state": "57921fd0-d20f-11ed-85e6-d19eaa167fb4",
>         "list": [
>           {
>             "preview": "7fc404ab-00a4-46f8-bd23-6e626827ce17",
>             "to": [
>               {
>                 "name": "firstname17928.surname17928@upn.integration-open-paas.org",
>                 "email": "firstname17928.surname17928@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "27cc41c0-de11-11eb-91ba-b3d6bfcf4bc8",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2021-07-06T04:18:02Z",
>             "sentAt": "2021-07-06T04:18:02Z",
>             "hasAttachment": false,
>             "subject": "07e86f92-129c-4cf4-8478-06d31d9b20e7",
>             "size": 678
>           },
>           {
>             "preview": "71db0513-ba4b-4264-815f-72c3ba457a5b",
>             "to": [
>               {
>                 "name": "firstname5638.surname5638@upn.integration-open-paas.org",
>                 "email": "firstname5638.surname5638@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "a153a7f0-c489-11eb-8ba9-0b039b674140",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$flagged": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-03T16:34:56Z",
>             "sentAt": "2021-06-03T16:34:56Z",
>             "hasAttachment": false,
>             "subject": "6148c32e-e2d7-4ab5-98de-d00171bc2976",
>             "size": 675
>           },
>           {
>             "preview": "f8098b68-f333-4a3f-a401-9d5c267e6fcd",
>             "to": [
>               {
>                 "name": "firstname2245.surname2245@upn.integration-open-paas.org",
>                 "email": "firstname2245.surname2245@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "a5de89c0-de10-11eb-91ba-b3d6bfcf4bc8",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-07-06T04:14:24Z",
>             "sentAt": "2021-07-06T04:14:24Z",
>             "hasAttachment": false,
>             "subject": "ba69a8dd-a20b-41e4-91d6-c9c60a72be63",
>             "size": 674
>           },
>           {
>             "preview": "51d7d6fc-3858-437f-8329-b8019b2b60ff",
>             "to": [
>               {
>                 "name": "firstname5821.surname5821@upn.integration-open-paas.org",
>                 "email": "firstname5821.surname5821@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "8b160170-f4e7-11eb-8f4d-db0c8139b4b9",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2021-08-04T05:48:07Z",
>             "sentAt": "2021-08-04T05:48:07Z",
>             "hasAttachment": false,
>             "subject": "262576a1-86f5-4695-9864-7556a19556c2",
>             "size": 675
>           },
>           {
>             "preview": "973b2914-d05e-44c4-b7d6-5064a736d645",
>             "to": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "6e7151d0-c300-11ed-b286-674033c03e6f",
>             "mailboxIds": {
>               "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname2423.surname2423@upn.integration-open-paas.org",
>                 "email": "firstname2423.surname2423@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$flagged": true,
>               "$seen": true
>             },
>             "receivedAt": "2023-03-15T07:10:13Z",
>             "sentAt": "2023-03-15T07:01:43Z",
>             "hasAttachment": false,
>             "subject": "08b04089-eacd-4d08-adba-f2a6f8d9fd84",
>             "size": 874
>           },
>           {
>             "preview": "14c78e76-da99-457f-b098-59f91e6439af",
>             "to": [
>               {
>                 "name": "firstname486.surname486@upn.integration-open-paas.org",
>                 "email": "firstname486.surname486@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "6cd51830-c5d6-11eb-aeaf-b904d4d394ad",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-05T08:17:10Z",
>             "sentAt": "2021-06-05T08:17:10Z",
>             "hasAttachment": false,
>             "subject": "ba65d9b5-1f94-428f-bee6-d8df60d58e25",
>             "size": 672
>           },
>           {
>             "preview": "7284ff59-e26f-4cce-839d-9784bc22bb6e",
>             "to": [
>               {
>                 "name": "firstname7090.surname7090@upn.integration-open-paas.org",
>                 "email": "firstname7090.surname7090@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "99e3a890-c5d2-11eb-8221-e13ec9072152",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-05T07:49:48Z",
>             "sentAt": "2021-06-05T07:49:48Z",
>             "hasAttachment": false,
>             "subject": "e383ab5c-1cb9-4833-a839-6c29027452db",
>             "size": 674
>           },
>           {
>             "preview": "30794a1c-060a-4ff3-a73b-2b481c8afb38",
>             "to": [
>               {
>                 "name": "firstname14905.surname14905@upn.integration-open-paas.org",
>                 "email": "firstname14905.surname14905@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "4bd38190-c4d6-11eb-85d7-7323a53e2418",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-04T01:43:43Z",
>             "sentAt": "2021-06-04T01:43:43Z",
>             "hasAttachment": false,
>             "subject": "6a9376e8-8501-4d12-b9f3-a881d1fd3619",
>             "size": 679
>           },
>           {
>             "preview": "d580177b-7b51-4a5e-878d-26680eefaec9",
>             "to": [
>               {
>                 "name": "firstname18133.surname18133@upn.integration-open-paas.org",
>                 "email": "firstname18133.surname18133@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "3598ecd0-ccba-11eb-93fc-61e7c1d86a65",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-14T02:42:50Z",
>             "sentAt": "2021-06-14T02:42:50Z",
>             "hasAttachment": false,
>             "subject": "a8b68085-a3ce-4de2-902b-8185be7878b1",
>             "size": 680
>           },
>           {
>             "replyTo": [
>               {
>                 "email": "expeditor@linagora.com"
>               }
>             ],
>             "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
>             "to": [
>               {
>                 "name": "Recipient",
>                 "email": "recipient@linagora.com"
>               }
>             ],
>             "id": "5bd18400-b40f-11ed-acb8-2f989b3f0bd9",
>             "mailboxIds": {
>               "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "Tuan PHAM",
>                 "email": "expeditor@linagora.com"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2023-02-24T06:49:17Z",
>             "sentAt": "2022-04-26T02:27:54Z",
>             "hasAttachment": false,
>             "subject": "test subject",
>             "size": 5104
>           },
>           {
>             "preview": "f6b7a7de-373e-4c4e-937c-a75e6bf17dd1",
>             "to": [
>               {
>                 "name": "firstname6763.surname6763@upn.integration-open-paas.org",
>                 "email": "firstname6763.surname6763@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "61adade0-de0f-11eb-bbc4-01054eff6c02",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2021-07-06T04:05:20Z",
>             "sentAt": "2021-07-06T04:05:20Z",
>             "hasAttachment": false,
>             "subject": "684ee87d-9ea0-4e9c-a03f-fa51e542b5bf",
>             "size": 675
>           },
>           {
>             "preview": "1a072acb-3a94-4fd8-bfbf-bd7238edb64e",
>             "to": [
>               {
>                 "name": "firstname1172.surname1172@upn.integration-open-paas.org",
>                 "email": "firstname1172.surname1172@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "8d2bd0d0-da5f-11ec-8371-2f1b2459e17b",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2022-05-23T06:14:06Z",
>             "sentAt": "2022-05-23T06:14:06Z",
>             "hasAttachment": false,
>             "subject": "072f1e42-a3f6-4bea-9193-9b5467390747",
>             "size": 674
>           },
>           {
>             "preview": "fe1595c2-2cca-45ba-93a4-c6be9ec2f3ee",
>             "to": [
>               {
>                 "name": "firstname6098.surname6098@upn.integration-open-paas.org",
>                 "email": "firstname6098.surname6098@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "44064ce0-f839-11eb-85e8-e1029c1737f1",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2021-08-08T11:10:38Z",
>             "sentAt": "2021-08-08T11:10:38Z",
>             "hasAttachment": false,
>             "subject": "59b1b3ce-e2aa-48e2-9db9-0b9dd182b8e8",
>             "size": 675
>           },
>           {
>             "preview": "e62669ff-a917-4ec8-8c1a-e984ce6d4c53",
>             "to": [
>               {
>                 "name": "firstname9186.surname9186@upn.integration-open-paas.org",
>                 "email": "firstname9186.surname9186@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "b0345b60-8b18-11ec-bf40-dd94b3d6a7a7",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2022-02-11T08:57:49Z",
>             "sentAt": "2022-02-11T08:57:49Z",
>             "hasAttachment": false,
>             "subject": "8c46879c-fe13-45ee-8b78-6b979f71f32f",
>             "size": 675
>           },
>           {
>             "preview": "56a7bdb5-77e4-4015-9e90-00792ede710e",
>             "to": [
>               {
>                 "name": "firstname4429.surname4429@upn.integration-open-paas.org",
>                 "email": "firstname4429.surname4429@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "ef96a730-dd76-11ec-8a54-9548d40d5682",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2022-05-27T04:39:03Z",
>             "sentAt": "2022-05-27T04:39:03Z",
>             "hasAttachment": false,
>             "subject": "4cd05113-c38d-49cd-8fa2-e94e90346264",
>             "size": 675
>           },
>           {
>             "preview": "a8ce3690-03ed-482c-bc67-0f4380e45f70",
>             "to": [
>               {
>                 "name": "firstname9019.surname9019@upn.integration-open-paas.org",
>                 "email": "firstname9019.surname9019@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "cbdd3000-f4e9-11eb-868e-458341e8a258",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$flagged": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-08-04T06:04:14Z",
>             "sentAt": "2021-08-04T06:04:14Z",
>             "hasAttachment": false,
>             "subject": "5a488898-3c56-4c46-9229-46ba0298c3c8",
>             "size": 674
>           },
>           {
>             "preview": "c09c34f5-10a0-4647-affc-12ddb65119b6",
>             "to": [
>               {
>                 "name": "firstname15868.surname15868@upn.integration-open-paas.org",
>                 "email": "firstname15868.surname15868@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "78ca6b20-d28f-11eb-9e9f-65386462f7c8",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-21T12:52:00Z",
>             "sentAt": "2021-06-21T12:52:00Z",
>             "hasAttachment": false,
>             "subject": "4a8e5d0d-4f94-490f-806b-ec2de251dd34",
>             "size": 680
>           },
>           {
>             "replyTo": [
>               {
>                 "email": "expeditor@linagora.com"
>               }
>             ],
>             "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
>             "to": [
>               {
>                 "name": "Recipient",
>                 "email": "recipient@linagora.com"
>               }
>             ],
>             "id": "4f0b1970-b40f-11ed-acb8-2f989b3f0bd9",
>             "mailboxIds": {
>               "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "Tuan PHAM",
>                 "email": "expeditor@linagora.com"
>               }
>             ],
>             "keywords": {
>               "$flagged": true,
>               "$seen": true
>             },
>             "receivedAt": "2023-02-24T06:48:56Z",
>             "sentAt": "2022-04-26T02:27:54Z",
>             "hasAttachment": false,
>             "subject": "test subject",
>             "size": 5104
>           },
>           {
>             "preview": "97106bc0-8f6c-4809-bdd6-be83e9fb5a91",
>             "to": [
>               {
>                 "name": "firstname7821.surname7821@upn.integration-open-paas.org",
>                 "email": "firstname7821.surname7821@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "a0692361-de10-11eb-91ba-b3d6bfcf4bc8",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$seen": true
>             },
>             "receivedAt": "2021-07-06T04:14:15Z",
>             "sentAt": "2021-07-06T04:14:15Z",
>             "hasAttachment": false,
>             "subject": "df64ad0c-19ec-4801-ae35-8005691f1ea6",
>             "size": 674
>           },
>           {
>             "preview": "1195a88f-2b8e-4597-b762-fa3503612e76",
>             "to": [
>               {
>                 "name": "firstname4173.surname4173@upn.integration-open-paas.org",
>                 "email": "firstname4173.surname4173@upn.integration-open-paas.org"
>               }
>             ],
>             "id": "229e4ef0-d00b-11eb-bc1e-efba5dd6657f",
>             "mailboxIds": {
>               "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
>             },
>             "from": [
>               {
>                 "name": "firstname31.surname31@upn.integration-open-paas.org",
>                 "email": "firstname31.surname31@upn.integration-open-paas.org"
>               }
>             ],
>             "keywords": {
>               "$answered": true,
>               "$flagged": true,
>               "$seen": true
>             },
>             "receivedAt": "2021-06-18T07:59:40Z",
>             "sentAt": "2021-06-18T07:59:40Z",
>             "hasAttachment": false,
>             "subject": "6bce5b56-6f5c-4379-98d8-983e1dc1632a",
>             "size": 673
>           }
>         ]
>       },
>       "c1"
>     ]
>   ]
> }
> ```

Oh, I will test again

### Comment by QuangHoang1210 at 2023-04-11T09:15:10Z

@dab246 

### Reproduce on preprod 0.7.6 becasue no outbox data to test on prod 0.7.6
*Data: Using account: firstname31

***Evidence:**

https://user-images.githubusercontent.com/124866146/231113594-4b803b89-5f1d-484b-b196-204ad4cb0991.mp4

### Request payload:
```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:apache:james:params:jmap:mail:shares"
  ],
  "methodCalls": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "filter": {
          "inMailbox": "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a"
        },
        "sort": [
          {
            "isAscending": false,
            "property": "receivedAt"
          }
        ],
        "limit": 20
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "#ids": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        },
        "properties": [
          "id",
          "subject",
          "from",
          "to",
          "cc",
          "bcc",
          "keywords",
          "size",
          "receivedAt",
          "sentAt",
          "preview",
          "hasAttachment",
          "replyTo",
          "mailboxIds"
        ]
      },
      "c1"
    ]
  ]
}
```
### Response payload:
```
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "queryState": "c62ed5e5",
        "canCalculateChanges": false,
        "ids": [
          "6e7151d0-c300-11ed-b286-674033c03e6f",
          "5bd18400-b40f-11ed-acb8-2f989b3f0bd9",
          "4f0b1970-b40f-11ed-acb8-2f989b3f0bd9",
          "ef96a730-dd76-11ec-8a54-9548d40d5682",
          "8d2bd0d0-da5f-11ec-8371-2f1b2459e17b",
          "b0345b60-8b18-11ec-bf40-dd94b3d6a7a7",
          "44064ce0-f839-11eb-85e8-e1029c1737f1",
          "cbdd3000-f4e9-11eb-868e-458341e8a258",
          "8b160170-f4e7-11eb-8f4d-db0c8139b4b9",
          "27cc41c0-de11-11eb-91ba-b3d6bfcf4bc8",
          "a5de89c0-de10-11eb-91ba-b3d6bfcf4bc8",
          "a0692361-de10-11eb-91ba-b3d6bfcf4bc8",
          "61adade0-de0f-11eb-bbc4-01054eff6c02",
          "78ca6b20-d28f-11eb-9e9f-65386462f7c8",
          "229e4ef0-d00b-11eb-bc1e-efba5dd6657f",
          "3598ecd0-ccba-11eb-93fc-61e7c1d86a65",
          "6cd51830-c5d6-11eb-aeaf-b904d4d394ad",
          "99e3a890-c5d2-11eb-8221-e13ec9072152",
          "4bd38190-c4d6-11eb-85d7-7323a53e2418",
          "a153a7f0-c489-11eb-8ba9-0b039b674140"
        ],
        "position": 0
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "eecaeca0-d846-11ed-85d9-2f62cdc4d454",
        "list": [
          {
            "preview": "7fc404ab-00a4-46f8-bd23-6e626827ce17",
            "to": [
              {
                "name": "firstname17928.surname17928@upn.integration-open-paas.org",
                "email": "firstname17928.surname17928@upn.integration-open-paas.org"
              }
            ],
            "id": "27cc41c0-de11-11eb-91ba-b3d6bfcf4bc8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:18:02Z",
            "sentAt": "2021-07-06T04:18:02Z",
            "hasAttachment": false,
            "subject": "07e86f92-129c-4cf4-8478-06d31d9b20e7",
            "size": 678
          },
          {
            "preview": "71db0513-ba4b-4264-815f-72c3ba457a5b",
            "to": [
              {
                "name": "firstname5638.surname5638@upn.integration-open-paas.org",
                "email": "firstname5638.surname5638@upn.integration-open-paas.org"
              }
            ],
            "id": "a153a7f0-c489-11eb-8ba9-0b039b674140",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2021-06-03T16:34:56Z",
            "sentAt": "2021-06-03T16:34:56Z",
            "hasAttachment": false,
            "subject": "6148c32e-e2d7-4ab5-98de-d00171bc2976",
            "size": 675
          },
          {
            "preview": "f8098b68-f333-4a3f-a401-9d5c267e6fcd",
            "to": [
              {
                "name": "firstname2245.surname2245@upn.integration-open-paas.org",
                "email": "firstname2245.surname2245@upn.integration-open-paas.org"
              }
            ],
            "id": "a5de89c0-de10-11eb-91ba-b3d6bfcf4bc8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:14:24Z",
            "sentAt": "2021-07-06T04:14:24Z",
            "hasAttachment": false,
            "subject": "ba69a8dd-a20b-41e4-91d6-c9c60a72be63",
            "size": 674
          },
          {
            "preview": "51d7d6fc-3858-437f-8329-b8019b2b60ff",
            "to": [
              {
                "name": "firstname5821.surname5821@upn.integration-open-paas.org",
                "email": "firstname5821.surname5821@upn.integration-open-paas.org"
              }
            ],
            "id": "8b160170-f4e7-11eb-8f4d-db0c8139b4b9",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-08-04T05:48:07Z",
            "sentAt": "2021-08-04T05:48:07Z",
            "hasAttachment": false,
            "subject": "262576a1-86f5-4695-9864-7556a19556c2",
            "size": 675
          },
          {
            "preview": "973b2914-d05e-44c4-b7d6-5064a736d645",
            "to": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "6e7151d0-c300-11ed-b286-674033c03e6f",
            "mailboxIds": {
              "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname2423.surname2423@upn.integration-open-paas.org",
                "email": "firstname2423.surname2423@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2023-03-15T07:10:13Z",
            "sentAt": "2023-03-15T07:01:43Z",
            "hasAttachment": false,
            "subject": "08b04089-eacd-4d08-adba-f2a6f8d9fd84",
            "size": 874
          },
          {
            "preview": "14c78e76-da99-457f-b098-59f91e6439af",
            "to": [
              {
                "name": "firstname486.surname486@upn.integration-open-paas.org",
                "email": "firstname486.surname486@upn.integration-open-paas.org"
              }
            ],
            "id": "6cd51830-c5d6-11eb-aeaf-b904d4d394ad",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-05T08:17:10Z",
            "sentAt": "2021-06-05T08:17:10Z",
            "hasAttachment": false,
            "subject": "ba65d9b5-1f94-428f-bee6-d8df60d58e25",
            "size": 672
          },
          {
            "preview": "7284ff59-e26f-4cce-839d-9784bc22bb6e",
            "to": [
              {
                "name": "firstname7090.surname7090@upn.integration-open-paas.org",
                "email": "firstname7090.surname7090@upn.integration-open-paas.org"
              }
            ],
            "id": "99e3a890-c5d2-11eb-8221-e13ec9072152",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-05T07:49:48Z",
            "sentAt": "2021-06-05T07:49:48Z",
            "hasAttachment": false,
            "subject": "e383ab5c-1cb9-4833-a839-6c29027452db",
            "size": 674
          },
          {
            "preview": "30794a1c-060a-4ff3-a73b-2b481c8afb38",
            "to": [
              {
                "name": "firstname14905.surname14905@upn.integration-open-paas.org",
                "email": "firstname14905.surname14905@upn.integration-open-paas.org"
              }
            ],
            "id": "4bd38190-c4d6-11eb-85d7-7323a53e2418",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-04T01:43:43Z",
            "sentAt": "2021-06-04T01:43:43Z",
            "hasAttachment": false,
            "subject": "6a9376e8-8501-4d12-b9f3-a881d1fd3619",
            "size": 679
          },
          {
            "preview": "d580177b-7b51-4a5e-878d-26680eefaec9",
            "to": [
              {
                "name": "firstname18133.surname18133@upn.integration-open-paas.org",
                "email": "firstname18133.surname18133@upn.integration-open-paas.org"
              }
            ],
            "id": "3598ecd0-ccba-11eb-93fc-61e7c1d86a65",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-14T02:42:50Z",
            "sentAt": "2021-06-14T02:42:50Z",
            "hasAttachment": false,
            "subject": "a8b68085-a3ce-4de2-902b-8185be7878b1",
            "size": 680
          },
          {
            "replyTo": [
              {
                "email": "expeditor@linagora.com"
              }
            ],
            "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
            "to": [
              {
                "name": "Recipient",
                "email": "recipient@linagora.com"
              }
            ],
            "id": "5bd18400-b40f-11ed-acb8-2f989b3f0bd9",
            "mailboxIds": {
              "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Tuan PHAM",
                "email": "expeditor@linagora.com"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-24T06:49:17Z",
            "sentAt": "2022-04-26T02:27:54Z",
            "hasAttachment": false,
            "subject": "test subject",
            "size": 5104
          },
          {
            "preview": "f6b7a7de-373e-4c4e-937c-a75e6bf17dd1",
            "to": [
              {
                "name": "firstname6763.surname6763@upn.integration-open-paas.org",
                "email": "firstname6763.surname6763@upn.integration-open-paas.org"
              }
            ],
            "id": "61adade0-de0f-11eb-bbc4-01054eff6c02",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:05:20Z",
            "sentAt": "2021-07-06T04:05:20Z",
            "hasAttachment": false,
            "subject": "684ee87d-9ea0-4e9c-a03f-fa51e542b5bf",
            "size": 675
          },
          {
            "preview": "1a072acb-3a94-4fd8-bfbf-bd7238edb64e",
            "to": [
              {
                "name": "firstname1172.surname1172@upn.integration-open-paas.org",
                "email": "firstname1172.surname1172@upn.integration-open-paas.org"
              }
            ],
            "id": "8d2bd0d0-da5f-11ec-8371-2f1b2459e17b",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2022-05-23T06:14:06Z",
            "sentAt": "2022-05-23T06:14:06Z",
            "hasAttachment": false,
            "subject": "072f1e42-a3f6-4bea-9193-9b5467390747",
            "size": 674
          },
          {
            "preview": "fe1595c2-2cca-45ba-93a4-c6be9ec2f3ee",
            "to": [
              {
                "name": "firstname6098.surname6098@upn.integration-open-paas.org",
                "email": "firstname6098.surname6098@upn.integration-open-paas.org"
              }
            ],
            "id": "44064ce0-f839-11eb-85e8-e1029c1737f1",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-08-08T11:10:38Z",
            "sentAt": "2021-08-08T11:10:38Z",
            "hasAttachment": false,
            "subject": "59b1b3ce-e2aa-48e2-9db9-0b9dd182b8e8",
            "size": 675
          },
          {
            "preview": "e62669ff-a917-4ec8-8c1a-e984ce6d4c53",
            "to": [
              {
                "name": "firstname9186.surname9186@upn.integration-open-paas.org",
                "email": "firstname9186.surname9186@upn.integration-open-paas.org"
              }
            ],
            "id": "b0345b60-8b18-11ec-bf40-dd94b3d6a7a7",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2022-02-11T08:57:49Z",
            "sentAt": "2022-02-11T08:57:49Z",
            "hasAttachment": false,
            "subject": "8c46879c-fe13-45ee-8b78-6b979f71f32f",
            "size": 675
          },
          {
            "preview": "56a7bdb5-77e4-4015-9e90-00792ede710e",
            "to": [
              {
                "name": "firstname4429.surname4429@upn.integration-open-paas.org",
                "email": "firstname4429.surname4429@upn.integration-open-paas.org"
              }
            ],
            "id": "ef96a730-dd76-11ec-8a54-9548d40d5682",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2022-05-27T04:39:03Z",
            "sentAt": "2022-05-27T04:39:03Z",
            "hasAttachment": false,
            "subject": "4cd05113-c38d-49cd-8fa2-e94e90346264",
            "size": 675
          },
          {
            "preview": "a8ce3690-03ed-482c-bc67-0f4380e45f70",
            "to": [
              {
                "name": "firstname9019.surname9019@upn.integration-open-paas.org",
                "email": "firstname9019.surname9019@upn.integration-open-paas.org"
              }
            ],
            "id": "cbdd3000-f4e9-11eb-868e-458341e8a258",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2021-08-04T06:04:14Z",
            "sentAt": "2021-08-04T06:04:14Z",
            "hasAttachment": false,
            "subject": "5a488898-3c56-4c46-9229-46ba0298c3c8",
            "size": 674
          },
          {
            "preview": "c09c34f5-10a0-4647-affc-12ddb65119b6",
            "to": [
              {
                "name": "firstname15868.surname15868@upn.integration-open-paas.org",
                "email": "firstname15868.surname15868@upn.integration-open-paas.org"
              }
            ],
            "id": "78ca6b20-d28f-11eb-9e9f-65386462f7c8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$seen": true
            },
            "receivedAt": "2021-06-21T12:52:00Z",
            "sentAt": "2021-06-21T12:52:00Z",
            "hasAttachment": false,
            "subject": "4a8e5d0d-4f94-490f-806b-ec2de251dd34",
            "size": 680
          },
          {
            "replyTo": [
              {
                "email": "expeditor@linagora.com"
              }
            ],
            "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
            "to": [
              {
                "name": "Recipient",
                "email": "recipient@linagora.com"
              }
            ],
            "id": "4f0b1970-b40f-11ed-acb8-2f989b3f0bd9",
            "mailboxIds": {
              "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Tuan PHAM",
                "email": "expeditor@linagora.com"
              }
            ],
            "keywords": {
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2023-02-24T06:48:56Z",
            "sentAt": "2022-04-26T02:27:54Z",
            "hasAttachment": false,
            "subject": "test subject",
            "size": 5104
          },
          {
            "preview": "97106bc0-8f6c-4809-bdd6-be83e9fb5a91",
            "to": [
              {
                "name": "firstname7821.surname7821@upn.integration-open-paas.org",
                "email": "firstname7821.surname7821@upn.integration-open-paas.org"
              }
            ],
            "id": "a0692361-de10-11eb-91ba-b3d6bfcf4bc8",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2021-07-06T04:14:15Z",
            "sentAt": "2021-07-06T04:14:15Z",
            "hasAttachment": false,
            "subject": "df64ad0c-19ec-4801-ae35-8005691f1ea6",
            "size": 674
          },
          {
            "preview": "1195a88f-2b8e-4597-b762-fa3503612e76",
            "to": [
              {
                "name": "firstname4173.surname4173@upn.integration-open-paas.org",
                "email": "firstname4173.surname4173@upn.integration-open-paas.org"
              }
            ],
            "id": "229e4ef0-d00b-11eb-bc1e-efba5dd6657f",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "firstname31.surname31@upn.integration-open-paas.org",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$answered": true,
              "$flagged": true,
              "$seen": true
            },
            "receivedAt": "2021-06-18T07:59:40Z",
            "sentAt": "2021-06-18T07:59:40Z",
            "hasAttachment": false,
            "subject": "6bce5b56-6f5c-4379-98d8-983e1dc1632a",
            "size": 673
          }
        ]
      },
      "c1"
    ]
  ]
}
```

### Comment by QuangHoang1210 at 2023-04-14T02:43:22Z

@hoangdat

### Comment by chibenwa at 2023-04-14T03:45:05Z

Let's discuss this at the office next thursday please

### Comment by QuangHoang1210 at 2023-04-27T07:12:44Z

Already discuss. Keep it in mind - handle later

@hoangdat @chibenwa  cc @dab246  @nqhhdev
