# GitHub issue #240: [Epic] Notification + Push notification

## Metadata

Repository: linagora/tmail-flutter
Issue number: 240
State: closed
Author: hoangdat
Created at: 2022-01-14T09:16:56Z
Updated at: 2023-04-05T02:53:13Z
Closed at: 2023-04-05T02:53:13Z
Labels: Epic
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/240

## Issue body

All related to notification when receiving email, the behavior of notification

## Comments

### Comment by hoangdat at 2022-01-14T09:30:03Z

@chibenwa can you share us all the things you need to update real-time?

### Comment by chibenwa at 2022-01-17T07:55:08Z

Sure.

**Step 1**: obtain a webPush URL from a push gateway like firebase.

When James Push stuff to this URL this will be received by the device.

This step depends on the Push gateway used by the device.

**Step 2**: Generate web push encryption key pairs. 

See https://tools.ietf.org/html/rfc8291 RFC 8291 - Web Push Message Encryption 

And see AES128-GCM content.

You need to generate a public key and a private key.

**Step3**: Register to James to get James pushing updates through the Push Gateway.

```
POST /jmap

{
    "using": ["urn:ietf:params:jmap:core"],
    "methodCalls": [
      [
        "PushSubscription/set",
        {
            "create": {
                "4f29": {
                  "deviceClientId": "a889-ffea-910",
                  "url": "https://my.push.gateway.com/link",
                  "types": ["Mailbox", "Email", "EmailDelivery"],
                  "keys": {
                    "p256dh": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE5ozzvKUAB7GIfJ44eG-sxEcjT1O2jtk9QVD-MzFOH988CAPlSdkitm16NsMxUWksq6qGwu-r6zT7GCM9oGPXtQ==",
                    "auth": "Z7B0LmM6iTZD85EWtNRwIg=="
                  }
                }
              }
        },
        "c1"
      ]
    ]
  }
```

James will then push a verification code through the Push gateway. Once received on the device, you need to use it to verify the newly created push subscription. (This is a counter measure for DDOS).

```
You receive this on the push subscription:

{
    "@type": "PushVerification",
    "pushSubscriptionId": "id48",
    "verificationCode": "abcdef"
}
```

And this is the verification request:

```
{
    "using": ["urn:ietf:params:jmap:core"],
    "methodCalls": [
      [
        "PushSubscription/set",
        {
            "update": {
                "id48": {
                  "verificationCode": "abcdef"
                }
              }
        },
        "c1"
      ]
    ]
  }
```

Once that's done you will receive state changes for types you register to. You will receive the latest state for those, which could help to re-synchronise cache without pulling and display notifications.

This looks like this:

```
{
    "@type": "StateChange",
    "changed": {
        "account5868368": {
          "Mailbox": "state34567"
        }
    }

```

(of course those are encrypted and needs to be decrypted prior usage ;-) )

I recommend adding a debounce: if you just triggered a cache wait at least 5 seconds before the next refresh (even if you receive extra notifications). This allows batching resynchronisations and can be very helpful!

@hoangdat does this answers your question?

Link to the relevant JMAP spec section: https://jmap.io/spec-core.html#pushsubscription

### Comment by hoangdat at 2022-03-09T05:21:19Z

@chibenwa 
Application can  handle the web push message from firebase with `data message` [here](https://firebase.google.com/docs/cloud-messaging/concept-options#notifications_and_data_messages).

But as I understand, James server have not implemented any communication with any push service and especially Firebase. Am I right?

### Comment by chibenwa at 2022-03-09T08:52:57Z

> But as I understand, James server have not implemented any communication with any push service and especially Firebase. Am I right?

Wrong, James can push to "any" push service including firebase.

If there's an issue then it's a bug and we shall fix it!

### Comment by hoangdat at 2022-03-31T08:01:23Z

@chibenwa I am finding the URL in `firebase`. Then I found that, our JMAP server can not POST anything to `firebase` if we don't have any `SERVER KEY` (provide by `firebase`).

### Comment by hoangdat at 2022-03-31T08:06:15Z

more than that, I don't think you can connect to Firebase if you don't use their rest API or client libraries.

https://firebase.google.com/docs/cloud-messaging/server?authuser=3&hl=en#choosing-a-server-option

### Comment by hoangdat at 2022-03-31T08:08:03Z

<img width="861" alt="image" src="https://user-images.githubusercontent.com/6462404/161007864-40b0438b-c9e3-495f-9701-6751574f0108.png">

How JMAP server send it to firebase or any other push service?

### Comment by hoangdat at 2022-03-31T08:09:49Z

Moreover, our application should be work with any JMAP server, we should not hardcode any `push configuration` in app site. WDYT?

### Comment by chibenwa at 2022-03-31T08:13:29Z

> more than that, I don't think you can connect to Firebase if you don't use their rest API or client libraries.

I mean, shouldn't mobiles have a Push gateway? be it firebase or not?

### Comment by hoangdat at 2022-03-31T08:16:58Z

> I mean, shouldn't mobiles have a Push gateway? be it firebase or not?

can not get your point. :(

### Comment by chibenwa at 2022-03-31T08:23:18Z

James should not know that it is speaking to firebase.

You should just be able to obtain a URL to POST updates to the device. But `how` is a mobile concern, James don't care.

### Comment by hoangdat at 2022-03-31T08:37:51Z

1. How James POST to URL without `firebase's SERVER_KEY`? 
2. Why `how` is mobile concern?
- We can not send the key to you when register `PushSubscription`
3. I can not imagine how you can communicate with any push service when you say the language which they don't understand?

### Comment by hoangdat at 2022-04-01T03:07:56Z

@chibenwa please try to make a request from JMAP to `firebase` with:
```
url: https://fcm.googleapis.com/fcm/send
deviceClientID: f1QAFVgalUNorOp0tgplhY:APA91bGlJjy5iP-CjrOKnVQ4h1A07phB4FBk4LWRWZ84rQ4gMdA2HyXJOgl1-kxuPmGOLZknEzVI23mv7rdH2k0ap9PSRWuVFqPGiqehp-R42g88cwKtjVKxUdaT9tXUiRZAFNBCWmXz
```

### Comment by chibenwa at 2022-04-01T03:23:59Z

The JMAP spec do not allow to have a separate deviceClientID. It should likely be part of the URL...

### Comment by hoangdat at 2022-04-01T03:30:31Z

can not get your point? or may be you should to create your own push service? no need to use Firebase or anthing else

### Comment by chibenwa at 2022-04-01T03:42:16Z

> can not get your point? or may be you should to create your own push service? no need to use Firebase or anthing else

And we would be back with a websocket basically, which is why we went for web push in order to reuse the device connections to the device push gateway.

### Comment by hoangdat at 2022-04-01T04:17:25Z

And the final decision is what? 
We will deliver the mail app without notification because our protocol not support it. Or the notification is not important to prioritize?

### Comment by chibenwa at 2022-04-01T07:13:27Z

We should find a way to use a push gateway. We should find a way to have a PUSH URL to give to the backend, that would mke it up to you.

### Comment by chibenwa at 2022-04-01T07:13:59Z

If possible I would be happy not to have to implement a firebase connector.

### Comment by hoangdat at 2022-04-01T07:36:31Z

> If possible I would be happy not to have to implement a firebase connector.

Nothing to say :)

> We should find a way to have a PUSH URL to give to the backend

Nothing more.

IMO, the protocol still miss the piece to work with mobile. Why you not change that? The PUSH URL not the problem.

> Wrong, James can push to "any" push service including firebase.

you are the problem

### Comment by Arsnael at 2022-04-01T10:40:14Z

I think you should have a meeting guys... I'm not sure to follow and it's obvious you are not understanding each other on this point, thus the confusion...

My 2 cents :)

### Comment by hoangdat at 2022-04-01T10:41:42Z

sure, a meeting should be arranged on Tuesday, is it ok? @chibenwa @Arsnael

### Comment by chibenwa at 2022-04-01T11:03:43Z

:+1: I think there's a wolf here...

### Comment by hoangdat at 2022-04-04T04:19:26Z

Hi @chibenwa, because we miss you in the meeting so I posted my questions here:

1. How we will connect with Firebase?

2. If Firebase is not compatible, what are the next steps?

3. Scope for mobile and back-end in this function?

### Comment by chibenwa at 2022-04-04T04:37:38Z

Sorry I though the meeting was tuesday.

> How we will connect with Firebase?

Ideally frontend should be able to get a push URL to give to the backend, compatible with RFC-8030.

> If Firebase is not compatible, what are the next steps?

 - 1. See with other people supporting push and see how they do.
   -> Maybe we can **ask twake people**?
   -> Maybe we can **investigate on other OpenSource projects like Rocket Chat mobile app**?
 - 2. Viable options are:
   -> Non firebase rfc-8030 services obtained from device.
   -> Operate a RFC-8030 -> firebase connector but I would like to keep clear from that.

> Scope for mobile and back-end in this function?

It's open for discussion clearly. Note that i'm concerned with interoperability, independance and costs concerns...

I wonder if push is really what we want here. Websockets for real time updates when the appis in foreground could be an option...

### Comment by hoangdat at 2022-04-05T02:13:46Z

> I wonder if push is really what we want here. Websockets for real time updates when the appis in foreground could be an option...

Before go to details of the problem, I share my thought.
From my aspect, push notification for a communication app is `MUST to HAVE`, it is the key different of mobile from other platforms. Users don't need to always keep focus on the app to know something new, he can spend time on other things. It belongs to PRODUCTIVITY apps. Moreover, all the competitor have this, but we can not because the `costs`. It is so weird to me.

Can you share about the cost estimation for that functions? IMO we can make a request to BOD. User need the notification. User don't need to know about the RFC. 
And then, in the case of SAAS, push notification could also keep the user to use the app. Marketing can use it to encourage user to use the app more and more....

(I am research more for the case of Mattermost)

### Comment by hoangdat at 2022-04-14T01:03:16Z

I found a good solution for server site: http://uniqush.org/documentation/index.html

### Comment by hoangdat at 2022-06-07T08:37:34Z

Hi, when we can include this topic to our roadmap?

### Comment by chibenwa at 2022-06-07T08:40:04Z

Yes.

We need to groom together a FCM extension for TMail, implement it on the backend first.

### Comment by hoangdat at 2022-10-05T22:54:13Z

- [ ] [Android] Runtime permission for notification for both case (API <= 12 and API >= 13)

### Comment by hoangdat at 2022-10-05T23:01:48Z

- [ ] Handle `registrationToken` logic:
  - get token when open the app
  - check if token is new or not
  - if it is new, store it in local and create new for JMAP extension (will be updated after back-end finish the draft). (need to delete the old one with JMAP?)
- [ ] Handle `onTokenRefresh` stream 

### Note: 
Docs: https://firebase.google.com/docs/cloud-messaging/manage-tokens
<img width="862" alt="Screen Shot 2022-10-06 at 06 05 25" src="https://user-images.githubusercontent.com/6462404/194179749-e47123b3-91bb-4e7f-a0ba-e1b5211b5ad9.png">

### Comment by hoangdat at 2022-10-05T23:11:18Z

- Modularize the `push` in Tmail code base
- plug it with `flag` in configuration file
- only play with it in the case `session` supported

### Comment by hoangdat at 2022-11-14T04:45:01Z

@chibenwa please share us the contracts for FCM extensions

### Comment by chibenwa at 2022-11-14T05:05:05Z

https://github.com/linagora/tmail-backend/blob/master/tmail-backend/integration-tests/jmap/jmap-integration-tests-common/src/main/scala/com/linagora/tmail/james/common/FirebaseSubscriptionGetMethodContract.scala

https://github.com/linagora/tmail-backend/blob/master/tmail-backend/integration-tests/jmap/jmap-integration-tests-common/src/main/scala/com/linagora/tmail/james/common/FirebaseSubscriptionSetMethodContract.scala

Is this what you were looking for @hoangdat  ?

### Comment by chibenwa at 2023-04-05T02:53:13Z

Done (firebase)

If issues remains then that is bugs.
