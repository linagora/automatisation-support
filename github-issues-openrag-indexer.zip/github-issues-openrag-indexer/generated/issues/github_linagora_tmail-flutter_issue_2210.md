# GitHub issue #2210: [Safari] 1st login with TMAIL took so long time to load, sometime it's loading forever

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2210
State: closed
Author: QuangHoang1210
Created at: 2023-10-04T09:00:37Z
Updated at: 2024-01-24T08:28:10Z
Closed at: 2024-01-24T08:28:10Z
Labels: bug, Major, customer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/2210

## Issue body

OS:  Website [Safari / chrome / firefox]
Device: Laptop
TMail version: 0.9.3 tmail.linagora.com

### *Precondition: 
- User 1st time login TMAIL (can clear all history in cache to reproduce this case)

### *Reproduce Step:
1, User A access tmail.linagora.com
2, User A input correct credentials and start login

### **Actual:** 
System loading TMAIL landing screen unstoppable

### **Expected:** 
System loading success and redirect user to TMAIL home screen


![Image](https://github.com/linagora/tmail-flutter/assets/124866146/acfc7f0c-de47-4fdd-8ec6-6daf0f34a870)




https://github.com/linagora/tmail-flutter/assets/124866146/eec5c1ae-5825-4dea-89a4-eb320889d346

## Comments

### Comment by dab246 at 2023-10-05T04:24:31Z

Please verify on `oncommit` and `canary`

### Comment by QuangHoang1210 at 2023-10-09T07:17:44Z

@dab246 dab
It's working well on both canary and oncomit

### Comment by hoangdat at 2023-10-09T22:38:57Z

We have a lot of fix in v0.10.0. Can you priority to verify v0.10.0 to roll it out?

### Comment by QuangHoang1210 at 2023-10-10T16:14:05Z

Reopened this ticket -> Still happen on https://canary-tmail.linagora.com/ v0.10.0

Reproduce Step:
1, Clear cookie
2, Access Tmail https://canary-tmail.linagora.com/
3, Signin successfully with correct credentials


https://github.com/linagora/tmail-flutter/assets/124866146/2437ef30-2c11-46b6-b3f9-8b839be41c14

### Comment by QuangHoang1210 at 2023-10-16T19:40:43Z

Still happen on safari, firefox, chrome. Also on canary tmail 0.10.1

https://github.com/linagora/tmail-flutter/assets/124866146/c5ad63da-4392-44ad-9bb1-92d02325322e

### Comment by dab246 at 2023-10-20T03:07:34Z

Still unable to reproduce on `MacOS chip M1` browsers. More research is needed.



https://github.com/linagora/tmail-flutter/assets/80730648/69dcb616-8609-4568-acef-4cfbd6facb03

### Comment by dab246 at 2023-10-30T02:58:09Z

Please clear data cache and re-test on version `0.10.3` @QuangHoang1210

### Comment by QuangHoang1210 at 2023-10-30T07:25:01Z

@dab246  @hoangdat 

Still happen on 0.10.3
Noted: Already clear data cache.

https://github.com/linagora/tmail-flutter/assets/124866146/2c5229cc-e9b2-4f18-a534-c679d531f590

### Comment by hoangdat at 2024-01-24T08:28:10Z

duplicated #2228
