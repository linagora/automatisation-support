# GitHub issue #1094: [Epic] Team Mailboxes

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1094
State: closed
Author: dieptran88
Created at: 2022-10-19T09:18:14Z
Updated at: 2023-04-05T03:15:30Z
Closed at: 2023-04-05T03:15:30Z
Labels: Epic
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1094

## Issue body

_No body_

## Comments

### Comment by chibenwa at 2022-10-19T11:25:07Z

You might find it interesting what the backend team actually delivered ;-)

https://github.com/linagora/tmail-backend/blob/master/docs/modules/ROOT/pages/tmail-backend/features/teamMailboxes.adoc

### Comment by dieptran88 at 2022-10-19T12:12:04Z

As my understanding, the setting of a team mailbox such as creating team mailbox, add/edit member... will be done by domain admin, not normal user, is there any interface for admin to do these actions ?

### Comment by dieptran88 at 2022-10-19T12:15:38Z

Ah, I see "Team mailboxes webAdmin routes", but I cannot access

### Comment by chibenwa at 2022-10-20T01:50:32Z

> will be done by domain admin, not normal user, is there any interface for admin to do these actions ?

So far, no. Ideally, console.

We could do a sync with LDAP / OBM too.

### Comment by dieptran88 at 2022-10-31T04:39:37Z

Benoit: 

For search + Team-Mailboxes:

 - All mailboxes (all mbxs + team - mailboxes)
 - My mailboxes
 - Folder section (allows selecting one mailbox belonging to the user)
 - Team-Mailbox section (allows selecting one team-mailbox)

### Comment by hoangdat at 2022-11-08T04:13:57Z

Hide a team mailbox in one client will be hide in all clients?

### Comment by chibenwa at 2022-11-08T07:18:03Z

No only for him

### Comment by hoangdat at 2022-11-08T07:27:33Z

> No only for him

him in android and web and iOS, or only him in web? ....

### Comment by chibenwa at 2022-11-09T02:48:25Z

Ah I got you.

We could plan on using the `isSubscribed` property in Team Mailboxes to hide / show them in all clients...

We likely have a backend bug to solve prior to this... :-/ CF https://github.com/linagora/james-project/issues/3505 https://github.com/linagora/james-project/issues/4147

### Comment by hoangdat at 2022-11-15T07:31:35Z

Team mailboxes in Preprod: https://app.zenhub.com/workspaces/tmail-backend-5873652b2a0b13cc0b8bbe63/issues/linagora/james-project-private/525

### Comment by hoangdat at 2022-12-12T02:50:02Z

https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=8085%3A334956&t=fMMda0d6iASmQAGx-4

### Comment by chibenwa at 2022-12-12T03:10:57Z

> https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=8085%3A334956&t=fMMda0d6iASmQAGx-4

In the `Mailboxes` section, `Personal mailboxes` goes first, then `Team mailboxes`.

### Comment by hoangdat at 2022-12-13T03:34:20Z

Created team-mailboxes along with members....

```
root@james-jmap-854578b778-ggq2f:/# curl 127.0.0.1:8000/domains/upn.integration-open-paas.org/team-mailboxes/hiring/members | jq .
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   671    0   671    0     0  31952      0 --:--:-- --:--:-- --:--:-- 31952
[
  {
    "username": "firstname23.surname23@upn.integration-open-paas.org"
  },
  {
    "username": "firstname24.surname24@upn.integration-open-paas.org"
  },
  {
    "username": "firstname25.surname25@upn.integration-open-paas.org"
  },
  {
    "username": "firstname26.surname26@upn.integration-open-paas.org"
  },
  {
    "username": "firstname27.surname27@upn.integration-open-paas.org"
  },
  {
    "username": "firstname28.surname28@upn.integration-open-paas.org"
  },
  {
    "username": "firstname29.surname29@upn.integration-open-paas.org"
  },
  {
    "username": "firstname30.surname30@upn.integration-open-paas.org"
  },
  {
    "username": "firstname31.surname31@upn.integration-open-paas.org"
  },
  {
    "username": "firstname32.surname32@upn.integration-open-paas.org"
  }
]



root@james-jmap-854578b778-ggq2f:/# curl 127.0.0.1:8000/domains/upn.integration-open-paas.org/team-mailboxes/marketting/members | jq .
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   135    0   135    0     0   7105      0 --:--:-- --:--:-- --:--:--  7105
[
  {
    "username": "firstname23.surname23@upn.integration-open-paas.org"
  },
  {
    "username": "firstname28.surname28@upn.integration-open-paas.org"
  }
]


root@james-jmap-854578b778-ggq2f:/# curl 127.0.0.1:8000/domains/upn.integration-open-paas.org/team-mailboxes/sales/members | jq .
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   336    0   336    0     0  19764      0 --:--:-- --:--:-- --:--:-- 19764
[
  {
    "username": "firstname23.surname23@upn.integration-open-paas.org"
  },
  {
    "username": "firstname25.surname25@upn.integration-open-paas.org"
  },
  {
    "username": "firstname27.surname27@upn.integration-open-paas.org"
  },
  {
    "username": "firstname29.surname29@upn.integration-open-paas.org"
  },
  {
    "username": "firstname31.surname31@upn.integration-open-paas.org"
  }
]



root@james-jmap-854578b778-ggq2f:/# curl 127.0.0.1:8000/domains/upn.integration-open-paas.org/team-mailboxes/human-resources/members | jq .
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   202    0   202    0     0  11222      0 --:--:-- --:--:-- --:--:-- 11222
[
  {
    "username": "firstname23.surname23@upn.integration-open-paas.org"
  },
  {
    "username": "firstname27.surname27@upn.integration-open-paas.org"
  },
  {
    "username": "firstname31.surname31@upn.integration-open-paas.org"
  }
]



root@james-jmap-854578b778-ggq2f:/# curl 127.0.0.1:8000/domains/upn.integration-open-paas.org/team-mailboxes/communication/members | jq .
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   202    0   202    0     0  10100      0 --:--:-- --:--:-- --:--:-- 10100
[
  {
    "username": "firstname23.surname23@upn.integration-open-paas.org"
  },
  {
    "username": "firstname26.surname26@upn.integration-open-paas.org"
  },
  {
    "username": "firstname29.surname29@upn.integration-open-paas.org"
  }
```

### Comment by ManhNTX at 2022-12-15T03:00:44Z

- check capability in session -> enable/disable team mailbox -> display team mailbox tree
- sub/unsub mailbox 
- search mailbox -> display team mailbox tree (#1187)
- search email ->  result emails in team mailbox 
- select identity with team mailbox

### Comment by hoangdat at 2022-12-20T23:12:29Z

https://github.com/linagora/tmail-backend/commit/e104c44b47eb5bee36de2e4d9f28056f4e8c4a32
