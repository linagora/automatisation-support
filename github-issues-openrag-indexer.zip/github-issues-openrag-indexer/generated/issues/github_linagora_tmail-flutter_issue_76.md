# GitHub issue #76: Search mail

## Metadata

Repository: linagora/tmail-flutter
Issue number: 76
State: closed
Author: hoangdat
Created at: 2021-09-10T04:32:26Z
Updated at: 2022-11-28T08:05:40Z
Closed at: 2022-11-28T08:05:40Z
Labels: Epic
Assignees: dieptran88
URL: https://github.com/linagora/tmail-flutter/issues/76

## Issue body

### Description: 

Search mail UX for different devices: Mobile, Tablet, ...

## Comments

### Comment by chibenwa at 2021-09-10T06:59:01Z

https://www.figma.com/proto/of2CfuDyhYPFFu4D1hrKzP/Mailbox?node-id=146%3A118

### Comment by hoangdat at 2021-09-10T07:11:28Z

> https://www.figma.com/proto/of2CfuDyhYPFFu4D1hrKzP/Mailbox?node-id=146%3A118

It is too complex for mobile UX, we will try to figure out the best UX for mobile, and tablet also.
First, @dieptran88  will compare to the other competitor application.

### Comment by chibenwa at 2021-09-10T07:14:56Z

IMO you could have a simplified UX with only few fields and have a way to move to a more advanced search,

### Comment by hoangdat at 2021-09-10T07:25:40Z

please help me the simplest request for search with text pattern, all the email which have subject, content include this text will be return? (same with the current UX of Gmail)

### Comment by chibenwa at 2021-09-10T07:29:13Z

> please help me the simplest request for search with text pattern, all the email which have subject, content include this text will be return? (same with the current UX of Gmail)

Looks legitimate to me.

### Comment by chibenwa at 2021-09-10T07:29:35Z

Maybe also flagged (star)

### Comment by hoangdat at 2021-09-29T03:26:06Z

> please help me the simplest request for search with text pattern, all the email which have subject, content include this text will be return? (same with the current UX of Gmail)

@chibenwa please help me the request for the search.

### Comment by chibenwa at 2021-09-30T04:38:00Z

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
  "methodCalls": [[
    "Email/query",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "filter": {"text": "banana"}
    },
    "c1"]]
}
```

Will search the body, cc, bcc, to, from and subject.

### Comment by hoangdat at 2021-09-30T07:18:30Z

With `query` we should add `Email/get` also to show preview in the result. Am I right?

Why not use `searchSnippet/get`? It seems simpler than `query + get`?

### Comment by chibenwa at 2021-09-30T07:21:41Z

> With query we should add Email/get also to show preview in the result. Am I right?

Right.

`searchSnippet` are not implemented in James.

(And it is actually Email/query + SearchSnipset/get + Email/get)

### Comment by chibenwa at 2021-10-26T01:58:29Z

Also it would be nice to display the mailbox the mail is in in the search result.

Something like:

![Screenshot from 2021-10-26 08-54-24](https://user-images.githubusercontent.com/6928740/138795677-e6c9fe70-378a-4b01-9cc8-d4d5bcb54dc1.png)
