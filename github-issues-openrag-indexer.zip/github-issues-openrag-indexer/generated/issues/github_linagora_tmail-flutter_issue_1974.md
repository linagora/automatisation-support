# GitHub issue #1974: RefreshToken with OIDC on` jmap.linagora.com/oidc`

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1974
State: closed
Author: dab246
Created at: 2023-06-30T04:18:08Z
Updated at: 2023-10-16T19:38:25Z
Closed at: 2023-10-16T19:38:25Z
Labels: bug, Critical
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1974

## Issue body

_No body_

## Comments

### Comment by hoangdat at 2023-07-03T03:26:59Z

hope you have more information:

Crashed logs collected from Store:
```
Exception java.lang.IllegalArgumentException:
  at net.openid.appauth.Preconditions.checkArgument (Preconditions.java)
  at net.openid.appauth.Preconditions.checkNotEmpty (Preconditions.java)
  at net.openid.appauth.TokenRequest$Builder.setRefreshToken (TokenRequest.java)
  at io.crossingthestreams.flutterappauth.FlutterAppauthPlugin.performTokenRequest (FlutterAppauthPlugin.java)
  at io.crossingthestreams.flutterappauth.FlutterAppauthPlugin.access$600 (FlutterAppauthPlugin.java)
  at io.crossingthestreams.flutterappauth.FlutterAppauthPlugin$3.onFetchConfigurationCompleted (FlutterAppauthPlugin.java)
  at net.openid.appauth.AuthorizationServiceConfiguration$ConfigurationRetrievalAsyncTask.onPostExecute (AuthorizationServiceConfiguration.java)
  at net.openid.appauth.AuthorizationServiceConfiguration$ConfigurationRetrievalAsyncTask.onPostExecute (AuthorizationServiceConfiguration.java)
  at android.os.AsyncTask.finish (AsyncTask.java:755)
  at android.os.AsyncTask.access$900 (AsyncTask.java:192)
  at android.os.AsyncTask$InternalHandler.handleMessage (AsyncTask.java:772)
  at android.os.Handler.dispatchMessage (Handler.java:107)
  at android.os.Looper.loop (Looper.java:224)
  at android.app.ActivityThread.main (ActivityThread.java:7561)
  at java.lang.reflect.Method.invoke
  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run (RuntimeInit.java:539)
  at com.android.internal.os.ZygoteInit.main (ZygoteInit.java:995)

```

### Comment by chibenwa at 2023-07-03T13:17:04Z

This exception is raised because the refresh token string is empty.

https://github.com/openid/AppAuth-Android/blob/d73ced59d07a4b93d9039ab3d193942fc7197959/library/java/net/openid/appauth/TokenRequest.java#L399

Lemon do return a refresh token. 

![Screenshot from 2023-07-03 20-16-24](https://github.com/linagora/tmail-flutter/assets/6928740/a02d276e-1d20-4da6-8c7b-cb3679038cde)


Do TMail store the refresh token?

### Comment by dab246 at 2023-07-04T01:41:15Z

> This exception is raised because the refresh token string is empty.
> 
> https://github.com/openid/AppAuth-Android/blob/d73ced59d07a4b93d9039ab3d193942fc7197959/library/java/net/openid/appauth/TokenRequest.java#L399
> 
> Lemon do return a refresh token.
> 
> ![Screenshot from 2023-07-03 20-16-24](https://user-images.githubusercontent.com/6928740/250567364-a02d276e-1d20-4da6-8c7b-cb3679038cde.png)


Good investigation. Exactly. `RefreshToken` was empty while calling `appAuth.token()` resulting in app crash. This problem only occurs on `Android` devices.

>
> Do TMail store the refresh token?

Yeah, TMail saved `RefreshToken` on local storage

### Comment by hoangdat at 2023-07-25T16:54:03Z

.

### Comment by QuangHoang1210 at 2023-08-07T02:25:55Z

Not passed yet on 0.8.9 android - ios - browser

### Comment by dab246 at 2023-08-15T02:25:59Z

Tested on `canary` and found the `scopes` of OIDC declaration variable was wrong as the documentation described.
- According to the documentation is `OIDC_SCOPES`

![Image](https://github.com/linagora/tmail-flutter/assets/80730648/17334419-8e81-4592-b9a9-b1c7558c95ab)


- But actually from the file `env.file` is `WEB_OIDC_SCOPE`




![Image](https://github.com/linagora/tmail-flutter/assets/80730648/393c54ff-80db-486c-ad50-ea056b20c5a9)

### Comment by dab246 at 2023-08-15T03:28:03Z

In `../well-known/openid-configuration` not found `offline_access` supported in `scopes_supported`



![Image](https://github.com/linagora/tmail-flutter/assets/80730648/309ee544-d470-4cc0-a2a0-4535e67f1f32)

### Comment by hoangdat at 2023-08-16T02:46:49Z

> In `../well-known/openid-configuration` not found `offline_access` supported in `scopes_supported`
> 
> ![Image](https://user-images.githubusercontent.com/80730648/260620160-309ee544-d470-4cc0-a2a0-4535e67f1f32.png)

Hi @guimard, `refreshToken` is support with this `scopes_supported`?

### Comment by guimard at 2023-08-21T03:25:42Z

> > In `../well-known/openid-configuration` not found `offline_access` supported in `scopes_supported`
> > ![Image](https://user-images.githubusercontent.com/80730648/260620160-309ee544-d470-4cc0-a2a0-4535e67f1f32.png)
> 
> Hi @guimard, `refreshToken` is support with this `scopes_supported`?

Hi,

refresh_token is supported but not exposed in metadata because it's not a common parameter but depends on the relying party connected. In tom-dev, it is allowed for TMail app

### Comment by hoangdat at 2023-08-21T03:37:48Z

no, it is not `tom-dev` ( we can not configure with `tom-dev`). This come from `https://canary-tmail.linagora.com/` & `https://sso.linagora.com`

### Comment by guimard at 2023-08-21T03:40:43Z

> no, it is not `tom-dev` ( we can not configure with `tom-dev`). This come from `https://canary-tmail.linagora.com/` & `https://sso.linagora.com`

Offline allowed for tmail, tmail-canary and tmail-app. No diff with tom-dev

### Comment by dab246 at 2023-08-24T03:16:42Z

Get `400 Bad Request` when get refresh token on `sso.linagora.com`

<img width="1435" alt="Screenshot 2023-08-24 at 09 05 51" src="https://github.com/linagora/tmail-flutter/assets/80730648/33f5443e-f110-4ece-9ab5-e6699774d6fe">


<img width="1435" alt="Screenshot 2023-08-24 at 09 05 56" src="https://github.com/linagora/tmail-flutter/assets/80730648/34fced73-bb85-45ff-b04e-2ae535a68722">

### Comment by hoangdat at 2023-08-24T03:19:35Z

@guimard please help us on it, we have `bad request` when call to get new `accessToken`. https://github.com/linagora/tmail-flutter/issues/1974#issuecomment-1690929638

### Comment by QuangHoang1210 at 2023-09-06T01:26:57Z

@dab246  @hoangdat 

Reopen this ticket.

### Reproduce step:
1, Login successfully
2, Keep browser alive overnight
3, Do any action on browser

Actual: System display error message and automatically relogin sucessfully.
Expected: System  not display error message and automatically relogin succesfully.



https://github.com/linagora/tmail-flutter/assets/124866146/5f74b7c2-1512-4680-ba65-3c72444a8a54

### Comment by dab246 at 2023-09-06T02:15:46Z

Check on server `upn`

### Comment by QuangHoang1210 at 2023-09-21T02:05:21Z

Reopened this ticket 

Precondition: 
- User login and keep it overnight

Step:
1, User login
2, User close browser but keep login state one night
3, User access tmail

Actual: User has been logout and system display error msg: "No Connection"
Expected: User still login. System display Tmail email thread view



https://github.com/linagora/tmail-flutter/assets/124866146/4dc7cbb1-b55e-48d1-8685-ee661ccf3f04

### Comment by guimard at 2023-09-21T04:04:19Z

Hi,

the problem is a lack of identification. When your access_token is expired, you have to identify the refresh_token request:

-  non public client: add a `Authorization: Basic ${Buffer.from(client_id+':'+client_secret).toString('base64')}`
```shell
$ curl -XPOST -H 'Authorization: Basic fzerfz==' -d 'grant_type=refresh_token&refresh_token=aabb' \
        https://sso/auth2/token | jq -S
```
- public client: add the client_id parameter in your request:
```shell
$ curl -XPOST -d 'grant_type=refresh_token&client_id=tmailapp&refresh_token=aabb' \
        https://sso/auth2/token | jq -S
```
