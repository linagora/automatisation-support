# GitHub issue #3023: [MU] SMime signature validation

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3023
State: closed
Author: chibenwa
Created at: 2024-07-22T08:23:36Z
Updated at: 2024-09-03T06:35:55Z
Closed at: 2024-09-03T06:35:54Z
Labels: customer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/3023

## Issue body

### Description

Have a pas/fail visualization regarding smime signature.

Requested for customer.

SMIME signature is to be validated on the backend side, and accessible to the frontend through the following headers: 

```
X-SMIME-Status: Good signature
X-SMIME-Status: Bad signature
X-SMIME-Status: Not signed
```

 - if `X-SMIME-Status: Not signed` or there is no header do nothing, like today

 - if `X-SMIME-Status: Good signature` when I open the mail a good signature icon is displayed next to the email.
 
 When I hover over it, a flyover messsage reads `The authenticity of this message had been verified with SMime signature` 

![Screenshot from 2024-07-22 10-19-52](https://github.com/user-attachments/assets/46cffc47-6201-4733-aed2-248fa8b7699f)

 - if `X-SMIME-Status: Bad signature` when I open the mail a bad signature icon is displayed next to the email.
 
 When I hover over it, a flyover messsage reads `This message failed SMime signature verification.` 

![Screenshot from 2024-07-22 10-22-51](https://github.com/user-attachments/assets/fc2dabff-678f-4ae5-b27f-c8aaaac625ec)

## Comments

### Comment by chibenwa at 2024-07-22T08:23:54Z

@hoangdat please plan work on this next sprint

### Comment by chibenwa at 2024-07-22T08:25:43Z

CF https://ci.linagora.com/linagora/lgs/twp/mail-gov-mauritius/-/issues/30

### Comment by hoangdat at 2024-07-22T08:58:58Z

@Bobpodvalnyi please help us on the icon for this function. Thanks

### Comment by hoangdat at 2024-07-26T08:34:40Z

@Bobpodvalnyi please help us

### Comment by chibenwa at 2024-07-26T08:36:02Z

After today discussion with @guimard without this feature LNG cannot be paied for the customer projet: it is mandated!

### Comment by Bobpodvalnyi at 2024-07-29T09:59:12Z

https://www.figma.com/design/XqLqMINlZw09BdEHI8yLb9/Teammail---1.1?node-id=2956-1011&t=rrvBVF6LhV32w9QH-0 @hoangdat @chibenwa

### Comment by chibenwa at 2024-07-29T10:52:55Z

Simple and efficient. Thanks!

### Comment by hoangdat at 2024-08-05T03:04:14Z

@Arsnael @chibenwa One question: any problem if man-in-the-middle can change this header?

### Comment by Arsnael at 2024-08-05T03:48:59Z

This header is set by the backend when it receives the email and treats it. If man in the middle sets it up it would be overriden when treated by the back anyways, and probably would fail because it has been tempered in the first place

### Comment by chibenwa at 2024-08-05T09:23:53Z

Please document that the header shall be removed as part of the delivery chain.


@Arsnael we can create a tmail backend ticket to remove this header in all default confs, deployments. Can you take care of it?
Thanks!

### Comment by Arsnael at 2024-08-05T09:33:38Z

> Please document that the header shall be removed as part of the delivery chain.

Well except if you use the smime verify signature mailet in the chain like for MU, correct? Or you want to delete it at the entry of the chain and do a verification behind?

### Comment by chibenwa at 2024-08-05T09:39:08Z

No we should always unset it now when using tmail front so pkease remove everywhere

### Comment by Arsnael at 2024-08-05T10:06:08Z

=> https://github.com/linagora/james-project/issues/5239

### Comment by Arsnael at 2024-08-27T04:02:57Z

FYI work has been done for this on the backend and the smime check signature mailet has been deployed on tmail.linagora.com with the CA cert from MU.

@hoangdat I guess your team can start working on this now, and that you could test this with on-commit env? Or do you need it deployed somewhere else?

### Comment by Arsnael at 2024-08-27T04:08:53Z

I see your team worked on that but it's not been merged into master branch, thus I can't check with the mail I tested with from MU on the oncommit env

### Comment by Arsnael at 2024-08-30T04:00:47Z

@hoangdat @chibenwa I tried to do a little recording with tmail front (canary) and smime check signature configured with MU CA on our prod

https://github.com/user-attachments/assets/545a44ed-c775-421c-af5a-22088c593e4a

Would that be enough?

### Comment by chibenwa at 2024-09-03T06:35:55Z

Yes indeed it is!
