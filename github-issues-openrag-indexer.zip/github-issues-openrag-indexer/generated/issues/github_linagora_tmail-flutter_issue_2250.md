# GitHub issue #2250: [Bug] Messages received as vacations auto reply have subject "????????!"

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2250
State: closed
Author: tprudentova
Created at: 2023-10-10T14:04:14Z
Updated at: 2023-11-15T17:58:52Z
Closed at: 2023-11-15T17:58:52Z
Labels: bug, bug?, costrat
Assignees: hoangdat, tprudentova
URL: https://github.com/linagora/tmail-flutter/issues/2250

## Issue body

Occurred time: 09/10/2023

Environment(version): https://tmail.linagora.com/

Steps to reproduce:

1. Log into Tmail
2. Set vacations auto reply 
3. Receive a letter from user B
4. The reply user B gets has topic "????????!" instead of set topic 

Image/Video evidence:
User B
![image](https://github.com/linagora/tmail-flutter/assets/97684890/e3db1789-50da-4adb-9a26-68744461754c)

User A
![image](https://github.com/linagora/tmail-flutter/assets/97684890/d0231ccd-3b0a-4164-8297-649323c70dc9)

## Comments

### Comment by chibenwa at 2023-10-10T15:54:53Z

Looks like a backend bug to me...

## Definition of done

 - Add subject + body with weird encodings within `VacationIntegrationTest`

### Comment by chibenwa at 2023-10-10T16:04:24Z

I cannot reproduce.

Which Mail User Agent is used for the screenshot? OpenPaaS?

### Comment by tprudentova at 2023-10-10T16:08:47Z

Yes, but looks the same on TMail
<img width="1013" alt="Screenshot 2023-10-09 at 16 18 56" src="https://github.com/linagora/james-project/assets/97684890/e11583f3-7678-46c0-ae02-422d0260e8f4">

### Comment by chibenwa at 2023-10-10T16:11:59Z

Ok then. Can you copy and paste the exact russian string please?

### Comment by tprudentova at 2023-10-10T16:15:50Z

From the subject? It's "Привет!"

### Comment by chibenwa at 2023-10-10T22:10:33Z

I cannot reproduce sur far...

![image](https://github.com/linagora/james-project/assets/6928740/0974ef5d-8437-4706-aec3-dc26a70b3fe6)

@tprudentova which browser did you use?

Any chance to open network tabs and capture JMAP requests?

@hoangdat could that be that the browser have no locale support?

### Comment by tprudentova at 2023-10-11T06:36:37Z

I think it was Safari for the sender and Chrome for receiver

### Comment by chibenwa at 2023-10-11T11:28:15Z

@QuangHoang1210 ?

### Comment by QuangHoang1210 at 2023-10-11T16:02:51Z

@chibenwa 

### This issue happen on both Chrome and Safari with Russian language.

**Precondition**
User A and User B config the language and region to be Russian

**Reproduce Step:**
1, User A setup the vacation following the image bellow:

<img width="1410" alt="Screenshot 2023-10-11 at 22 58 30" src="https://github.com/linagora/tmail-flutter/assets/124866146/731948da-b24d-4cc5-a834-c054fdc71906">

2, User B send an email to user A

**Actual:** The auto-reply email title being "???????"
**Expected:** It should be "Привет" which inputted in the vacation mode setup

### Additional information:
**Payload Response**

<img width="1420" alt="Screenshot 2023-10-11 at 23 01 15" src="https://github.com/linagora/tmail-flutter/assets/124866146/a2b19e6f-2116-4788-b4eb-430c5ff58fc1">

**Reproduce Video**

https://github.com/linagora/tmail-flutter/assets/124866146/488cbe2b-aaf2-48f5-8173-a98266e3366a

### Comment by chibenwa at 2023-10-11T18:12:58Z

Can you give me the EML of the faulty message please?

### Comment by QuangHoang1210 at 2023-10-12T03:35:53Z

[EML.zip](https://github.com/linagora/tmail-flutter/files/12876760/EML.zip)

@chibenwa

### Comment by chibenwa at 2023-10-12T16:39:10Z

In the EML: `Subject: ????????????`

TODO: backend team investigate...

### Comment by quantranhong1999 at 2023-10-18T11:26:00Z

I tried to reproduce on preprod but did not succeed yet.

VacationResponse/get result:
```json
[
    "VacationResponse/get",
    {
        "accountId": "9039d9068b20a681e63de6e52f0476b1d10efbc82153a690eb92dcb040517b90",
        "notFound": [],
        "state": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
        "list": [
            {
                "subject": "Привет!",
                "id": "singleton",
                "toDate": "2023-10-19T09:57:00Z",
                "isEnabled": true,
                "htmlBody": "<p>Привет!</p><p>Привет!<br></p>",
                "fromDate": "2023-10-17T09:56:00Z"
            }
        ]
    },
    "c1"
]
```

Email/get (the vacation response mail):
```json
{
    "name": "Subject",
    "value": " =?UTF-8?B?0J/RgNC40LLQtdGCIQ==?="
}
```

` =?UTF-8?B?0J/RgNC40LLQtdGCIQ==?=` seems to be the UTF-8 charset encode (by backend) of "Привет!".

@chibenwa do you have any idea which code piece in James do this encoding? I would like to check if it is "unstable" or not.


![Image](https://github.com/linagora/tmail-flutter/assets/55171818/4e10b00b-c5ee-4cee-ae4e-e76b8726741e)

In `VacationIntegrationTest` I was not able to reproduce the encoding part so I am not sure where it comes from.

### Comment by chibenwa at 2023-10-18T15:47:55Z

Ok let's see with @tprudentova when in Paris then...

### Comment by hoangdat at 2023-11-15T17:40:08Z

@tprudentova please test it together

### Comment by QuangHoang1210 at 2023-11-15T17:58:52Z

Passed on 0.10.4 Canary on my side

https://github.com/linagora/tmail-flutter/assets/124866146/3f9f9afd-6eaa-48ae-bd58-1ccc5713741d
