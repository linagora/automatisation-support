# GitHub issue #20: [Story] As an user, I want to read the email content

## Metadata

Repository: linagora/tmail-flutter
Issue number: 20
State: closed
Author: hoangdat
Created at: 2021-08-09T09:28:35Z
Updated at: 2022-01-05T05:01:45Z
Closed at: 2022-01-05T05:01:45Z
Labels: 
Assignees: dieptran88
URL: https://github.com/linagora/tmail-flutter/issues/20

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Technical issues](#technical-issues)
* [Misc](#misc)

## Related EPIC

## Definition

- Given that i am a Tmail user and i already had an account (John Doe) 
- Given that i log-in successfully to the Tmail app
- I can see the default view  is Inbox mail list
- I touch in one email on the mail list, the screen email content will be opened.
- Email content screen includes 3 main parts: Header fields, the message body and attachments (if any)

**UC1 Read Header fields**
   - Subject: Display full subject of the email 
   - From : Email address of the message author: name - email
   - To: Email address lists of recipients. The first 3 emails will be displayed. The remaining number of email is shown as (+n).
   - Date: the date -time that i received this email
- There is an arrow icon at the end of field "To" that when i click on, a collapsible section will be shown including fields:
   - The full list of email address of field "To". The format of email address is: Name . In case there is no name, it will show only email. The email address in the list will have tag "me" if it is my own email address. 
   - Cc/BCC: The list of email addresses which are filled by the author when he composed this message. This is optional field.
   - When i touch a name in the list of To/CC/BCC, the full email address will be shown
- For the mailbox "Sent": The header is as same as above except that the Bcc list of email addresses will be displayed if i input in this field when composing the email. 

**UC2. Read Email body**

- I can read all content in plain-text if the email is sent in plain-text mode
- If the email is composed with html options, i can see the email content with the correct formats: 
  Font, FontSize, Bold, Italic, Underline, strikethrough, Text color,Bullets, Numbering, Text Background Color, Align text(Left, Center, Right), Line height, indent
- If there is a table in email content, i also see that table on my email 
- If i there is an image included inline in the email body, i can see that image displayed in correct position. If the image format is not supported, there will be a place-holder image 
- If there is a link in the email body, when i click on that link, i am navigated to the device browser to open that link. 
- If the signature is included, i can see it at the last of the email body.

**UC3. Attached file**
- If there are attached files in the email, in the threadview, i can see the icon attachment  on that email
- I open that email and  I can see the list of these attachments under the email body
- Each attached file will contain information: File name, file size, file icon 
- If the attachment list is very long, i can scroll to the last item. 


[Back to Summary](#summary)

## UI Design

#### Mockups

#### Final design

![image](https://user-images.githubusercontent.com/68209176/132980132-f2e2c7aa-c545-41d1-871c-e54d4c216319.png)
![image](https://user-images.githubusercontent.com/68209176/132980145-80354334-329d-472f-8042-0c37d1a4b691.png)
![image](https://user-images.githubusercontent.com/68209176/132980148-4c55d55f-32cc-47f5-8821-8ef52f43ca0f.png)


[Back to Summary](#summary)

## Technical issues

[Back to Summary](#summary)

## Misc

[Back to Summary](#summary)

## Comments

### Comment by chibenwa at 2021-08-10T02:52:00Z

## The JMAP queries

Sending...

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
     "methodCalls": [[
    "Email/get",
    {
      "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
      "ids": ["360"],
      "properties":["bodyValues", "htmlBody", "attachments"],
      "fetchHTMLBodyValues": true
    },
    "c1"]]
}
```

Will return:

```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/get",
            {
                "accountId": "405010d6c16c16dec36f3d7a7596c2d757ba7b57904adc4801a63e40914fd5c9",
                "notFound": [],
                "state": "1385e36a-71cb-4cdf-ad2b-f7743ec11f18",
                "list": [
                    {
                        "attachments": [
                            {
                                "charset": "us-ascii",
                                "disposition": "attachment",
                                "size": 50290,
                                "partId": "3",
                                "name": "toto.jpg",
                                "blobId": "360_3",
                                "type": "image/jpeg"
                            },
                            {
                                "charset": "us-ascii",
                                "disposition": "attachment",
                                "size": 49909,
                                "partId": "4",
                                "name": "hrfhrgerhvewrlvherv.jpg",
                                "blobId": "360_4",
                                "type": "image/jpeg"
                            },
                            {
                                "charset": "us-ascii",
                                "disposition": "attachment",
                                "size": 1206272,
                                "partId": "5",
                                "blobId": "360_5",
                                "type": "application/msword"
                            },
                            {
                                "charset": "us-ascii",
                                "disposition": "attachment",
                                "size": 62897,
                                "partId": "6",
                                "blobId": "360_6",
                                "type": "image/jpeg"
                            },
                            {
                                "charset": "us-ascii",
                                "disposition": "attachment",
                                "size": 41516,
                                "partId": "7",
                                "blobId": "360_7",
                                "type": "image/jpeg"
                            },
                            {
                                "charset": "us-ascii",
                                "disposition": "attachment",
                                "size": 1206272,
                                "partId": "8",
                                "blobId": "360_8",
                                "type": "application/octet-stream"
                            }
                        ],
                        "htmlBody": [
                            {
                                "charset": "us-ascii",
                                "size": 771,
                                "partId": "2",
                                "blobId": "360_2",
                                "type": "text/plain"
                            }
                        ],
                        "id": "360",
                        "bodyValues": {
                            "2": {
                                "value": "FYI...\n\nI will prepare the work request.\n\nHollis\n---------------------- Forwarded by Hollis Kimbrough/EWC/Enron on 03/12/2002 \n10:09 AM ---------------------------\n\n\nJim Wallace\n03/12/2002 09:21 AM\nTo: Hollis Kimbrough/EWC/Enron@ENRON\ncc:  \n\nSubject: Pad # 79 & # 30 Trent Mesa site\n\nHollis\n\nAttached is the FAR # 01461 for Pad # 30 and FAR # 1459 for Pad # 79.   We \nwill use the date on the FAR's as the damage date.\n\n\n\n\n\n\n***********\nEDRM Enron Email Data Set has been produced in EML, PST and NSF format by ZL Technologies, Inc. This Data Set is licensed under a Creative Commons Attribution 3.0 United States License <http://creativecommons.org/licenses/by/3.0/us/> . To provide attribution, please cite to \"ZL Technologies, Inc. (http://www.zlti.com).\"\n***********\n",
                                "isEncodingProblem": false,
                                "isTruncated": false
                            }
                        }
                    }
                ]
            },
            "c1"
        ]
    ]
}
```

Note that the HTML body parts defaults to `text/plain` if no `text/html` alternatives exists.

### Comment by hoangdat at 2021-08-10T09:01:02Z

@chibenwa What is the difference from `textBody ` and `htmlBody`?

### Comment by chibenwa at 2021-08-10T09:38:18Z

Mail clients send generally two version of the same text: one in HTML, one in plain text.

They do use a specific mime type `multipart/alternative` to say that the receiver needs to display one, or the other of the versions:
   - HTML is they can
   - Plain text if there is no other choice.
   
For instance, the Apache mailing lists only allow Plain text, and will keep only the text/plain part.

Syntax:

```
Content-Type: multipart/alternative; boundary=----123456

----123456
Content-Type: text/plain

This is an awesome message
on several lines.
----123456
Content-Type: text/html

This is an <b>awesome</b> message<br/> on several lines.
----123456
```

Note that there are some multiparts that are a bit famous: `multipart/related` allow working with inlined images (to be displayed within the HTML rendering)

Example:

```
Content-Type: multipart/related; boundary=----123456

----123456
Content-Type: text/html

<p>This is the text before the image...</p>
<br>
<br>

<img alt="" src="cid:part1.37A15C92.A7C3488D"
      height="73" width="73">

<br>
<br>
<p>This is the text after the image...</p>

----123456
Content-Type: image/jpeg; name=abc.jpg
Content-ID: <part1.37A15C92.A7C3488D>
Content-Disposition: inline

XXXXXXX
----123456
```

Also `multipart/mixed` is used to wrap attachments around a text body:


```
To: James User <user@james.org>
From: James Sender <sender@james.org>
Subject: Message with text attachment
Message-ID: <ffaa7bce-fbe3-83b5-de3f-9a7301233615@linagora.com>
Date: Tue, 5 Sep 2017 09:54:16 +0200
MIME-Version: 1.0
Content-Type: multipart/mixed;
 boundary="------------D24E361990BDBA143D4D8794"
Content-Language: en-US

This is a multi-part message in MIME format.
--------------D24E361990BDBA143D4D8794
Content-Type: text/plain; charset=utf-8; format=flowed
Content-Transfer-Encoding: 7bit

The message has a text attachment.

--------------D24E361990BDBA143D4D8794
Content-Type: text/plain; charset=UTF-8;
 name="attachment.txt"
Content-Transfer-Encoding: base64
Content-Disposition: attachment;
 filename="attachment.txt"

VGhpcyBpcyBhIGJlYXV0aWZ1bCBiYW5hbmEuCg==
--------------D24E361990BDBA143D4D8794--
```

Of course you can write messages combining all of the above <3

```
multipart/mixed
\___ multipart/alternative (either rich text, or plain text)
         \___ multipart/related (the rich text have some inlined images...)
                  \___ Body Part: HTML plain version of the message
                  \___ Body Part: Inlined image 1
                  \___ Body Part: Inlined image 2
         \___ Body Part: Text plain version of the message
\___ Body Part: Attachment 1
\___ Body Part: Attachment 2
```

Yes, MIME messages is something complex but hopefully JMAP had been thought in a way that enables JMAP clients to skip most of this complexity.

If you want to have a look at it, you can still (in postman) request the `bodyStructure` property: James will not be hidding things. But so far you may stick around with `htmlBody` and `attachments` properties ;-)

A bit long but does it answer your question?

### Comment by chibenwa at 2021-08-10T09:39:06Z

Also be ready to handle several values in `htmlBody` :-) (this was a bug of OpenPaaS)

### Comment by hoangdat at 2021-08-10T22:24:00Z

@chibenwa 🙏 so detail, I will continue to investigate.
@dieptran88 please read all the comments and ask any question related to email body here.

### Comment by chibenwa at 2021-08-11T02:06:03Z

And remember: there is no stupid questions!

### Comment by dieptran88 at 2021-08-12T04:21:05Z

1. As i understand, the body of message can be in  text body or html body. And client will try to display in html as first choice.  so is there any conditions or factor that prevent to display in html format?
2. For image or video, is it  considered as content of the message in or an attachment ? If it is content, how will it be displayed in  textBody format?

### Comment by chibenwa at 2021-08-12T04:52:52Z

1. Always ask html to James. 

2. Let's care of inlined stuff later.

Inlined stuff will be set as attachment. You will have to find the attachment matching the CID, download it, and render it in the middle of the html text...

### Comment by chibenwa at 2021-08-19T02:24:44Z

### Doing downloads for CID

```
GIVEN a CID in the body of an email
LOOKUP the attachment and find one with the same blobId
Look at the download URL pattern within the session,
Fill the url pattern with attachment details
And execute the HTTP request to the backend server
```

Here is what the doanload template looks like for James:

```
{
   ...
   "downloadUrl" : "http://domain.com/download/{accountId}/{blobId}?type={type}&name={name}",
    ...
}
```

EG:

```
GET /download/29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6/ruigerkfgwukfgkwge_3

Where

GET /download/ACCOUNT_ID/BLOB_ID
```

`type` and `name` are optional....

### Comment by hoangdat at 2021-08-19T02:34:16Z

`cid` is one type of `blobId`?

### Comment by dab246 at 2021-08-19T02:40:15Z

I run on web browser. it not working `https://dev.open-paas.org/download/3ce33c876a726662c627746eb9537a1d13c2338193ef27bd051a3ce5c0fe5b12/382312d0-fa5c-11eb-b647-2fef1ee78d9e_5?name=A233DF1D-151E-44C7-A480-68338CAEC176.jpeg`

### Comment by chibenwa at 2021-08-19T02:40:29Z

No `cid` is used as an identifier to position the inlined attachment within the body

`blobId` allow to retrieve the content of the attachment to display it.

Here is how an `attachment` looks like:

```
                                  {
                                    "partId": "5",
                                    "blobId": "${messageId.serialize}_5",
                                    "headers": [
                                        {
                                            "name": "Content-ID",
                                            "value": " <14672787885774e5c4d4cee471352039@linagora.com>"
                                        },
                                        {
                                            "name": "Content-Type",
                                            "value": " text/plain; charset=\\\"iso-8859-1\\\"; name=\\\"avertissement.txt\\\""
                                        },
                                        {
                                            "name": "Content-Disposition",
                                            "value": " inline; filename=\\\"avertissement.txt\\\""
                                        },
                                        {
                                            "name": "Content-Transfer-Encoding",
                                            "value": " binary"
                                        }
                                    ],
                                    "size": 19,
                                    "name": "avertissement.txt",
                                    "type": "text/plain",
                                    "charset": "iso-8859-1",
                                    "disposition": "inline",
                                    "cid": "14672787885774e5c4d4cee471352039@linagora.com"
                                }
```

### Comment by chibenwa at 2021-08-19T02:44:18Z

>  I run on web browser. it not working https://dev.open-paas.org/download/3ce33c876a726662c627746eb9537a1d13c2338193ef27bd051a3ce5c0fe5b12/382312d0-fa5c-11eb-b647-2fef1ee78d9e_5?name=A233DF1D-151E-44C7-A480-68338CAEC176.jpeg

Let me guess: 404 ? :trollface: 

If so, then it is like for `.well-known/jmap`: it is a configuration issue of the NGINX server that fails at redirecting the stuff to James. We will fix DEV as soon as French people get backs but so far we likely do not have the access. :-(

Does it work on the `memory` testing server?

### Comment by dab246 at 2021-08-19T02:48:30Z

I am very annoyed when I have to switch back and forth between the test server and the dev server. Please tell them to fix it as soon as possible.

### Comment by chibenwa at 2021-08-19T02:49:38Z

I'm very sorry for this situation, and sure I will do everything possible to get it fixed as soon as possible.

### Comment by hoangdat at 2021-08-19T02:49:46Z

> I am very annoyed when I have to switch back and forth between the test server and the dev server. Please tell them to fix it as soon as possible.

Please use `memory` for development stuff :)

### Comment by dab246 at 2021-08-19T02:51:11Z

Please send me high configuration machine. I don't want to damage my computer.

### Comment by hoangdat at 2021-08-19T02:57:15Z

> Please send me high configuration machine. I don't want to damage my computer.

please contact me. We are ready to purchasing.

### Comment by chibenwa at 2021-08-19T03:03:55Z

@dab246 I did set up the memory image on one of our servers.

`curl -XGET -H "Accept: application/json; jmapVersion=rfc-8621" -u XXXX http://51.68.40.116/jmap/session`

Creds sent on signal.

Memory image provisionning done there...

You can use it if you want.

### Comment by hoangdat at 2021-09-10T04:53:05Z

@dieptran88 
UC1: when touch to a name in list of To/Cc/Bcc, the exact email should be showed. 

UC3: IMO, attachment should be at the end of email body, below signature, we have limited space for displaying in mobile, the good UX should be focus to the context of it (content body) first.
