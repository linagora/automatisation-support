# GitHub issue #1037: Out of sprint

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1037
State: closed
Author: hoangdat
Created at: 2022-10-03T09:45:15Z
Updated at: 2022-10-17T07:51:50Z
Closed at: 2022-10-17T07:51:50Z
Labels: 
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1037

## Issue body

_No body_

## Comments

### Comment by hoangdat at 2022-10-03T09:46:02Z

- [x] Fastmail video demo with - `1HD`
- [x] ltt.rs Android authorize with Fastmail

### Comment by dab246 at 2022-10-04T02:39:43Z

4 HD - `Review and Planning`

### Comment by dab246 at 2022-10-06T02:37:07Z

2 HD - `#1045`

### Comment by dab246 at 2022-10-07T02:35:46Z

1 HD - `#1042`
1 HD -  `#1039 #1051`

### Comment by dab246 at 2022-10-07T02:51:23Z

1 HD - `#1043`

### Comment by dab246 at 2022-10-10T02:54:05Z

2 HD - `#508`

### Comment by dab246 at 2022-10-12T03:00:19Z

1 HD - `Slide`
1 HD - `#1018`

### Comment by dab246 at 2022-10-13T02:43:47Z

2 HD - `#1018`

### Comment by dab246 at 2022-10-14T03:23:30Z

1 HD - `#1064`

### Comment by dab246 at 2022-10-14T03:23:50Z

2 HD - `#1018`

### Comment by dab246 at 2022-10-17T02:45:30Z

2 HD - `#1018`

### Comment by dab246 at 2022-10-17T02:46:06Z

2 HD - `#1064-#1066`
