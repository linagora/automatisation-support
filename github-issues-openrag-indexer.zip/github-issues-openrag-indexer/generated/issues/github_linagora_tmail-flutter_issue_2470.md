# GitHub issue #2470: [TwakeMail-Box] [Configuration Issue] Some TwakeMail-box is missing system folder

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2470
State: closed
Author: QuangHoang1210
Created at: 2024-01-17T11:23:22Z
Updated at: 2024-04-17T03:35:21Z
Closed at: 2024-04-17T03:35:21Z
Labels: bug, Major, back-end implementing
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/2470

## Issue body

OS:  Web Firefox / Chrome
Device: laptop 
TMail version: 0.11.3 Twake mail preprod 

### *Test data:
firstname23.surname23
firstname31.surname31

### *Precondition:
- Tmail-box 1 <hiring> is config to user A and user B
- Tmail-box 2 <sale> is config to user A and user B
- User A <userA@linagora.com>
- User B <userB@linagora.com>

### *Reproduce Step:
1, User A and B access TwakeMail in 2 browsers
2, Double check TwakeMail-box system folder on both user

### **Actual:** 
- one of them have expand icon at TwakeMail-box and have System folder also
- Other one only have TwakeMail-box without system folder and expand icon

### **Expected:** 
- Should be same
- Should included all System folder **[Inbox, Drafts, outbox, Sent, Trash]** each TwakeMail-box <following this [User Story Move Message in TwakeMail-box](https://github.com/linagora/tmail-flutter/issues/1209)>

![Image](https://github.com/linagora/tmail-flutter/assets/124866146/d02f0e69-3ef7-4516-b6b3-0757ddf2841a)

## Comments

### Comment by hoangdat at 2024-01-18T03:09:11Z

@Arsnael please help us on this config for easier in verifying

### Comment by Arsnael at 2024-01-18T03:25:34Z

Not impossible that this is an old one... Will have a look though

### Comment by Arsnael at 2024-01-18T06:05:25Z

2 points here. 

1. Team-mailboxes with no subfolders showing. From what I checked, I don't see anything wrong from the backend side. For example, user 23:

![user23-team-mailboxes](https://github.com/linagora/tmail-flutter/assets/9005025/f9b59fed-6a36-42df-bca5-e93692448707)

Let's take the communication TM for example. In the answer returned by the Mailbox/get method, I can see the Inbox and Sent subfolders for communication TM, as you can see here :

```
                    {
                        "totalThreads": 2,
                        "name": "communication",
                        "isSubscribed": true,
                        "totalEmails": 2,
                        "unreadThreads": 0,
                        "unreadEmails": 0,
                        "sortOrder": 1000,
                        "rights": {
                            "firstname23.surname23@upn.integration-open-paas.org": [
                                "i",
                                "l",
                                "r",
                                "s",
                                "t",
                                "w"
                            ]
                        },
                        "namespace": "TeamMailbox[communication@upn.integration-open-paas.org]",
                        "myRights": {
                            "mayReadItems": true,
                            "mayAddItems": true,
                            "mayRemoveItems": true,
                            "maySetSeen": true,
                            "maySetKeywords": true,
                            "mayCreateChild": false,
                            "mayRename": false,
                            "mayDelete": false,
                            "maySubmit": false
                        },
                        "id": "d7561ff0-64b4-11ed-88c0-338bebbdf582"
                    },
                    {
                        "totalThreads": 1,
                        "name": "INBOX",
                        "isSubscribed": false,
                        "totalEmails": 1,
                        "unreadThreads": 1,
                        "unreadEmails": 1,
                        "sortOrder": 1000,
                        "rights": {
                            "firstname23.surname23@upn.integration-open-paas.org": [
                                "i",
                                "l",
                                "r",
                                "s",
                                "t",
                                "w"
                            ]
                        },
                        "parentId": "d7561ff0-64b4-11ed-88c0-338bebbdf582",
                        "namespace": "TeamMailbox[communication@upn.integration-open-paas.org]",
                        "myRights": {
                            "mayReadItems": true,
                            "mayAddItems": true,
                            "mayRemoveItems": true,
                            "maySetSeen": true,
                            "maySetKeywords": true,
                            "mayCreateChild": false,
                            "mayRename": false,
                            "mayDelete": false,
                            "maySubmit": false
                        },
                        "id": "d759c970-64b4-11ed-88c0-338bebbdf582"
                    },
                    {
                        "totalThreads": 5,
                        "name": "Sent",
                        "isSubscribed": false,
                        "totalEmails": 5,
                        "unreadThreads": 3,
                        "unreadEmails": 3,
                        "sortOrder": 1000,
                        "rights": {
                            "firstname23.surname23@upn.integration-open-paas.org": [
                                "i",
                                "l",
                                "r",
                                "s",
                                "t",
                                "w"
                            ]
                        },
                        "parentId": "d7561ff0-64b4-11ed-88c0-338bebbdf582",
                        "namespace": "TeamMailbox[communication@upn.integration-open-paas.org]",
                        "myRights": {
                            "mayReadItems": true,
                            "mayAddItems": true,
                            "mayRemoveItems": true,
                            "maySetSeen": true,
                            "maySetKeywords": true,
                            "mayCreateChild": false,
                            "mayRename": false,
                            "mayDelete": false,
                            "maySubmit": false
                        },
                        "id": "d75d4be0-64b4-11ed-88c0-338bebbdf582"
                    },
```

Backend answers back some subfolders that Tmail front doesn't show. I think for this problem lies on the front side. Please check @hoangdat 

2. Missing subfolders Draft Outbox and Trash. That I suspect on staging likely because the team mailboxes were created before we add those sub folders on the backend creation. I will verify that theory, let me dig a bit more on this

### Comment by Arsnael at 2024-01-18T06:11:09Z

Regarding the missing subfolders we might have an issue, even on newer tm created I don't see subfolders outbox, trash, draft. Will investigate and open an issue in the backend shortly

### Comment by Arsnael at 2024-01-18T06:40:41Z

Found the issue => https://github.com/linagora/tmail-backend/issues/897

Will work on it. Will ask @quantranhong1999 to include it for release in process (sorry Quan^^)

### Comment by quantranhong1999 at 2024-01-18T07:31:03Z

> Will work on it. Will ask @quantranhong1999 to include it for release in process (sorry Quan^^)

Sure, no problem. cc @QuangHoang1210 please postpone your plan on testing tmail-backend release. We would ping you again when the fix for this is included.

### Comment by Arsnael at 2024-01-18T09:02:53Z

> Found the issue => https://github.com/linagora/tmail-backend/issues/897

Merged (yes yes already). @hoangdat should have this deployed soon on staging with the new backend release.

First point above is left, but that's on your side I believe, as TMail app does not seem to show subfolders of a Team mailbox sometimes for some reason, despite the response from the backend containing them

### Comment by Arsnael at 2024-01-22T03:13:43Z

@hoangdat @QuangHoang1210 fix deployed on staging.

Note that the issue was that we didnt add rights to the missing mailboxes for members of a TM, so if you want them to appear though you gonna have to remove the member and add it again in the team mailbox before seeing the missing subfolders though

If any problem, dont hesitate.

### Comment by QuangHoang1210 at 2024-01-23T18:28:58Z

Hi @Arsnael , @quantranhong1999 

Please check for me 2 accounts bellow: 
firstname23.surname23
firstname31.surname31


I don't know if it config yet cause now feeling still not yet have correct system folder on preprod.

<img width="1495" alt="Screenshot 2024-01-23 at 10 27 44 PM" src="https://github.com/linagora/tmail-flutter/assets/124866146/0606047f-0072-49a5-98f2-e5c83c49832e">

### Comment by quantranhong1999 at 2024-01-24T02:44:21Z

> I don't know if it config yet cause now feeling still not yet have correct system folder on preprod.

I bet that removing and then adding the member to the team mailbox would fix the issue...
Let's me have a look.

### Comment by quantranhong1999 at 2024-01-24T05:27:56Z

Indeed some admin action on the backend side was needed.

I reset (deleted and recreated) the team mailboxes on preprod to recreate full mailboxes.
Sorry that the test messages in the team mailboxes are lost, but mailboxes have fully existed now:
![image](https://github.com/linagora/tmail-flutter/assets/55171818/6d0839db-d045-4d71-b390-6ba5621fbab2)

FYI `communication`, `hiring`, `human-resources`, `marketting` and `sales` team mailboxes include users 22 -> 32 now :-).

cc @QuangHoang1210 can you check again?

### Comment by Arsnael at 2024-01-24T06:02:49Z

Thanks @quantranhong1999 for checking and cleaning up the existing mess :)

### Comment by Arsnael at 2024-04-17T02:06:42Z

Can we close this?

### Comment by quantranhong1999 at 2024-04-17T02:45:58Z

> Can we close this?

Yes, I think we are good now.

cc @hoangdat
