# GitHub issue #33: Support quotas

## Metadata

Repository: linagora/tmail-flutter
Issue number: 33
State: closed
Author: chibenwa
Created at: 2021-08-19T01:10:21Z
Updated at: 2023-07-24T07:14:15Z
Closed at: 2022-12-09T06:50:23Z
Labels: 
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/33

## Issue body

Look at the session object.

If it contains the `urn:apache:james:params:jmap:mail:quota` the add the `urn:apache:james:params:jmap:mail:quota` capability to `Mailbox/get` calls. Quota information would then be added to the mailboxes.

Use the quota of INBOX as the quota of the account and display it at the bottom left.

If the `urn:apache:james:params:jmap:mail:quota` capability is **not** here, then do not display quotas.

### Example

```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:apache:james:params:jmap:mail:quota"],
  "methodCalls": [[
    "Mailbox/get",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "ids": ["abcd"]
    },
    "c1"]]
}
```

Will return 

```
{
  "sessionState": "${SESSION_STATE.value}",
  "methodResponses": [[
    "Mailbox/get",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "list": [
        {
          "id": "${mailboxId}",
          "name": "custom",
          "sortOrder": 1000,
          "totalEmails": 0,
          "unreadEmails": 0,
          "totalThreads": 0,
          "unreadThreads": 0,
          "myRights": {
            "mayReadItems": true,
            "mayAddItems": true,
            "mayRemoveItems": true,
            "maySetSeen": true,
            "maySetKeywords": true,
            "mayCreateChild": true,
            "mayRename": true,
            "mayDelete": true,
            "maySubmit": true
          },
          "isSubscribed": false,
          "quotas": {
            "#private&bob@domain.tld": {
              "Storage": { "used": 0},
              "Message": {"used": 0, "max": 36000}
            }
          }
        }
      ],
      "notFound": []
    },
    "c1"]]
}
```

Unit for quotas is bytes. The value useful for your display is `Storage`... Missing `max` of course means unlimited.

### Bonus

When the quota is occupied at ore than 90% display the quota information in **red**

## Comments

### Comment by hoangdat at 2022-06-07T08:10:21Z

@chibenwa How about we do it after `rich text`?

### Comment by chibenwa at 2022-06-07T08:20:00Z

Ok!

### Comment by chibenwa at 2022-06-07T08:21:12Z

But to be fairly honnest I'd prefer us to wait for next IETF meeting and implement the official spec cf https://datatracker.ietf.org/doc/draft-ietf-jmap-quotas/

That would allow to drop our custom spec <3

IMO wait, @Arsnael is working hard on getting this specified, let's avoid custom stuff.

### Comment by chibenwa at 2022-09-26T04:30:33Z

TODO:

 - Rework quota examples - @Arsnael  or @chibenwa ETA 30/09

 - Visuals for QUOTA (bottom of mailbox bar) @dieptran88 ETA 30/09

 - Banner waning (orange) if more than 90% consumed @dieptran88 ETA 30/09

 - Banner error (red)  if 100% consumed @dieptran88 ETA 30/09

 - Make sure "otherquota" JMAP exceptions are well managed by the Flutter APP -> @hoangdat to create the ticket
    - `if I send n email while being otherquota I get a relevant warning`
    - `if I send a 50MB large file I get a relevant error`

More grooming with Diep BA and Khanh (designer). Results to be presented next TMail weekly (03/10) ?

### Comment by Arsnael at 2022-09-27T04:20:16Z

Can't edit your comments but here would be an updated example:

## Quota/get

```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:ietf:params:jmap:quota"],
  "methodCalls": [[
    "Quota/get",
    {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "ids": null
    },
    "c1"]]
}
```
will return:
```
{
  "sessionState": "${SESSION_STATE.value}",
  "methodResponses": [[ "Quota/get", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "state": "78540",
      "list": [{
        "id": "2a06df0d-9865-4e74-a92f-74dcc814270e",
        "resourceType": "count",
        "used": 1056,
        "warnLimit": 1600,
        "softLimit": 1800,
        "limit": 2000,
        "scope": "account",
        "name": "bob@example.com",
        "description": "Personal account usage",
        "datatypes" : [ "Mail" ]
      }, {
        "id": "3b06df0e-3761-4s74-a92f-74dcc963501x",
        "resourceType": "octets",
        "used": 100000,
        "warnLimit": 64000,
        "softLimit": 128000,
        "limit": 256000,
        "scope": "domain",
        "name": "example.com",
        "description": "Domain example.com usage",
        "datatypes" : [ "Mail" ]
      }],
      "notFound": []
    }, "c1" ]]
}
```

## Quota/change

Request fetching the changes for a specific quota:

```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:ietf:params:jmap:quota"],
  "methodCalls": [["Quota/changes", {
                       "accountId": "u33084183",
                       "sinceState": "10824",
                       "maxChanges": 20
                     }, "0" ],
                     [ "Quota/get", {
                       "accountId": "u33084183",
                       "#ids": {
                         "resultOf": "0",
                         "name": "Quota/changes",
                         "path": "/updated"
                       },
                       "#properties": {
                         "resultOf": "0",
                         "name": "Quota/changes",
                         "path": "/updatedProperties"
                       }
                     }, "1" ]]
}
```
will return:
```
{
  "sessionState": "${SESSION_STATE.value}",
  "methodResponses": [[ "Quota/changes", {
            "accountId": "u33084183",
            "oldState": "10824",
            "newState": "10826",
            "hasMoreChanges": false,
            "created": [],
            "updated": ["2a06df0d-9865-4e74-a92f-74dcc814270e"],
            "destroyed": []
          }, "0" ],
          [ "Quota/get", {
            "accountId": "u33084183",
            "state": "10826",
            "list": [{
              "id": "2a06df0d-9865-4e74-a92f-74dcc814270e",
              "used": 1246
            }],
            "notFound": []
          }, "1" ]]
}
```

### Comment by hoangdat at 2022-09-28T04:32:33Z

<img width="677" alt="image" src="https://user-images.githubusercontent.com/6462404/192688017-4bd32857-8d6a-4665-8755-71fe02f104b0.png">

we should show the quota for `count` in UI, am I right?

### Comment by chibenwa at 2022-09-28T05:34:05Z

No `octets`.

### Comment by hoangdat at 2022-09-28T07:45:24Z

> No `octets`.

how to let users know when they reach the limit of `count`?

### Comment by chibenwa at 2022-09-28T09:48:52Z

> how to let users know when they reach the limit of count?

We won't set count limits on our products.

### Comment by hoangdat at 2022-09-28T09:50:07Z

@dieptran88 please note that

### Comment by ManhNTX at 2022-11-09T09:32:48Z

@chibenwa I checked on the environment `https://gateway.upn.integration-open-paas.org`. But it seems that the results are not quite right. The current quotas list in response is empty. Can you check it again?

### Comment by chibenwa at 2022-11-09T10:04:06Z

Correct because no limit is set (all unlimited)

Let me change this.

### Comment by chibenwa at 2022-11-09T10:13:45Z

I did set a 10GB quota by default. Can you re-check?

### Comment by ManhNTX at 2022-11-09T10:42:26Z

@chibenwa  It seems still not working. Can you re-check?
<img width="188" alt="Screen Shot 2022-11-09 at 17 42 10" src="https://user-images.githubusercontent.com/107173849/200809320-1d7761c4-46a2-4d6e-9480-6fe8fca88f2d.png">

### Comment by chibenwa at 2022-11-10T02:49:22Z

Please use `firstname21.surname21@upn.integration-open-paas.org`

This would work on this user.

### Comment by hoangdat at 2023-07-17T22:39:16Z

Hi @chibenwa @Arsnael , what `limit` we will use to show the warning alert for `storage`? How many level of alert we will use? `orange` for 90% (what limit), `red` for 100% (what limit)?

### Comment by chibenwa at 2023-07-18T01:17:06Z

> orange for 90% (what limit), red for 100% (what limit)?

Perfect!

### Comment by chibenwa at 2023-07-18T01:17:24Z

On storage limit.

### Comment by hoangdat at 2023-07-18T01:54:22Z

> Perfect!

I mean:
- 90% in what limit? `softLimit`? 
- 100% in what limit? `limit`?
- we will ignore `warnLimit`?

### Comment by Arsnael at 2023-07-24T07:14:14Z

> Hi @chibenwa @Arsnael , what `limit` we will use to show the warning alert for `storage`? How many level of alert we will use? `orange` for 90% (what limit), `red` for 100% (what limit)?

@hoangdat As i understand you dont seem to want to apply some partial restrictions. So I think:

- `orange` 90% -> `warnLimit`
- `red` 100% -> `hardLimit`

You can ignore the sofLimit IMO
