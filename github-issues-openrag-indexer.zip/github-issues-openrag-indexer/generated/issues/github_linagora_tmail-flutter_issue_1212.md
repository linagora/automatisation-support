# GitHub issue #1212: docker version - tmail web - access error

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1212
State: closed
Author: aioun
Created at: 2022-11-16T15:59:51Z
Updated at: 2023-02-07T14:32:12Z
Closed at: 2023-02-07T14:32:12Z
Labels: bug
Assignees: tk-nguyen
URL: https://github.com/linagora/tmail-flutter/issues/1212

## Issue body

### Description
Hello,
Using docker version of tmail-web:master , if you go http://localhost:8080 you will be redirected to http://localhost:8080/auth. Then you will got nginx error 404 not found.  If now you execute docker exec -it web /bin/bash ( to access the container) , there is no auth folder in  /usr/share/nginx/html/ 
Could you fix this please. 
### Expected result

### Current behavior

### Preconditions (optional)

#### Reproduction Steps

### Acceptance criteria

The list of acceptance criteria (defined in the corresponding User Story or coming from your functional knowledge of the product)
These acceptance criteria must be met by the corrective implementation done by the developers.

### Context

Devices, OS

### Additional information

frequency, log files,...

## Comments

### Comment by tk-nguyen at 2022-11-17T03:43:52Z

Can you add more information? How did you run the image?

### Comment by aioun at 2022-11-17T08:21:57Z

I followed the instruction at: https://hub.docker.com/r/linagora/tmail-web 
The env.file contains: SERVER_URL=https://my-jmap-server.com 
Knowing that tmail backend running at my localhost.
Best,

### Comment by tk-nguyen at 2022-11-17T09:36:02Z

That's weird. It should redirect to the login page, and not `/auth`. I cannot reproduce this on anything. Can you describe all the steps you did in more details?

### Comment by aioun at 2022-11-17T10:08:09Z

Renaming the server_url with localhost works.

### Comment by aioun at 2022-11-17T10:09:51Z

I still have some errors in the console:
[ERROR] AccountCacheManager::getSelectedAccount(): Bad state: No element
main.dart.js:71744 [ERROR] GetAuthenticatedAccountInteractor::execute(): Instance of 'NotFoundAuthenticatedAccountException'
main.dart.js:71744 [ERROR] HomeController::_handleFailureViewState(): NoAuthenticatedAccountFailure
main.dart.js:71744 OidcConfigurationCacheManager::deleteAuthorityOidc()
2main.dart.js:71744 HiveCacheConfig::getEncryptionKey(): encryptionKey: LIm2bgJXqI2uMivoyXuGlBq7aoFWHPSgN+HAjvGjPfY=

main.dart.js:71744 HomeController::_handleSuccessViewState(): CheckOIDCIsAvailableLoading
/.well-known/webfinger?resource=http://localhost&rel=http://openid.net/specs/connect/1.0/issuer:1          Failed to load resource: net::ERR_CONNECTION_REFUSED

main.dart.js:71744 AuthorizationInterceptors::onError(): DioError [DioErrorType.response]: XMLHttpRequest error.

main.dart.js:71744 [ERROR] HomeController::_handleFailureViewState(): CheckOIDCIsAvailableFailure
/.well-known/webfinger?resource=http://localhost&rel=http://openid.net/specs/connect/1.0/issuer:1          Failed to load resource: net::ERR_CONNECTION_REFUSED

main.dart.js:71744 AuthorizationInterceptors::onError(): DioError [DioErrorType.response]: XMLHttpRequest error.

### Comment by tk-nguyen at 2022-11-17T11:13:59Z

You need to expose port 80 of `tmail-backend` container and (for testing only) disable CORS on your browser. Also you need to provision some users on `tmail-backend`, see here: https://github.com/linagora/tmail-backend/blob/master/tmail-backend/apps/memory/README.md#provisioning

### Comment by aioun at 2022-11-17T13:42:28Z

Done, but still some errors bellow. Thanks
![image](https://user-images.githubusercontent.com/42891685/202461825-4054073a-f7ec-490f-96e7-44acece23773.png)

### Comment by hoangdat at 2022-11-17T13:52:15Z

> I still have some errors in the console:
> 
> [ERROR] AccountCacheManager::getSelectedAccount(): Bad state: No element
> 
> main.dart.js:71744 [ERROR] GetAuthenticatedAccountInteractor::execute(): Instance of 'NotFoundAuthenticatedAccountException'
> 
> main.dart.js:71744 [ERROR] HomeController::_handleFailureViewState(): NoAuthenticatedAccountFailure
> 
> main.dart.js:71744 OidcConfigurationCacheManager::deleteAuthorityOidc()
> 
> 2main.dart.js:71744 HiveCacheConfig::getEncryptionKey(): encryptionKey: LIm2bgJXqI2uMivoyXuGlBq7aoFWHPSgN+HAjvGjPfY=
> 
> 
> 
> main.dart.js:71744 HomeController::_handleSuccessViewState(): CheckOIDCIsAvailableLoading
> 
> /.well-known/webfinger?resource=http://localhost&rel=http://openid.net/specs/connect/1.0/issuer:1          Failed to load resource: net::ERR_CONNECTION_REFUSED
> 
> 
> 
> main.dart.js:71744 AuthorizationInterceptors::onError(): DioError [DioErrorType.response]: XMLHttpRequest error.
> 
> 
> 
> main.dart.js:71744 [ERROR] HomeController::_handleFailureViewState(): CheckOIDCIsAvailableFailure
> 
> /.well-known/webfinger?resource=http://localhost&rel=http://openid.net/specs/connect/1.0/issuer:1          Failed to load resource: net::ERR_CONNECTION_REFUSED
> 
> 
> 
> main.dart.js:71744 AuthorizationInterceptors::onError(): DioError [DioErrorType.response]: XMLHttpRequest error.

No problem with this error, if we can not find OIDC configuration, we support login with basic auth

### Comment by aioun at 2022-11-17T13:58:31Z

Thanks a lot. I tried to send an email from alice@localhost account to bob@localhost,  but it is not working. In fact if I add bob@localhost.com the email is accepted but it is not retrieved in bob inbox. 
Thank you for your help.

### Comment by hoangdat at 2022-11-17T22:53:48Z

What did you find in the console?

### Comment by aioun at 2022-11-18T09:57:18Z

I created the domain my-jmap-server.com and I can access Tmail Web. The messages are sent but I con't find them in box (sent, in). Here is the trace.

09:52:28.372 [INFO ] o.a.j.m.s.StoreMailboxManager - #private:alice@my-jmap-server.com:tmail mailbox was created concurrently
09:52:28.436 [INFO ] o.a.j.m.s.StoreMailboxManager - #private:bob@my-jmap-server.com:tmail mailbox was created concurrently
09:52:29.158 [INFO ] o.a.j.m.s.StoreMailboxManager - #private:alice@my-jmap-server.com:tmail mailbox was created concurrently
09:52:29.159 [INFO ] o.a.j.m.s.StoreMailboxManager - #private:alice@my-jmap-server.com:tmail.backend mailbox was created concurrently
09:52:29.223 [INFO ] o.a.j.m.s.StoreMailboxManager - #private:bob@my-jmap-server.com:tmail mailbox was created concurrently
09:52:29.223 [INFO ] o.a.j.m.s.StoreMailboxManager - #private:bob@my-jmap-server.com:tmail.backend mailbox was created concurrently
09:53:16.721 [INFO ] o.a.j.m.s.StoreMailboxManager - Mailbox '6 #private:alice@my-jmap-server.com:tmail' does not belong to user 'Username{localPart=bob, domainPart=Optional[Domain : my-jmap-server.com]}' but to 'Username{localPart=alice, domainPart=Optional[Domain : my-jmap-server.com]}'
09:53:16.932 [INFO ] o.a.j.m.s.StoreMailboxManager - Mailbox '6 #private:alice@my-jmap-server.com:tmail' does not belong to user 'Username{localPart=bob, domainPart=Optional[Domain : my-jmap-server.com]}' but to 'Username{localPart=alice, domainPart=Optional[Domain : my-jmap-server.com]}'
09:53:22.052 [INFO ] o.a.j.m.s.StoreMailboxManager - Mailbox '18 #private:alice@my-jmap-server.com:Outbox' does not belong to user 'Username{localPart=bob, domainPart=Optional[Domain : my-jmap-server.com]}' but to 'Username{localPart=alice, domainPart=Optional[Domain : my-jmap-server.com]}'
09:53:24.282 [INFO ] o.a.j.m.s.StoreMailboxManager - Mailbox '19 #private:alice@my-jmap-server.com:Sent' does not belong to user 'Username{localPart=bob, domainPart=Optional[Domain : my-jmap-server.com]}' but to 'Username{localPart=alice, domainPart=Optional[Domain : my-jmap-server.com]}'
09:53:25.383 [INFO ] o.a.j.m.s.StoreMailboxManager - Mailbox '24 #private:alice@my-jmap-server.com:Trash' does not belong to user 'Username{localPart=bob, domainPart=Optional[Domain : my-jmap-server.com]}' but to 'Username{localPart=alice, domainPart=Optional[Domain : my-jmap-server.com]}'
09:53:58.844 [INFO ] o.a.j.m.s.StoreMailboxManager - Mailbox '18 #private:alice@my-jmap-server.com:Outbox' does not belong to user 'Username{localPart=bob, domainPart=Optional[Domain : my-jmap-server.com]}' but to 'Username{localPart=alice, domainPart=Optional[Domain : my-jmap-server.com]}'
09:54:49.037 [INFO ] o.a.j.t.m.j.d.SieveExecutor - Can not locate SIEVE script for user <bob@my-jmap-server.com>
09:54:49.075 [INFO ] o.a.j.t.m.d.SimpleMailStore - Local delivered mail f36a2c2a-7265-424b-9007-8c9b5e69c348 with messageId <Mime4j.2.af8e86222ebd5afe.1848a2989cc@my-jmap-server.com> successfully from alice@my-jmap-server.com to <bob@my-jmap-server.com> in folder INBOX with composedMessageId ComposedMessageId{mailboxId=1, messageId=InMemoryMessageId{value=82}, uid=MessageUid{uid=5}}

### Comment by hoangdat at 2022-11-18T14:35:23Z

@chibenwa can you help him on this trace? Thanks

### Comment by chibenwa at 2022-11-18T15:16:07Z

The email is in bob@my-jmap-server.com INBOX.

Please be reminded this is in-memory: a restart resets the data.

### Comment by aioun at 2022-11-21T08:40:14Z

OK, let me explain more, 
1) I login with alice@my-jmap-server.com
2) I write an email for bob@my-jmap-server.com, the email is sent 
3) I logout
4) I login with bob@my-jmap-server.com
5) the INBOX shows Inbox(1), but I can't read the email

When I comeback to alice, I also can't see the sent email.
There is no restart of the dockers here, James and Web
Hope it is clear now!
