# GitHub issue #339: Empty  entries in email list view

## Metadata

Repository: linagora/tmail-flutter
Issue number: 339
State: closed
Author: chibenwa
Created at: 2022-03-14T02:56:22Z
Updated at: 2022-05-26T09:16:19Z
Closed at: 2022-05-26T09:16:18Z
Labels: bug, Critical
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/339

## Issue body

### Description


https://user-images.githubusercontent.com/6928740/158096991-f1555845-82f3-45f2-aee8-d3650b2f2702.mp4

Happens regulary to me. Switching mailboxes, setting filters, scrolling and I sometime gets this.

## Comments

### Comment by Arsnael at 2022-03-15T03:31:37Z

Noticed as well on ios version:
![signal-2022-03-15-102920](https://user-images.githubusercontent.com/9005025/158300669-0698a60f-e9aa-4ea3-bd10-881f40ac68d3.jpeg)

### Comment by hoangdat at 2022-03-16T07:30:55Z

Hi @chibenwa, i found you not use the latest version for this issue, can you show me your currently `commitId`

### Comment by chibenwa at 2022-03-16T07:33:56Z

No idea how to get that from the docker container. Deployed it on friday 11/03. 

Now `tmail.linagora.*` is updated nightly.

I will see if this still happens.

### Comment by chibenwa at 2022-03-16T07:35:29Z

![Screenshot from 2022-03-16 14-34-56](https://user-images.githubusercontent.com/6928740/158539393-2e3c282c-ca57-43d2-827b-c0feb8e80cbe.png)

### Comment by hoangdat at 2022-03-16T07:46:59Z

@chibenwa how to reproduce it

### Comment by chibenwa at 2022-03-16T07:48:52Z

I don't know I'm not doing anything special.

Note: ctrl + f5 don't drop the cache, I only see Mailbox/changes , Email/changes being issued so I can't go back in history and provide you JMAP requests.

### Comment by Arsnael at 2022-03-16T07:53:03Z

@hoangdat Happens randomly to me as well... I was just checking on different mailboxes a few times before seeing this sometimes

### Comment by hoangdat at 2022-03-16T09:18:41Z

> Note: ctrl + f5 don't drop the cache, I only see Mailbox/changes , Email/changes being issued so I can't go back in history and provide you JMAP requests.

for the debug, all the log are dumped to console, if you have more information, please share to me

### Comment by lecaotunglam at 2022-04-07T07:37:52Z

Failed on CI platform. I found two emails having this issue:
![image](https://user-images.githubusercontent.com/32490981/162145631-e5a3b0fe-8a18-4ac7-9d39-cb67b5576040.png)

Email content: 
![image](https://user-images.githubusercontent.com/32490981/162145692-ab4bfd51-5605-4eac-8a19-de0103c33b22.png)
![image](https://user-images.githubusercontent.com/32490981/162145784-4092799f-d4f2-4a3e-8fa6-a46a89fb13a2.png)

### Comment by hoangdat at 2022-04-07T07:59:17Z

@Kevinle2312 please share us the way and the platform you reproduce that?

### Comment by lecaotunglam at 2022-04-08T03:20:43Z

> @Kevinle2312 please share us the way and the platform you reproduce that?
I tested it on: https://tmail.upn.integration-open-paas.org/
 This is an email injected into my test account mailbox for testing purposes. 
 For reproducing steps: 
1. I sign to the mailbox
2. I go to the inbox 
3. The empty entries in the email list view are there.

### Comment by chibenwa at 2022-04-08T04:56:17Z

![Screenshot from 2022-04-08 11-56-00](https://user-images.githubusercontent.com/6928740/162367551-4523855d-6690-4e54-9d1d-4c4bd5734035.png)

I just did a ctrl+ f5 to ensure lasst version is loaded, I'll raise a voice here if it happens again...

### Comment by hoangdat at 2022-04-08T08:02:13Z

> > @Kevinle2312 please share us the way and the platform you reproduce that?
> > I tested it on: https://tmail.upn.integration-open-paas.org/
> > This is an email injected into my test account mailbox for testing purposes.
> > For reproducing steps:
> 
> 1. I sign to the mailbox
> 2. I go to the inbox
> 3. The empty entries in the email list view are there.

it is `always` or `sometimes`. if `always`, please share me your credentials

### Comment by lecaotunglam at 2022-04-08T08:17:48Z

> > > @Kevinle2312 please share us the way and the platform you reproduce that?
> > > I tested it on: https://tmail.upn.integration-open-paas.org/
> > > This is an email injected into my test account mailbox for testing purposes.
> > > For reproducing steps:
> > 
> > 
> > 
> > 1. I sign to the mailbox
> > 2. I go to the inbox
> > 3. The empty entries in the email list view are there.
> 
> it is `always` or `sometimes`. if `always`, please share me your credentials

It is `always` there.
My email: firstname200.surname200@upn.integration-open-paas.org
pass: secret200

### Comment by hoangdat at 2022-04-08T09:20:07Z

hmm, can not reproduce

### Comment by lecaotunglam at 2022-04-08T09:37:45Z

> hmm, can not reproduce

Please scroll down to the very bottom:
![image](https://user-images.githubusercontent.com/32490981/162409468-5651685b-dba8-4ddb-9798-231d59243a03.png)

### Comment by dab246 at 2022-04-12T04:52:01Z

Currently, I can't reproduce this error.

### Comment by Arsnael at 2022-04-13T04:08:01Z

I got it just now on chromium on tmail.linagora.com:

![screenshot-tmail linagora com-2022 04 13-11_06_31](https://user-images.githubusercontent.com/9005025/163098262-4d68193a-56f1-4d65-8f55-395d70b80776.png)

And same on FF as well

### Comment by lecaotunglam at 2022-04-14T01:09:10Z

> Currently, I can't reproduce this error.

On tmail.linagora.com, the most likely email having this issue is the one from `Gitlab`. On the Pre-production platform, I am not sure since the data is injected into the mailbox.

### Comment by hoangdat at 2022-04-14T01:37:09Z

yesterday, I have the same issue, I am investigating on the cache. I will update the information soon

### Comment by hoangdat at 2022-04-27T06:08:59Z

Root cause: updated item (missing metadata) is inserted to cache when cache not hit

Reproduce: 
1. Open Inbox in `tmail app 1` (mobile/tablet/browser)
2. in `tmail app 1`, Go to other mailbox
3. Open inbox in `tmail app 2` (mobile/tablet/browser)
4. In `tmail app 2`, in Inbox, scroll to load more some emails
5. In `tmail app 2`, in Inbox, after scroll, select an email, mark as unread/read/star or un-star
6. In `tmail app 1`, Go to Inbox then scroll -> will see the item with empty information in the list.

### Comment by chibenwa at 2022-04-28T03:13:26Z

I'm sorry not to think about this as a possibility, it's that stupid and quitte simple!

Good job ;-)

### Comment by lecaotunglam at 2022-05-26T09:16:18Z

I have tested this issue by following @hoangdat guide. I confirm that this issue no longer happens on the pro-production platform.
