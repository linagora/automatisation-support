# GitHub issue #3717: Unable to access settings in Tmail web

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3717
State: closed
Author: dougmeredith
Created at: 2025-05-11T16:24:54Z
Updated at: 2025-08-28T10:30:00Z
Closed at: 2025-06-20T02:24:20Z
Labels: bug
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/3717

## Issue body

### Description

I can see a round circle in the top right corner, which I'm guessing is supposed to be a user avatar. When I hover over it, the mouse pointer changes, as if I should be able to click on it. Clicking has no effect.

### Expected result

I'm guessing this is intended to get me into the settings.

### Context

Version 0.15.3 using Docker.

Browser it the current Chrome, on Linux.

## Comments

### Comment by hoangdat at 2025-05-12T03:15:51Z

Hi, 

Thanks for your reporting.
But it still works in our side

<img width="364" alt="Image" src="https://github.com/user-attachments/assets/d1bd0072-ff63-4f7d-a794-ec90ec93a8bd" />

Can you open devTools/console of browser, then send us anymore relate information?

### Comment by dougmeredith at 2025-05-12T11:51:33Z

Thanks for the quick reply!

Firstly I should note that the problem also occurs for me using Firefox. Secondly, the top right corner of my browser tab doesn't look like yours:

![Image](https://github.com/user-attachments/assets/b0dd0478-4a74-4256-b561-2d511f0d378c)

This is from the Chrome console when I click:

```
main.dart.js:58775 Instance of 'minified:aQE'
main.dart.js:58775 at Object.k (https://tmail.test.dstrc.org/main.dart.js:3619:19)
main.dart.js:58775     at Object.ad (https://tmail.test.dstrc.org/main.dart.js:3628:15)
main.dart.js:58775     at Object.lp (https://tmail.test.dstrc.org/main.dart.js:42423:16)
main.dart.js:58775     at rA.ab0 (https://tmail.test.dstrc.org/main.dart.js:202982:18)
main.dart.js:58775     at bSM.$1 (https://tmail.test.dstrc.org/main.dart.js_5.part.js:7960:38)
main.dart.js:58775     at bgF.$1 (https://tmail.test.dstrc.org/main.dart.js:80063:14)
main.dart.js:58775     at akf.bE0 (https://tmail.test.dstrc.org/main.dart.js:97724:14)
main.dart.js:58775     at tear_off.<anonymous> (https://tmail.test.dstrc.org/main.dart.js:3755:65)
main.dart.js:58775     at cjs.$0 (https://tmail.test.dstrc.org/main.dart.js:91859:22)
main.dart.js:58775     at mD.aC6 (https://tmail.test.dstrc.org/main.dart.js:91416:9)
```

### Comment by dougmeredith at 2025-05-12T12:05:54Z

This isn't my area of expertise, so I don't know if these things are relevant, but I'll mention them in case:

I'm using Stalwart, and in order to get past CORS issues, I had to add this to the Stalwart config:

```
  [server.http]
  headers = [
      "Access-Control-Allow-Origin: https://tmail.test.dstrc.org",
      "Access-Control-Allow-Methods: GET, POST, OPTIONS",
      "Access-Control-Allow-Headers: Authorization, Content-Type"
  ]
```

Twake Mail is behind Traefik.

### Comment by dougmeredith at 2025-05-12T18:55:01Z

For anyone else suffering from this problem, you can access the settings at mail.example.com/settings

### Comment by dab246 at 2025-05-19T07:22:28Z

> Thanks for the quick reply!
> 
> Firstly I should note that the problem also occurs for me using Firefox. Secondly, the top right corner of my browser tab doesn't look like yours:
> 
> ![Image](https://github.com/user-attachments/assets/b0dd0478-4a74-4256-b561-2d511f0d378c)
> 

According to the image you provided, I guess the application is not finding the user's `Email address` in the session. So now there is only a white circle. If possible, please provide us with more details of the `session` from `.../.well-known/jmap` so we can analyze it further. @dougmeredith

### Comment by dougmeredith at 2025-05-21T16:32:19Z

Your comment about "the application is not finding the user's Email address in the session" made me curious and I did some testing...

It appears that if account names are email addresses, then the settings are accessible. If account names are not email addresses (as is my case), then this does not work.

### Comment by dab246 at 2025-05-22T06:50:10Z

> Your comment about "the application is not finding the user's Email address in the session" made me curious and I did some testing...
> 
> It appears that if account names are email addresses, then the settings are accessible. If account names are not email addresses (as is my case), then this does not work.

Probably so, but don't worry, we've fixed it to better support it. We can't merge it on the main branch for now, so you can use the `customer-stalwart/tf-3484-stallwart-interoperability` branch to solve your problem. @dougmeredith

### Comment by hoangdat at 2025-06-20T02:24:20Z

hi @dougmeredith , please verify your problem in v0.16.0.

### Comment by dougmeredith at 2025-06-20T11:42:48Z

> hi [@dougmeredith](https://github.com/dougmeredith) , please verify your problem in v0.16.0.

Sorry, I'm no longer using Twake Mail.

### Comment by Gictorbit at 2025-06-29T06:48:17Z

Hi there,
I'm using Stalwart along with Twake Mail, and everything works great—thank you for the amazing work!

However, I noticed that the user avatar isn't being displayed. It's currently just a blank or white placeholder, even when the user hasn't set a profile photo. Ideally, there should be a default avatar shown in such cases to avoid the empty appearance.

docker image: `linagora/tmail-web:latest`

Thanks again for the great project!
![Image](https://github.com/user-attachments/assets/61cd67b1-8fa2-498b-9b1a-f25e19cb6cee)

### Comment by dab246 at 2025-06-30T05:21:23Z

> Hi there, I'm using Stalwart along with Twake Mail, and everything works great—thank you for the amazing work!
> 
> However, I noticed that the user avatar isn't being displayed. It's currently just a blank or white placeholder, even when the user hasn't set a profile photo. Ideally, there should be a default avatar shown in such cases to avoid the empty appearance.
> 
> docker image: `linagora/tmail-web:latest`
>

Hi @Gictorbit, we are using the first character of `ownEmailAddress` in `Session` to display the avatar. I think it is possible that your `ownEmailAddress` in Session is null which results in the avatar not being displayed. If possible, can you check again or provide us the Session information for further investigation.

<img width="522" alt="Image" src="https://github.com/user-attachments/assets/a96ac7c1-c9bd-4081-bdcf-acbf43f77f82" />

### Comment by Gictorbit at 2025-07-01T05:59:16Z

> > Hi there, I'm using Stalwart along with Twake Mail, and everything works great—thank you for the amazing work!
> > However, I noticed that the user avatar isn't being displayed. It's currently just a blank or white placeholder, even when the user hasn't set a profile photo. Ideally, there should be a default avatar shown in such cases to avoid the empty appearance.
> > docker image: `linagora/tmail-web:latest`
> 
> Hi [@Gictorbit](https://github.com/Gictorbit), we are using the first character of `ownEmailAddress` in `Session` to display the avatar. I think it is possible that your `ownEmailAddress` in Session is null which results in the avatar not being displayed. If possible, can you check again or provide us the Session information for further investigation.
> 
> <img alt="Image" width="522" src="https://private-user-images.githubusercontent.com/80730648/460419242-a96ac7c1-c9bd-4081-bdcf-acbf43f77f82.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NTEzNDk1MzMsIm5iZiI6MTc1MTM0OTIzMywicGF0aCI6Ii84MDczMDY0OC80NjA0MTkyNDItYTk2YWM3YzEtYzliZC00MDgxLWJkY2YtYWNiZjQzZjc3ZjgyLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNTA3MDElMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjUwNzAxVDA1NTM1M1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWFlMmNkZjM4NDc0MjBkNjYxOTRmNDhmMmM2N2ZkOTVmZDc3OGU5ZjZiZGM1MzIyYmNmZTc1YTY0Zjk1ZmU5ODMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.yPYOaKWoQBFpq8mGBdqOmb8rJQQxxS_iAy9HIcV1HO8">

Hi @dab246 , thanks for the update!

That makes sense. Could you please let me know where I can check the Session data to verify the `ownEmailAddress` value? I'm happy to look into it and share the details if needed.

Just to clarify, I'm using `Stalwart` as my mail server with the `JMAP` protocol, and in our setup, we use the username (not the email address) to log in to TMail. This might be related to why `ownEmailAddress` is null in the Session.

Let me know the best way to access that info—whether it's from local storage, a specific API response, or a debug panel.

Thanks!

### Comment by hoangdat at 2025-07-01T08:16:15Z

hi @Gictorbit ,

please refresh your tmail web app, and check the very first jmap request in dev tools like this, you can see the response of session. Please scan it or share it with us for more detail. 

Thanks

<img width="518" alt="Image" src="https://github.com/user-attachments/assets/cd8c2584-d79a-4532-b40f-820fda357201" />

### Comment by Gictorbit at 2025-07-03T17:01:58Z

Hi, I refreshed the TMail web app as suggested, but I don't see any request named session in the DevTools network tab. I checked both the very first JMAP request and the rest, but none of them seem to be labeled session. Could you clarify where exactly I should be seeing it or if it might have a different name?

![Image](https://github.com/user-attachments/assets/8253cb66-2f4e-46a0-a626-499bc029c764)

here is my `env.file` content:
```env
SERVER_URL: "https://mail.*****.com/"
DOMAIN_REDIRECT_URL: "https://webmail.*****.com/"
WEB_OIDC_CLIENT_ID: "teammail-web"
OIDC_SCOPES: "openid,profile,email,offline_access"
APP_GRID_AVAILABLE: "supported"
FCM_AVAILABLE: "supported"
IOS_FCM: "supported"
FORWARD_WARNING_MESSAGE: ""
PLATFORM: "other"
WS_ECHO_PING: ""
```

### Comment by Bananas-Are-Yellow at 2025-07-04T15:28:21Z

I'm using Stalwart with Twake too.

When I refresh the browser, I can see the `/jmap/session` request in DevTools. Here is the response from Stalwart.

```json
{
    "capabilities": {
        "urn:ietf:params:jmap:core": {
            "maxSizeUpload": 50000000,
            "maxConcurrentUpload": 4,
            "maxSizeRequest": 10000000,
            "maxConcurrentRequests": 4,
            "maxCallsInRequest": 16,
            "maxObjectsInGet": 500,
            "maxObjectsInSet": 500,
            "collationAlgorithms": [
                "i;ascii-numeric",
                "i;ascii-casemap",
                "i;unicode-casemap"
            ]
        },
        "urn:ietf:params:jmap:mail": {},
        "urn:ietf:params:jmap:submission": {},
        "urn:ietf:params:jmap:vacationresponse": {},
        "urn:ietf:params:jmap:sieve": {
            "implementation": "Stalwart v1.0.0"
        },
        "urn:ietf:params:jmap:blob": {},
        "urn:ietf:params:jmap:quota": {},
        "urn:ietf:params:jmap:websocket": {
            "url": "wss://mail.example.com/jmap/ws",
            "supportsPush": true
        }
    },
    "accounts": {
        "c": {
            "name": "David Taylor",
            "isPersonal": true,
            "isReadOnly": false,
            "accountCapabilities": {
                "urn:ietf:params:jmap:mail": {
                    "maxMailboxesPerEmail": null,
                    "maxMailboxDepth": 10,
                    "maxSizeMailboxName": 255,
                    "maxSizeAttachmentsPerEmail": 50000000,
                    "emailQuerySortOptions": [
                        "receivedAt",
                        "size",
                        "from",
                        "to",
                        "subject",
                        "sentAt",
                        "hasKeyword",
                        "allInThreadHaveKeyword",
                        "someInThreadHaveKeyword"
                    ],
                    "mayCreateTopLevelMailbox": true
                },
                "urn:ietf:params:jmap:submission": {
                    "maxDelayedSend": 2592000,
                    "submissionExtensions": {
                        "FUTURERELEASE": [],
                        "SIZE": [],
                        "DSN": [],
                        "DELIVERYBY": [],
                        "MT-PRIORITY": [
                            "MIXER"
                        ],
                        "REQUIRETLS": []
                    }
                },
                "urn:ietf:params:jmap:vacationresponse": {},
                "urn:ietf:params:jmap:sieve": {
                    "maxSizeScriptName": 512,
                    "maxSizeScript": 1048576,
                    "maxNumberScripts": 256,
                    "maxNumberRedirects": 1,
                    "sieveExtensions": [
                        "body",
                        "comparator-elbonia",
                        "comparator-i;ascii-casemap",
                        "comparator-i;ascii-numeric",
                        "comparator-i;octet",
                        "convert",
                        "copy",
                        "date",
                        "duplicate",
                        "editheader",
                        "enclose",
                        "encoded-character",
                        "enotify",
                        "envelope",
                        "envelope-deliverby",
                        "envelope-dsn",
                        "environment",
                        "ereject",
                        "extlists",
                        "extracttext",
                        "fcc",
                        "fileinto",
                        "foreverypart",
                        "ihave",
                        "imap4flags",
                        "imapsieve",
                        "include",
                        "index",
                        "mailbox",
                        "mailboxid",
                        "mboxmetadata",
                        "mime",
                        "redirect-deliverby",
                        "redirect-dsn",
                        "regex",
                        "reject",
                        "relational",
                        "replace",
                        "servermetadata",
                        "spamtest",
                        "spamtestplus",
                        "special-use",
                        "subaddress",
                        "vacation",
                        "vacation-seconds",
                        "variables",
                        "virustest"
                    ],
                    "notificationMethods": [
                        "mailto"
                    ],
                    "externalLists": null
                },
                "urn:ietf:params:jmap:blob": {
                    "maxSizeBlobSet": 7499488,
                    "maxDataSources": 16,
                    "supportedTypeNames": [
                        "Email",
                        "Thread",
                        "SieveScript"
                    ],
                    "supportedDigestAlgorithms": [
                        "sha",
                        "sha-256",
                        "sha-512"
                    ]
                },
                "urn:ietf:params:jmap:quota": {}
            }
        }
    },
    "primaryAccounts": {
        "urn:ietf:params:jmap:core": "c",
        "urn:ietf:params:jmap:mail": "c",
        "urn:ietf:params:jmap:submission": "c",
        "urn:ietf:params:jmap:vacationresponse": "c",
        "urn:ietf:params:jmap:sieve": "c",
        "urn:ietf:params:jmap:blob": "c",
        "urn:ietf:params:jmap:quota": "c",
        "urn:ietf:params:jmap:websocket": "c"
    },
    "username": "david",
    "apiUrl": "https://mail.example.com/jmap/",
    "downloadUrl": "https://mail.example.com/jmap/download/{accountId}/{blobId}/{name}?accept={type}",
    "uploadUrl": "https://mail.example.com/jmap/upload/{accountId}/",
    "eventSourceUrl": "https://mail.example.com/jmap/eventsource/?types={types}&closeafter={closeafter}&ping={ping}",
    "state": "3e25b2a0"
}
```
There is no mention of `ownEmailAddress` anywhere.

Later, there is JMAP request for `Identity/get`. Here is the response:
```json
{
    "methodResponses": [
        [
            "Identity/get",
            {
                "accountId": "c",
                "state": "se2",
                "list": [
                    {
                        "id": "b",
                        "name": "David Taylor",
                        "email": "david@example.com",
                        "replyTo": null,
                        "bcc": null,
                        "textSignature": "",
                        "htmlSignature": "",
                        "mayDelete": true
                    }
                ],
                "notFound": []
            },
            "c0"
        ]
    ],
    "sessionState": "3e25b2a0"
}
```
Again, no mention of `ownEmailAddress`.

Why not use the first letter of "name" ('D' in my case), which is available from either of these responses?

### Comment by Gictorbit at 2025-07-06T13:30:56Z

I see your response at `/.well-known/jmap` instead of `/jmap/session`

### Comment by Bananas-Are-Yellow at 2025-07-06T17:19:43Z

`/.well-known/jmap` should redirect to `/jmap/session`. Try entering it in your browser.

### Comment by Gictorbit at 2025-07-07T05:46:36Z

> `/.well-known/jmap` should redirect to `/jmap/session`. Try entering it in your browser.

I did it many times before nothing happened, what is your stalwart version? I'm using `stalwartlabs/stalwart:v0.12.4` docker image

### Comment by Bananas-Are-Yellow at 2025-07-07T07:51:26Z

> > `/.well-known/jmap` should redirect to `/jmap/session`. Try entering it in your browser.
> 
> I did it many times before nothing happened, what is your stalwart version? I'm using `stalwartlabs/stalwart:v0.12.4` docker image

I'm using v0.12.5, which is the latest currently.

### Comment by Gictorbit at 2025-07-07T10:31:59Z

> > > `/.well-known/jmap` should redirect to `/jmap/session`. Try entering it in your browser.
> > 
> > 
> > I did it many times before nothing happened, what is your stalwart version? I'm using `stalwartlabs/stalwart:v0.12.4` docker image
> 
> I'm using v0.12.5, which is the latest currently.

Thanks for the quick reply! I've now updated to the latest version `v0.12.5` as well, but I'm still experiencing the same issue. I'm using Stalwart with OAuth to handle user logins, so perhaps there's a setting or configuration I'm missing related to that. Any pointers would be appreciated!

### Comment by Bananas-Are-Yellow at 2025-07-07T10:47:10Z

The avatar is blank for me too. It looks like they are using the first character of a field that Stalwart does not return.

### Comment by dab246 at 2025-07-08T05:57:27Z

Hi @Gictorbit, @Bananas-Are-Yellow 

This issue is closed as completed. Please discuss the `blank user avatar` issue in this issue: https://github.com/linagora/tmail-flutter/issues/3847

### Comment by europacafe at 2025-08-28T10:30:00Z

> This isn't my area of expertise, so I don't know if these things are relevant, but I'll mention them in case:
> 
> I'm using Stalwart, and in order to get past CORS issues, I had to add this to the Stalwart config:
> 
> ```
>   [server.http]
>   headers = [
>       "Access-Control-Allow-Origin: https://tmail.test.dstrc.org",
>       "Access-Control-Allow-Methods: GET, POST, OPTIONS",
>       "Access-Control-Allow-Headers: Authorization, Content-Type"
>   ]
> ```
> 
> Twake Mail is behind Traefik.

Thanks for the tip. Where in the Stalwart admin page to put this setting?
