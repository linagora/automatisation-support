# GitHub issue #1311: [Dev] Hide `Team-Mailboxes` in mailbox menu

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1311
State: closed
Author: ManhNTX
Created at: 2022-12-14T03:33:09Z
Updated at: 2023-02-15T10:20:12Z
Closed at: 2023-02-15T10:20:12Z
Labels: 
Assignees: nqhhdev
URL: https://github.com/linagora/tmail-flutter/issues/1311

## Issue body

### Story:

#1105

### DoD:

- Support option `Hide` for `Team-Mailboxes` in each mailbox menu item as new design.
  - [ ] Add context menu for Web
  - [ ] Action for Tablet and mobile

### Desc:

1. Display UI

  - If `isSubscribed=true`: Support option `Hide mailbox`

![Screenshot 2022-12-19 at 14.39.18.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/72f942cb-9bcc-44cd-bcad-7dfc499c7aec)

2. Implement api

- Create function handle show/hide team mailboxes in `repository/datasource`

```dart
enum MailboxSubscribeState {
  enable,
  disable
}

class SubscribeMailboxRequest with Equatable {

  final MailboxId mailboxId;
  final MailboxSubscribeState newState;

  SubscribeMailboxRequest(this.mailboxId, this.newState);
}

Future<bool> subscribeMailbox(AccountId accountId, SubscribeMailboxRequest request);
```

- Implement `SetMailboxMethod` in `MailboxApi` to update property `isSubscribed`
    - `isSubscribed=false` to hide mailbox

### Related

- New design on Figma: https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=8085%3A334825&t=f2LV1DrjxQB6ws9s-0

## Comments

### Comment by ManhNTX at 2022-12-14T06:34:36Z

@hoangdat

### Comment by hoangdat at 2022-12-14T08:30:27Z

- story?
- DoD?
- How to implement it? Repositories? API?

### Comment by hoangdat at 2022-12-15T22:40:00Z

What problem if we unsubscribe a mailbox inside team mailbox?

### Comment by hoangdat at 2022-12-19T22:12:25Z

> Implement SetMailboxMethod in MailboxApi to update property isSubscribed
isSubscribed=false to hide mailbox

How about if we add new API for hide/show mailbox?

### Comment by hoangdat at 2022-12-19T22:13:59Z

Moreover, we can not support `Show mailbox` in the case of MailboxView

### Comment by hoangdat at 2022-12-19T22:14:23Z

How about Hide/show personal mailbox?

### Comment by dab246 at 2022-12-20T03:05:35Z

> How about if we add new API for hide/show mailbox?

The process of handling it is similar to the case `RenameMailbox`

### Comment by dab246 at 2022-12-20T03:07:02Z

> Moreover, we can not support Show mailbox in the case of MailboxView

Ok. I reused it. On Mailbox menu only supports `Hide`, in search we support both.

### Comment by hoangdat at 2022-12-21T04:07:39Z

Hey team! Please [add your planning poker estimate](https://app.zenhub.com/workspaces/Tmail-Flutter-60d039db6ef62a0013432c14/issues/linagora/tmail-flutter/1311?planning-poker) with Zenhub @dab246 @ManhNTX
