# GitHub issue #1232: [Feedback] Can not copy/paste to mentioned fields in ticket with mobile application

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1232
State: closed
Author: hoangdat
Created at: 2022-11-22T09:48:11Z
Updated at: 2023-06-05T02:20:51Z
Closed at: 2023-06-05T02:20:51Z
Labels: bug, Major
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/1232

## Issue body

OS:
Android 10 QP1 A.190711.020
IOS 16.1.1

Precondition: Bug only happen with fields mentioned in step 2 bellow

Reproduce step:
1, User copy a text content in email body
2, User tap on one of these field (Subject, To, CC, BCC)
3, User tap and hold until copy paste option is displayed

Actual: System didn't display copy paste option which let user select to paste
Expected: User can copy and paste on fields which mentioned in step 2

https://user-images.githubusercontent.com/124866146/223012443-d892b986-5a75-40e7-8ff2-7f0a1120a7e2.mp4

## Comments

### Comment by hoangdat at 2022-11-24T08:05:59Z

can not reproduce in both Android and iOS v0.4.3

### Comment by hoangdat at 2023-03-06T03:12:02Z

@QuangHoang1210 please help us verify

### Comment by QuangHoang1210 at 2023-03-06T03:19:34Z

https://user-images.githubusercontent.com/124866146/223012443-d892b986-5a75-40e7-8ff2-7f0a1120a7e2.mp4

Precondition: Bug only happen with fields mentioned in step 2 bellow

Reproduce step:
1, User copy a text content email body
2, User tap on one of these field (Subject, To, CC, BCC)
3, User tap and hold until copy paste option is displayed

Actual: System didn't display copy paste option which let user select to paste
Expected: User can copy and paste on fields which mentioned in step 2

### Comment by dab246 at 2023-03-06T11:50:40Z

It works well. Please check again. @QuangHoang1210 



https://user-images.githubusercontent.com/80730648/223102189-437cf3b3-30ad-4b17-b03e-1df2109bedc6.mp4

### Comment by QuangHoang1210 at 2023-03-08T01:51:29Z

@dab246  Please reproduce with case "Copy text content from **email body** then try to paste to mentioned fields above"

### Comment by dab246 at 2023-03-08T02:32:32Z

- Real device

### Comment by dab246 at 2023-03-08T03:02:07Z

> @dab246 Please reproduce with case "Copy text content from email body then try to paste to mentioned fields above"

We tested on real device, simulator all work fine.



https://user-images.githubusercontent.com/80730648/223608900-460a8154-391a-4385-bf53-b2223981d164.mp4

### Comment by QuangHoang1210 at 2023-03-08T05:12:31Z

@dab246  please following exactly reproduce step and watch video bellow:


https://user-images.githubusercontent.com/124866146/223625255-f3a32a2b-6b00-46b9-a3a2-e621933d8ce7.mp4

### Comment by QuangHoang1210 at 2023-03-14T07:38:38Z

Re-open this ticket.

It still happen on Tmail 0.7.4 Android 
cc @dab246  @hoangdat  @huynguyennovem 
https://user-images.githubusercontent.com/124866146/224928144-2d685903-32dd-4e80-9ed0-eaf8ac3cf62c.mp4

### Comment by dab246 at 2023-03-30T04:12:22Z

- Double tap: Not working
- Long tap: Work fine

### Comment by hoangdat at 2023-04-12T03:48:46Z

- Context: in composer
- Should support: double tap and long tap also
@QuangHoang1210 ?

### Comment by QuangHoang1210 at 2023-05-23T03:55:42Z

Retest on 0.7.9 IOS

- Double tap: Work fine
- Long tap: Work fine

I will do more test on new version
@hoangdat  @dab246
