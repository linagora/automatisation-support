# GitHub issue #1631: [Notification] User cannot receive new email notification

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1631
State: closed
Author: QuangHoang1210
Created at: 2023-03-20T17:19:05Z
Updated at: 2023-04-17T23:25:17Z
Closed at: 2023-04-17T23:25:17Z
Labels: bug, Critical, regression
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1631

## Issue body

**OS: Android / IOS
Device: Mobile (Redmi Note9)
TMail version: 0.7.4 (preprod)**

***Receiver Setting:**
![Image](https://user-images.githubusercontent.com/124866146/226418460-5398cc14-cbd4-4413-ba44-98d51b5e9c1a.png)

***Precondition:** User already login successfully

***Reproduce Step:**
1, Sender send an email to receiver

Actual: Receiver already receive that email however there is no notification was displayed.
Expected: The new email notification is displayed then receiver can click to view email details.


![Image](https://user-images.githubusercontent.com/124866146/226419014-fc261a02-75a6-4ca4-8514-70736eb3ee60.png)


![Image](https://user-images.githubusercontent.com/124866146/226419036-1dcf653d-f5c2-49bd-b040-d9cc6da00036.png)

## Comments

### Comment by QuangHoang1210 at 2023-03-20T18:12:21Z

it still working well on ver0.7.1

### Comment by hoangdat at 2023-03-20T20:13:35Z

May be the version outdated

### Comment by hoangdat at 2023-03-22T12:40:04Z

@quantranhong1999 can you take a look at F*** console? we reach to any quota or not?

### Comment by quantranhong1999 at 2023-03-22T12:53:19Z

> @quantranhong1999 can you take a look at F*** console? we reach to any quota or not?

I spotted the new email sync issue on even 0.7.1 on prod: https://github.com/linagora/tmail-flutter/issues/1597
@Arsnael you have the same issue on prod, do you?

I checked the browser console log, it seems browser still gets updates from server:
```
FcmService::handleFirebaseForegroundMessage():message: {8e1534a48ceb6a660b23b18d0de5fba066b2179de5872d4426f90a2cc931095d:Mailbox: e26b53b0-c8af-11ed-83dc-519ac3004b0f, 8e1534a48ceb6a660b23b18d0de5fba066b2179de5872d4426f90a2cc931095d:EmailDelivery: e26b53b0-c8af-11ed-83dc-519ac3004b0f, 8e1534a48ceb6a660b23b18d0de5fba066b2179de5872d4426f90a2cc931095d:Email: e26b53b0-c8af-11ed-83dc-519ac3004b0f}
```

There is `EmailDelivery` change, but it seems no synchronization action made?

### Comment by Arsnael at 2023-03-23T02:20:52Z

@quantranhong1999 not the same :) I think potentially related to the fact I use Brave that is more strict by default? I'm not sure... The ServiceWorker fails to register in my case, as shown here:

![Screenshot from 2023-03-23 09-17-42](https://user-images.githubusercontent.com/9005025/227082347-a4592404-38bf-4e30-8992-feb940e87e86.png)
![Screenshot from 2023-03-23 09-17-15](https://user-images.githubusercontent.com/9005025/227082364-e0bd6bce-841c-4117-9027-d4c7dbd00fa4.png)

TMail web prod 0.7.1
Brave browser 1.49.120 based on Chromium 111.0.5563.64

### Comment by hoangdat at 2023-03-28T12:00:43Z

it is a `regression bug`:
- Reason: Refactor the `error handler` make the side effect to binding `FCM`: 72138e8d8de6949a74c6c57c2202515e76a13598

### Comment by chibenwa at 2023-03-28T12:41:59Z

Please put a link to the SHA-1

### Comment by QuangHoang1210 at 2023-04-17T23:25:17Z

Passed on 0.7.7 beta Android and IOS
