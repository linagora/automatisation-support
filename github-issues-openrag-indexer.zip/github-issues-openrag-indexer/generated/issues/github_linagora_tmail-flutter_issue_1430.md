# GitHub issue #1430: Unable to configure display name on mobile app

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1430
State: closed
Author: guimard
Created at: 2023-02-07T12:50:55Z
Updated at: 2023-04-04T08:16:18Z
Closed at: 2023-04-04T08:16:18Z
Labels: bug
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1430

## Issue body

### Description

There is no menu entry to configure display name

### Expected result

Parameters should allow to configure display name and then send mails using `From: Display Name <user@domain.com>`

### Current behavior

Mails are sent using `From: <user@domain.com>`

#### Reproduction Steps

Install app, configure your JMAP account and send a test mail

### Context

Mobile app on Android 12

## Comments

### Comment by hoangdat at 2023-02-07T14:17:48Z

hi @guimard, 

You can set up the identities in `Manage account` -> `Profiles`

### Comment by guimard at 2023-02-08T03:44:04Z

Hi @hoangdat, so I have to add an identity instead of being able to modify my primary identity ?

### Comment by hoangdat at 2023-02-08T07:41:19Z

Hi, 
you can `edit` any identity, and add what you want. 
Then choosing the identity when composing new email.

<img width="779" alt="image" src="https://user-images.githubusercontent.com/6462404/217465557-29e313f4-fd6a-4e6c-8bfd-7b51f074254a.png">

### Comment by guimard at 2023-02-08T07:43:03Z

I think Tmail app should be able to edit default identity (like other clients)

### Comment by guimard at 2023-02-08T07:45:49Z

It works after adding new identity. Maybe Tmail should create de default one during JMAP enrollment ?

### Comment by chibenwa at 2023-02-08T08:45:42Z

Yes, clearly @guimard you are pointing some user experience that would benefit from being improved.

@hoangdat is right, in JMAP, identity is the right concept to come up with in order to carry the Display name of the sender email address.

It's reasonable, at least to me, that we find a way for the backend to supply such a value.

Very likely we could get the display name from the LDAP and be able to pre-provision a reasonable default identity with reasonable display name from it, using tools like LSC. (LDAP is not a core dependency for James/Tmail backend).

I did open https://github.com/linagora/tmail-backend/issues/554 to handle such concerns.

### Comment by quantranhong1999 at 2023-02-14T03:47:15Z

Hi,
While we (as the backend side) could work on provisioning a default display name, I believe currently "User is able to edit default identity (like other clients)`.

Our JMAP Identity APIs do support [retrieving default identities ](https://github.com/apache/james-project/blob/cc17e8f502cfc3f415af3963b72f9d1ba1880f2c/server/protocols/jmap-rfc-8621-integration-tests/jmap-rfc-8621-integration-tests-common/src/main/scala/org/apache/james/jmap/rfc8621/contract/IdentityGetContract.scala#L74) and [modify those default identities](https://github.com/apache/james-project/blob/cc17e8f502cfc3f415af3963b72f9d1ba1880f2c/server/protocols/jmap-rfc-8621-integration-tests/jmap-rfc-8621-integration-tests-common/src/main/scala/org/apache/james/jmap/rfc8621/contract/IdentitySetContract.scala#L1848).

I checked how FE calls identity APIs, there are 2 issues:
-  Identity/get do return default identities, however, FE does not display them in the identities managing screen.
   Server response:
```json
{
	"sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
	"methodResponses": [
		["Identity/get", {
			"accountId": "8e1534a48ceb6a660b23b18d0de5fba066b2179de5872d4426f90a2cc931095d",
			"state": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
			"list": [{
				"name": "Quan1",
				"htmlSignature": "",
				"id": "83b2487a-f5f1-4a20-b7d4-e84cd1d25d9a",
				"bcc": [],
				"textSignature": "",
				"mayDelete": true,
				"email": "hqtran@linagora.com",
				"replyTo": []
			}, {
				"name": "hqtran@linagora.com",
				"email": "hqtran@linagora.com",
				"htmlSignature": "",
				"id": "a5f670c5-d5e0-3b22-8197-02a9c37cad27",
				"textSignature": "",
				"mayDelete": false
			}]
		}, "c0"]
	]
}
```
   FE only displays custom identity:
![image](https://user-images.githubusercontent.com/55171818/218633820-a6ae7b52-697e-4ae9-84c0-94caef3390a7.png)

- FE does not support modify default identities.

### Comment by chibenwa at 2023-04-04T08:16:18Z

Solved. Closing...
