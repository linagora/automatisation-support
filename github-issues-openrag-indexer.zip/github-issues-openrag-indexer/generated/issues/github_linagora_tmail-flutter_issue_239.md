# GitHub issue #239: [Story] As an user, I want to delete email in Trash (permanently)

## Metadata

Repository: linagora/tmail-flutter
Issue number: 239
State: closed
Author: hoangdat
Created at: 2022-01-05T10:59:56Z
Updated at: 2022-06-28T03:59:47Z
Closed at: 2022-06-28T03:59:46Z
Labels: 
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/239

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition

- Given that i am Tmail user and logged-in to the app 
- I opened folder "Trash" and see the list of emails 

**UC1. Empty Trash folder**
- On the thread-view of Trash folder, I can see an icon "Delete " at the top of screen next to icon Search 
- I click on this icon, there will be a dialog: "You are about to permanently delete all items in Trash . Do you want to continue?" 
- I confirm delete, all emails in the Trash folder will be removed. The folder is empty now. 
- I cannot see icon Delete and Search at the top of screen. 

**UC2. Delete one or some emails permanently (only in Trash folder)**

1. - I open the mail then click on icon Delete on top, then a dialog will be displayed: "You are about to permanently delete this message. Do you want to continue?"
    - I confirm delete, the email will be deleted 

2.  - On the thread-view, i can long-press on the avatar icon to select 1 or multiple emails, then there will be an action bar displayed on the top.
     - I click on three-dots button then there will be a context menu that contain actions. I select option "Delete permanently", then the dialog will be displayed: ": "You are about to permanently delete [number of selected] items. Do you want to continue?"
      - I confirm delete, the selected emails will be deleted.

[Back to Summary](#summary)

## Screenshots

![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/41a82415-9c54-4124-a9bf-2fceb1729375) ![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/0cbd1b53-2358-43fb-86f3-5cd7423867c8)

 ![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/ed6667d6-8db6-4305-b81a-43abd4219d9d)  ![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/b82a181b-509b-4a73-9366-67c71346a787)

![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/78ab90ae-dbe2-4085-97d6-d60208a19615) ![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/b8054db0-1c66-41aa-896f-a1ccfcd1b61c)

![image.png](https://images.zenhubusercontent.com/5fe051fa8d2c764dc30ad13b/373058b6-cd32-4828-b0d3-cf834fadf67a)

[Back to Summary](#summary)

## Design ticket

https://ci.linagora.com/linagora/lgs/design/-/issues/98

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by chibenwa at 2022-01-05T11:11:07Z

(IMO we only delete emails that are already in the trash.)

### Comment by hoangdat at 2022-01-06T03:39:28Z

> (IMO we only delete emails that are already in the trash.)

So email should be moved to trash first?

### Comment by chibenwa at 2022-01-06T05:48:39Z

> So email should be moved to trash first?

Yes.

### Comment by dieptran88 at 2022-01-13T02:01:47Z

@hoangdat @chibenwa  Please help me to verify this story

### Comment by chibenwa at 2022-01-13T02:04:44Z

The police in the confirmation message looks weird to me, otherwise looks good to me!

### Comment by dieptran88 at 2022-01-13T02:42:21Z

there is some apps do not use confirmation while some others use, IMO this action cannot be undone so I put the confirmation before deletion. 
WDYT @hoangdat

### Comment by chibenwa at 2022-01-13T02:45:50Z

>  there is some apps do not use confirmation while some others use, IMO this action cannot be undone so I put the confirmation before deletion.

No you did not understood.

Of course I want a confirmation dialog box.

However the character police choice within the confirmation dialog looks weird.

### Comment by hoangdat at 2022-01-13T03:35:19Z

@chibenwa
Diep are trying to make the prototype, so the UI is not perfect, this story will be transferred to designer to have better look. When the final design (of story) is ok in designer process, developer will implement that. Don't worry

### Comment by lecaotunglam at 2022-06-28T03:59:46Z

Passed on the Production platform.
