# GitHub issue #627: Implement Advanced Search for email

## Metadata

Repository: linagora/tmail-flutter
Issue number: 627
State: closed
Author: hoangdat
Created at: 2022-06-07T03:34:49Z
Updated at: 2022-09-28T09:36:10Z
Closed at: 2022-09-28T09:36:10Z
Labels: 0, onboarding
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/627

## Issue body

### Story:

#478 

### Design:

https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=2632%3A159883

<img width="1127" alt="image" src="https://user-images.githubusercontent.com/6462404/172294314-7a638252-0284-46ad-929d-55fe70a02724.png">

### Desc:

- Interactor: `SearchEmailInteractor`
- Repository: `ThreadRepository`

### DoD:
- Can filter the emails which matched the criterias 
- UI as design: mobile/tablet/browser

## Comments

### Comment by hoangdat at 2022-06-13T02:50:42Z

Please [add your planning poker estimate](https://app.zenhub.com/workspaces/Tmail-Flutter-60d039db6ef62a0013432c14/issues/linagora/tmail-flutter/627?planning-poker) with ZenHub @dab246

### Comment by hoangdat at 2022-06-15T02:35:01Z

+1HD

### Comment by hoangdat at 2022-06-16T03:22:46Z

2HD

### Comment by hoangdat at 2022-06-17T02:55:40Z

2HD

### Comment by hoangdat at 2022-06-20T02:42:34Z

1HD

### Comment by hoangdat at 2022-06-21T02:53:07Z

1HD - off

### Comment by hoangdat at 2022-06-21T02:53:18Z

2HD

### Comment by ManhNTX at 2022-06-21T07:18:52Z

[](url)When i using Email\query method has error like below. Please check this.
Request:
<img width="1032" alt="Screen Shot 2022-06-21 at 12 52 12" src="https://user-images.githubusercontent.com/107173849/174739563-c979ae0d-f33f-46d9-8f0e-1ce80f4f178b.png">
Response:
<img width="640" alt="Screen Shot 2022-06-21 at 12 52 20" src="https://user-images.githubusercontent.com/107173849/174739665-88713919-8806-4c95-9e55-85196a2ff23d.png">

### Comment by chibenwa at 2022-06-21T07:26:29Z

Yes @ManhNTX Remove the AND:

```
"filter": { "conditions": [ { "inMailbox" ...} , {"operator": "AND", "conditions": [] } 
```

The inMailboxFilter need to be at the top level to be supported by James.

In practice this is powerful enough to express all JMAP queries

Other products like Cyrus are subject to similar limitations.

### Comment by ManhNTX at 2022-06-21T07:58:11Z

@chibenwa Thank for support. I follow step by step like your comment but still error. Please check this.
Request:
<img width="758" alt="Screen Shot 2022-06-21 at 14 51 28" src="https://user-images.githubusercontent.com/107173849/174747339-6b38aba5-c986-454f-9a62-44636233d324.png">
Response:
<img width="765" alt="Screen Shot 2022-06-21 at 14 51 37" src="https://user-images.githubusercontent.com/107173849/174747259-aadaccc9-f979-4591-9d05-1035802e5141.png">

### Comment by chibenwa at 2022-06-21T09:32:30Z

```
"conditions": [
    {"inMailbox":xyz,
      "hasAttachment": true}
]
```

???

(sorry for the previous answer)

### Comment by chibenwa at 2022-06-21T10:50:30Z

For your information I also relaxed the assumptions James does on the filter structure.

Now one inMailbox* condition can be put in a AND. No nesting, no double inMailbox criterion.

https://github.com/apache/james-project/pull/1060

With that your first request would work.

### Comment by hoangdat at 2022-06-22T02:54:53Z

2HD

### Comment by hoangdat at 2022-06-24T04:48:09Z

2HD

### Comment by hoangdat at 2022-06-24T04:48:14Z

2HD

### Comment by hoangdat at 2022-06-27T07:56:44Z

Remaining:
- [ ] auto complete email
- [ ] docs ADR

### Comment by hoangdat at 2022-06-29T03:08:45Z

2HD

### Comment by hoangdat at 2022-07-01T01:42:33Z

2HD

### Comment by hoangdat at 2022-07-01T02:39:35Z

1HD
