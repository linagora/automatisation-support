# GitHub issue #470: emails with HTML format lose the format when being forwarded from Tmail to Gmail

## Metadata

Repository: linagora/tmail-flutter
Issue number: 470
State: closed
Author: hantt12
Created at: 2022-04-07T08:24:06Z
Updated at: 2022-11-25T08:05:02Z
Closed at: 2022-11-25T08:05:02Z
Labels: bug, 0, Medium
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/470

## Issue body

Original email:
![2022-04-07_15-22.png](https://images.zenhubusercontent.com/5ee9def7c40b48447a4362e2/d2a79952-621c-4925-9956-e5d7644747f9)

Forwarded and viewed in Gmail:
![2022-04-07_15-23.png](https://images.zenhubusercontent.com/5ee9def7c40b48447a4362e2/1866e3d9-c3da-48c5-aa13-056796389f95)

## Comments

### Comment by chibenwa at 2022-04-14T07:14:05Z

Please share the whole EML not just the HTML.

### Comment by hoangdat at 2022-04-14T08:26:24Z

[DM TEST DI - tdvu@linagora.com - 2022-04-14 1010.eml.zip](https://github.com/linagora/tmail-flutter/files/8487575/DM.TEST.DI.-.tdvu%40linagora.com.-.2022-04-14.1010.eml.zip)

this EML was download from `thunderbird`

### Comment by hoangdat at 2022-04-20T03:41:28Z

> [DM TEST DI - tdvu@linagora.com - 2022-04-14 1010.eml.zip](https://github.com/linagora/tmail-flutter/files/8487575/DM.TEST.DI.-.tdvu%40linagora.com.-.2022-04-14.1010.eml.zip)
> 
> this EML was download from `thunderbird`

Hi @chibenwa, can you take a look and give us some idea

### Comment by hoangdat at 2022-06-08T03:07:39Z

@chibenwa it should be great if you spend time to look at this issue

### Comment by chibenwa at 2022-06-08T03:59:59Z

Likely related to https://github.com/linagora/tmail-flutter/issues/634

### Comment by hoangdat at 2022-06-09T03:45:23Z

> Likely related to #634

why it related to send attachment?

### Comment by hoangdat at 2022-06-20T02:37:00Z

Please add `ADR` with PR

### Comment by dab246 at 2022-06-20T09:44:30Z

@hoangdat @chibenwa 
After the test period. I discovered the cause of the error.
- Because We automatically set up the plain text part when sending an email, so in our `.eml` file there are always 2 contents of `text/html` and `text/plain` (See attached example file)
- Some email clients (Gmail/Apple Mail) only take the content of `Content-Type: text/plain`. I don't know why either, maybe it's the final content.

[[POSTMAN] SEND EMAIL WITH CSS STYLE.eml](https://app.zenhub.com/files/378835363/41349721-fe5d-4d87-9e2a-aeae6c7ef251/download)

### Comment by chibenwa at 2022-06-20T10:03:10Z

![Screenshot from 2022-06-20 17-01-49](https://user-images.githubusercontent.com/6928740/174578136-b05ae279-0595-4110-9b58-4899143869e4.png)

...

Thunderbird supports this very well.

I'm investigating what is going wrong with GMail multipart/alternative support...

### Comment by chibenwa at 2022-06-20T10:15:16Z

Privately discussing this with Dat Vu.

We will need to drop the `text/html` => `multipart alternative` support on email/set.

We will likely nned to re-think inter-operability, especially for mail client not supporting HTML rendering.

Move to james backend.

### Comment by dab246 at 2022-06-20T10:32:56Z

I changed the content position of 2 `content-type`

- Initial
```eml
---=Part.41f.5fd8765406e9cb33.181808b33f6.dff85f37c84945c7=-
Content-Type: text/html; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

<h1>This is a Heading</h1>
---=Part.41f.5fd8765406e9cb33.181808b33f6.dff85f37c84945c7=-
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

This is a Heading
---=Part.41f.5fd8765406e9cb33.181808b33f6.dff85f37c84945c7=---
```
![Screen Shot 2022-06-20 at 17.26.06.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/8f5b4e20-958b-4978-8e71-938148e45802)

- After the change
```eml
---=Part.41f.5fd8765406e9cb33.181808b33f6.dff85f37c84945c7=-
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

This is a Heading
---=Part.41f.5fd8765406e9cb33.181808b33f6.dff85f37c84945c7=-
Content-Type: text/html; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

<h1>This is a Heading</h1>
---=Part.41f.5fd8765406e9cb33.181808b33f6.dff85f37c84945c7=---
```
![Screen Shot 2022-06-20 at 17.25.28.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/36b80554-19f7-47b5-b31c-cca05ec93d48)

Conclusion.
- If `Content-Type=multipart alternative`, the content of `content-type` at the bottom will be fetched for display (Works with most email clients: Gmail/Apple Mail/Outlook/Thunderbird)

### Comment by chibenwa at 2022-06-20T11:12:10Z

The fix https://github.com/apache/james-project/pull/1059

### Comment by hoangdat at 2022-06-21T02:47:53Z

2HD
