# GitHub issue #1448: Verify the app in browsers [Safari, Firefox, ...]

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1448
State: closed
Author: hoangdat
Created at: 2023-02-13T11:58:49Z
Updated at: 2023-04-05T04:01:02Z
Closed at: 2023-04-05T04:01:02Z
Labels: 
Assignees: QuangHoang1210
URL: https://github.com/linagora/tmail-flutter/issues/1448

## Issue body

### DoD: 
- the state of the app in each browser

## Comments

### Comment by hoangdat at 2023-02-13T12:01:11Z

Deadline: Friday 17thFeb

### Comment by chibenwa at 2023-02-13T12:01:52Z

https://user-images.githubusercontent.com/6928740/218452593-3ec88284-b43a-4245-a80e-0f802f891db5.mp4

### Comment by hoangdat at 2023-02-13T13:54:57Z

![Image](https://user-images.githubusercontent.com/6462404/218476374-2145e275-cbf3-45c3-b217-7c10fb307a87.png)

IMO, it is fixed?

### Comment by chibenwa at 2023-02-13T15:10:37Z

Which endpoint did complain?

We did rollback one version in prod so it is likely that the fix was unapplied...

Safari version from Diana: Version 15.2 (17612.3.6.1.6)

### Comment by hoangdat at 2023-02-13T22:11:00Z

https://github.com/linagora/tmail-backend/issues/536

### Comment by hoangdat at 2023-02-13T22:14:11Z

> Which endpoint did complain?

I have the error when call the session, preprod have no problem

### production 
<img width="725" alt="image" src="https://user-images.githubusercontent.com/6462404/218586551-06e44c3a-7eb4-4c65-a326-a436bf762fb8.png">

### Comment by chibenwa at 2023-02-13T23:54:39Z

So that's it

### Comment by hoangdat at 2023-03-07T03:16:19Z

@chibenwa @Arsnael when production can work with it?

### Comment by chibenwa at 2023-03-07T03:18:59Z

> @chibenwa @Arsnael when production can work with it?

-> https://github.com/linagora/james-project-private/issues/591

### Comment by QuangHoang1210 at 2023-03-10T06:36:21Z

**It work well:**

- Chrome , Firefox on window.
- Safari on mobile

### Comment by chibenwa at 2023-03-10T07:15:58Z

Any chance to test safari on laptop?

@QuangHoang1210 please document versions tested too ^^

### Comment by QuangHoang1210 at 2023-03-11T05:40:42Z

@chibenwa  I don't have macbook device to test on laptop safari :(

### Comment by QuangHoang1210 at 2023-03-13T02:54:19Z

Retest on Safari by Macbook:  <only happen on Tmail production while using safari browser on laptop>
Tmail version v.0.7.1
@chibenwa  @dab246  @hoangdat 

Reproduce step:
1, User access tmail.linagora.com
2. User signing in

Actual: 404 not found
Expected: User can login normally

![Image](https://user-images.githubusercontent.com/124866146/224597410-e90ef440-feaf-4211-9aed-7dced643455b.png)

### Comment by chibenwa at 2023-03-13T03:29:18Z

On TMail.linagora.com ?

Expected. Please re-test tomorrow once the backend team updated the platform.

### Comment by QuangHoang1210 at 2023-03-13T03:57:03Z

@chibenwa  yes on Tmail.linagora.com. But it only happen on safari latpop. It work well on safari mobile

Yup I will take a look carefully.

### Comment by QuangHoang1210 at 2023-03-15T19:45:43Z

Retest: Its still happen on production (new release of backend)
Note: Only happen on safari window
Browser: Safari version Version 16.1 (18614.2.9.1.12)

![Image](https://user-images.githubusercontent.com/124866146/225424978-26c2e061-6c34-491a-b32d-424034400fbc.png)

### Comment by QuangHoang1210 at 2023-03-15T19:56:20Z

*Note:
I cannot access pre prod Tmail on safari also

https://tmail.upn.integration-open-paas.org/#/

https://user-images.githubusercontent.com/124866146/225427289-264f18bb-2cba-42a0-a699-4421c91e187b.mov

### Comment by chibenwa at 2023-03-16T01:42:48Z

Debugger console?

### Comment by QuangHoang1210 at 2023-03-16T03:20:57Z

Debugger console for production (tmail.linagora.com)

```
[Log] LoginController::handleLoginPressed(): LoginFormType.credentialForm (main.dart.js, line 74498)
[Log] AccountRepositoryImpl::setCurrentAccount(): Account (main.dart.js, line 74498)
[Log] AccountCacheManager::setSelectedAccount(): Instance of 'AccountCacheClient' (main.dart.js, line 74498)
[Log] HiveCacheConfig::getEncryptionKey(): encryptionKey: uEUeC4XCTyAwPsvo68TndfkYPuuWtZg8Gv1KL7TwX8w= (main.dart.js, line 74498)
[Error] Failed to load resource: A server with the specified hostname could not be found. (jmap, line 0)
[Log] AuthorizationInterceptors::onError(): DioError [DioErrorType.response]: XMLHttpRequest error. (main.dart.js, line 74498)
[Log] [ERROR] RemoteExceptionThrower::throwException():error: DioError [DioErrorType.response]: XMLHttpRequest error. (main.dart.js, line 74498)
Source stack:
StackTrace_current@https://tmail.linagora.com/main.dart.js:14361:49
@https://tmail.linagora.com/main.dart.js:125863:48
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
fetch$body$DioMixin@https://tmail.linagora.com/main.dart.js:125893:31
fetch$1$1@https://tmail.linagora.com/main.dart.js:125848:38
@https://tmail.linagora.com/main.dart.js:125836:57
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
request$body$DioMixin@https://tmail.linagora.com/main.dart.js:125845:31
request$1$7$cancelToken$data$onReceiveProgress$onSendProgress$options$queryParameters@https://tmail.linagora.com/main.dart.js:125774:40
request$1$5$cancelToken$onReceiveProgress$options$queryParameters@https://tmail.linagora.com/main.dart.js:125777:104
$get$1$5$cancelToken$onReceiveProgress$options$queryParameters@https://tmail.linagora.com/main.dart.js:125768:84
@https://tmail.linagora.com/main.dart.js:238071:115
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
$get$body$HttpClient@https://tmail.linagora.com/main.dart.js:238083:31
$get$1@https://tmail.linagora.com/main.dart.js:238055:39
@https://tmail.linagora.com/main.dart.js:238648:79
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
execute$0@https://tmail.linagora.com/main.dart.js:238660:31
@https://tmail.linagora.com/main.dart.js:305012:114
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
getSession$0@https://tmail.linagora.com/main.dart.js:305024:31
@https://tmail.linagora.com/main.dart.js:304977:78
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
call$0@https://tmail.linagora.com/main.dart.js:304989:31
Future_Future$sync@https://tmail.linagora.com/main.dart.js:11658:36
getSession$0@https://tmail.linagora.com/main.dart.js:304961:34
@https://tmail.linagora.com/main.dart.js:305055:96
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
execute$0@https://tmail.linagora.com/main.dart.js:305094:31
@https://tmail.linagora.com/main.dart.js:305123:99
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
_getSession$0@https://tmail.linagora.com/main.dart.js:305130:31
onReady$0@https://tmail.linagora.com/main.dart.js:305104:28
call$1@https://tmail.linagora.com/main.dart.js:222745:34
_invokeFrameCallback$3@https://tmail.linagora.com/main.dart.js:176382:24
_invokeFrameCallback$2@https://tmail.linagora.com/main.dart.js:176391:41
handleDrawFrame$0@https://tmail.linagora.com/main.dart.js:176361:39
_handleDrawFrame$0@https://tmail.linagora.com/main.dart.js:176312:30
@https://tmail.linagora.com/main.dart.js:9081:45
invoke@https://tmail.linagora.com/main.dart.js:3185:24
call$1@https://tmail.linagora.com/main.dart.js:91891:17
_rootRunUnary@https://tmail.linagora.com/main.dart.js:12167:22
@https://tmail.linagora.com/main.dart.js:315539:29
runUnary$2$2@https://tmail.linagora.com/main.dart.js:107150:45
runUnaryGuarded$1$2@https://tmail.linagora.com/main.dart.js:107091:26
call$1@https://tmail.linagora.com/main.dart.js:107272:44
invokeClosure@https://tmail.linagora.com/main.dart.js:8977:32
@https://tmail.linagora.com/main.dart.js:8996:24
[Log] RemoteExceptionThrower::throwException(): CONNECTION: ConnectivityResult.wifi (main.dart.js, line 74498)
[Log] OidcConfigurationCacheManager::deleteAuthorityOidc() (main.dart.js, line 74498)
[Log] HiveCacheConfig::getEncryptionKey(): encryptionKey: uEUeC4XCTyAwPsvo68TndfkYPuuWtZg8Gv1KL7TwX8w= (main.dart.js, line 74498, x2)
[Log] AuthenticationClientWeb::getAuthenticationInfo(): authUrl: null (main.dart.js, line 74498)
[Log] GetAuthenticationInfoInteractor::execute(): result: null (main.dart.js, line 74498)
[Log] [ERROR] AccountCacheManager::getSelectedAccount(): Bad state: No element (main.dart.js, line 74498)
[Log] [ERROR] GetAuthenticatedAccountInteractor::execute(): Instance of 'NotFoundAuthenticatedAccountException' (main.dart.js, line 74498)
[Error] Failed to load resource: A server with the specified hostname could not be found. (webfinger, line 0)
[Log] AuthorizationInterceptors::onError(): DioError [DioErrorType.response]: XMLHttpRequest error. (main.dart.js, line 74498)
[Log] [ERROR] RemoteExceptionThrower::throwException():error: DioError [DioErrorType.response]: XMLHttpRequest error. (main.dart.js, line 74498)
Source stack:
StackTrace_current@https://tmail.linagora.com/main.dart.js:14361:49
@https://tmail.linagora.com/main.dart.js:125863:48
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
fetch$body$DioMixin@https://tmail.linagora.com/main.dart.js:125893:31
fetch$1$1@https://tmail.linagora.com/main.dart.js:125848:38
@https://tmail.linagora.com/main.dart.js:125836:57
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
request$body$DioMixin@https://tmail.linagora.com/main.dart.js:125845:31
request$1$7$cancelToken$data$onReceiveProgress$onSendProgress$options$queryParameters@https://tmail.linagora.com/main.dart.js:125774:40
request$1$5$cancelToken$onReceiveProgress$options$queryParameters@https://tmail.linagora.com/main.dart.js:125777:104
$get$1$5$cancelToken$onReceiveProgress$options$queryParameters@https://tmail.linagora.com/main.dart.js:125768:84
@https://tmail.linagora.com/main.dart.js:121522:127
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
$get$body$DioClient@https://tmail.linagora.com/main.dart.js:121534:31
$get$4$cancelToken$onReceiveProgress$options@https://tmail.linagora.com/main.dart.js:121495:38
$get$1@https://tmail.linagora.com/main.dart.js:121501:63
@https://tmail.linagora.com/main.dart.js:275956:83
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
checkOIDCIsAvailable$body$OIDCHttpClient@https://tmail.linagora.com/main.dart.js:275977:31
checkOIDCIsAvailable$1@https://tmail.linagora.com/main.dart.js:275941:59
@https://tmail.linagora.com/main.dart.js:274329:92
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
_asyncStartSync@https://tmail.linagora.com/main.dart.js:11509:26
call$0@https://tmail.linagora.com/main.dart.js:274343:31
Future_Future$sync@https://tmail.linagora.com/main.dart.js:11658:36
checkOIDCIsAvailable$1@https://tmail.linagora.com/main.dart.js:274280:34
@https://tmail.linagora.com/main.dart.js:276508:143
@https://tmail.linagora.com/main.dart.js:11545:17
call$2@https://tmail.linagora.com/main.dart.js:104641:22
call$0@https://tmail.linagora.com/main.dart.js:104654:31
_rootRun@https://tmail.linagora.com/main.dart.js:12149:24
@https://tmail.linagora.com/main.dart.js:315536:24
run$1$1@https://tmail.linagora.com/main.dart.js:107145:45
runGuarded$1@https://tmail.linagora.com/main.dart.js:107081:21
call$0@https://tmail.linagora.com/main.dart.js:107266:37
_rootRun@https://tmail.linagora.com/main.dart.js:12153:22
@https://tmail.linagora.com/main.dart.js:315536:24
run$1$1@https://tmail.linagora.com/main.dart.js:107145:45
runGuarded$1@https://tmail.linagora.com/main.dart.js:107081:21
call$0@https://tmail.linagora.com/main.dart.js:107266:37
_microtaskLoop@https://tmail.linagora.com/main.dart.js:11920:30
_startMicrotaskLoop@https://tmail.linagora.com/main.dart.js:11926:25
call$1@https://tmail.linagora.com/main.dart.js:104524:15
invokeClosure@https://tmail.linagora.com/main.dart.js:8977:32
@https://tmail.linagora.com/main.dart.js:8996:24
[Log] RemoteExceptionThrower::throwException(): CONNECTION: ConnectivityResult.wifi (main.dart.js, line 74498)
```

### Comment by QuangHoang1210 at 2023-03-16T03:22:57Z

Debugger console for prepared (tmail.upn.integration-open-paas.org)

```
[Warning] Failed to load app from service worker. Falling back to plain <script> tag. (tmail.upn.integration-open-paas.org, line 94)
[Debug] Flutter Web Bootstrap: Auto. (main.dart.js, line 18365)
[Log] Got object store box in database encryptionkeycache. (main.dart.js, line 80692)
[Log] Got object store box in database emailcache. (main.dart.js, line 80692)
[Log] Got object store box in database recentsearchcache. (main.dart.js, line 80692)
[Log] Creating objectStore box in database recentloginurlcache... (main.dart.js, line 80692)
[Log] Creating objectStore box in database recentloginusernamecache... (main.dart.js, line 80692)
```
