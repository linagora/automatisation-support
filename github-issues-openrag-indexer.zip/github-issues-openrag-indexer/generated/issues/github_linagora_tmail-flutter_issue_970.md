# GitHub issue #970: [Read mail] Select mail to mark as read from outlook, check mail from Tmail is still marked as unread

## Metadata

Repository: linagora/tmail-flutter
Issue number: 970
State: closed
Author: haftus98
Created at: 2022-09-22T09:49:46Z
Updated at: 2022-11-25T10:58:40Z
Closed at: 2022-11-25T10:58:40Z
Labels: bug, Critical
Assignees: hoangdat, haftus98
URL: https://github.com/linagora/tmail-flutter/issues/970

## Issue body

**Current behaviour:** 
I selected unread mails from Outlook to mark them as read. Then I got back to Tmail to view those mails, they were still under status of unread.

**Expected:**
The status of mail has to be the same from every mail clients.

## Comments

### Comment by hoangdat at 2022-09-22T10:03:23Z

Hi @chibenwa @Arsnael any idea for this issue?
I still see it always in OpenPaaS, and still in Tmail also.

### Comment by Arsnael at 2022-09-22T10:16:23Z

Never seen this issue with TB... so I'm not sure how to reproduce. Can we have a little video if possible? Is it possible as well that outlook failed at updating email flags?

### Comment by chibenwa at 2022-09-22T10:57:11Z

@haftus98 take screenshots and share details allowing to know which message it is.

@haftus98 has the message been COPIED before ? Is there 1 mailbox where it is read, one mailbox where it is unread ?

@Arsnael inconsistencies between `messageIdTable` and `imapUidTable` ?

### Comment by Arsnael at 2022-09-23T01:58:16Z

That looks like a different issue from the previous one IMO... but that's why I would like to see screenshots to be sure we understand correctly.

### Comment by hoangdat at 2022-09-23T03:16:30Z

any related to #929?

### Comment by Arsnael at 2022-09-23T03:52:57Z

I don't think it is... other issue you still could see unread counter emails in jmap because somehow there is some messages not showing... while they show on imap and if you read them then it fix the counter for jmap too.

Here it feels more like she reads messages on outlook (imap), and those message are still unread on tmail (jmap).

But I know sometimes we don't all speak the same language, thus asking for a screenshot or video so we can be sure we understand each other

### Comment by haftus98 at 2022-09-23T07:36:12Z

https://user-images.githubusercontent.com/97084773/191912204-adcfb7f9-1956-43dd-8747-b92a78163ec8.mp4


I read mail from Outlook, then reload the page in Tmail but it was still marked as unread from Tmail

### Comment by Arsnael at 2022-09-26T02:03:25Z

So yep nothing to do with #929 (I think?)
Thanks @haftus98 for the video :)

### Comment by chibenwa at 2022-09-26T02:05:33Z

Is the email marked as read in OpenPaaS ?

Does pressing `ctrl + f5` solves the issue in TMail ?

### Comment by Arsnael at 2022-09-26T02:26:14Z

Might be more some isolated issue with Outlook? I have no problem doing this with Thunderbird and TMail for example

### Comment by chibenwa at 2022-09-26T05:30:28Z

Yes I may be thinking "cache issues"

Basicaly I suspect under some conditions TMail app badly refreshes its cache. That's the scope of my question...

### Comment by hoangdat at 2022-09-26T06:53:48Z

yes, for one week ago, I found that we have synchronization between JMAP and IMAP, but not before (I always see the read mail in IMAP is unread in JMAP). So I will test more with the case.

### Comment by hoangdat at 2022-09-26T16:05:45Z

please verify the issue with v0.3.15 (please make sure to clean out the Tmail before test)

### Comment by haftus98 at 2022-09-30T10:09:55Z

[Untitled_ Sep 30,2022 4_37 PM.webm](https://user-images.githubusercontent.com/97084773/193247636-4698d32d-0306-4042-a2ef-a544230ee686.webm)

still bugging :((

### Comment by hoangdat at 2022-10-05T03:25:47Z

fixed with #1044
