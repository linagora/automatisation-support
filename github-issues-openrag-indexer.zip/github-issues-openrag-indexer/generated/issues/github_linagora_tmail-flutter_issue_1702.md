# GitHub issue #1702: Offline mode

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1702
State: closed
Author: chibenwa
Created at: 2023-04-03T05:05:37Z
Updated at: 2023-09-16T09:42:22Z
Closed at: 2023-09-16T09:42:22Z
Labels: Offline mode
Assignees: dieptran88
URL: https://github.com/linagora/tmail-flutter/issues/1702

## Issue body

### US 0: Keep N recently opened email in the cache 

(round robin)

CF https://github.com/linagora/tmail-flutter/issues/1431

### US 1.a: Sending emails when offline

```
GIVEN I am offline
WHEN I send an email (or reply or forward)
THEN a pop up indicates that the actions will be performed once I am online
AND  the email is saved in my Sending-queue (shown as a system mailbox entry with a counter)
          In US 1 I cannot open the Sending Queue

Sending queue is hidden if empty
           
WHEN I come back online
THEN the email send resumes (empty sending queue
```

### US 1.b: Manage the sending queue

```
GIVEN I have content in the sending queue
WHEN I click the sendingQueue entry in system mbxs
THEN I can see the list of emails in the sending queue (to + subject + date + attachment)
          Each entry have a delete button allowing (after confirmation) to delete the mail.
          I can not open / modify a scheduled email.
```

### US 1.c: View / modify sendingQueue entries

```
GIVEN I have content in the sending queue
AND opened the sending queue view
WHEN I click on an entry 
THEN it opens it in the composer, allowing me to edit it.
```
### US 2: Reading recent emails when on slow network/offline

```
GIVEN I am on Wifi
WHEN I receive an email in my INBOX (background OR foreground)
THEN TeamMail will download the attachment structure and the HTML body for that email
           (No need to download external images)

TeamMail will keep up to 100 emails // 100MB of email data locally. Removes the oldest emails first.
```

```
GIVEN I am on slow network / offline
AND I received 10 email in that status
WHEN I come back on wifi
THEN TeamMail will download these 10 emails body information
```

### US 3: Performing actions when offline

```
GIVEN I am offline
WHEN I perform email actions
THEN a pop up indicates that the actions will be performed once I am online,
AND  these actions are saved on the device
AND the local cache is modified

GIVEN I have email actions saved on the device
WHEN I come back online
THEN these email actions are executed against the server as if I just performed them.
AND the local cache is updated only when the changes are flushed

Actions:
 - Flag/unflag
 - Moving email
 - Read/unread
 - Delete email
 
 Note: No need to support mailbox actions.
```

Cc @hoangdat @guimard this would be my MVP for offline mode...

## Comments

### Comment by hoangdat at 2023-04-17T13:30:39Z

```
GIVEN I am on slow network / offline
AND I received 10 email in that status
WHEN I come back on wifi
THEN TeamMail will download these 10 emails body information
```
srr, can not understand this case

### Comment by hoangdat at 2023-04-17T13:31:49Z

for `UC3` please compare with other mail client, what user need?

### Comment by chibenwa at 2023-04-20T07:54:21Z

Let's spend 2 sprints (1 month) on the offline topic (50% of developer time for offline, 50% for bug/ux fixes)

## US 0

Useful: 2-3

Complexity / risk: 1-2

No need to display distant HTML

## US 2 

Usefull: 4-3

Complexity / risk: 2

Only on mobile, nhee not on web

## US 1.a

Usefull: 3

Note: disable `saving as draft when offline`

Complexity: 3

There's maybe a point on uploading attachment then send

## US 1.b

Usefull: 3

Complexity: 2

## US 1.c

Usefull: 2-4

Complexity:  2

## US 3

It is a COULD have. 

It will not be part of offline mode MVP.

### Comment by chibenwa at 2023-04-25T08:54:00Z

COSOFT comment:

```
A test to add: network is back but not enough time to resynchronize. Client should be able to restart synchronisation 
```

### Comment by quantranhong1999 at 2023-06-19T07:10:46Z

Hi, I tried a bit the offline mode on the TMail android app v0.8.0 and have some feedback (just from my using perspective)

In offline mode experiences:
- Advertising the offline mode feature to users is not intuitive IMO (When disconnected, only a red error no connection is shown, maybe a popup showing that the user can still use offline mode after that would be better?)
  Today If I were a normal user and I do not know that TMail has an offline mode feature, I would not even know that there is that feature to use.
- TMail keeps toasting the red error messages regarding no connection while navigating in offline mode. 
  IMO user should not be toasted of too many connection errors once he knows he is in offline mode and trying to use TMail even in offline mode.
- In offline mode, I can not open newly received messages (without opening them first)
  I can see currently we apply round-robin for opened messages to be cached. However, maybe we can utilize caching new messages as well? As a user myself, I would tend to be interested in new and unopened messages rather than reopening some emails.
- Could be a bonus IMO: be able to use auto-complete contacts in offline.

After offline mode experiences:
Managing the sent mails in the offline mode is not intuitive to me:
  - I can not check the sending queue in online mode (maybe we should cache the sent results for a while, at least after the user checked them?)
  - A TMail notification is shown which displays the sent email's subject and body. Why? Maybe it should be a message like "This mail was sent after network reconnecting"?

### Comment by hoangdat at 2023-06-19T07:16:42Z

> When disconnected, only a red error no connection is shown

Yeah, we are working on it to improve the UX @QuangHoang1210 

> TMail keeps toasting the red error messages regarding no connection while navigating in offline mode.

We are fixing it @dab246 

> In offline mode, I can not open newly received messages (without opening them first)

Can you give us more hint to reproduce it?

> Could be a bonus IMO: be able to use auto-complete contacts in offline.

Good idea for the next improvement

### Comment by quantranhong1999 at 2023-06-19T07:22:31Z

> In offline mode, I can not open newly received messages (without opening them first)
>> Can you give us more hint to reproduce it?

Is not the current behavior expected by the user story?
```
US 0: Keep N recently opened email in the cache
(round robin)
```

E.g currently we cache 20 opened messages and no cache for new but unopened messages.

I propose (at least from my experience):e.g we cache 20 opened messages, and 10 top new messages but unopened messages.

### Comment by hoangdat at 2023-06-19T07:26:34Z

> and 10 top new messages but unopened messages.

it is US 2. Yes implemented. New coming email -> notification show and MAYBE this new email will be cached too.

### Comment by quantranhong1999 at 2023-06-19T07:32:03Z

> it is US 2. Yes implemented. New coming email -> notification show and MAYBE this new email will be cached too.

I don't know if that is already in v0.8.0. At least not worked for me. But good to know that would be implemented.

### Comment by hoangdat at 2023-06-19T07:56:52Z

@QuangHoang1210 can you investigate this case of @quantranhong1999. Thanks

### Comment by QuangHoang1210 at 2023-06-19T09:23:50Z

- The issue above is already raised as the list out tickets bellow:
https://github.com/linagora/tmail-flutter/issues/1923
https://github.com/linagora/tmail-flutter/issues/1932
https://github.com/linagora/tmail-flutter/issues/1934
https://github.com/linagora/tmail-flutter/issues/1933
https://github.com/linagora/tmail-flutter/issues/1931

- Offline Mode UX story will be provided asap in the next couple days.
@quantranhong1999  cc @hoangdat
