# GitHub issue #3498: Release new version  Release v0.14.13

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3498
State: closed
Author: hoangdat
Created at: 2025-02-20T02:42:02Z
Updated at: 2025-03-24T03:49:57Z
Closed at: 2025-03-24T03:49:57Z
Labels: releasing
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/3498

## Issue body

### DoD:
- [x] Request translating in weblate and merge to branch
- [x] Test in all platforms base on the check-list case:  [tnr-tmail-template.ods](https://github.com/user-attachments/files/16719554/tnr-tmail-template.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [x] CHANGE LOG test
- [x] Memory leak verifycation
- [x] Tag new version
- [x] Push new docker image
- [x] iOS - Release app in Test Flight
- [x] Android - Release app in Internal Test

## Comments

### Comment by hoangdat at 2025-02-20T02:49:15Z

- [x] @dab246: iOS, edge
- [x] @hoangdat: android. chrome
- [x] @tddang-linagora: firefox, safari

=> Result

- [tmail-0.14.13-firefox-safari.ods](https://github.com/user-attachments/files/18883586/tmail-0.14.13-firefox-safari.ods)
- [tmail-v0.14.13-iOS-edge-android.ods](https://github.com/user-attachments/files/18963525/tmail-v0.14.13-iOS-edge-android.ods)

### Comment by tddang-linagora at 2025-02-20T07:06:20Z

## Twake Workplace redirect
Redirection jumps to app store even when the app is installed
- Not signed in

https://github.com/user-attachments/assets/fb0de047-dd60-44f0-af20-a515606246a6

- Signed in with same account

https://github.com/user-attachments/assets/42bdd3cd-a32f-46a1-abd3-32d356177c16

- Signed in with different account

https://github.com/user-attachments/assets/3613d095-31dc-43fd-8b4d-12ea91c818f8

### Comment by tddang-linagora at 2025-02-20T07:35:16Z

## Support Cyrus server
Cannot send email
<details>
<summary>Request</summary>

```json
{
  "using": [
    "urn:ietf:params:jmap:submission",
    "urn:ietf:params:jmap:mail",
    "urn:ietf:params:jmap:core"
  ],
  "methodCalls": [
    [
      "Mailbox/set",
      {
        "accountId": "bob",
        "create": {
          "f71a4b61-ef5c-11ef-ac2d-41c7acf8245d": {
            "name": "Outbox",
            "isSubscribed": true
          }
        }
      },
      "c0"
    ],
    [
      "Email/set",
      {
        "accountId": "bob",
        "create": {
          "f71a4b62-ef5c-11ef-ac2d-41c7acf8245d": {
            "mailboxIds": {
              "#f71a4b61-ef5c-11ef-ac2d-41c7acf8245d": true
            },
            "subject": "dlawknd",
            "from": [
              {
                "name": null,
                "email": "bob@example.com"
              }
            ],
            "to": [
              {
                "name": null,
                "email": "bob@example.com"
              }
            ],
            "cc": [],
            "bcc": [],
            "replyTo": [
              {
                "name": null,
                "email": "bob@example.com"
              }
            ],
            "htmlBody": [
              {
                "partId": "f71a4b60-ef5c-11ef-ac2d-41c7acf8245d",
                "type": "text/html"
              }
            ],
            "bodyValues": {
              "f71a4b60-ef5c-11ef-ac2d-41c7acf8245d": {
                "value": "<div>sawbdw<br><br></div>",
                "isEncodingProblem": false,
                "isTruncated": false,
                "header:Accept-Language:asText": "fr-FR, en-US, vi-VN, ru-RU, ar-TN, it-IT, de-DE",
                "header:Content-Language:asText": "en-US"
              }
            },
            "header:User-Agent:asText": "Twake-Mail/0.14.13 Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
          }
        }
      },
      "c1"
    ],
    [
      "EmailSubmission/set",
      {
        "accountId": "bob",
        "create": {
          "f71a4b63-ef5c-11ef-ac2d-41c7acf8245d": {
            "emailId": "#f71a4b62-ef5c-11ef-ac2d-41c7acf8245d",
            "envelope": {
              "mailFrom": {
                "email": "bob@example.com"
              },
              "rcptTo": [
                {
                  "email": "bob@example.com"
                }
              ]
            }
          }
        },
        "onSuccessUpdateEmail": {
          "#f71a4b63-ef5c-11ef-ac2d-41c7acf8245d": {
            "mailboxIds/xhrnf36c9jvd5zwfi37x32gw": true,
            "mailboxIds/#f71a4b61-ef5c-11ef-ac2d-41c7acf8245d": null,
            "keywords/$seen": true,
            "keywords/$draft": null
          }
        }
      },
      "c2"
    ]
  ]
}
```
</details>


<details>
<summary>Response</summary>

```json
{
    "methodResponses": [
        [
            "Mailbox/set",
            {
                "oldState": "96",
                "newState": "96",
                "created": null,
                "updated": null,
                "destroyed": null,
                "notCreated": {
                    "f71a4b61-ef5c-11ef-ac2d-41c7acf8245d": {
                        "type": "invalidProperties",
                        "properties": [
                            "name"
                        ]
                    }
                },
                "notUpdated": null,
                "notDestroyed": null,
                "accountId": "bob"
            },
            "c0"
        ],
        [
            "Email/set",
            {
                "oldState": "96",
                "newState": "96",
                "created": null,
                "updated": null,
                "destroyed": null,
                "notCreated": {
                    "f71a4b62-ef5c-11ef-ac2d-41c7acf8245d": {
                        "type": "invalidProperties",
                        "properties": [
                            "mailboxIds"
                        ]
                    }
                },
                "notUpdated": null,
                "notDestroyed": null,
                "accountId": "bob"
            },
            "c1"
        ],
        [
            "EmailSubmission/set",
            {
                "oldState": "63",
                "newState": "63",
                "created": null,
                "updated": null,
                "destroyed": null,
                "notCreated": {
                    "f71a4b63-ef5c-11ef-ac2d-41c7acf8245d": {
                        "type": "invalidProperties",
                        "properties": [
                            "emailId"
                        ]
                    }
                },
                "notUpdated": null,
                "notDestroyed": null,
                "accountId": "bob"
            },
            "c2"
        ],
        [
            "Email/set",
            {
                "oldState": "96",
                "newState": "96",
                "created": null,
                "updated": null,
                "destroyed": null,
                "notCreated": null,
                "notUpdated": null,
                "notDestroyed": null,
                "accountId": "bob"
            },
            "c2"
        ]
    ],
    "sessionState": "0"
}
```
</details>

Set up
- https://github.com/linagora/cyrus-postfix-docker
- env.file: SERVER_URL=http://localhost:8008/

### Comment by dab246 at 2025-02-21T07:50:53Z

> ## Twake Workplace redirect
> Redirection jumps to app store even when the app is installed
>
> Cannot redirection jumps to app store when the app is  not installed on FIREFOX 
>


After investigating I found the issue on TWP side. When clicking on the app item on TWP website, on mobile it will do 2 actions
1. Open a deep link
2. Open the app store link after time out.

So we have to check if the app opened successfully then it does not redirect to the app store.

## Propose

- Use `document.hidden` to check if the app has opened successfully.
- Use an `iframe` instead of `window.location` to prevent the browser from automatically falling back.
- Only redirect to the store if the app does not open after a few seconds.

```js

const handleTwakeMailLink = (deepLink) => {
  const playStoreUrl =
    'https://play.google.com/store/apps/details?id=com.linagora.android.teammail&hl=en';

  // Create an iframe to open the deep link
  const iframe = document.createElement("iframe");
  iframe.style.display = "none";
  iframe.src = deepLink;
  document.body.appendChild(iframe);

  // Set a timeout to redirect if the app doesn't open
  const timeout = setTimeout(() => {
    if (!document.hidden) {
      window.location.href = playStoreUrl;
    }
  }, 2000);

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      clearTimeout(timeout);
    }
  });

  // Remove the iframe after 3 seconds to avoid DOM clutter
  setTimeout(() => {
    document.body.removeChild(iframe);
  }, 3000);
};


```


@hoangdat @rezk2ll

### Comment by dab246 at 2025-02-21T10:03:36Z

> ## Support Cyrus server
> Cannot send email
> 

Fixed at https://github.com/linagora/tmail-flutter/pull/3505

### Comment by hoangdat at 2025-02-25T14:48:16Z

- [x] release v0.14.14 with fix for Cyrus and add translation

### Comment by rezk2ll at 2025-02-28T15:55:56Z

> > ## Twake Workplace redirect
> > Redirection jumps to app store even when the app is installed
> > Cannot redirection jumps to app store when the app is  not installed on FIREFOX
> 
> After investigating I found the issue on TWP side. When clicking on the app item on TWP website, on mobile it will do 2 actions
> 
> 1. Open a deep link
> 2. Open the app store link after time out.
> 
> So we have to check if the app opened successfully then it does not redirect to the app store.
> 
> ## Propose
> * Use `document.hidden` to check if the app has opened successfully.
> * Use an `iframe` instead of `window.location` to prevent the browser from automatically falling back.
> * Only redirect to the store if the app does not open after a few seconds.
> 
> const handleTwakeMailLink = (deepLink) => {
>   const playStoreUrl =
>     'https://play.google.com/store/apps/details?id=com.linagora.android.teammail&hl=en';
> 
>   // Create an iframe to open the deep link
>   const iframe = document.createElement("iframe");
>   iframe.style.display = "none";
>   iframe.src = deepLink;
>   document.body.appendChild(iframe);
> 
>   // Set a timeout to redirect if the app doesn't open
>   const timeout = setTimeout(() => {
>     if (!document.hidden) {
>       window.location.href = playStoreUrl;
>     }
>   }, 2000);
> 
>   document.addEventListener("visibilitychange", () => {
>     if (document.hidden) {
>       clearTimeout(timeout);
>     }
>   });
> 
>   // Remove the iframe after 3 seconds to avoid DOM clutter
>   setTimeout(() => {
>     document.body.removeChild(iframe);
>   }, 3000);
> };
> [@hoangdat](https://github.com/hoangdat) [@rezk2ll](https://github.com/rezk2ll)

I found another proper solution using `document.hasFocus` method.

it is deployed to staging for testing now

### Comment by dab246 at 2025-03-04T03:19:52Z

> 
> I found another proper solution using `document.hasFocus` method.
> 
> it is deployed to staging for testing now

I checked on stg, but it still fails, please try again @rezk2ll 


https://github.com/user-attachments/assets/bfde1f7e-e580-4cb9-af7b-ab2f39e51a0d

### Comment by rezk2ll at 2025-03-04T08:33:42Z

> > I found another proper solution using `document.hasFocus` method.
> > it is deployed to staging for testing now
> 
> I checked on stg, but it still fails, please try again [@rezk2ll](https://github.com/rezk2ll)
> 
>  ScreenRecording_03-04-2025.10-17-22_1.MP4

in the demo, did you hit the back button right after opening the tmail application or it happened on it's own?

### Comment by dab246 at 2025-03-04T08:54:05Z

> > > I found another proper solution using `document.hasFocus` method.
> > > it is deployed to staging for testing now
> > 
> > 
> > I checked on stg, but it still fails, please try again [@rezk2ll](https://github.com/rezk2ll)
> 
> in the demo, did you hit the back button right after opening the tmail application or it happened on it's own?

I did nothing, just clicked Mail item in TWP page and it happened by itself.
