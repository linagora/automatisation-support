# GitHub issue #880: [Dev] Apply new design for rich text on mobile on new repository Linagora

## Metadata

Repository: linagora/tmail-flutter
Issue number: 880
State: closed
Author: dab246
Created at: 2022-08-24T10:12:39Z
Updated at: 2022-12-01T09:27:37Z
Closed at: 2022-12-01T09:27:37Z
Labels: 0
Assignees: ManhNTX
URL: https://github.com/linagora/tmail-flutter/issues/880

## Issue body

### DoD
- Create new repository on Linagora with name `Rich-Text-Composer`
- Figma: [https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=5221%3A250131](https://www.figma.com/file/rRVxJpCu1G22D0jqyvK7I9/TeamMail?node-id=5221%3A250131)
- Show list button on keyboard for Mobile
![Screen Shot 2022-09-05 at 10.29.33.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/ee7dac84-5f88-4ce1-84f3-06eec4fb08c7)
- Apply new design for `Format` popup menu
![Screen Shot 2022-09-05 at 10.35.52.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/93404a4f-482c-46cb-9e0d-84a949f1e760)

## Comments

### Comment by dab246 at 2022-09-20T06:17:21Z

1 HD

### Comment by dab246 at 2022-09-21T02:53:39Z

1 HD

### Comment by dab246 at 2022-09-22T02:55:47Z

2 HD

### Comment by hoangdat at 2022-09-22T04:59:35Z

@ManhNTX please note that, stop the ticket after success 
```
Show list button on keyboard for Mobile
```
with function: `image`, `attachment` (style will be applied in other ticket)
for both android/iOS, and tablet.

### Comment by dab246 at 2022-09-23T02:47:37Z

2 HD

### Comment by dab246 at 2022-09-26T02:34:24Z

2 HD

### Comment by dab246 at 2022-09-27T02:23:10Z

2 HD

### Comment by dab246 at 2022-09-28T02:36:55Z

2 HD

### Comment by dab246 at 2022-09-29T03:00:38Z

2 HD

### Comment by dab246 at 2022-09-30T02:38:38Z

2 HD

### Comment by dab246 at 2022-09-30T02:52:18Z

Use https://github.com/linagora/rich-text-composer/pull/4
