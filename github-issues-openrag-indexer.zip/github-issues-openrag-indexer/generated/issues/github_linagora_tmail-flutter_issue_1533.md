# GitHub issue #1533: [EmailSearching] Logic of searching function is not correctly

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1533
State: closed
Author: QuangHoang1210
Created at: 2023-03-06T05:54:13Z
Updated at: 2023-03-15T06:53:29Z
Closed at: 2023-03-15T06:53:28Z
Labels: bug, back-end implementing
Assignees: ManhNTX
URL: https://github.com/linagora/tmail-flutter/issues/1533

## Issue body

OS: Window / ios / andoird
Device: Laptop / mobile
TMail version: 0.7.1 <production>


*Reproduce Step:
1, User login sucessfully
2, User click to search and input "dat" into search textbox --> press Enter to get the searching result
3, User click to search and input "hoangdat" into search textbox --> press Enter to get the searching result
4, User click to search and input "dat" into search textbox --> press Enter to get the searching result

Actual: System will search the email contain "searching keywords" from the previous searching result
Expected: System should search the email contain "searching keywords" from all email


https://user-images.githubusercontent.com/124866146/223029195-02194a2f-28b3-4305-9be6-0d320ec7bd1a.mp4

## Comments

### Comment by chibenwa at 2023-03-06T08:11:57Z

@QuangHoang1210 Please give the details of each and every JMAP request emmitted...

### Comment by QuangHoang1210 at 2023-03-06T08:23:43Z

JMAP: https://jmap.linagora.com/jmap
Request Method: POST

Payload: `{"using":["urn:ietf:params:jmap:core","urn:ietf:params:jmap:mail"],"methodCalls":[["Email/query",{"accountId":"912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd","filter":{"operator":"AND","conditions":[{"before":"2023-02-13T12:01:26.000Z","text":"dat"}]},"sort":[{"isAscending":false,"property":"receivedAt"}],"limit":5},"c0"],["Email/get",{"accountId":"912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd","#ids":{"resultOf":"c0","name":"Email/query","path":"/ids/*"},"properties":["id","subject","from","to","keywords","receivedAt","sentAt","preview","hasAttachment","mailboxIds"]},"c1"]]}`

Response: `{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/query",
      {
        "accountId": "912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd",
        "queryState": "af7aec47",
        "canCalculateChanges": false,
        "ids": [
          "246d7270-ab96-11ed-aef6-65eed79c126f",
          "d2860a30-ab95-11ed-aef6-65eed79c126f",
          "d085cd60-ab95-11ed-aef6-65eed79c126f",
          "66bbf860-a8e7-11ed-aef6-65eed79c126f",
          "5be7c0e0-a8e7-11ed-aef6-65eed79c126f"
        ],
        "position": 0
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd",
        "notFound": [],
        "state": "a3133f90-bbf6-11ed-ac1a-8ff6338155e4",
        "list": [
          {
            "subject": "[linagora/tmail-flutter] Verify the app in browsers [Safari, Firefox, ...] (Issue #1448)",
            "preview": "— Reply to this email directly, view it on GitHub, or unsubscribe. You are receiving this because you were assigned.Message ID: <linagora/tmail-flutter/issues/1448@github.com>",
            "to": [
              {
                "name": "linagora/tmail-flutter",
                "email": "tmail-flutter@noreply.github.com"
              }
            ],
            "id": "d2860a30-ab95-11ed-aef6-65eed79c126f",
            "mailboxIds": {
              "81b9c2b0-a823-11ed-aef6-65eed79c126f": true
            },
            "from": [
              {
                "name": "Dat H. Pham",
                "email": "notifications@github.com"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-02-13T11:59:08Z",
            "sentAt": "2023-02-13T11:59:01Z",
            "hasAttachment": false
          },
          {
            "subject": "Re: [linagora/tmail-flutter] Verify the app in browsers [Safari, Firefox, ...] (Issue #1448)",
            "preview": "Deadline: Friday 17thFeb — Reply to this email directly, view it on GitHub, or unsubscribe. You are receiving this because you were assigned.Message ID: <linagora/tmail-flutter/issues/1448/1427823097@github.com>",
            "to": [
              {
                "name": "linagora/tmail-flutter",
                "email": "tmail-flutter@noreply.github.com"
              }
            ],
            "id": "246d7270-ab96-11ed-aef6-65eed79c126f",
            "mailboxIds": {
              "81b9c2b0-a823-11ed-aef6-65eed79c126f": true
            },
            "from": [
              {
                "name": "Dat H. Pham",
                "email": "notifications@github.com"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-02-13T12:01:26Z",
            "sentAt": "2023-02-13T12:01:21Z",
            "hasAttachment": false
          },
          {
            "subject": "New event from Dat PHAM HOANG: Twake mobile daily",
            "preview": "Dat PHAM HOANG has invited you to a meeting Twake mobile daily TimeMonday 16 January 2023 10:00 AM - 10:15 AM Asia/Saigon (See in Calendar)Attendees - Dat PHAM HOANG <dphamhoang@linagora.com> (Organizer) - Tuan Manh NGUYEN <tmnguyen@linagora.com> - Nhat Qu",
            "to": [
              {
                "email": "nqnguyen@linagora.com"
              }
            ],
            "id": "66bbf860-a8e7-11ed-aef6-65eed79c126f",
            "mailboxIds": {
              "81b9c2b0-a823-11ed-aef6-65eed79c126f": true
            },
            "from": [
              {
                "email": "dphamhoang@linagora.com"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-02-10T02:05:33Z",
            "sentAt": "2023-02-10T02:05:32Z",
            "hasAttachment": true
          },
          {
            "subject": "New event from Dat PHAM HOANG: TeamMail daily",
            "preview": "Dat PHAM HOANG has invited you to a meeting TeamMail daily TimeFriday 22 October 2021 09:30 AM - 09:45 AM Asia/Saigon (See in Calendar)Attendees - Dat PHAM HOANG <dphamhoang@linagora.com> (Organizer) - The Dat VU <tdvu@linagora.com> - Quang Huy NGUYEN <qhu",
            "to": [
              {
                "email": "nqnguyen@linagora.com"
              }
            ],
            "id": "5be7c0e0-a8e7-11ed-aef6-65eed79c126f",
            "mailboxIds": {
              "81b9c2b0-a823-11ed-aef6-65eed79c126f": true
            },
            "from": [
              {
                "email": "dphamhoang@linagora.com"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-02-10T02:05:15Z",
            "sentAt": "2023-02-10T02:05:10Z",
            "hasAttachment": true
          },
          {
            "subject": "Re: [linagora/tmail-flutter] Verify the app in browsers [Safari, Firefox, ...] (Issue #1448)",
            "preview": "Assigned #1448 to @QuangHoang1210. — Reply to this email directly, view it on GitHub, or unsubscribe. You are receiving this because you were assigned.Message ID: <linagora/tmail-flutter/issue/1448/issue_event/8503613151@github.com>",
            "to": [
              {
                "name": "linagora/tmail-flutter",
                "email": "tmail-flutter@noreply.github.com"
              }
            ],
            "id": "d085cd60-ab95-11ed-aef6-65eed79c126f",
            "mailboxIds": {
              "81b9c2b0-a823-11ed-aef6-65eed79c126f": true
            },
            "from": [
              {
                "name": "Dat H. Pham",
                "email": "notifications@github.com"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-02-13T11:59:05Z",
            "sentAt": "2023-02-13T11:59:00Z",
            "hasAttachment": false
          }
        ]
      },
      "c1"
    ]
  ]
}`

### Comment by chibenwa at 2023-03-06T09:41:23Z

Ok, so do this for 2, 3, 4.

Use jsonlint.com/ for formatting please

### Comment by QuangHoang1210 at 2023-03-06T10:32:28Z

I can't reproduce this one already. Trying to reproduce then I will provide the beautiful json haha

### Comment by chibenwa at 2023-03-06T10:37:33Z

Let's have a label for bugs waiting reproduction then. WDYT?

### Comment by QuangHoang1210 at 2023-03-06T10:40:27Z

Yep. I'll add more information immediately once I can reproduce this one

### Comment by QuangHoang1210 at 2023-03-07T03:20:50Z

Step:
1, User search with text "Vu"
```
curl 'https://jmap.linagora.com/jmap' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Connection: keep-alive' \
  -H 'Origin: https://tmail.linagora.com' \
  -H 'Referer: https://tmail.linagora.com/' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Site: same-site' \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36' \
  -H 'accept: application/json;jmapVersion=rfc-8621' \
  -H 'content-type: application/json' \
  -H 'sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-platform: "Windows"' \
  --data-raw '{"using":["urn:ietf:params:jmap:core","urn:ietf:params:jmap:mail"],"methodCalls":[["Email/query",{"accountId":"912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd","filter":{"operator":"AND","conditions":[{"text":"Vu","subject":""},{"operator":"AND","conditions":[{"from":"dat"}]}]},"sort":[{"isAscending":false,"property":"receivedAt"}],"limit":20},"c0"],["Email/get",{"accountId":"912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd","#ids":{"resultOf":"c0","name":"Email/query","path":"/ids/*"},"properties":["id","subject","from","to","cc","bcc","keywords","size","receivedAt","sentAt","preview","hasAttachment","replyTo","mailboxIds"]},"c1"]]}' \
  --compressed
```


2, User search with text "Dat Vu"

```
curl 'https://jmap.linagora.com/jmap' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Connection: keep-alive' \
  -H 'Origin: https://tmail.linagora.com' \
  -H 'Referer: https://tmail.linagora.com/' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Site: same-site' \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36' \
  -H 'accept: application/json;jmapVersion=rfc-8621' \
  -H 'content-type: application/json' \
  -H 'sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-platform: "Windows"' \
  --data-raw '{"using":["urn:ietf:params:jmap:core","urn:ietf:params:jmap:mail"],"methodCalls":[["Email/query",{"accountId":"912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd","filter":{"operator":"AND","conditions":[{"text":"Dat Vu","subject":""},{"operator":"AND","conditions":[{"from":"dat"}]}]},"sort":[{"isAscending":false,"property":"receivedAt"}],"limit":20},"c0"],["Email/get",{"accountId":"912618096e03fb03fe14293a97102272d4875bd9c3d80ad49de32c58bb4b28bd","#ids":{"resultOf":"c0","name":"Email/query","path":"/ids/*"},"properties":["id","subject","from","to","cc","bcc","keywords","size","receivedAt","sentAt","preview","hasAttachment","replyTo","mailboxIds"]},"c1"]]}' \
  --compressed
```

https://user-images.githubusercontent.com/124866146/223311829-a61166d5-dfe1-417c-be7c-4a7c1a249f1b.mp4

### Comment by hoangdat at 2023-03-07T03:26:26Z

checking with Quang's response

### Comment by dab246 at 2023-03-15T02:45:37Z

Fixed on version `v0.7.4`

### Comment by QuangHoang1210 at 2023-03-15T05:00:32Z

reproduce on preprod 0.7.4:

Step:
1, User search with 'wang'
**Request payload:**
```
`{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail"
  ],
  "methodCalls": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "filter": {
          "operator": "AND",
          "conditions": [
            {
              "text": "wang"
            }
          ]
        },
        "sort": [
          {
            "isAscending": false,
            "property": "receivedAt"
          }
        ],
        "limit": 20
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "#ids": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        },
        "properties": [
          "id",
          "subject",
          "from",
          "to",
          "cc",
          "bcc",
          "keywords",
          "size",
          "receivedAt",
          "sentAt",
          "preview",
          "hasAttachment",
          "replyTo",
          "mailboxIds"
        ]
      },
      "c1"
    ]
  ]
}`
```

**Response payload:**
```
`{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "queryState": "32f74c20",
        "canCalculateChanges": false,
        "ids": [
          "e3cec650-c243-11ed-8a14-a7f3fbfdb520",
          "3f830b70-c184-11ed-8a14-a7f3fbfdb520",
          "dbfa4180-c157-11ed-8c44-99a9242b6bc0",
          "019b2fe0-c152-11ed-8c44-99a9242b6bc0",
          "18b80220-b27a-11ed-8e2c-f549e2a24cfd",
          "e5e4afb0-b279-11ed-8e2c-f549e2a24cfd",
          "e466c240-b279-11ed-8e2c-f549e2a24cfd",
          "d88b7b00-b279-11ed-8e2c-f549e2a24cfd",
          "d579ce30-b279-11ed-8e2c-f549e2a24cfd",
          "d63fdbe0-b08d-11ed-8e2c-f549e2a24cfd",
          "d4c6f780-b08d-11ed-8e2c-f549e2a24cfd",
          "85723110-af19-11ed-8e2c-f549e2a24cfd",
          "e53f6fe0-af14-11ed-8e2c-f549e2a24cfd"
        ],
        "position": 0
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "5b271760-c2ae-11ed-8a14-a7f3fbfdb520",
        "list": [
          {
            "replyTo": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "preview": "Okk nhe -- Wang đẹp zai",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "e53f6fe0-af14-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "fff9f670-30a9-11eb-9a8d-254ee97830fe": true
            },
            "from": [
              {
                "name": "wwang",
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-17T22:46:19Z",
            "sentAt": "2023-02-17T22:46:15Z",
            "hasAttachment": false,
            "subject": "wang1",
            "size": 1354
          },
          {
            "replyTo": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "preview": "-- Wang đẹp zai",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "dbfa4180-c157-11ed-8c44-99a9242b6bc0",
            "mailboxIds": {
              "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "wwang",
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-03-13T04:31:01Z",
            "sentAt": "2023-03-13T04:30:50Z",
            "hasAttachment": false,
            "subject": "Test 1 rules",
            "size": 1343
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "âcca",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "d579ce30-b279-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Wang1",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-22T06:26:26Z",
            "hasAttachment": false,
            "subject": "Wang only wang",
            "size": 1062,
            "cc": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "sentAt": "2023-02-22T06:26:26Z"
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "On Feb 22, 2023 1:26 PM, from Wang1 âcca -- -- Quang Dep Trai 1 Link công ty: https://www.google.com/ Phone number: 090909090",
            "id": "e466c240-b279-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Wang1",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$draft": true,
              "$seen": true
            },
            "receivedAt": "2023-02-22T06:26:51Z",
            "sentAt": "2023-02-22T06:26:51Z",
            "hasAttachment": false,
            "subject": "Re: Wang only wang",
            "size": 1636
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "------- Forwarded message ------- Subject: OK k Date: Feb 18, 2023 6:19 AM From: Wwang To: firstname31.surname31@upn.integration-open-paas.org Oksbz -- Wang đẹp zai -- ok",
            "id": "d63fdbe0-b08d-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Wang2",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$draft": true,
              "$seen": true
            },
            "receivedAt": "2023-02-19T19:44:34Z",
            "sentAt": "2023-02-19T19:44:34Z",
            "hasAttachment": false,
            "subject": "Fwd: OK k",
            "size": 1916
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "ok duoc day  On Feb 22, 2023 1:26 PM, from Wang1 âcca -- https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https:/",
            "to": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "id": "18b80220-b27a-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Wang2",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-22T06:28:18Z",
            "sentAt": "2023-02-22T06:28:18Z",
            "hasAttachment": false,
            "subject": "Re: Wang only wang",
            "size": 2661
          },
          {
            "replyTo": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "preview": "Oksbz -- Wang đẹp zai",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "85723110-af19-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "fff9f670-30a9-11eb-9a8d-254ee97830fe": true
            },
            "from": [
              {
                "name": "wwang",
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-17T23:19:26Z",
            "sentAt": "2023-02-17T23:19:17Z",
            "hasAttachment": false,
            "subject": "OK k",
            "size": 1349
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "âcca",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "d88b7b00-b279-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "fff9f670-30a9-11eb-9a8d-254ee97830fe": true
            },
            "from": [
              {
                "name": "Wang1",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-02-22T06:26:31Z",
            "hasAttachment": false,
            "subject": "Wang only wang",
            "size": 1248,
            "cc": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "sentAt": "2023-02-22T06:26:26Z"
          },
          {
            "replyTo": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "preview": "-- Wang đẹp zai",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "019b2fe0-c152-11ed-8c44-99a9242b6bc0",
            "mailboxIds": {
              "fff9f670-30a9-11eb-9a8d-254ee97830fe": true
            },
            "from": [
              {
                "name": "wwang",
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$seen": true
            },
            "receivedAt": "2023-03-13T03:49:07Z",
            "sentAt": "2023-03-13T03:48:54Z",
            "hasAttachment": false,
            "subject": "Test rule 1",
            "size": 1342
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "On Feb 22, 2023 1:26 PM, from Wang1 âcca -- -- Quang Dep Trai 1 Link công ty: https://www.google.com/ Phone number: 090909090",
            "id": "e5e4afb0-b279-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Wang1",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$draft": true,
              "$seen": true
            },
            "receivedAt": "2023-02-22T06:26:53Z",
            "hasAttachment": false,
            "subject": "Re: Wang only wang",
            "size": 1693,
            "cc": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "sentAt": "2023-02-22T06:26:53Z"
          },
          {
            "replyTo": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "preview": "-- Wang đẹp zai",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              },
              {
                "email": "binlinzin@gmail.com"
              }
            ],
            "id": "e3cec650-c243-11ed-8a14-a7f3fbfdb520",
            "mailboxIds": {
              "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "wwang",
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-03-14T08:40:35Z",
            "sentAt": "2023-03-14T08:40:24Z",
            "hasAttachment": false,
            "subject": "Test WANG WNAG",
            "size": 1366
          },
          {
            "replyTo": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "preview": "ádadadad -- Wang đẹp zai",
            "to": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "id": "3f830b70-c184-11ed-8a14-a7f3fbfdb520",
            "mailboxIds": {
              "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "wwang",
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "keywords": {},
            "receivedAt": "2023-03-13T09:48:46Z",
            "sentAt": "2023-03-13T09:48:35Z",
            "hasAttachment": false,
            "subject": "oke",
            "size": 1360
          },
          {
            "replyTo": [
              {
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "preview": "On Feb 18, 2023 6:19 AM, from Wwang Oksbz -- Wang đẹp zai -- ok",
            "to": [
              {
                "email": "firstname27.surname27@upn.integration-open-paas.org"
              }
            ],
            "id": "d4c6f780-b08d-11ed-8e2c-f549e2a24cfd",
            "mailboxIds": {
              "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true
            },
            "from": [
              {
                "name": "Wang2",
                "email": "firstname31.surname31@upn.integration-open-paas.org"
              }
            ],
            "keywords": {
              "$draft": true,
              "$seen": true
            },
            "receivedAt": "2023-02-19T19:44:32Z",
            "sentAt": "2023-02-19T19:44:32Z",
            "hasAttachment": false,
            "subject": "Re: OK k",
            "size": 1720
          }
        ]
      },
      "c1"
    ]
  ]
}`
```

2, User search with 'ww'
**Request payload:**
```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail"
  ],
  "methodCalls": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "filter": {
          "operator": "AND",
          "conditions": [
            {
              "text": "ww"
            }
          ]
        },
        "sort": [
          {
            "isAscending": false,
            "property": "receivedAt"
          }
        ],
        "limit": 20
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "#ids": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        },
        "properties": [
          "id",
          "subject",
          "from",
          "to",
          "cc",
          "bcc",
          "keywords",
          "size",
          "receivedAt",
          "sentAt",
          "preview",
          "hasAttachment",
          "replyTo",
          "mailboxIds"
        ]
      },
      "c1"
    ]
  ]
}
```

**Response payload:**
```
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "queryState": "00000000",
        "canCalculateChanges": false,
        "ids": [],
        "position": 0
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "5b271760-c2ae-11ed-8a14-a7f3fbfdb520",
        "list": []
      },
      "c1"
    ]
  ]
}
```


--- Actual: No result which containt 'ww' is displayed although there is exist email having ww
--- Expected: It should display email containt 'ww' matching with search condition



https://user-images.githubusercontent.com/124866146/225211427-830d5557-d86e-4aa2-b887-ce941ae2a9f5.mp4

### Comment by dab246 at 2023-03-15T05:09:59Z

> reproduce on preprod 0.7.4:
> 
> Step: 1, User search with 'wang' **Request payload:** `{ "using": [ "urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail" ], "methodCalls": [ [ "Email/query", { "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b", "filter": { "operator": "AND", "conditions": [ { "text": "wang" } ] }, "sort": [ { "isAscending": false, "property": "receivedAt" } ], "limit": 20 }, "c0" ], [ "Email/get", { "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b", "#ids": { "resultOf": "c0", "name": "Email/query", "path": "/ids/*" }, "properties": [ "id", "subject", "from", "to", "cc", "bcc", "keywords", "size", "receivedAt", "sentAt", "preview", "hasAttachment", "replyTo", "mailboxIds" ] }, "c1" ] ] }`
> 
> **Response payload:** `{ "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943", "methodResponses": [ [ "Email/query", { "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b", "queryState": "32f74c20", "canCalculateChanges": false, "ids": [ "e3cec650-c243-11ed-8a14-a7f3fbfdb520", "3f830b70-c184-11ed-8a14-a7f3fbfdb520", "dbfa4180-c157-11ed-8c44-99a9242b6bc0", "019b2fe0-c152-11ed-8c44-99a9242b6bc0", "18b80220-b27a-11ed-8e2c-f549e2a24cfd", "e5e4afb0-b279-11ed-8e2c-f549e2a24cfd", "e466c240-b279-11ed-8e2c-f549e2a24cfd", "d88b7b00-b279-11ed-8e2c-f549e2a24cfd", "d579ce30-b279-11ed-8e2c-f549e2a24cfd", "d63fdbe0-b08d-11ed-8e2c-f549e2a24cfd", "d4c6f780-b08d-11ed-8e2c-f549e2a24cfd", "85723110-af19-11ed-8e2c-f549e2a24cfd", "e53f6fe0-af14-11ed-8e2c-f549e2a24cfd" ], "position": 0 }, "c0" ], [ "Email/get", { "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b", "notFound": [], "state": "5b271760-c2ae-11ed-8a14-a7f3fbfdb520", "list": [ { "replyTo": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "preview": "Okk nhe -- Wang đẹp zai", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "e53f6fe0-af14-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "fff9f670-30a9-11eb-9a8d-254ee97830fe": true }, "from": [ { "name": "wwang", "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-02-17T22:46:19Z", "sentAt": "2023-02-17T22:46:15Z", "hasAttachment": false, "subject": "wang1", "size": 1354 }, { "replyTo": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "preview": "-- Wang đẹp zai", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "dbfa4180-c157-11ed-8c44-99a9242b6bc0", "mailboxIds": { "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "wwang", "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-03-13T04:31:01Z", "sentAt": "2023-03-13T04:30:50Z", "hasAttachment": false, "subject": "Test 1 rules", "size": 1343 }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "âcca", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "d579ce30-b279-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "Wang1", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-02-22T06:26:26Z", "hasAttachment": false, "subject": "Wang only wang", "size": 1062, "cc": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "sentAt": "2023-02-22T06:26:26Z" }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "On Feb 22, 2023 1:26 PM, from Wang1 âcca -- -- Quang Dep Trai 1 Link công ty: https://www.google.com/ Phone number: 090909090", "id": "e466c240-b279-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "Wang1", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$draft": true, "$seen": true }, "receivedAt": "2023-02-22T06:26:51Z", "sentAt": "2023-02-22T06:26:51Z", "hasAttachment": false, "subject": "Re: Wang only wang", "size": 1636 }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "------- Forwarded message ------- Subject: OK k Date: Feb 18, 2023 6:19 AM From: Wwang To: firstname31.surname31@upn.integration-open-paas.org Oksbz -- Wang đẹp zai -- ok", "id": "d63fdbe0-b08d-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "Wang2", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$draft": true, "$seen": true }, "receivedAt": "2023-02-19T19:44:34Z", "sentAt": "2023-02-19T19:44:34Z", "hasAttachment": false, "subject": "Fwd: OK k", "size": 1916 }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "ok duoc day On Feb 22, 2023 1:26 PM, from Wang1 âcca -- https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https://www.google.com/ https:/", "to": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "id": "18b80220-b27a-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "Wang2", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-02-22T06:28:18Z", "sentAt": "2023-02-22T06:28:18Z", "hasAttachment": false, "subject": "Re: Wang only wang", "size": 2661 }, { "replyTo": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "preview": "Oksbz -- Wang đẹp zai", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "85723110-af19-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "fff9f670-30a9-11eb-9a8d-254ee97830fe": true }, "from": [ { "name": "wwang", "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-02-17T23:19:26Z", "sentAt": "2023-02-17T23:19:17Z", "hasAttachment": false, "subject": "OK k", "size": 1349 }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "âcca", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "d88b7b00-b279-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "fff9f670-30a9-11eb-9a8d-254ee97830fe": true }, "from": [ { "name": "Wang1", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-02-22T06:26:31Z", "hasAttachment": false, "subject": "Wang only wang", "size": 1248, "cc": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "sentAt": "2023-02-22T06:26:26Z" }, { "replyTo": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "preview": "-- Wang đẹp zai", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "019b2fe0-c152-11ed-8c44-99a9242b6bc0", "mailboxIds": { "fff9f670-30a9-11eb-9a8d-254ee97830fe": true }, "from": [ { "name": "wwang", "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "keywords": { "$seen": true }, "receivedAt": "2023-03-13T03:49:07Z", "sentAt": "2023-03-13T03:48:54Z", "hasAttachment": false, "subject": "Test rule 1", "size": 1342 }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "On Feb 22, 2023 1:26 PM, from Wang1 âcca -- -- Quang Dep Trai 1 Link công ty: https://www.google.com/ Phone number: 090909090", "id": "e5e4afb0-b279-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "Wang1", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$draft": true, "$seen": true }, "receivedAt": "2023-02-22T06:26:53Z", "hasAttachment": false, "subject": "Re: Wang only wang", "size": 1693, "cc": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "sentAt": "2023-02-22T06:26:53Z" }, { "replyTo": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "preview": "-- Wang đẹp zai", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" }, { "email": "binlinzin@gmail.com" } ], "id": "e3cec650-c243-11ed-8a14-a7f3fbfdb520", "mailboxIds": { "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "wwang", "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "keywords": {}, "receivedAt": "2023-03-14T08:40:35Z", "sentAt": "2023-03-14T08:40:24Z", "hasAttachment": false, "subject": "Test WANG WNAG", "size": 1366 }, { "replyTo": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "preview": "ádadadad -- Wang đẹp zai", "to": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "id": "3f830b70-c184-11ed-8a14-a7f3fbfdb520", "mailboxIds": { "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "wwang", "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "keywords": {}, "receivedAt": "2023-03-13T09:48:46Z", "sentAt": "2023-03-13T09:48:35Z", "hasAttachment": false, "subject": "oke", "size": 1360 }, { "replyTo": [ { "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "preview": "On Feb 18, 2023 6:19 AM, from Wwang Oksbz -- Wang đẹp zai -- ok", "to": [ { "email": "firstname27.surname27@upn.integration-open-paas.org" } ], "id": "d4c6f780-b08d-11ed-8e2c-f549e2a24cfd", "mailboxIds": { "9d0a0230-32cf-11eb-995c-a3ae66e9f96a": true }, "from": [ { "name": "Wang2", "email": "firstname31.surname31@upn.integration-open-paas.org" } ], "keywords": { "$draft": true, "$seen": true }, "receivedAt": "2023-02-19T19:44:32Z", "sentAt": "2023-02-19T19:44:32Z", "hasAttachment": false, "subject": "Re: OK k", "size": 1720 } ] }, "c1" ] ] }`
> 
> 2, User search with 'ww' **Request payload:**
> 
> ```
> {
>   "using": [
>     "urn:ietf:params:jmap:core",
>     "urn:ietf:params:jmap:mail"
>   ],
>   "methodCalls": [
>     [
>       "Email/query",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "filter": {
>           "operator": "AND",
>           "conditions": [
>             {
>               "text": "ww"
>             }
>           ]
>         },
>         "sort": [
>           {
>             "isAscending": false,
>             "property": "receivedAt"
>           }
>         ],
>         "limit": 20
>       },
>       "c0"
>     ],
>     [
>       "Email/get",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "#ids": {
>           "resultOf": "c0",
>           "name": "Email/query",
>           "path": "/ids/*"
>         },
>         "properties": [
>           "id",
>           "subject",
>           "from",
>           "to",
>           "cc",
>           "bcc",
>           "keywords",
>           "size",
>           "receivedAt",
>           "sentAt",
>           "preview",
>           "hasAttachment",
>           "replyTo",
>           "mailboxIds"
>         ]
>       },
>       "c1"
>     ]
>   ]
> }
> ```
> 
> **Response payload:**
> 
> ```
> {
>   "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
>   "methodResponses": [
>     [
>       "Email/query",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "queryState": "00000000",
>         "canCalculateChanges": false,
>         "ids": [],
>         "position": 0
>       },
>       "c0"
>     ],
>     [
>       "Email/get",
>       {
>         "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
>         "notFound": [],
>         "state": "5b271760-c2ae-11ed-8a14-a7f3fbfdb520",
>         "list": []
>       },
>       "c1"
>     ]
>   ]
> }
> ```
> 
> --- Actual: No result which containt 'ww' is displayed although there is exist email having ww --- Expected: It should display email containt 'ww' matching with search condition

@Arsnael Is this a bug from the back-end?

### Comment by chibenwa at 2023-03-15T06:53:28Z

No we do **NOT SUPPORT** partial search on words.

That's not how efficient search works, at scale.

Not getting any results for searching `ww` is **expected**.
