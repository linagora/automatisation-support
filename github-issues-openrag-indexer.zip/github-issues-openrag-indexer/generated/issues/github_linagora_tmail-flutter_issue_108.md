# GitHub issue #108: [Story] Cache email 

## Metadata

Repository: linagora/tmail-flutter
Issue number: 108
State: closed
Author: hoangdat
Created at: 2021-09-18T09:22:04Z
Updated at: 2022-01-05T04:40:05Z
Closed at: 2022-01-05T04:40:05Z
Labels: 
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/108

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition

```
Given I am a user of Tmail, I logged in the app before
Then I open the application to check the email but no network connection
I want to read last emails I received in the app
```

```
Given I am a user of Tmail, I logged in the app before
Then I want to refresh the mailbox to get all the changes of this mailbox
I pull to refresh, mailbox is update with latest change
Data in the cache should be synchronize 
```

```
Given I am a user of Tmail, I logged in the app before
Then I want to access the email as fast as possible
Application use caching to improve that but I don't want the data of Tmail grow too much and impact to the storage size of mobile device
```
[Back to Summary](#summary)

## Screenshots

None

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by chibenwa at 2021-09-20T04:21:06Z

## Resynchronizing mailboxes

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
  "methodCalls": [
    ["Mailbox/changes", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "sinceState": "d34rtfedferte",
      "maxChanges": 128
    }, "c1"],
    ["Mailbox/get", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "#properties": {
        "resultOf": "c1",
        "name": "Mailbox/changes",
        "path": "updatedProperties"
      },
      "#ids": {
        "resultOf": "c1",
        "name": "Mailbox/changes",
        "path": "/updated"
      }
    }, "c2"],
    ["Mailbox/get", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "#ids": {
        "resultOf": "c1",
        "name": "Mailbox/changes",
        "path": "/created"
      }
    }, "c3"],
  ]
}
```

Will return

```
{
    "sessionState": "abcdefgh",
    "methodResponses": [
      [ "Mailbox/changes", {
        "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
        "oldState": "d34rtfedferte",
        "newState": "auergerkerkbeververbbsvrb",
        "hasMoreChanges": false,
        "updatedProperties": ["totalEmails", "unreadEmails", "totalThreads", "unreadThreads"],
        "created": ["24"],
        "updated": ["23"],
        "destroyed": ["25"]
      }, "c1"],
      ["Mailbox/get", {
        "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
        "notFound": [],
        "state": "auergerkerkbeververbbsvrb",
        "list": [
          {
            "id": "23",
            "totalEmails": 1,
            "unreadEmails": 1,
            "totalThreads": 1,
            "unreadThreads": 1
          }
        ]
      }, "c2"],
      ["Mailbox/get", {
        "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
        "notFound": [],
        "state": "auergerkerkbeververbbsvrb",
        "list": [
          {
            "id": "24",
            "name": "mailbox1",
            "sortOrder": 1000,
            "totalEmails": 1,
            "unreadEmails": 1,
            "totalThreads": 1,
            "unreadThreads": 1,
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "isSubscribed": false
          }
        ]
      }, "c3"]
    ]
}
```

`25` can be removed straight away ;-)

The state to use as a new state is the one returned by the `/changes` (to govern cache).

If there is more than `128` changes, just do a /get to retrieve all items.

Be ready to handle there errors by doing a /get to get all mailboxes:

```
{
  "sessionState": "abcdefgh",
  "methodResponses": [[
    "error", {
      "type": "cannotCalculateChanges",
      "description": "State '$state' could not be found"
    }, "c1"]
  ]
}
```

### Comment by hoangdat at 2021-09-20T04:45:43Z

Cool for mailbox. We will check in some days. Please help us on email to refresh `ThreadView`? @chibenwa

### Comment by chibenwa at 2021-09-20T04:50:22Z

## Resynchronysing emails

```
{
  "using": ["urn:ietf:params:jmap:core", "urn:ietf:params:jmap:mail"],
  "methodCalls": [
    ["Mailbox/changes", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "sinceState": "d34rtfedferte"
    }, "c1"],
    ["Mailbox/get", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "properties": ["mailboxIds", "keywords"],
      "#ids": {
        "resultOf": "c1",
        "name": "Email/changes",
        "path": "/updated"
      }
    }, "c2"],
    ["Email/get", {
      "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
      "#ids": {
        "resultOf": "c1",
        "name": "Email/changes",
        "path": "/created"
      },
      "properties": ["id", "subject", "from", "to", "cc", "bcc", "keywords", "size", "receivedAt", "sentAt", "replyTo", "preview", "hasAttachment"],
    }, "c3"],
  ]
}
```

Would return:

```
{
    "sessionState": "${SESSION_STATE.value}",
    "methodResponses": [
      [ "Email/changes", {
        "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
        "oldState": "d34rtfedferte",
        "newState": "auergerkerkbeververbbsvrb",
        "hasMoreChanges": false,
        "created": ["23"],
        "updated": ["24"],
        "destroyed": ["25"]
      }, "c1"],
      [ "Email/get", {
        "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
        "state": "auergerkerkbeververbbsvrb",
        "list": [{
              "id": "24",
              "keywords": { "$answered": true  },
              "mailboxIds": {"wvrwgwrbervwbwrbrbvre": true}
          }],
         "notFound": []
      }, "c2"],
      [ "Email/changes", {
        "accountId": "29883977c13473ae7cb7678ef767cbfbaffc8a44a6e463d971d23a65c1dc4af6",
        "state": "auergerkerkbeververbbsvrb",
        "list": [{
              "id": "23",
              "keywords": { "$answered": true  },
              "mailboxIds": {"wvrwgwrbervwbwrbrbvre": true},
              ...
          }],
         "notFound": []
      }, "c3"],
    ]
}
```

For created / updated emails you would need to see which mailbox of the cache it fits in, and if it is part of displayable elements (after the date).


If there is more than 128 changes, just do a /query & /get to retrieve all items.

Be ready to handle these errors by doing a /query + /get to get all email:

```
{
  "sessionState": "abcdefgh",
  "methodResponses": [[
    "error", {
      "type": "cannotCalculateChanges",
      "description": "State '$state' could not be found"
    }, "c1"]
  ]
}
```

### Comment by chibenwa at 2021-09-20T04:50:42Z

> Cool for mailbox. We will check in some days. Please help us on email to refresh ThreadView? @chibenwa

One minute!!! ;-)

### Comment by hoangdat at 2021-09-20T07:22:03Z

> "sinceState": "d34rtfedferte"

IMO it quite easier than we expect, but we are not sure if the cache have enough email from state `d34rtfedferte`(Fx), because we will delete all email in the cache more than 7 days (keep the cache not grow too much in limited storage in mobile)

### Comment by chibenwa at 2021-09-20T07:25:09Z

JMAP is designed to work with a small cache. I'm not worry.

### Comment by hoangdat at 2021-09-20T08:20:31Z

> JMAP is designed to work with a small cache. I'm not worry.

I can not get your point. I mean:

1. the cache  update with state A
2. then some mails in state A is deleted in cache (by some rules, Fx: email have sent at more than 7 day ago from now)
3. right now, state A is quite not consistent 
4. then we get `/chages` with `"sinceState": "A"` -> it quite we are missing some emails which we deleted in client (2)?

### Comment by chibenwa at 2021-09-20T09:12:58Z

No you will be told about deleted email, and you would be able to remove them from your cache if need be.

### Comment by hoangdat at 2021-09-20T09:18:15Z

First, please separate things: (i)deleted email by user and (ii)deleted email by cache manager.

i. I will update the cache as other `created`, `updated`. 

ii. we will clean up the cache periodically -> keep the cache in control, not grow too much. it will make the cache not consistent with the state, am I right?

### Comment by chibenwa at 2021-09-20T09:20:58Z

`/changes` returns deleted items (meaning deleted by other devices), so that you can update your cache (read again the above code examples with JMAP responses.)

### Comment by hoangdat at 2021-09-20T09:25:20Z

> `/changes` returns deleted items (meaning deleted by other devices), so that you can update your cache (read again the above code examples with JMAP responses.)

yes, I agree about that. I mention it in https://github.com/linagora/tmail-flutter/issues/108#issuecomment-922758380 (i)

But we need to discuss in (ii).

### Comment by chibenwa at 2021-09-20T09:30:23Z

> it will make the cache not consistent with the state, am I right?

Not really: if you have a clear rule of what fits in the cache and what don't fit, you know when you need to fetch more items.

EG you say "after 7 days -> out of cache" and the users wants to read emails of 6 days or less -> only read the cache

But if he want to read emails before these 7 days then you know you need extra requests.

Also for the caching policy let I suggest to:
   - Have a generic expiracy mechanism (7 days looks fine to me) - items are kept 7 days there after display, no longer.
   - Cache mailboxes. always, all of the time.
   - Cache email thread view entries, with a 7 day expiracy:
       - Per item: email entries are kept kept 7 days only
       - Global: we discard the cache for the thread view of that mailbox if it was not open for 7 days.
   - We need to store the date of the oldest displayed message (if any). If the thread view contains more than 20 items, created/updated items older than that date are ignored.
   - We could think of pre-loading some HTMLs too for newly received emails (email just created and are the most recent of their mailbox) to be offline friendly - but it might be early IMO.

### Comment by hoangdat at 2021-09-21T09:55:54Z

Please help me the request to get more from the `oldest date`

### Comment by chibenwa at 2021-09-21T10:22:40Z

> Please help me the request to get more from the oldest date

Email/query + Email/get just like scrolling? :-p (already implemented?)

### Comment by hoangdat at 2021-09-21T11:24:50Z

no, I mean, after get all from the cache, we need to get more, so use `before` in `filtering` am I right?

### Comment by chibenwa at 2021-09-21T12:55:48Z

yes, like paging with /query & /get
