# GitHub issue #3891: Release new version v0.17.0

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3891
State: closed
Author: hoangdat
Created at: 2025-07-20T23:02:43Z
Updated at: 2025-10-22T07:57:14Z
Closed at: 2025-10-22T07:57:14Z
Labels: releasing
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/3891

## Issue body

### CHANGELOG

## [0.17.0] - 2025-07-20
### Added
- #3881 Thread Detail improvements and fixes.
- #3878 Thread Detail content and setting fixes.
- #3699 Thread Detail next/previous actions.
- #3731 Thread Detail email cache optimization.
- #3837 Thread Detail offline view adjustment.
- #3804 Thread Detail parallel email loading.
- #3844 Thread Detail context menu style fix.
- #3845 Thread Detail blue bar scroll fix.
- #3775 Thread Detail UI and functionality improvements.
- #3720 Thread Detail email display refinements.
- #3698 Thread Detail refactoring and real-time updates.
- #3769 Thread Detail comprehensive UI/UX and performance enhancements.
- #3697 Open specific thread detail email.
- #3724 Thread Detail UI and action optimizations.
- #3715 Thread Detail extensive bug fixes and action refinements.
- #3644 Thread Detail scroll handling.
- #3643 Thread Detail extensive UI/UX, performance, and data handling improvements.

### Fixed
- #3835 Android font selection fix.
- HOTFIX Integration tests and Patrol version updates.
- Spam banner/alert UI updates.
- #3847 Stalwart server avatar fix.
- Profile and Language settings UI/UX improvements.
- Font rendering consistency.
- Advanced search tag handling fix.
- Preferences and Settings UI redesign.
- Modal and dialog UI updates.
- #3846 Notion email mobile view fix.
- Custom font loading optimization.
- #3826 Webfinger and network error handling for login.
- #3885 Fix language default 
- Android API 35 support

### DoD:
- [ ] Request translating in weblate and merge to branch
- [ ] Test in all platforms base on the check-list case: [tnr-tmail-template_20Mar.ods](https://github.com/user-attachments/files/19358057/tnr-tmail-template_20Mar.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [ ] Memory leak verifycation
  - View emails with heavy inline
  - Send multiple emails with heavy inline image and attachment
  - Create identity with heavy image
- [x] Tag new version
- [x] Push new docker image
- [x] iOS - Release app in Test Flight
- [x] Android - Release app in Internal Test

## Comments

### Comment by hoangdat at 2025-07-21T02:36:21Z

@tddang-linagora 
- [x] ~memory leaks: thread enable/disable.~ No leak detected.

<img width="4064" height="2384" alt="Image" src="https://github.com/user-attachments/assets/62df6bb8-12c1-4cf1-ae45-a17d3773d1e2" />

- [x] firefox

[tmail-0.17.0-firefox.ods](https://github.com/user-attachments/files/21358251/tmail-0.17.0-firefox.ods)

@dab246 
- [x] chrome 
- [x] iOS

[tmail-0.17.0-chrome-ios.ods](https://github.com/user-attachments/files/21345096/tmail-0.17.0-chrome-ios.ods)

@hoangdat 
- [x] android 
- [x] safari

[tnr-tmail-v0.17.1_android-safari.ods](https://github.com/user-attachments/files/21359436/tnr-tmail-v0.17.1_android-safari.ods)

### Comment by dab246 at 2025-07-21T02:43:31Z

- [x] Missing sender when open email on mobile


<img width="496" height="696" alt="Image" src="https://github.com/user-attachments/assets/1d68d6e5-f3eb-45ca-82a8-a5983f4bd468" />

### Comment by dab246 at 2025-07-21T03:14:19Z

- [x] Cannot see content quoted on iOS. We should disable collapse quoted

### Comment by dab246 at 2025-07-21T03:38:35Z

- [x] Check the space between recipients and email content in the design, it's a bit big right now.

<img width="1284" height="2778" alt="Image" src="https://github.com/user-attachments/assets/0e6c6629-0af3-4308-aa75-4b20edc68239" />

### Comment by dab246 at 2025-07-21T03:43:19Z

- [x] After upgrading the app to version 0.17.0, a white screen appears when opening email from notification on iOS

<img width="1284" height="2778" alt="Image" src="https://github.com/user-attachments/assets/d6257e54-d722-4ad3-995f-8ed60047f4e6" />

### Comment by chibenwa at 2025-07-21T08:03:21Z

v0.17.0 is available on https://canary-tmail.linagora.com/

### Comment by hoangdat at 2025-07-22T04:38:45Z

- [x] drag n drop image in safari, image be placed under signature @dab246 

https://github.com/user-attachments/assets/2369285d-db88-4224-aa77-03e47a86e7ae

### Comment by hoangdat at 2025-07-22T06:59:05Z

- [x] in safari this email was not render well in both thread enable or disable @tddang-linagora, (no problem in chrome)

[\[linagora_tmail-flutter\] TF-3894 Fix blank email content when opening email (PR #3896).eml.txt](https://github.com/user-attachments/files/21360694/linagora_tmail-flutter.TF-3894.Fix.blank.email.content.when.opening.email.PR.3896.eml.txt)

https://github.com/user-attachments/assets/66f5ab4a-bd46-41ef-91ef-7f089ca561d0

### Comment by dab246 at 2025-07-22T10:50:16Z

> * [x]  drag n drop image in safari, image be placed under signature [@dab246](https://github.com/dab246)
> 

Fixed at https://github.com/linagora/tmail-flutter/pull/3897
