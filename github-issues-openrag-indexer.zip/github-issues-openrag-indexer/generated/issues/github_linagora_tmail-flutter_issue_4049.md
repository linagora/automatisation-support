# GitHub issue #4049: Pre-fill OIDC login form...

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4049
State: closed
Author: chibenwa
Created at: 2025-09-24T07:03:54Z
Updated at: 2025-12-18T09:12:46Z
Closed at: 2025-12-18T09:12:46Z
Labels: enhancement, customer
Assignees: guimard, hoangdat, dab246
URL: https://github.com/linagora/tmail-flutter/issues/4049

## Issue body

## Why ? 

See https://github.com/linagora/tmail-flutter/pull/2317

GIVEN I am on mobile (I need to resolve the JMAP server)
THEN the mobile app prompt for mail address
AND use SRV records to locate the JMAP server
AND discover the OpenID configuration with webfinger
AND redirects to the SSO

On the SSO login page, the user is prompted again for login and password.

So the user has to input his login twice (!)

Note that for web we can preconfigure the endpoint and the sso configuration in order to skip webfinger/srv records. On web we can just blindly redirect to the SSO so we do not need to cary over the login information to the SSO.

## How?

If available the mobile application can pass to the SSO the mail address as a parameter.

Apparently we *could* use the `registration` parameter that allows to pass a free form JSON to that end:

Example:

```
  HTTP/1.1 302 Found
  Location: openid://?
    response_type=id_token
    &client_id=https%3A%2F%2Fclient.example.org%2Fcb
    &scope=openid%20profile
    &state=af0ifjsldkj
    &nonce=n-0S6_WzA2Mj
    &registration=%7B%22mailaddress%22%3A%22bob%40domain.tld%22%7D
```

(url decoded `{"mailaddress":"bob@domain.tld"}` )

Then a LemonLDAP plugin could capture this and prefill the login field, potentially applying a pre-configured (on lemon side) normalization step - for instance keep the local part.

Caracteristic:
 
 - Downgrade friendly: if the SSO do not understand this parameter then it would skip it and let the user input his name a second time...

## Comments

### Comment by guimard at 2025-09-24T10:27:24Z

Why not using "login_hint" ?

### Comment by chibenwa at 2025-09-24T11:18:29Z

> There is a field for that (already implemented in SS0): login_hint. Note: was implemented following Tmail-Team request 😉

> Why not using "login_hint" ?

INDEED

### Comment by chibenwa at 2025-09-24T11:18:46Z

I did put this in the sprint let's add login_hint

### Comment by hoangdat at 2025-10-15T08:26:19Z

hi @guimard 
cc @chibenwa 

I tested with govmu account, `login_hint` still not work when we open `auth.*****`. Even it works with `linagora` and `mail (dev) with keycloak`.

Do you know the reason why?

### Comment by chibenwa at 2025-10-15T08:44:47Z

Likely a LemonLDAP plugin is not displayed there.

### Comment by hoangdat at 2025-10-15T08:44:59Z

@rezk2ll can you update `sign-up` page to support `login_hint`.

### Comment by guimard at 2025-10-15T09:30:34Z

> hi [@guimard](https://github.com/guimard) cc [@chibenwa](https://github.com/chibenwa)
> 
> I tested with govmu account, `login_hint` still not work when we open `auth.*****`. Even it works with `linagora` and `mail (dev) with keycloak`.
> 
> Do you know the reason why?

Because this feature isn't deployed yet in govmu, try in preprod

### Comment by hoangdat at 2025-10-16T07:10:48Z

hi @guimard , still not work in `preprod`

### Comment by guimard at 2025-10-16T21:14:16Z

> hi [@guimard](https://github.com/guimard) , still not work in `preprod`

Could you retry ?

### Comment by hoangdat at 2025-10-17T02:55:45Z

hi @guimard. Still not work in preprod. 

<img width="1071" height="799" alt="Image" src="https://github.com/user-attachments/assets/61f7e03d-13f4-4188-b180-cc71be2bd214" />

### Comment by guimard at 2025-10-18T11:10:01Z

Govmu template not updated...

### Comment by chibenwa at 2025-12-02T12:03:54Z

Is it OK?

### Comment by hoangdat at 2025-12-18T09:12:46Z

good now
