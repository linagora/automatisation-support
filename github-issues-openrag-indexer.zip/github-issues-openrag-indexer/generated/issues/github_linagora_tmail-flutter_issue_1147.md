# GitHub issue #1147: [Bug] Identity/get is invoked when opening email

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1147
State: closed
Author: hoangdat
Created at: 2022-11-02T08:32:24Z
Updated at: 2023-02-19T19:42:37Z
Closed at: 2023-02-19T19:42:37Z
Labels: bug, onboarding, perf_jmap
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1147

## Issue body

### DoD:
- remove unnecessary request

## Comments

### Comment by chibenwa at 2022-11-02T08:45:07Z

https://user-images.githubusercontent.com/6928740/199441683-d9669b7c-314b-4346-9de7-7128e36e48f3.mp4

### Comment by hoangdat at 2022-11-07T11:05:48Z

`Identity/get` is invoked because to handle `send Receipt`.

@chibenwa what identity should be used to send Receipt?  Default is ok?

### Comment by chibenwa at 2022-11-07T11:08:27Z

Why do we need to call `send Receipt` when opening an email?

### Comment by hoangdat at 2022-11-07T13:40:27Z

send `Read` when open email with MDN? we dont need it?

### Comment by chibenwa at 2022-11-07T14:37:54Z

The one matching the To field the email is received on, if any. Otherwise defaut.

And please do identity/get only when you need to send a read receipt, not all the time.

### Comment by chibenwa at 2022-11-07T14:39:32Z

When you open a mail you do not need to identity/get that's 1000% sure.

### Comment by hoangdat at 2022-11-07T22:27:40Z

> what identity should be used to send Receipt? Default is ok?

How about that?

### Comment by chibenwa at 2022-11-08T02:19:16Z

> How about that?

The one matching the To field the email is received on, if any. Otherwise defaut.

### Comment by hoangdat at 2023-02-07T14:38:03Z

please handle it with #1321
