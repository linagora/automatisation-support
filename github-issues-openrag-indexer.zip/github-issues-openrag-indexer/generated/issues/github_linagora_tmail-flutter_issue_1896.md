# GitHub issue #1896: [Auto Sync] [Chrome/Firefox] System not auto sync once user recieved new email

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1896
State: closed
Author: QuangHoang1210
Created at: 2023-06-01T02:54:40Z
Updated at: 2023-08-28T19:50:29Z
Closed at: 2023-08-28T19:50:29Z
Labels: bug, Major
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1896

## Issue body

OS: Chrome / Firefox
Device: Laptop
TMail version: 0.7.9 - preprod
TMail version: 0.7.8 - production

### *Reproduce Step:
1, User A send a new email to user B
2, Go to check user B email thread

### **Actual:** 
System not auto sync and reload to displaye the new email on the list

### **Expected:** 

System should auto sync and reload to display the new email on the list

https://github.com/linagora/tmail-flutter/assets/124866146/d706b8ee-3f7e-4bd1-8da6-0b1a491d1e24

## Comments

### Comment by dab246 at 2023-07-04T09:45:46Z

Work fine on version `0.8.3`

### Comment by QuangHoang1210 at 2023-07-20T18:36:15Z

Not Passed

### Comment by QuangHoang1210 at 2023-07-27T04:19:26Z

Re test -> Not Passed 

Version: 0.8.8 -- https://canary-tmail.linagora.com/

![Image](https://github.com/linagora/tmail-flutter/assets/124866146/b9a2337f-c1bf-4b70-8151-7e4be95c4cbf)

@dab246

### Comment by dab246 at 2023-08-15T03:24:52Z

After investigate, i found the error:



![Image](https://github.com/linagora/tmail-flutter/assets/80730648/6699bd40-b8f6-459a-b238-fd6bd75dee0f)


Furthermore, the file `env.fcm` is missing the `FIREBASE_WEB_VAPID_PUBLIC_KEY` variable to get the correct token on the web

### Comment by hoangdat at 2023-08-15T03:28:10Z

@ducnm0711 can you help us on it?

### Comment by hoangdat at 2023-08-15T03:37:59Z

Regress a lot. Take a lot of time to check in every releasing

### Comment by dab246 at 2023-08-15T03:57:48Z

![Image](https://github.com/linagora/tmail-flutter/assets/80730648/73083d23-da77-493c-8fc2-37b49eb0b304)

### Comment by dab246 at 2023-08-22T04:46:39Z

- Work fine

  - Canary (`v0.9.0`): SpentTime ~ 1m



https://github.com/linagora/tmail-flutter/assets/80730648/29182b47-1950-4c7b-8b11-356feb82b287



  - On-Commit (`v0.9.0`): SpentTime ~ 1m




https://github.com/linagora/tmail-flutter/assets/80730648/d1ceaee1-e358-475f-bdd9-a56916302a87


 - Prod (`v0.8.3`): SpentTime ~ 15s




https://github.com/linagora/tmail-flutter/assets/80730648/194a884a-862e-4fbd-9fef-d944466d9ffe
