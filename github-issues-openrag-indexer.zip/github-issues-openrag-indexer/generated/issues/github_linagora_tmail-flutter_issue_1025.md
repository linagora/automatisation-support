# GitHub issue #1025: [Story] As a user, I want to see quota information 

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1025
State: closed
Author: dieptran88
Created at: 2022-09-29T11:11:22Z
Updated at: 2022-12-01T09:21:47Z
Closed at: 2022-12-01T09:21:47Z
Labels: 
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1025

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition

**UC1. View quota limit for my account**
- Given that I am a LinShare user and I logged in successfully to the system 
- I can see a quota banner at the bottom of mailbox bar.
- This banner include information:
   - Used quota
   - My account's quota limit
   - The percentage of used quota/quota limit 
- When I create/delete/receive message, the quota is changed and updated accordingly in this banner.
- The color in this banner is matched with the level of current used quota. There are 3 levels of used quota:
   - Normal: When the used quota  <90% of limit
   - Warning: When the used quota >= 90 % of limit
   - Error: When the storage is full. 

**UC2. View floating warning banner when my used quota is >90%**
- When my used quota/limit reaches 90%, there will be a floating warning banner at the top of mail list view
- The banner is shown with a warning color and text: 
"Your storage is almost full ([  ]%). If you run out of storage space, you won't be able to send and receive email."
- In the banner I can see a "Learn more" button that when I click, a new page will be opened that shows me all details of quota:
   - If user is using SAAS product,  there will be an Upgrade button and then I click on this button, the Lean more page will be displayed with a detail list of subcriptions that I can choose to buy. The upgrade button also appears under the quota banner at the bottom of mailbox list (UC1) when the warning banner appears. 
   - If user is using On-premise version, in Learn more page, I can see a message: Contact to your administrator to upgrade

**UC3. View floating error banner when my used quota reached the limit**
- When my storage 100% used,  there will be a floating warning banner at the top of mail list view
- The banner is shown with a error color and text: 
"Your storage is full.  You won't be able to send and receive email."
- Now user cannot create or receive message: The button create new email will be disabled. 
- In the banner I can see a "Learn more" button that when I click, a new page will be opened that shows me all details of quota

[Back to Summary](#summary)

## Design ticket

https://ci.linagora.com/linagora/lgs/design/-/issues/293

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by dieptran88 at 2022-09-29T11:11:51Z

@hoangdat  Please take a look

### Comment by dieptran88 at 2022-09-29T11:16:01Z

As my understanding, when user used >90% storage, he can still receive email and cannot create/update new message. Can you confirm ? @hoangdat

### Comment by hoangdat at 2022-09-30T02:56:50Z

Hi @Arsnael, as definition in docs 

<img width="593" alt="image" src="https://user-images.githubusercontent.com/6462404/193180228-be3517ea-a313-4007-8976-c117ea9e6163.png">

I understand we will have a way to get what kind of events the account will be prevented or not when he reach `softLimit`? If right, how to do it?

### Comment by hoangdat at 2022-09-30T03:03:10Z

for `UC2`, how about to click on the banner to learn more about the limitation?  @chibenwa @dieptran88 WDYT?

### Comment by chibenwa at 2022-09-30T03:38:56Z

> I understand we will have a way to get what kind of events the account will be prevented or not when he reach softLimit? If right, how to do it?

I think we could hard code this in James:

```
softLimit = limit
warnLimit = 90% of limit
```

> for UC2, how about to click on the banner to learn more about the limitation? @chibenwa @dieptran88 WDYT?

Good idea.

### Comment by Arsnael at 2022-09-30T07:46:10Z

softLimit is an optional param and I thought we were not really managing it for now?

### Comment by hoangdat at 2022-09-30T08:04:06Z

> softLimit is an optional param and I thought we were not really managing it for now?

oh. If we don't have it. How about the case?
```
As I am an user, I reach the limit in quota. Can I received emails?
```

### Comment by chibenwa at 2022-09-30T08:19:26Z

> As I am an user, I reach the limit in quota. Can I received emails?

No you can't. James will say "no this guy is over quota, sorry, try to send your mail later".

### Comment by hoangdat at 2022-09-30T08:35:25Z

but he comes from outside send email, James still response to him?

### Comment by chibenwa at 2022-09-30T08:41:14Z

Yes, that's called a bounce.

Mobile APP do not need to care.

### Comment by dieptran88 at 2022-09-30T08:44:21Z

So when storage reaches 90%, he can receive and send email as normal until  100% quota is used ?

### Comment by hoangdat at 2022-09-30T08:44:48Z

yeah, very easy to say that no need to care, but the BA want to know exactly to describe it in the story, the UI/UX too

### Comment by hoangdat at 2022-09-30T08:47:36Z

@dieptran88 please also care the case of warning, what message need to deliver to user in both case: `on-premise` and `SaaS`.

### Comment by chibenwa at 2022-10-03T04:43:47Z

`UC3. View floating error banner when my used quota reached the limit`

Consider the limit reached when the quota is 99% full
