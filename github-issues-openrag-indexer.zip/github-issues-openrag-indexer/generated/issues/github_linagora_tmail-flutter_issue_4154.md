# GitHub issue #4154: Release new version 0.22.x

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4154
State: closed
Author: hoangdat
Created at: 2025-11-17T15:53:03Z
Updated at: 2026-06-15T04:44:16Z
Closed at: 2026-06-15T04:44:16Z
Labels: releasing
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/4154

## Issue body

### DoD:
- [x] Request translating in weblate and merge to branch
- [x] Test in all platforms base on the check-list case: [tnr-tmail-template_20Mar.ods](https://github.com/user-attachments/files/19358057/tnr-tmail-template_20Mar.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [x] Memory leak verifycation
  - View emails with heavy inline
  - Send multiple emails with heavy inline image and attachment
  - Create identity with heavy image
- [x] Tag new version
- [x] Push new docker image
- [ ] iOS - Release app in Test Flight
- [ ] Android - Release app in Internal Test

## CHANGELOG

[0.22.0] - 2025-11-17
Added
#4148: Add link to common settings in mobile application
#4145: Add OIDC user info endpoint & paywall URL with FQDN validation
#4142: Implement hyperlink insertion in composer
#4064: Support drag & drop email addresses in composer on mobile
#4082: Save and restore text formatting menu state in composer
#4050: Preview and download uploaded files in composer on web
#1715: Add Favorite folder with star email support
#4053: Implement move folder content feature
#4011: Support Tab shortcut key in tag input field
#4122: Display CTA to download mobile application
#3996: Add dividers for items in context menu on desktop
#3976: Support native DNS resolvers without Cloudflare/Google dependency
#3911: Add keyboard shortcuts support & shortcuts dictionary in settings
Fixed
#4146: Handle time for email view
#4139: Fix attachment reminder mistakenly shown when replying
#4128: Separate download handling into independent class on web
#4124: Fix localhost addresses email validation
#4122: Replace deprecated apple-mobile-web-app-capable meta tag
#4117: Fix UI blocking when opening recipient modal in composer
#4004: Apply new UI for delete rule email dialog as confirm modal
#3976: Fix URL lookup failure when DNS resolution fails
#3871: Fix blue bar displays wrongly for event counter
Fix email subject text cut off at the bottom on web
Fix duplicated email subject after enabling thread mode
Fix hide storage section when quota is empty

## Comments

### Comment by hoangdat at 2025-11-17T23:16:09Z

- [x] resize image in composer

### Comment by hoangdat at 2025-11-18T02:38:18Z

- [x] firefox, safari, memory leak @tddang-linagora 

[safari-firefox-0.22.x.ods](https://github.com/user-attachments/files/23618391/safari-firefox-0.22.x.ods)

- [ ] chrome, iOS @hoangdat 

[android-edge-v0.22.x.ods](https://github.com/user-attachments/files/23670743/android-edge-v0.22.x.ods)

- [x] android, edge @dab246 

[android-edge-v0.22.x.ods](https://github.com/user-attachments/files/23619331/android-edge-v0.22.x.ods)

### Comment by dab246 at 2025-11-18T04:12:28Z

> * [x]  resize image in composer

Fixed at https://github.com/linagora/tmail-flutter/pull/4156

### Comment by hoangdat at 2025-11-18T09:29:02Z

- [x] If I have not favorites, please display empty state (like for other folder)

### Comment by tddang-linagora at 2025-11-18T09:45:51Z

### Memory leak verifycation
- View emails with heavy inline ❌
- Send multiple emails with heavy inline image and attachment ✅
- Create identity with heavy image ✅

<img width="1946" height="301" alt="Image" src="https://github.com/user-attachments/assets/24742501-3bd1-4fb0-a2fb-14802026329b" />

When viewing an email with 13mb inline, the entire content of this inline is retained in memory. More over, all data that `SingleEmailController` and `EmailView` hold is also memory leaked. Tracing the memory profile, it is clear that `keyboardShortcutFocusNode` of `ThreadDetailController` is keeping those data from being GC. By comment out the initialization of `keyboardShortcutFocusNode` in `lib/features/thread_detail/presentation/extension/handle_mail_shortcut_actions_extension.dart:37`, this memory leak problem is gone, further confirms the problematic piece of code.

### Comment by dab246 at 2025-11-18T10:05:34Z

> * [x]  If I have not favorites, please display empty state (like for other folder)

Fixed at https://github.com/linagora/tmail-flutter/pull/4157

### Comment by dab246 at 2025-11-18T10:06:06Z

> ### Memory leak verifycation
> * View emails with heavy inline ❌
> 
 compare vs previous version

### Comment by tddang-linagora at 2025-11-18T10:26:35Z

> > ### Memory leak verifycation
> > 
> > * View emails with heavy inline ❌
> 
> compare vs previous version

This profile is from current tmail.linagora.com

<img width="1321" height="766" alt="Image" src="https://github.com/user-attachments/assets/5ae9cdf8-71cb-4466-b606-79edd4a29ecb" />

### Comment by dab246 at 2025-11-18T10:51:07Z

> > > ### Memory leak verifycation

- [x] Also should check memory leak on mobile @tddang-linagora

### Comment by tddang-linagora at 2025-11-19T02:40:51Z

>Also should check memory leak on mobile

Mobile is ok

### Comment by dab246 at 2025-11-19T05:03:49Z

- [x] Missing `To` field when only other fields are filled on mobile

https://github.com/user-attachments/assets/6dcd352d-e939-467b-aa43-55d16324a0f1

### Comment by dab246 at 2025-11-19T05:11:09Z

> * [x]  Missing `To` field when only other fields are filled on mobile
> 

Fixed at #4163

### Comment by hoangdat at 2025-11-21T04:18:14Z

- @tddang-linagora please run E2E tests

### Comment by tddang-linagora at 2025-11-21T09:53:39Z

>please run E2E tests

```console
Test summary:
📝 Total: 74
✅ Successful: 60
❌ Failed: 14
  - Should display and navigate app grid correctly when clicked (integration_test/tests/app_grid/app_grid_test.dart)
  - Should see attachment list in email view after forward email successfully (integration_test/tests/email_detailed/forwarding_email_lost_attachments_test.dart)
  - Should see mailbox unread count update real time (integration_test/tests/mailbox/mailbox_count_real_time_update_test.dart)
  - Should see quota increase when send email successfully (integration_test/tests/mailbox/quota_count_test.dart)
  - Should see back to top button when scroll list email in mailbox to bottom and not see back to top button when scroll list emai (integration_test/tests/mailbox/scroll_list_email_in_mailbox_and_back_to_top_test.dart)
  - Should switch and see emails in mailboxes (integration_test/tests/mailbox/switch_mailbox_test.dart)
  - Should see email in team mailbox INBOX after sending to team mailbox address (integration_test/tests/mailbox/team_mailbox_receive_email_test.dart)
  - Should see the same email when selecting filter and changing search input text (integration_test/tests/search/persist_filter_when_change_search_input_text_test.dart)
  - Should see list email displayed by date time `Last 7 days` and sort order `Relevance` when search email successfully (integration_test/tests/search/search_email_by_date_time_and_sort_order_relevance_test.dart)
  - Should see list email displayed by sort order `Relevance` by default when search email successfully (integration_test/tests/search/search_email_with_sort_order_relevance_by_default_test.dart)
  - Should see highlighted keyword in search result (integration_test/tests/search/search_result_highlights_test.dart)
  - Should see highlighted keyword in search suggestion (integration_test/tests/search/search_suggestion_highlights_test.dart)
  - Should see reply of thread detail (integration_test/tests/thread_detail/thread_detail_reply_real_time_update_test.dart)
  - Should see thread view updated per web socket message (integration_test/tests/web_socket/web_socket_test.dart)
⏩ Skipped: 0
📊 Report: file:///Users/dangdat/Desktop/dev/linagora-master/tmail-flutter/build/app/reports/androidTests/connected/index.html
⏱️  Duration: 4121s
```
