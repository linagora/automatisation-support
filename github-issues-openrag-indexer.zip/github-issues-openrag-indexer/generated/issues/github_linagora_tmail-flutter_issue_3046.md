# GitHub issue #3046: [Bug] Cannot mark email as spam

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3046
State: closed
Author: tprudentova
Created at: 2024-07-25T06:52:01Z
Updated at: 2024-08-12T13:58:38Z
Closed at: 2024-08-12T13:58:38Z
Labels: bug, regression
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/3046

## Issue body

0.12.1 tested on Android, Firefox, Safari, Opera; mail.stg.lin-saas.com

1. Select an email 
2. Click Mark as spam
3. Nothing happens 

Expectation: email is moved to Spam and is marked as spam


https://github.com/user-attachments/assets/032e4600-d27e-4caf-8a68-e0a92555e004

## Comments

### Comment by chibenwa at 2024-07-25T07:37:46Z

https://github.com/user-attachments/assets/eb413a1e-652d-4679-8ca0-90cbcf71d987


Frontend bug:

 - nothing happens when I click the mark as spam button
 - works great when I click the "move" button

### Comment by hoangdat at 2024-07-25T07:40:01Z

hi @chibenwa , it is conflict in `spam` role. please upgrade backend which include "junk" role fixed

### Comment by chibenwa at 2024-07-25T07:59:16Z

Well ideally front should support both to ease the migration ^^

Falling back to role `spam` when you do not find role `junk` is trivial and avoids headache of a breaking change.

![image](https://github.com/user-attachments/assets/c44f2898-201f-4f16-892b-989e075a3ddf)

Asked for it! https://github.com/linagora/tmail-flutter/issues/2894#issuecomment-2132866788

Please @hoangdat be more careful when applying PO + JMAP-expert feedback. If I ask for something, it is not to annoy you or your team nor make tmail frontend more of a complicated product. It is that there is a STRONG reason behind it.

As such I still mark it as a **regression** as it did broke compatibility with some backend versions.

### Comment by chibenwa at 2024-07-25T08:06:51Z

Fixed by deploying backend 0.10.2

### Comment by hoangdat at 2024-07-25T08:07:14Z

agree. Will apply for both `roles`

### Comment by chibenwa at 2024-07-25T08:09:31Z

https://ci.linagora.com/linagora/lrs/saas/deployments/twake/twake-workplace-apps/-/merge_requests/122

### Comment by chibenwa at 2024-07-25T08:15:20Z

@tprudentova fixed on staging

### Comment by dab246 at 2024-07-25T09:26:58Z

Fixed at #3049

### Comment by tprudentova at 2024-08-12T13:37:47Z

https://github.com/user-attachments/assets/bab09159-43d9-4d26-8aa2-1a00da0a3d14

Tested on tmail.linagora.com, the issue is still there (it's fixed on staging though)

### Comment by hoangdat at 2024-08-12T13:58:38Z

this is old version (v0.11.4) is less than staging version (0.12.0). Wait for release.
