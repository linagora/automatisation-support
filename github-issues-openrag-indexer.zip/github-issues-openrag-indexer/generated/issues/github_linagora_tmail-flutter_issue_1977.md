# GitHub issue #1977: Clickable logo

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1977
State: closed
Author: chibenwa
Created at: 2023-06-30T09:21:30Z
Updated at: 2023-09-21T02:33:47Z
Closed at: 2023-09-21T02:33:46Z
Labels: good first issue, Minor, UX, intern
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1977

## Issue body

### Description

When I click the top right logo, I want to be redirected to my INBOX

![Screenshot from 2023-06-30 16-20-04](https://github.com/linagora/tmail-flutter/assets/6928740/8d89f7f9-3a8f-4d74-972e-836c27dd2d84)

## Comments

### Comment by abhishek09827 at 2023-06-30T16:14:16Z

hello pls assign this task to me

### Comment by chibenwa at 2023-07-01T09:39:04Z

here you are ;-)

### Comment by abhishek09827 at 2023-07-02T11:12:33Z

hello @chibenwa could you pls help me in setting up application in my system I am getting 
Error: " because rule_filter depends on both flutter_test from sdk and mockito 5.3.2, version solving failed."
I have tried a few things but nothing worked

### Comment by dab246 at 2023-07-03T03:16:23Z

> hello @chibenwa could you pls help me in setting up application in my system I am getting Error: " because rule_filter depends on both flutter_test from sdk and mockito 5.3.2, version solving failed." I have tried a few things but nothing worked

Let us know more. Please run `flutter doctor -v`

### Comment by sherlockvn at 2023-07-03T06:33:42Z

> hello @chibenwa could you pls help me in setting up application in my system I am getting Error: " because rule_filter depends on both flutter_test from sdk and mockito 5.3.2, version solving failed." I have tried a few things but nothing worked

What version of flutter you use, i think you use the wrong version

### Comment by abhishek09827 at 2023-07-03T13:26:18Z

lutter (Channel stable, 3.10.5, on Microsoft Windows [Version 10.0.23471.1000], locale en-US)
    • Flutter version 3.10.5 on channel stable at C:\src\flutter\flutter
    • Upstream repository https://github.com/flutter/flutter.git
    • Framework revision 796c8ef792 (3 weeks ago), 2023-06-13 15:51:02 -0700
    • Engine revision 45f6e00911
    • Dart version 3.0.5
    • DevTools version 2.23.1

[√] Windows Version (Installed version of Windows is version 10 or higher)

[√] Android toolchain - develop for Android devices (Android SDK version 33.0.2)
    • Android SDK at C:\Users\user\AppData\Local\Android\sdk
    • Platform android-33-ext5, build-tools 33.0.2
    • Java binary at: C:\Program Files\Android\Android Studio\jre\bin\java
    • Java version OpenJDK Runtime Environment (build 11.0.12+7-b1504.28-7817840)
    • All Android licenses accepted.

[√] Chrome - develop for the web
    • Chrome at C:\Program Files\Google\Chrome\Application\chrome.exe

[X] Visual Studio - develop for Windows
    X Visual Studio not installed; this is necessary for Windows development.
      Download at https://visualstudio.microsoft.com/downloads/.
      Please install the "Desktop development with C++" workload, including all of its default components

[√] Android Studio (version 2021.2)
    • Android Studio at C:\Program Files\Android\Android Studio
    • Flutter plugin can be installed from:
       https://plugins.jetbrains.com/plugin/9212-flutter
    • Dart plugin can be installed from:
       https://plugins.jetbrains.com/plugin/6351-dart
    • Java version OpenJDK Runtime Environment (build 11.0.12+7-b1504.28-7817840)

[√] IntelliJ IDEA Community Edition (version 2022.1)
    • IntelliJ at C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.1.1
    • Flutter plugin version 70.0.4
    • Dart plugin version 221.5591.58

[√] VS Code (version 1.79.2)
    • VS Code at C:\Users\user\AppData\Local\Programs\Microsoft VS Code
    • Flutter extension version 3.66.0

[√] Connected device (3 available)
    • Windows (desktop) • windows • windows-x64    • Microsoft Windows [Version 10.0.23471.1000]
    • Chrome (web)      • chrome  • web-javascript • Google Chrome 114.0.5735.199
    • Edge (web)        • edge    • web-javascript • Microsoft Edge 115.0.1901.157

[√] Network resources
    • All expected network resources are available.

> > hello @chibenwa could you pls help me in setting up application in my system I am getting Error: " because rule_filter depends on both flutter_test from sdk and mockito 5.3.2, version solving failed." I have tried a few things but nothing worked
> 
> Let us know more. Please run `flutter doctor -v`

### Comment by sherlockvn at 2023-07-03T13:30:58Z

> lutter (Channel stable, 3.10.5, on Microsoft Windows [Version 10.0.23471.1000], locale en-US) • Flutter version 3.10.5 on channel stable at C:\src\flutter\flutter • Upstream repository https://github.com/flutter/flutter.git • Framework revision 796c8ef792 (3 weeks ago), 2023-06-13 15:51:02 -0700 • Engine revision 45f6e00911 • Dart version 3.0.5 • DevTools version 2.23.1
> 
> [√] Windows Version (Installed version of Windows is version 10 or higher)
> 
> [√] Android toolchain - develop for Android devices (Android SDK version 33.0.2) • Android SDK at C:\Users\user\AppData\Local\Android\sdk • Platform android-33-ext5, build-tools 33.0.2 • Java binary at: C:\Program Files\Android\Android Studio\jre\bin\java • Java version OpenJDK Runtime Environment (build 11.0.12+7-b1504.28-7817840) • All Android licenses accepted.
> 
> [√] Chrome - develop for the web • Chrome at C:\Program Files\Google\Chrome\Application\chrome.exe
> 
> [X] Visual Studio - develop for Windows X Visual Studio not installed; this is necessary for Windows development. Download at https://visualstudio.microsoft.com/downloads/. Please install the "Desktop development with C++" workload, including all of its default components
> 
> [√] Android Studio (version 2021.2) • Android Studio at C:\Program Files\Android\Android Studio • Flutter plugin can be installed from: https://plugins.jetbrains.com/plugin/9212-flutter • Dart plugin can be installed from: https://plugins.jetbrains.com/plugin/6351-dart • Java version OpenJDK Runtime Environment (build 11.0.12+7-b1504.28-7817840)
> 
> [√] IntelliJ IDEA Community Edition (version 2022.1) • IntelliJ at C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.1.1 • Flutter plugin version 70.0.4 • Dart plugin version 221.5591.58
> 
> [√] VS Code (version 1.79.2) • VS Code at C:\Users\user\AppData\Local\Programs\Microsoft VS Code • Flutter extension version 3.66.0
> 
> [√] Connected device (3 available) • Windows (desktop) • windows • windows-x64 • Microsoft Windows [Version 10.0.23471.1000] • Chrome (web) • chrome • web-javascript • Google Chrome 114.0.5735.199 • Edge (web) • edge • web-javascript • Microsoft Edge 115.0.1901.157
> 
> [√] Network resources • All expected network resources are available.
> 
> > > hello @chibenwa could you pls help me in setting up application in my system I am getting Error: " because rule_filter depends on both flutter_test from sdk and mockito 5.3.2, version solving failed." I have tried a few things but nothing worked
> > 
> > 
> > Let us know more. Please run `flutter doctor -v`

use Flutter version 3.7.5 instead

### Comment by dab246 at 2023-07-04T03:09:11Z

> lutter (Channel stable, 3.10.5, on Microsoft Windows [Version 10.0.23471.1000], locale en-US) • Flutter version 3.10.5 on channel stable at C:\src\flutter\flutter • Upstream repository https://github.com/flutter/flutter.git • Framework revision 796c8ef792 (3 weeks ago), 2023-06-13 15:51:02 -0700 • Engine revision 45f6e00911 • Dart version 3.0.5 • DevTools version 2.23.1
> 
> [√] Windows Version (Installed version of Windows is version 10 or higher)
> 
> [√] Android toolchain - develop for Android devices (Android SDK version 33.0.2) • Android SDK at C:\Users\user\AppData\Local\Android\sdk • Platform android-33-ext5, build-tools 33.0.2 • Java binary at: C:\Program Files\Android\Android Studio\jre\bin\java • Java version OpenJDK Runtime Environment (build 11.0.12+7-b1504.28-7817840) • All Android licenses accepted.
> 
> [√] Chrome - develop for the web • Chrome at C:\Program Files\Google\Chrome\Application\chrome.exe
> 
> [X] Visual Studio - develop for Windows X Visual Studio not installed; this is necessary for Windows development. Download at https://visualstudio.microsoft.com/downloads/. Please install the "Desktop development with C++" workload, including all of its default components
> 
> [√] Android Studio (version 2021.2) • Android Studio at C:\Program Files\Android\Android Studio • Flutter plugin can be installed from: https://plugins.jetbrains.com/plugin/9212-flutter • Dart plugin can be installed from: https://plugins.jetbrains.com/plugin/6351-dart • Java version OpenJDK Runtime Environment (build 11.0.12+7-b1504.28-7817840)
> 
> [√] IntelliJ IDEA Community Edition (version 2022.1) • IntelliJ at C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.1.1 • Flutter plugin version 70.0.4 • Dart plugin version 221.5591.58
> 
> [√] VS Code (version 1.79.2) • VS Code at C:\Users\user\AppData\Local\Programs\Microsoft VS Code • Flutter extension version 3.66.0
> 
> [√] Connected device (3 available) • Windows (desktop) • windows • windows-x64 • Microsoft Windows [Version 10.0.23471.1000] • Chrome (web) • chrome • web-javascript • Google Chrome 114.0.5735.199 • Edge (web) • edge • web-javascript • Microsoft Edge 115.0.1901.157
> 
> [√] Network resources • All expected network resources are available.
> 
> > > hello @chibenwa could you pls help me in setting up application in my system I am getting Error: " because rule_filter depends on both flutter_test from sdk and mockito 5.3.2, version solving failed." I have tried a few things but nothing worked
> > 
> > 
> > Let us know more. Please run `flutter doctor -v`

@abhishek09827  Thanks for your information. Currently the TMail project is running on Flutter version `3.7.5` and Dart version `2.19.2`. So when you run on flutter `3.10.x` some dependencies will not be compatible. So I have 2 suggestions for you if you want to continue:
1. Downgrade flutter version to `3.7.5` and dart version `2.19.2`
2. You can create a PR to upgrade flutter version to `3.10.x` for TMail for us. We would also love to upgrade to `3.10.x` but don't have time for it yet, we'd appreciate it if you could. This issue has also been raised here #1849

### Comment by QuangHoang1210 at 2023-09-21T02:33:46Z

Passed on 0.9.3 canary
