# GitHub issue #128: [Bug] Download attachment make the app crash sometimes in iOS

## Metadata

Repository: linagora/tmail-flutter
Issue number: 128
State: closed
Author: hoangdat
Created at: 2021-09-29T01:28:14Z
Updated at: 2022-04-15T02:30:45Z
Closed at: 2022-04-15T02:30:45Z
Labels: bug, Major
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/128

## Issue body

### Description

Download attachment make the app crash sometimes in iOS

### Expected result

### Current behavior

### Preconditions (optional)

attachement is attached by other user use this app to send email

#### Reproduction Steps

### Acceptance criteria

The list of acceptance criteria (defined in the corresponding User Story or coming from your functional knowledge of the product)
These acceptance criteria must be met by the corrective implementation done by the developers.

### Context

Devices, OS

### Additional information

frequency, log files,...

## Comments

### Comment by dab246 at 2021-09-29T03:14:55Z

Please provide the specific faulty tested device here.

### Comment by dab246 at 2021-09-29T03:30:07Z

Tested on some ios virtual machines without any problems. Please provide more information.

### Comment by hoangdat at 2021-09-29T03:34:01Z

IMO, it is sometime in Iphone 11 Pro Max

### Comment by dab246 at 2021-09-29T07:16:16Z

This error was not found.

### Comment by hoangdat at 2021-10-01T10:37:02Z

Move to sprint backlog to monitor more. I have this issue in iOS 14.3

### Comment by dab246 at 2021-10-04T08:43:00Z

Tested on simulator ios 14.3 did not detect this error.

### Comment by hoangdat at 2021-10-04T10:13:29Z

> Tested on simulator ios 14.3 did not detect this error.

sure, we will check this when back to the office

### Comment by hoangdat at 2022-03-21T00:18:38Z

@Kevinle2312 please help us review this case

### Comment by lecaotunglam at 2022-04-08T08:04:31Z

@hoangdat I checked on iPhone 7 and this issue does not happen. The only thing is once the file is downloaded, there is no message for the user.

### Comment by hoangdat at 2022-04-08T08:06:33Z

what is message? what you expect? please describe it more clearly

### Comment by lecaotunglam at 2022-04-08T08:18:57Z

> what is message? what you expect? please describe it more clearly

Something like "File is downloaded" or "File saved"

### Comment by lecaotunglam at 2022-04-15T02:30:45Z

PAssed on CI platform.
