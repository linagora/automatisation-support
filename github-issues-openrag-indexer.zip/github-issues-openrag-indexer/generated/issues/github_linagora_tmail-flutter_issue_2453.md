# GitHub issue #2453: Trouble with cache on mobile app

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2453
State: closed
Author: guimard
Created at: 2024-01-14T12:22:08Z
Updated at: 2025-05-07T20:08:48Z
Closed at: 2024-04-03T07:51:26Z
Labels: bug
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/2453

## Issue body

### Description

When deleting mails with another mail client, Tmail app still shoes this deleted messages

### Expected result

Synchronization should detect that mail were modified/deleted. The app should never show a deleted email when it is online and able to detect this deletion

### Current behavior

Message deleted are still present in mobile app (not web app)

### Context

Thunderbird on desktop, Tmail on Android

## Comments

### Comment by chibenwa at 2024-01-15T07:30:48Z

Thanks for the remark Xavier.

On a technical standpoint `Email/changes` returns `destroyed` mail ids. Those can be dropped straight away from the cache. We can detect the need to call `/changes` by relying on push notifications.

### Comment by QuangHoang1210 at 2024-01-15T08:45:27Z

Hi @guimard and @chibenwa  cc @hoangdat 

I have reproduce this case.

Step:
1, I removed one email from Samsung email
2, I have check again that email in Twake Mail (Samsung app, IOS app)

Actual: The email is removed 
--> So it catch our expectation

**Noted:**  
- But we should do one refresh action (scroll to reload, refresh) then the email will be disappeared
- I have tried to removed the 1st email, 23th email, 52th emails -> Same

**Video**

https://github.com/linagora/tmail-flutter/assets/124866146/19690622-499c-4985-a3e7-f745bb19e20c


![photo_2024-01-15 12 31 58](https://github.com/linagora/tmail-flutter/assets/124866146/6ec42d5f-1756-47bf-879e-79be886ce376)

### Comment by chibenwa at 2024-01-15T11:02:31Z

@hoangdat Ok I think I got it!

IMAP uses an expunge model (eeeeeeurk!)

Which basically means that a message in order to be deleted needs to be marked as deleted (with a flag) `A0 STORE 89 \Deleted` before expunging it which would eventually remove the data `A1 EXPUNGE *`. Most clients do this in a short timewindow and the delta during which the message can be seen is actually null. But some other clients like Samsung mail *might not expunge the data straight away*, leaving it as marked as deleted but not actually deleted...

JMAP spec is quite clear about this:

```
Any message with the \Deleted keyword MUST NOT be visible via JMAP (and so are not counted in the “totalEmails”, “unreadEmails”, “totalThreads”, and “unreadThreads” Mailbox properties).
```

And... James is half compliant as of today...

`Email/query` currently handlremoves messages marked as deleted from the request. 

CF `EmailQueryMethodContract::messagesMarkedAsDeletedShouldNotBeExposedOverJMAP`

BUT we would also need to alter the notification system in order to send deletion notification also when the item is marked as deleted. We would need to take care of not sending deletion notification twice (ie When expunging a message marked as deleted). Which means that 1. the change cannot be resynchronised with `/changes` and 2. cannot be detected through a FCM push. Only a full reload of the app will be able to catch this!

@guimard @QuangHoang1210 you agree that if sign off/sign on then the problem is fixed?

### Comment by guimard at 2024-01-15T11:10:02Z

> @hoangdat Ok I think I got it!
> 
> IMAP uses an expunge model (eeeeeeurk!)
> 
> Which basically means that a message in order to be deleted needs to be marked as deleted (with a flag) `A0 STORE 89 \Deleted` before expunging it which would eventually remove the data `A1 EXPUNGE *`. Most clients do this in a short timewindow and the delta during which the message can be seen is actually null. But some other clients like Samsung mail _might not expunge the data straight away_, leaving it as marked as deleted but not actually deleted...

Not only, even after purging IMAP mailbox (using "compact" from Thunderbird which really deletes all pending deletion), messages are still in Tmail app. That's why no problem with Tmail web

> JMAP spec is quite clear about this:
> 
> ```
> Any message with the \Deleted keyword MUST NOT be visible via JMAP (and so are not counted in the “totalEmails”, “unreadEmails”, “totalThreads”, and “unreadThreads” Mailbox properties).
> ```
> 
> And... James is half compliant as of today...
> 
> `Email/query` currently handlremoves messages marked as deleted from the request.
> 
> CF `EmailQueryMethodContract::messagesMarkedAsDeletedShouldNotBeExposedOverJMAP`
> 
> BUT we would also need to alter the notification system in order to send deletion notification also when the item is marked as deleted. We would need to take care of not sending deletion notification twice (ie When expunging a message marked as deleted). Which means that 1. the change cannot be resynchronised with `/changes` and 2. cannot be detected through a FCM push. Only a full reload of the app will be able to catch this!
> 
> @guimard @QuangHoang1210 you agree that if sign off/sign on then the problem is fixed?

Yes, after sign off + sign in, mailbox is displayed in the same state than Thunderbird and Tmail web

### Comment by chibenwa at 2024-01-15T14:44:39Z

CF https://github.com/linagora/james-project/issues/5039

### Comment by guimard at 2024-01-26T04:51:38Z

Of course, disconnect/reconnect fixes temporary the issue but on next deletion, bug is still there.

Worst : when I open a deleted message on Tmail app, it stays locally in state "unread" and I'm unable to delete it. I think  will encounter this issue too

### Comment by guimard at 2024-01-26T04:52:35Z

This bug didn't exist before Tmail had a cache

### Comment by chibenwa at 2024-01-26T07:39:38Z

Well I can backport this on James side if wanted...
