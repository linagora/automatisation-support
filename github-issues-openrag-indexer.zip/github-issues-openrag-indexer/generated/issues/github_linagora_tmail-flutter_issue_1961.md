# GitHub issue #1961: Email text content could be temporarily truncated

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1961
State: closed
Author: chibenwa
Created at: 2023-06-22T06:16:44Z
Updated at: 2023-08-22T20:10:08Z
Closed at: 2023-08-22T20:10:08Z
Labels: bug, Major
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1961

## Issue body

### Current behavior

When I open this mail on mobile I can only read the top of the mail.

The bottom of the mail is truncated and thus cannot be read.


https://github.com/linagora/tmail-flutter/assets/6928740/2b8ed2b5-0d0a-4667-abef-dba16cd5d539

However after some time, (I had the phone on the side of the desk while opening the bug report) the full content loaded as shhown here:


https://github.com/linagora/tmail-flutter/assets/6928740/2134d062-6392-44ca-ba75-b5c8bf31619a

Happens only on mobile. No problem with WEB

https://github.com/linagora/tmail-flutter/assets/6928740/222dd92f-befc-44e3-b0c1-c329c79e5115


### Expected result

Can read the full email


https://github.com/linagora/tmail-flutter/assets/6928740/2823f4fa-6c78-47ca-9277-109e0a043923


### Context

Android TMail app, v 0.7.8

### Additional information

EML :  [truncated-eml.txt](https://github.com/linagora/tmail-flutter/files/11829480/truncated-eml.txt)

CC @QuangHoang1210 @hoangdat

## Comments

### Comment by dab246 at 2023-06-22T06:34:40Z

@chibenwa  please send again file `.eml`. Thank

### Comment by QuangHoang1210 at 2023-06-22T07:37:04Z

@chibenwa  Can you send me your html in email body!?

This is the way how I created the new html email - but  I cannot reproduce the issue :(

https://github.com/linagora/tmail-flutter/assets/124866146/ebe7809b-bb4f-45ca-947d-edc72c7ed52b

-- View html email on android:

https://github.com/linagora/tmail-flutter/assets/124866146/6de04f93-9a32-47fa-a579-7fbeca27e975

### Comment by chibenwa at 2023-06-22T07:51:59Z

Both of you READ AGAIN THE BUG REPORT

### Comment by chibenwa at 2023-06-22T07:52:45Z

![Screenshot from 2023-06-22 14-52-05](https://github.com/linagora/tmail-flutter/assets/6928740/40baf82c-28e0-44fe-b480-f98ea01811cf)

### Comment by dab246 at 2023-06-22T09:03:16Z

> Both of you READ AGAIN THE BUG REPORT

Why don't you `compress` it under the `.eml` file. File` .txt` it will be inaccurate and difficult for us to reproduce.

### Comment by chibenwa at 2023-06-22T09:17:29Z

[Tr : Alexandre Blick Rothenberg Seminar: IR35 Regulations – the practical aspects - Alexandre ZAPOLSKY <azapolsky@linagora.com> - 2023-06-21 1936.zip](https://github.com/linagora/tmail-flutter/files/11832315/Tr.Alexandre.Blick.Rothenberg.Seminar.IR35.Regulations.the.practical.aspects.-.Alexandre.ZAPOLSKY.azapolsky%40linagora.com.-.2023-06-21.1936.zip)

### Comment by dab246 at 2023-06-23T03:06:56Z

@chibenwa 

I have rechecked the error video you provided. At the 4th second (`0:04`). This is not an error, the data is still being downloaded. The loading bar is still visible, indicating that the email content has not been fully rendered to the screen. So we cannot scroll to the end of the content. And in the following video, the email content has been completely rendered so it can be scrolled.

<img width="298" alt="Screenshot 2023-06-23 at 09 59 39" src="https://github.com/linagora/tmail-flutter/assets/80730648/85769d3b-ee7a-4b58-a4aa-2fcfd910c5e2">

I have to admit the loading bar is gray so it's hard to see for the user. We will come up with a plan to improve this.

Finally you can test it again by opening the email and waiting for the loading bar to disappear you will be able to scroll the email.

### Comment by QuangHoang1210 at 2023-06-23T03:07:06Z

https://github.com/linagora/tmail-flutter/assets/124866146/f8a9dbbb-d186-4a03-93ca-2a5bebc6674e

This is not a bug. System is loading about 50 seconds then the email is load sucessfully to scroll down to view. <Both ios & android>

-- Should improve UX or the loading time performance

-- Other email clients are loading fastly

### Comment by hoangdat at 2023-06-23T05:17:12Z

IMO, we should more investigate on this issue, how to have better solution for this kind of email. Sure, for us not a big problem but with some decision maker, a not acceptable UX. Majox one.

### Comment by chibenwa at 2023-06-23T05:24:33Z

> This is not a bug. System is loading about 50 seconds then the email is load sucessfully to scroll down to view.

Then that's a bug ^^
