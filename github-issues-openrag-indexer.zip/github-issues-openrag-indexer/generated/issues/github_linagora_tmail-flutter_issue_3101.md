# GitHub issue #3101: Test to Release new version v0.13.0 (sprint #26)

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3101
State: closed
Author: hoangdat
Created at: 2024-08-21T08:46:46Z
Updated at: 2024-08-27T04:59:46Z
Closed at: 2024-08-27T04:59:46Z
Labels: releasing
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/3101

## Issue body

### Manual test 
- [ ] chrome
- [ ] firefox
- [ ] edge
- [ ] safari
- [ ] android
- [ ] ios

[tnr-tmail-sprint26.ods](https://github.com/user-attachments/files/16688957/tnr-tmail-sprint26.ods)

## Comments

### Comment by hoangdat at 2024-08-21T08:48:39Z

@hoangdat 
- [x] firefox
- [x] android


[tnr-tmail-sprint26.ods](https://github.com/user-attachments/files/16756745/tnr-tmail-sprint26.ods)

### Comment by hoangdat at 2024-08-21T08:49:28Z

@tddang-linagora 
- [x] edge
- [x] safari

[safari-edge.ods](https://github.com/user-attachments/files/16743725/safari-edge.ods)

### Comment by hoangdat at 2024-08-21T08:49:56Z

@dab246 
- [x] Chrome -> Have some bug with identity -> Fixed
- [x] iOS - Have some issue with identity -> fixed

### Comment by dab246 at 2024-08-22T04:34:49Z

- [x] `PublicAsset/set` method always call when close identity creator view


https://github.com/user-attachments/assets/52ffd630-a5ee-448b-8ce7-986d14b5068c



- [x] Checkbox `Set as default identity` not selected when edit identity

https://github.com/user-attachments/assets/52669977-c159-4e8d-91b3-5090f5ef4b54

### Comment by tddang-linagora at 2024-08-22T04:59:32Z

>`PublicAsset/set` method always call when close identity creator view

- https://github.com/linagora/tmail-flutter/pull/3105

### Comment by dab246 at 2024-08-22T08:18:58Z

1. Tested IOS:

- [ ] The signature message input box is too big.


https://github.com/user-attachments/assets/3bdfee22-06a0-421a-a3a9-d586acbe0a91


- [x] Loading icon should be placed in the middle of the signature input box.


https://github.com/user-attachments/assets/a9d69451-0585-4ad2-a4a4-d32b62953d75

### Comment by tddang-linagora at 2024-08-22T09:50:50Z

>The signature message input box is too big.

The content contains too many new lines, else I can't reproduce it

### Comment by dab246 at 2024-08-23T05:03:35Z

> > The signature message input box is too big.
> 
> The content contains too many new lines, else I can't reproduce it

It is very easy to reproduce. Please see below video.


https://github.com/user-attachments/assets/dd78f66c-1a6b-45dd-a747-3503a4545e1c
