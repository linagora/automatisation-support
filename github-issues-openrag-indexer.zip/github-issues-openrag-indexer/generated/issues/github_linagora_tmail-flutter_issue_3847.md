# GitHub issue #3847: blank user avatar

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3847
State: closed
Author: Gictorbit
Created at: 2025-06-29T06:59:36Z
Updated at: 2025-07-21T08:04:28Z
Closed at: 2025-07-18T10:34:30Z
Labels: bug, stalwart
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/3847

## Issue body

### Description
User avatars in Twake Mail are not displaying correctly. When a user does not have a profile photo, the avatar appears blank or white instead of showing a fallback/default image.

### Expected result
If a user does not have a profile photo, a default avatar (e.g. an initial-based icon or placeholder image) should be shown.

### Current behavior
User avatars are completely blank (white and empty) when no profile photo is set, which can be confusing or look broken in the UI.

![Image](https://github.com/user-attachments/assets/111f3924-db99-4081-8285-f7f152755581)

### Preconditions (optional)
Twake Mail is installed and integrated with Stalwart Mail server.
The user has not uploaded a profile photo.

#### Reproduction Steps
Log into Twake Mail with a user account that has no profile photo.
Open the inbox or user profile area.
Observe the avatar display.

### Acceptance criteria
A default avatar is displayed when a user does not have a profile photo.
The default avatar should be consistent across all components (inbox, sidebar, message view, etc.).
No blank or broken image should appear in place of the avatar.
Behavior should apply to both newly created users and existing users without profile images.

### Context

Browser: Chrome
Twake Mail with `Stalwart` Mail integration
Docker Image: `linagora/tmail-web:latest`

## Comments

### Comment by dab246 at 2025-06-30T06:51:52Z

Hi @Gictorbit  Please see comment https://github.com/linagora/tmail-flutter/issues/3717#issuecomment-3017840571

### Comment by Gictorbit at 2025-07-07T11:14:05Z

We've discussed this issue extensively, but we still haven't been able to pinpoint the root cause. I'd really like to fix this soon so I can properly see the user avatar. Any help or suggestions would be greatly appreciated!

### Comment by dab246 at 2025-07-08T09:26:30Z

Hi @Gictorbit ,

We fixed the blank user avatar bug, you can try it now on the `bugfix/tf-3847-blank-user-avatar` branch. While we review and merge it into the master branch

### Comment by Gictorbit at 2025-07-09T08:40:37Z

> Hi [@Gictorbit](https://github.com/Gictorbit) ,
> 
> We fixed the blank user avatar bug, you can try it now on the `bugfix/tf-3847-blank-user-avatar` branch. While we review and merge it into the master branch

Hi, thanks for the quick fix! I’ll test it now on the `bugfix/tf-3847-blank-user-avatar` branch and let you know if I notice anything. Appreciate your support!

### Comment by Gictorbit at 2025-07-09T19:22:01Z

@dab246 
Can you provide a Docker image for the `bugfix/tf-3847-blank-user-avatar` branch so we can test the fix right away?

### Comment by Bananas-Are-Yellow at 2025-07-18T11:05:47Z

Looking forward to docker image v0.16.5 so I can enjoy this fix.

### Comment by Bananas-Are-Yellow at 2025-07-18T11:23:10Z

> Looking forward to docker image v0.16.5 so I can enjoy this fix.

I just tried `v0.16.5-rc-auto-check-oidc` to see if the fix is in that image. The Twake UI fails to appear.

The client makes a call to `https://mail.example.com/.well-known/webfinger`, which is not found on my Stalwart mail server.

### Comment by hoangdat at 2025-07-21T03:36:38Z

You can use image v0.17.0

-- 

Sent from Twake Mail



On Jul 18, 2025 6:06 PM, from David Taylor ***@***.***>Bananas-Are-Yellow left a comment (linagora/tmail-flutter#3847)
Looking forward to docker image v0.16.5 so I can enjoy this fix.



—
Reply to this email directly, view it on GitHub, or unsubscribe.
You are receiving this because you are subscribed to this thread.Message ID: ***@***.***>

### Comment by Bananas-Are-Yellow at 2025-07-21T08:04:28Z

> You can use image v0.17.0
> […](#)

It works now. Thanks.
