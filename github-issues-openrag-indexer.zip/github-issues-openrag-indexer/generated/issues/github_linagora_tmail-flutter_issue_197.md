# GitHub issue #197: Unexpected text is added to email content

## Metadata

Repository: linagora/tmail-flutter
Issue number: 197
State: closed
Author: hantt12
Created at: 2021-10-18T14:26:46Z
Updated at: 2022-06-30T02:47:50Z
Closed at: 2022-06-30T02:47:50Z
Labels: bug, Minor
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/197

## Issue body

This issue does not always happen but it happened once when I test. 
"Sending from Gmail" text is automatically added to the email body 

![image_2021_10_18T09_42_33_285Z.png](https://images.zenhubusercontent.com/5ee9def7c40b48447a4362e2/8b9cf402-f8aa-43a4-8775-e4fb6425a33d)

## Comments

### Comment by chibenwa at 2021-10-18T14:28:15Z

EML please. This may more be of a James issue.

(go to openpaas and download the EML of that very email as well as a display of the expected display...)

### Comment by hantt12 at 2021-10-18T14:33:52Z

@tlle14 could you please help me extract the EML of the email you received?

### Comment by tlle14 at 2021-10-19T02:08:10Z

[test.zip](https://github.com/linagora/tmail-flutter/files/7369637/test.zip)
@chibenwa @hantt12

### Comment by chibenwa at 2021-10-19T03:16:08Z

Can you share the TMail display for this?

### Comment by chibenwa at 2021-10-19T03:40:35Z

Thunderbird display

![Screenshot from 2021-10-19 10-14-47](https://user-images.githubusercontent.com/6928740/137840035-c599bae2-978f-40c4-8bad-b84b96a9bf59.png)

Tmail display:

![Screenshot_20211019-103829_Team Mail](https://user-images.githubusercontent.com/6928740/137840051-1e3f0d00-ab3a-48e5-a905-966da00974b7.jpg)


I would say it looks like we look good. QA you agree?

### Comment by chibenwa at 2021-10-19T03:41:54Z

(the different date is expected, and is matching the value I specified during the import...)

### Comment by hantt12 at 2021-10-19T03:49:05Z

But why do we have “sending from Gmail” text? I didn’t input mail body when I sent the email

Sent from my iPhone

> On 19 Oct 2021, at 10:42, Benoit TELLIER ***@***.***> wrote:
> 
> ﻿
> (the different date is expected, and is matching the value I specified during the import...)
> 
> —
> You are receiving this because you were mentioned.
> Reply to this email directly, view it on GitHub, or unsubscribe.

### Comment by chibenwa at 2021-10-19T04:05:01Z

GMail did it for you :smiling_imp:

### Comment by chibenwa at 2021-10-19T04:06:08Z

Closing because the text also appears in thunderbird: this is in no way a TMail problem.

### Comment by hoangdat at 2021-10-19T04:13:09Z

Let me make it clear:
1. Compose mail by TeamMail (sender account)
2. Open that email in thunderbird (recipient account)
3. `Sending from Gmail` is appended?

Am I right? @hantt12

### Comment by chibenwa at 2021-10-19T04:16:24Z

No the email was written in GMail, correct?

### Comment by chibenwa at 2021-10-19T04:17:44Z

No!

```
Received: from 172.17.0.1 (EHLO incoming.linagora.com) ([172.17.0.1])
          by incoming.linagora.com (JAMES SMTP Server ) with ESMTP ID 1640832626
          for <tlle@linagora.com>;
          Mon, 18 Oct 2021 09:36:08 +0000 (GMT)
Received: from smtp.linagora.com (smtp.linagora.com [54.36.8.78])
	by incoming.linagora.com (Postfix) with ESMTPS id 539539C401
	for <tlle@linagora.com>; Mon, 18 Oct 2021 09:36:08 +0000 (UTC)
Received: from ?Open?PaaS?SMTP?server?for?Linagora? (unknown [51.83.109.124])
	(using TLSv1.2 with cipher ECDHE-RSA-AES256-GCM-SHA384 (256/256 bits))
	(No client certificate requested)
	by smtp.linagora.com (Postfix) with ESMTPSA id C529C41896
	for <tlle@linagora.com>; Mon, 18 Oct 2021 10:12:31 +0200 (CEST)
```

This proves the EMail only transited by linagora email infrastructure...

### Comment by chibenwa at 2021-10-19T04:21:12Z

```
$ grep Gmail * -R
[no results]
```

WTF !

### Comment by chibenwa at 2021-10-19T04:26:36Z

Honnestly there must be something special about accounts of the QA team!

### Comment by hantt12 at 2021-10-19T06:27:15Z

> Let me make it clear:
> 
> 1. Compose mail by TeamMail (sender account)
> 2. Open that email in thunderbird (recipient account)
> 3. `Sending from Gmail` is appended?
> 
> Am I right? @hantt12

1. Email is sent from Tmail
2. Email is opened in whatever email client you can (openpaas , thunderbird, even Tmail...)
3. "Sending from Gmail" text is there

### Comment by lecaotunglam at 2022-06-30T02:47:50Z

Passed on the Production platform.
