# GitHub issue #468: Not able to login Tmail in mobile web

## Metadata

Repository: linagora/tmail-flutter
Issue number: 468
State: closed
Author: hantt12
Created at: 2022-04-07T03:57:02Z
Updated at: 2022-10-27T13:53:32Z
Closed at: 2022-10-27T13:53:32Z
Labels: bug, 0, Major
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/468

## Issue body

### Description
User should be able to login and use Tmail in mobile web

### Current behavior
Unable to  login. There is no error message

#### Reproduction Steps
1. Go to Tmail.lingora.com in mobile web browser
2. Input valid username and password and tap login buton

## Comments

### Comment by chibenwa at 2022-04-07T10:32:37Z

Specific app/version of mobile web browser?

### Comment by hantt12 at 2022-04-07T10:37:57Z

Device 1: iphone 7 plus, ios 15.4.1, Google Chrome
Device 2: iphone 11, ios 15.3.1, Safari

### Comment by hoangdat at 2022-06-23T04:07:46Z

still not connect. Need more debug with chrome mobile

### Comment by dab246 at 2022-07-06T11:04:06Z

2 HD

### Comment by dab246 at 2022-07-07T11:14:41Z

2 HD

### Comment by dab246 at 2022-07-07T11:33:11Z

BaseUrl: `https://tmail.linagora.com`

- `Android`: Login successful on Chrome
- `iOS`: Error getting session on Safari
```json
{
     "type": "about:blank",
     "status": 401,
     "detail": "No valid authentication methods provided"
}
```

![Screen Shot 2022-07-07 at 18.28.32.png](https://images.zenhubusercontent.com/605059df174a357c7888640f/78fcc6e5-e992-4352-927a-7dee5673f127)

@chibenwa  @hoangdat  Do you have any ideas for this problem?

### Comment by chibenwa at 2022-07-07T15:22:28Z

My feeling is maybe a missing space after ';' in the accept header?

I am in vacations cc @Arsnael

### Comment by dab246 at 2022-07-08T02:08:20Z

@chibenwa  Oh, sorry to bother you now. I'll check this out more until you come back.

### Comment by Arsnael at 2022-07-08T02:28:06Z

I just managed to login successfully on my iphone with safari browser on my account in https://tmail.linagora.com so... 

Are you sure you did not put the wrong password or sth? Cause it works without issue for me.

Iphone 11, ios 15.5

### Comment by dab246 at 2022-07-08T09:01:38Z

@Arsnael  
- I make sure I entered it correctly. Because I have successfully logged in on my android device.
- I think maybe it's because I'm testing on an iOS Simulator that it blocks like that.
- If you have successfully signed in on your device then I think this error should be fixed.

### Comment by Arsnael at 2022-07-11T02:02:46Z

@dab246 Maybe because you are on an emulator... Honestly I know very little regarding ios dev... Can't you see with QA to get your hand on one of the iphone devices at the office to check with a real one and do a comparison?
