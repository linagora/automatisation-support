# GitHub issue #979: Allign identity cards ?

## Metadata

Repository: linagora/tmail-flutter
Issue number: 979
State: closed
Author: chibenwa
Created at: 2022-09-24T08:26:00Z
Updated at: 2023-04-05T03:12:52Z
Closed at: 2023-04-05T03:12:52Z
Labels: Minor, UX
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/979

## Issue body

### Description

Bottom of identity cards are not necessarily alligned...

![Screenshot from 2022-09-24 15-23-43](https://user-images.githubusercontent.com/6928740/192088385-7e6bfbcb-f044-47bf-b0e3-eae7839370ea.png)

## Comments

### Comment by hknguyen91 at 2022-10-11T09:18:57Z

It depends on what users fill on the input, how much information was required

### Comment by chibenwa at 2022-10-11T09:46:02Z

So what is the decision here?

### Comment by hknguyen91 at 2022-10-11T14:41:52Z

Just keep it flexible by its contents. Anyway, I asked Diep to create a new ticket, then I'll improve this function, I see some things that can improve

### Comment by chibenwa at 2022-10-12T00:53:50Z

Like... `Default - Default` and `Demo - Demo`?

### Comment by hoangdat at 2022-10-12T02:26:55Z

> Default - Default and Demo - Demo

yeah, the duplicated info

### Comment by hknguyen91 at 2022-10-12T03:28:48Z

@chibenwa In my design, these are aliases and depend on what users name it, not the same like our demo anyway  
![image](https://user-images.githubusercontent.com/95336527/195243162-7916d0c0-4a51-45ed-9f1c-39092a906afb.png)

### Comment by hoangdat at 2022-10-12T03:44:16Z

okie let improve the design then we discuss more

### Comment by chibenwa at 2022-10-12T04:47:05Z

Cool.

Once we are at it, can we display signature text too?

### Comment by chibenwa at 2023-04-05T03:12:52Z

![Screenshot from 2023-04-05 10-12-19](https://user-images.githubusercontent.com/6928740/229972038-2c68e33b-050d-4b9b-b9ab-9b26a42653d2.png)

Fixed
