# GitHub issue #1086: Out of sprint #9

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1086
State: closed
Author: dab246
Created at: 2022-10-17T08:30:23Z
Updated at: 2022-10-31T04:24:06Z
Closed at: 2022-10-31T04:24:06Z
Labels: 0
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/1086

## Issue body

- Improve Linshare: 4 point
+ `909` `https://github.com/linagora/linshare-mobile-flutter-app/issues/909`
+ `906` `https://github.com/linagora/linshare-mobile-flutter-app/issues/906`

## Comments

### Comment by dab246 at 2022-10-18T06:29:01Z

4 HD - `Review and Planning sprint`
1 HD - `Hoang dat meeting`
1 HD - `#1064-1066`
1 HD - `#1042`
1 HD - `#656`

### Comment by dab246 at 2022-10-19T02:58:28Z

2 HD - `#1064-1066`

### Comment by dab246 at 2022-10-21T02:22:49Z

2 HD - `#909 Linshare`

### Comment by dab246 at 2022-10-24T02:37:31Z

1 HD - `#909 Linshare`

### Comment by dab246 at 2022-10-24T03:11:13Z

1 HD - `#1098`

### Comment by dab246 at 2022-10-25T02:24:16Z

1 HD - `#909 Linshare`

### Comment by dab246 at 2022-10-26T03:11:06Z

1 HD - `#909 Linshare`

### Comment by dab246 at 2022-10-27T02:34:42Z

1 HD - `#906 Linshare`

### Comment by dab246 at 2022-10-28T03:39:52Z

2 HD - `#906 Linshare`
