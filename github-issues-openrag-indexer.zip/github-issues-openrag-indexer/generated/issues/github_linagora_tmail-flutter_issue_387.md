# GitHub issue #387: Attach files in iOS app, but can not open attachments in web-mail app

## Metadata

Repository: linagora/tmail-flutter
Issue number: 387
State: closed
Author: hoangdat
Created at: 2022-03-22T04:55:11Z
Updated at: 2022-11-16T11:43:22Z
Closed at: 2022-11-16T11:43:22Z
Labels: bug, 0, Major
Assignees: hoangdat
URL: https://github.com/linagora/tmail-flutter/issues/387

## Issue body

### Desc:

Attach files in iOS app, but can not open the attachments in web-mail app

### Reproduce:

- open the app in iOS
- compose a mail
- attach some images
- send to some userB
- userB uses web-mail to open the received email
- download attachments
- Can not open

### Context: 
- Chrome
- v0.2.1 in both platforms

## Comments

### Comment by lecaotunglam at 2022-03-24T04:28:52Z

@hoangdat I tested on tmail.linagora.com today and found out that all attachments send from tmail all have this issue (from web and app). I tested the following cases:
 - Case 1: from webmail to webmail
 - Case 2: from app( bother iOS and Android) to webmail
 - Case 3: from app to app

### Comment by dab246 at 2022-03-25T02:34:40Z

@chibenwa  Can you send me sample example for email sending api with attachment? I want to test my api again.

### Comment by dab246 at 2022-03-25T10:16:02Z

@chibenwa Is it correct to request API send email with attachment like this?

````
{
    "using": [
        "urn:ietf:params:jmap:submission",
        "urn:ietf:params:jmap:mail",
        "urn:ietf:params:jmap:core"
    ],
    "methodCalls": [
        [
            "Email/set",
            {
                "accountId": "3ce33c876a726662c627746eb9537a1d13c2338193ef27bd051a3ce5c0fe5b12",
                "create": {
                    "dab1234": {
                        "id": "dab1234",
                        "mailboxIds": {
                            "abb2be40-18d9-11eb-a677-2990b970028d": true
                        },
                        "subject": "Test send email with attachment",
                        "from": [
                            {
                                "name": "userB",
                                "email": "userb@qa.open-paas.org"
                            }
                        ],
                        "to": [
                            {
                                "name": "DatX",
                                "email": "datx1995@gmail.com"
                            }
                        ],
                        "attachments": [
                            {
                                "blobId": "uploads-64b52d70-ab63-11ec-90ba-e169393c493e",
                                "size": 2967966,
                                "name": "IMG_0019.PNG",
                                "type": "image/png",
                                "disposition": "attachment"
                            }
                        ],
                        "htmlBody": [
                            {
                                "partId": "mmm",
                                "blobId": "aaaa",
                                "type": "text/html"
                            }
                        ],
                        "bodyValues": {
                            "mmm": {
                                "value": "Test send email with attachment",
                                "isEncodingProblem": false,
                                "isTruncated": false
                            }
                        },
                        "header:User-Agent:asText": "Android/XXX TeamMail/1.0"
                    }
                }
            },
            "c0"
        ],
        [
            "EmailSubmission/set",
            {
                "accountId": "3ce33c876a726662c627746eb9537a1d13c2338193ef27bd051a3ce5c0fe5b12",
                "create": {
                    "a1234": {
                        "emailId": "#dab1234",
                        "envelope": {
                            "mailFrom": {
                                "email": "userb@qa.open-paas.org"
                            },
                            "rcptTo": [
                                {
                                    "email": "datx1995@gmail.com"
                                }
                            ]
                        }
                    }
                },
                "onSuccessUpdateEmail": {
                    "#a1234": {
                        "mailboxIds/abb99c10-18d9-11eb-a677-2990b970028d": true,
                        "keywords/$seen": true
                    }
                }
            },
            "c1"
        ]
    ]
}
````

### Comment by hoangdat at 2022-03-28T01:56:12Z

@chibenwa please take a look on it, this kind of issue was occurred some month ago. We really want to kill it before alpha@linagora

### Comment by chibenwa at 2022-03-28T02:15:48Z

I would say you might not need to specify the size of attachments in `Email/set`:

```
["Email/set", {
      "accountId": "$ACCOUNT_ID",
      "create": {
        "aaaaaa": {
          "mailboxIds": {
             "${mailboxId.serialize}": true
          },
          "subject": "World domination",
          "attachments": [
            {
              "blobId": "$blobId",
              "type":"text/plain",
              "charset":"UTF-8",
              "disposition": "attachment"
            }
          ]
        }
      }
    }, "c1"]
```

(From james test suite).

We can get rid of it IMO.

Also, this might be related to the missing `Content-Transfer-Encoding` header. In which case it would be a James bug. (99% sure of this)

@Kevinle2312 please share the EML of the message!

### Comment by lecaotunglam at 2022-03-28T02:38:59Z

@BenoitTallandier Here you go: https://wetransfer.com/downloads/4682cf5f155d633a093ce64d3d311fba20220328023554/470046

### Comment by chibenwa at 2022-03-28T03:28:47Z

It's @chibenwa . Benoit Tallendier is the twake PO

### Comment by chibenwa at 2022-03-28T03:31:01Z

BTW I confirm this is fucked up without transfer encoding.

![Screenshot from 2022-03-28 10-29-27](https://user-images.githubusercontent.com/6928740/160321748-92d49311-a11b-4223-b4ab-839410e528ce.png)

@Kevinle2312 can you confirm this is not just an IOS bug but that you can't open the sent attachment whatever the platform? (Android, tmail.linagora.com ) ?

### Comment by lecaotunglam at 2022-03-28T04:31:56Z

@chibenwa  No. It is on all platforms (iOS, Android, tmail.linagora.com). As I said, I tested 3 cases, all of them have this issue:  
- Case 1: from webmail to webmail
- Case 2: from app( bother iOS and Android) to webmail
- Case 3: from app to app

### Comment by Arsnael at 2022-03-28T04:34:58Z

Stop tagging the wrong Benoit ahah

### Comment by lecaotunglam at 2022-03-28T04:40:04Z

> Stop tagging the wrong Benoit ahah

SOrry m bad :(( . I fixed it.

### Comment by chibenwa at 2022-03-28T05:13:58Z

Ok I confirm this is https://github.com/apache/james-project/pull/927 ...

Will be fixed in TMail 0.5.0 coming in a few weeks.

### Comment by lecaotunglam at 2022-04-07T07:15:09Z

Failed on CI platform. I sent an email with a pdf file attachment from the iOS app. When I open that pdf file on my PC, the file is empty. @dab246

### Comment by hoangdat at 2022-04-07T07:38:06Z

@Kevinle2312 please read the comment: https://github.com/linagora/tmail-flutter/issues/387#issuecomment-1080203238

### Comment by lecaotunglam at 2022-04-15T07:58:21Z

@chibenwa This morning, I test the following case: 
1. Upload a video as an attachment on the iOS app
2. Send the email from the iOS app to a Gmail account
3. Download the video on the Gmail site and the video file is corrupted. 

Tested version: iOS app 0.2.2
PLatform: CI platform.
I will reopen this issue. #WDYT

### Comment by hoangdat at 2022-04-15T08:00:50Z

@Kevinle2312 please add more information: what environment?. It is important, we have a ton of environment. Hard to give the diagnosis without it.

### Comment by lecaotunglam at 2022-04-22T09:54:46Z

I tested it on 2 environments today: 
- On tmail.upn.integration-open-paas.org: I have this problem
- On openpaas.upn.integration-open-paas.org: This problem does not happen.

@chibenwa @hoangdat

### Comment by hoangdat at 2022-04-22T10:00:38Z

what did you test on `openpaas.upn.integration-open-paas.org`? Why we need to care about that here?

### Comment by hoangdat at 2022-04-22T10:02:10Z

> apache/james-project#927

Any update from your site @chibenwa, what environment we have the fix?

### Comment by lecaotunglam at 2022-04-22T10:19:39Z

> what did you test on `openpaas.upn.integration-open-paas.org`? Why we need to care about that here?

I try to send an email from that platform to a gmail account. When I received the attachment on gmail site, the file is fine.

### Comment by hoangdat at 2022-06-14T09:07:38Z

working well with v0.3.6 in Preprod
