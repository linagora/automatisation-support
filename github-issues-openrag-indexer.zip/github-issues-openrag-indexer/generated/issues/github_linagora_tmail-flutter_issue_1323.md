# GitHub issue #1323: [Attachment/staging] cannot attach image on mobile and web

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1323
State: closed
Author: haftus98
Created at: 2022-12-15T09:16:36Z
Updated at: 2023-02-19T12:26:30Z
Closed at: 2023-02-19T12:26:30Z
Labels: bug, Major
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1323

## Issue body

**Description**
I attached an image and it took long time to attach successfully.

**Video**

https://user-images.githubusercontent.com/97084773/207821147-65f66b76-7ff7-46b4-9636-6bd626e7a926.mp4



<img width="1440" alt="image" src="https://user-images.githubusercontent.com/97084773/207824674-c38aff6d-d434-4b20-8708-cf39890fdfe7.png">


**Environment**
preproduction, v0.5.1, IOS 15.6.1, macos 12.6.1 (21G217)

## Comments

### Comment by hoangdat at 2023-01-03T04:40:09Z

![Image](https://user-images.githubusercontent.com/6462404/210300978-45aa3948-c3fe-4940-bec7-eb066410ef9e.png)

### Comment by chibenwa at 2023-01-03T05:02:36Z

Does the request have the authorization header?

### Comment by hoangdat at 2023-01-03T05:58:25Z

still have, but need more invesigation

<img width="446" alt="image" src="https://user-images.githubusercontent.com/6462404/210306421-29c63136-142c-4b65-b117-a2154826e0c6.png">

### Comment by dab246 at 2023-02-02T08:44:17Z

I investigated it. And detect this error from server `preprod`. We cannot upload to the server at this time. It always returns error `500 Internal Server Error`.



![Image](https://user-images.githubusercontent.com/80730648/216274530-c911a9c9-3ad0-45ce-b449-d92bb5736de7.png)

### Comment by chibenwa at 2023-02-02T10:00:24Z

Hug @Arsnael please recover the log of what went wrong...

### Comment by Arsnael at 2023-02-03T03:06:01Z

An error from S3 (or Swift? whatever), as said yesterday, and errors sent back from S3 are never really clear:

```
{"timestamp":"2023-02-02T09:23:50.337Z","level":"ERROR","thread":"parallel-1","logger":"org.apache.james.jmap.routes.DownloadRoutes","message":"Unexpected error upon uploads","context":"default","exception":"software.amazon.awssdk.services.s3.model.S3Exception: null (Service: S3, Status Code: 400, Request ID: null)\n\tat software.amazon.awssdk.protocols.xml.internal.unmarshall.AwsXmlPredicatedResponseHandler.handleErrorResponse(AwsXmlPredicatedResponseHandler.java:156)\n\tat software.amazon.awssdk.protocols.xml.internal.unmarshall.AwsXmlPredicatedResponseHandler.handleResponse(AwsXmlPredicatedResponseHandler.java:108)\n\tat software.amazon.awssdk.protocols.xml.internal.unmarshall.AwsXmlPredicatedResponseHandler.handle(AwsXmlPredicatedResponseHandler.java:85)\n\tat software.amazon.awssdk.protocols.xml.internal.unmarshall.AwsXmlPredicatedResponseHandler.handle(AwsXmlPredicatedResponseHandler.java:43)\n\tat software.amazon.awssdk.core.internal.handler.BaseClientHandler.lambda$successTransformationResponseHandler$7(BaseClientHandler.java:266)\n\tat software.amazon.awssdk.core.internal.http.async.AsyncResponseHandler.lambda$prepare$0(AsyncResponseHandler.java:89)\n\tat java.base/java.util.concurrent.CompletableFuture$UniCompose.tryFire(Unknown Source)\n\tat java.base/java.util.concurrent.CompletableFuture.postComplete(Unknown Source)\n\tat java.base/java.util.concurrent.CompletableFuture.complete(Unknown Source)\n\tat software.amazon.awssdk.core.internal.http.async.AsyncResponseHandler$BaosSubscriber.onComplete(AsyncResponseHandler.java:132)\n\tat software.amazon.awssdk.http.nio.netty.internal.ResponseHandler$DataCountingPublisher$1.onComplete(ResponseHandler.java:513)\n\tat software.amazon.awssdk.http.nio.netty.internal.ResponseHandler.runAndLogError(ResponseHandler.java:250)\n\tat software.amazon.awssdk.http.nio.netty.internal.ResponseHandler.access$600(ResponseHandler.java:75)\n\tat software.amazon.awssdk.http.nio.netty.internal.ResponseHandler$PublisherAdapter$1.onComplete(ResponseHandler.java:371)\n\tat software.amazon.awssdk.http.nio.netty.internal.nrs.HandlerPublisher.complete(HandlerPublisher.java:447)\n\tat software.amazon.awssdk.http.nio.netty.internal.nrs.HandlerPublisher.channelInactive(HandlerPublisher.java:430)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:303)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:274)\n\tat io.netty.handler.logging.LoggingHandler.channelInactive(LoggingHandler.java:206)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:303)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:274)\n\tat io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:81)\n\tat io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:277)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:303)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:274)\n\tat io.netty.channel.CombinedChannelDuplexHandler$DelegatingChannelHandlerContext.fireChannelInactive(CombinedChannelDuplexHandler.java:418)\n\tat io.netty.handler.codec.ByteToMessageDecoder.channelInputClosed(ByteToMessageDecoder.java:411)\n\tat io.netty.handler.codec.ByteToMessageDecoder.channelInactive(ByteToMessageDecoder.java:376)\n\tat io.netty.handler.codec.http.HttpClientCodec$Decoder.channelInactive(HttpClientCodec.java:329)\n\tat io.netty.channel.CombinedChannelDuplexHandler.channelInactive(CombinedChannelDuplexHandler.java:221)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:303)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:274)\n\tat io.netty.handler.codec.ByteToMessageDecoder.channelInputClosed(ByteToMessageDecoder.java:411)\n\tat io.netty.handler.codec.ByteToMessageDecoder.channelInactive(ByteToMessageDecoder.java:376)\n\tat io.netty.handler.ssl.SslHandler.channelInactive(SslHandler.java:1075)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:305)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:274)\n\tat io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:81)\n\tat io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:277)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:303)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:274)\n\tat io.netty.channel.DefaultChannelPipeline$HeadContext.channelInactive(DefaultChannelPipeline.java:1405)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:301)\n\tat io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:281)\n\tat io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:901)\n\tat io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:813)\n\tat io.netty.util.concurrent.AbstractEventExecutor.runTask(AbstractEventExecutor.java:174)\n\tat io.netty.util.concurrent.AbstractEventExecutor.safeExecute(AbstractEventExecutor.java:167)\n\tat io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:470)\n\tat io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:566)\n\tat io.netty.util.concurrent.SingleThreadEventExecutor$4.run(SingleThreadEventExecutor.java:997)\n\tat io.netty.util.internal.ThreadExecutorMap$2.run(ThreadExecutorMap.java:74)\n\tat java.base/java.lang.Thread.run(Unknown Source)\n"}
```

Notice that:
I rollbacked to the version we have on prod (0.6.4-rc2) and the issue still occurs, while on prod we can upload without issues... Honestly I will try to recheck the conf we have regarding object storage today and investigate more

### Comment by Arsnael at 2023-02-06T06:33:18Z

FYI: We found the cause but not really sure what to do about it...

It seems it fails because James fails to create buckets for uploads, and if you try to upload to S3 an object to a non existing bucket, it fails...

Normally it should return a NoSuchBucketException , which when we catch it we would then retry with creating the bucket first, and it would pass

For some reason Swift from OVH on preprod does not seem to return this error anymore but a more generic one... the weird thing being here is that we use the same kind of object storage for prod and it still works fine... I really don't get it...

So we might just add a cron job on preprod that will check if the bucket or not for this week and next week exist and if not create it to workaround this, cause we consider it's a problem on ovh side.

### Comment by Arsnael at 2023-02-08T09:54:10Z

@dab246 @hoangdat that issue should be solved now.

I deployed and tested the workaround, seems fine for the moment. Don't hesitate to let me know if you have issues with that again

Please test again and close the issue if you deem it solved. Thanks :)
