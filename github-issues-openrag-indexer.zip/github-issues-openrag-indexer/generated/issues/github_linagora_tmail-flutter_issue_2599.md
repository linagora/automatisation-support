# GitHub issue #2599: Notification flood!

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2599
State: closed
Author: chibenwa
Created at: 2024-02-12T22:02:39Z
Updated at: 2024-08-30T05:21:18Z
Closed at: 2024-08-30T05:21:18Z
Labels: bug, Major, customer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/2599

## Issue body

### Description

Given I have 13 new emails unseen in my mailbox
When I receive notification 
Then I receive 13 notification
And the notifications are eventually folded

### Expected result

I should receive a single notification saying I have 13 email and allow me to see each mail detail

### Actual result

https://github.com/linagora/tmail-flutter/assets/6928740/b0f68a43-c883-455c-896d-18ac388cae01

### Platform

Android

But apparently that is the same for IOS

## Comments

### Comment by hoangdat at 2024-02-15T07:02:03Z

We still not understand the expectation. 
One notification for 13 email details, then how to click on notification to open email? 
It is really common behavior?

Cc @QuangHoang1210 please help us verify the notification for this case of Outlook, Gmail

### Comment by QuangHoang1210 at 2024-02-15T07:54:24Z

- If user have 13 new emails then system will displayed 13 notification = 13 new emails.

**Behaviours:**
A- On Android
Receive new 10 emails -> Notification Center is displayed 10 emails in 1 noti
==> User can click to expand it to view list of new email 
===> User can click each email to go to email details in Twake Mail app

![IMG_4097](https://github.com/linagora/tmail-flutter/assets/124866146/f7402587-8325-4761-ab67-417f9ff582bf)

B- On IOS
Receive new 10 emails -> Notification Center is displayed 10 emails belong to 10 notifications separately
==> User can click to expand it to view list of new email 
===> User can click each email to go to email details in Twake Mail app

**-> Twake mail behaviour same with Samsung email / Outlook / Gmail on both IOS and Android**

<img width="413" alt="Screenshot 2024-02-15 at 11 55 47 AM" src="https://github.com/linagora/tmail-flutter/assets/124866146/dba366a9-ed57-48c1-8322-b11605ed298f">

@chibenwa  @hoangdat  @dab246

### Comment by chibenwa at 2024-02-15T23:29:55Z

Please start grouping messages from 3 new messages.

Given I have 10 new mail at the same time my phone should ring once.

### Comment by hoangdat at 2024-02-16T01:25:01Z

How to display folded notification?

### Comment by QuangHoang1210 at 2024-02-19T04:44:52Z

### Define notification AC:

### A- Receiving multiple emails on ANDROID

**1- Same time**: Time receiving email : 4:05 PM for example
```
GIVEN User A,B,C are Tmail users
AND C using Android device
WHEN A and B sent an email to C at 4:05 PM
THEN C Android device receive 1 notification sound
AND 2 emails will be collapse in one on Notification Center
AND C can click on arrow to expand separated emails short description
```

**2- Different time receiving email : 4:05 PM - 1 email AND 4:06 - 1 email**
```
GIVEN User A,B,C are Tmail users
AND C using Android device
WHEN A sent an email to C at 4:05 PM
AND B sent an email to C at 4:06 PM
THEN C Android device receive 2 notification sound
AND 2 emails will be separately displayed on Notification Center
```

**Compare other mail client**
https://github.com/linagora/tmail-flutter/assets/124866146/fc25bc5e-4ee7-4066-a481-bc8baa51b5df

**Actual of Twake Mail on ANDROID**
https://github.com/linagora/tmail-flutter/assets/124866146/617ae00a-5742-4c0c-a35e-1758e448e085

### **B- Receiving multiple emails in the same time on IOS**
**1- Same time**
```
GIVEN User A,B,C are Tmail users
AND C using IOS device
WHEN A and B sent an email to C at 4:05 PM
THEN C IOS device receive 2 notification sound
AND 2 emails will be separated displaying on Notification Center
```

**2- Different time**
```
GIVEN User A,B,C are Tmail users
AND C using IOS device
WHEN A sent an email to C at 4:05 PM
AND B sent an email to C at 4:06 PM
THEN C IOS device receive 2 notification sound
AND 2 emails will be separately displayed on Notification Center
```


**Compare other mail client**
https://github.com/linagora/tmail-flutter/assets/124866146/44170304-bf72-44c7-a082-c565f050c935

**Actual of Twake on IOS**
Same

### Comment by chibenwa at 2024-04-26T13:58:47Z

HELLO Reported again by a customer!

### Comment by hoangdat at 2024-04-26T14:12:49Z

> HELLO Reported again by a customer!
> 
> 

But what is his expectation?

### Comment by chibenwa at 2024-04-26T19:08:12Z

Well like me: not have my phone ring for 10 minutes when I wake up in the morning!

My mother already also complained me about that...

### Comment by hoangdat at 2024-04-27T03:37:12Z

> Well like me: not have my phone ring for 10 minutes when I wake up in the morning!
> 
>

You turned off the phone at night, then you turn it on in the next morning, and you have ton of notifications?

### Comment by chibenwa at 2024-04-27T22:00:06Z

Precisely. Phone rings for 10 minutes without a break

### Comment by chibenwa at 2024-05-13T14:07:41Z

Related but making notification settings easier to access would make it easier for users to navigate this,

https://github.com/linagora/tmail-flutter/issues/1387

### Comment by hoangdat at 2024-07-24T02:15:00Z

still have flood from current version @chibenwa ?

### Comment by chibenwa at 2024-07-24T05:41:36Z

Looks better overall to me yes
