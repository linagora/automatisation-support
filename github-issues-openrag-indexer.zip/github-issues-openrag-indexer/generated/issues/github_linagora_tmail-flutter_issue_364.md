# GitHub issue #364: [Web] Attached images are not displayed in the email content

## Metadata

Repository: linagora/tmail-flutter
Issue number: 364
State: closed
Author: itswillta
Created at: 2022-03-17T04:19:44Z
Updated at: 2022-04-07T10:33:13Z
Closed at: 2022-04-07T10:33:13Z
Labels: bug, Medium
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/364

## Issue body

### Current behavior

- When I receive an email with attached images, those images are not displayed in the email content.

![image](https://user-images.githubusercontent.com/24670327/158735805-93c5c1d3-968f-4b84-a21c-4b7efc00449b.png)

### Expected result

- The images should be displayed normally. The screenshot below is taken from Thunderbird in the same email:

![image](https://user-images.githubusercontent.com/24670327/158735914-4475a05b-26fa-4a41-be19-b216ca048023.png)

### Devices, OS

- Chrome / Ubuntu Desktop / Web

### Additional information

- JMAP Response and EML: [jmap-response-and-eml.zip](https://github.com/linagora/tmail-flutter/files/8281350/jmap-response-and-eml.zip)

## Comments

### Comment by chibenwa at 2022-03-17T04:35:36Z

Wont fix!

```
Content-Type: image/png; name=app-logo.png
Content-ID: <app-logo.png>
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename=app-logo.png
```

As you can see the content disposition is set as attachment and not as inlined. We are thus not supposed to desplay it in the body of the mail.

The sender of the mail is the one guilty here!

### Comment by tuanlc at 2022-03-17T07:46:26Z

> As you can see the content disposition is set as attachment and not as inlined. We are thus not supposed to desplay it in the body of the mail.
> The sender of the mail is the one guilty here!

@chibenwa Can you explain how other mail clients (Thunder bird, Gmail, Outlook, mobile mail) work with this kind of email?

### Comment by itswillta at 2022-03-17T07:55:31Z

> Wont fix!
> 
> ```
> Content-Type: image/png; name=app-logo.png
> Content-ID: <app-logo.png>
> Content-Transfer-Encoding: base64
> Content-Disposition: attachment; filename=app-logo.png
> ```
> 
> As you can see the content disposition is set as attachment and not as inlined. We are thus not supposed to desplay it in the body of the mail.
> 
> The sender of the mail is the one guilty here!

From a pure user perspective, I was previously using OBM, OpenPaaS Inbox and Thunderbird. They all display these emails just fine.  Now I'm switching to this new application and it's not displaying them, so I think there might be something wrong with this new application.

From a (not so) technical point of view, I want to ask if something has changed about the way email contents (images) are displayed. Is it like this new Tmail Web only supports modern standards and drops support for older, deprecated standards?

### Comment by chibenwa at 2022-03-17T08:03:01Z

> Is it like this new Tmail Web only supports modern standards and drops support for older, deprecated standards?

1. it is more about the James JMAP attachment parsing strategy, and yes we rewrotte that when implementing RFC-8620
2. this is not spec compliant. Not old, obselete or whatever
3. Parsing and interpreting mime is hell.
4. got the point, We'll fix that sir Huy.

### Comment by chibenwa at 2022-03-17T08:05:13Z

> Can you explain how other mail clients (Thunder bird, Gmail, Outlook, mobile mail) work with this kind of email?

They are overwritting Content-Dispostion from attachment to inlined when there's a CID. Disregarding user input...

It gets tricky because some other clients are using cid for text part disposed as attachments and you shall not throw them away...

Working with mime is **hell**...

### Comment by tuanlc at 2022-03-17T08:11:13Z

> They are overwritting Content-Dispostion from attachment to inlined when there's a CID. Disregarding user input...

>  It gets tricky because some other clients are using cid for text part disposed as attachments and you shall not throw them away...
> Working with mime is hell...

Thank you for the explanation!

I was asking it because we use `cid` to insert inline attachment (We build email templates and send them by a 3rd SMTP service). If it isn't the right way, could you please tell me the right way to attach images in the email content?

### Comment by chibenwa at 2022-03-17T08:12:57Z

Ok sorry for the mess here. 

`EmailBodyPart` as per RFC-8621 should ease access to underlying mime fields and should not alter these value. This means back is not the right place to solve this issue.

Thus, we need to handle that on the client side ( `:-(` )

@hoangdat we can...

 - Remove attachments with `disposition:attachment` and a CID from the attachment bar. (condition to be in top bar is `no cid and disposition attachment`)
 - Do not require `disposition:inlined` to display inlined content.

### Comment by itswillta at 2022-03-17T08:37:26Z

Is sending images in an email as its attachments (with `Content-Disposition: attachment`) a common/recommended practice? Is there anyway to do it without added disadvantages?

### Comment by chibenwa at 2022-03-17T09:18:07Z

> Is sending images in an email as its attachments (with Content-Disposition: attachment) a common/recommended practice? 

That's what you do when you want it as an attachment. When it is displayed inlined you need the corresponding disposition...

> Is there anyway to do it without added disadvantages?

No, it's just non-email people messing up.

By the way we will handle such kind of invalid contents.

### Comment by lecaotunglam at 2022-04-07T04:16:38Z

Passed on CI platform.
![image](https://user-images.githubusercontent.com/32490981/162120432-a0b8f8d5-ea1a-4d11-92d5-006c087d3212.png)
