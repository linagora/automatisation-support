# GitHub issue #2598: Notifications for drafts on IOS?

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2598
State: closed
Author: chibenwa
Created at: 2024-02-12T17:07:21Z
Updated at: 2025-05-07T20:17:51Z
Closed at: 2024-08-30T05:14:45Z
Labels: Major, bug?, customer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/2598

## Issue body

### Description

A customer described received notifications for drafts using the IOS application.

Notes:
 - He described "not receiving notifications straight away". This is because the app will only resynchronise when receiving an email (Email Delivery) and might include drafts.
 
 I'm not having an IOS phone, not able to reproduce. A mission for @QuangHoang1210 
 
 Of course no notification for email in draft / sent mailbox shall be sent.

## Comments

### Comment by hoangdat at 2024-02-14T22:14:08Z

Confirmed. Side effect from plain notification in iOS. The fixed was applied in front-back in 0.11.6 (but not verified)

### Comment by chibenwa at 2024-02-14T22:30:46Z

Cool

Please backport on patch4-x

### Comment by hoangdat at 2024-02-20T05:13:32Z

- patch for front-end was merged
- [ ] missing patch from back-end: `[FCM] Only set alert for the APN message upon EmailDelivery` (on 0.8.2)

### Comment by hoangdat at 2024-02-20T05:29:09Z

- `v0.11.3-patch4-4` still have issue with linagora (0.8.2)

### Comment by dab246 at 2024-02-21T07:37:31Z

On `v0.11.3-patch4-dev` branch and prod server, BE still returns `alert` of payload in push notification on iOS device when performing `mark as read`, `move` or some other email-related actions.  @hoangdat @quantranhong1999 



![Image](https://github.com/linagora/tmail-flutter/assets/80730648/2ffbe903-564e-4e05-a208-947f542b8be3)

### Comment by quantranhong1999 at 2024-02-21T07:42:26Z

> On v0.11.3-patch4-dev branch and prod server, BE still returns alert of payload in push notification on iOS device when performing mark as read, move or some other email-related actions. @hoangdat @quantranhong1999

Can you try to check if this is the issue for preprod env? (I do not have access to prod so I am not sure which tmail backend image is running - with the fix or not).

### Comment by quantranhong1999 at 2024-02-21T07:49:47Z

The current alert title on master branch: `Twake Mail`
cf https://github.com/linagora/tmail-backend/blob/master/tmail-backend/jmap/extensions/src/main/java/com/linagora/tmail/james/jmap/firebase/FirebasePushClient.java#L114

While the alert title in the above image is `TMail notification`. (old title)

Likely an old tmail backend without the fix is running on prod.

### Comment by hoangdat at 2024-02-21T07:53:18Z

As I checked, `tmail@linagora` still use back-end image `chibenwa/tmail-backend:distributed-0.8.1-patch--16`, so it not include commit https://github.com/linagora/tmail-backend/commit/43c49615a06edb850fdd7d4b35fbd05873dfc6af. Please check it again @chibenwa.

@dab246 please verify one more time new iOS app with preprod. Thanks
