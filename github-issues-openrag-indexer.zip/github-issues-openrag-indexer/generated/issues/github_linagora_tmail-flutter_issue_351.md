# GitHub issue #351: Today I cannot open the composer

## Metadata

Repository: linagora/tmail-flutter
Issue number: 351
State: closed
Author: chibenwa
Created at: 2022-03-16T03:25:59Z
Updated at: 2022-04-07T10:24:50Z
Closed at: 2022-04-07T10:24:50Z
Labels: bug, web, Major, composer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/351

## Issue body

https://user-images.githubusercontent.com/6928740/158510704-b6f99143-56e7-42e8-8ef3-564f873f5af6.mp4

CTRL + F5 and this was working!

No details in error console.

## Comments

### Comment by hoangdat at 2022-03-17T04:51:19Z

> No details in error console.

maybe `tmail.linagora.com` is built in release mode, so no log are dumped. I will test more.

### Comment by chibenwa at 2022-03-17T04:52:27Z

> maybe tmail.linagora.com is built in release mode, so no log are dumped. I will test more.

Can we switch the build to have testing output on by default?

### Comment by hoangdat at 2022-03-17T05:03:29Z

@Arsnael , please read the docs: https://docs.flutter.dev/testing/build-modes and update the `docker file`. I still stuck in some critical bugs :(

At a glance: only change to `flutter build web --debug`

### Comment by Arsnael at 2022-03-17T07:10:02Z

@hoangdat : seems not :D => https://github.com/flutter/flutter/issues/96283

The web part is far being as mature as the mobile...

Will check a bit more to see if there is alternatives

### Comment by Arsnael at 2022-03-17T07:31:17Z

@hoangdat the best I could find: https://stackoverflow.com/questions/59710360/how-to-build-flutter-web-app-in-debug-mode

```
flutter build web --profile --dart-define=Dart2jsOptimization=O0
```
Not exactly as good as debug as people seem saying, but the closest you could get? Might give you error traces from what I can read...

Wanna give it a shot? :)

### Comment by hoangdat at 2022-03-17T07:39:52Z

`--profile` is ok. 
But `--dart-define=Dart2jsOptimization=O0` for what?

### Comment by Arsnael at 2022-03-17T07:47:07Z

@hoangdat you know my flutter knowledge is highly limited, not even sure what profile is for... You are the expert :D 

But with a quick search: https://dart.dev/tools/dart2js

that defines pretty much the degree of optimization when flutter converts dart to js. With O0 you disable most optimization, maybe suitable the time to debug? (O1 being the default that I guess we have currently?)

### Comment by hoangdat at 2022-03-17T07:48:30Z

okie, why not try with it?

### Comment by chibenwa at 2022-03-17T07:52:35Z

Mmh I'm not fan of not running the same stuff in prod and tests.

I'd prefer not downgrading the optimisation level.

### Comment by Arsnael at 2022-03-17T07:57:20Z

> Mmh I'm not fan of not running the same stuff in prod and tests.

Ah cause we have a testing machine now for flutter web? I didn't know :o (yes I'm being sarcastic)

### Comment by Arsnael at 2022-03-17T07:58:36Z

Well let's start with profile then...

### Comment by chibenwa at 2022-03-17T07:59:17Z

> Ah cause we have a testing machine now for flutter web? I didn't know :o (yes I'm being sarcastic)

The day you package it in a HELM chart and put it on preprod, dude: https://github.com/linagora/james-project-private/issues/353

### Comment by chibenwa at 2022-03-17T08:00:14Z

>  a testing machine now for flutter web

To be fair we don't need a testing machine dedicated to tmail web, it's just a tiny tiny NGinx container.

> (yes I'm being sarcastic)

You should not.

### Comment by Arsnael at 2022-03-17T08:13:55Z

@hoangdat https://github.com/linagora/tmail-flutter/pull/365

### Comment by lecaotunglam at 2022-04-07T07:52:08Z

Passed on CI platform.

https://user-images.githubusercontent.com/32490981/162148462-8730ebbc-22d7-4e55-805f-455d28e664f2.mp4
