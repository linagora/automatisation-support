# GitHub issue #2460: Real time updates for web are broken

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2460
State: closed
Author: chibenwa
Created at: 2024-01-16T14:21:41Z
Updated at: 2025-05-07T20:09:06Z
Closed at: 2024-09-26T09:23:54Z
Labels: bug, Major, customer, user-feedback
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/2460

## Issue body

### Description

Manual refresh needed for web.

### Expected result

I expect FCM to be able to refresh also web without manual refresh

### Current behavior

https://github.com/linagora/tmail-flutter/assets/6928740/23f300fb-aa91-41b0-ab5a-3fc2e24e6e95

## Comments

### Comment by hoangdat at 2024-01-16T14:27:44Z

It was fixed with the release v0.11.3. I though you not get full update of the main.dart.js, please use ctrl+F5 to test it again

### Comment by chibenwa at 2024-01-16T15:15:36Z

> It was fixed with the release v0.11.3. I though you not get full update of the main.dart.js, please use ctrl+F5 to test it again

Nope.

I tried 2 different browser, even in incognito mode.

No luck!

### Comment by chibenwa at 2024-02-02T09:50:39Z

Please NEEDED for a customer

### Comment by hoangdat at 2024-02-02T10:34:44Z

- [x] some commits on back-end side to handle expired token should be backport
- [ ] cherry pick this in #2483 also to `v0.11.3-patchx`

### Comment by chibenwa at 2024-02-02T12:46:27Z

> cherry pick this in https://github.com/linagora/tmail-flutter/pull/2483 also to v0.11.3-patchx

Done in `v0.11.3-patch5`

>  some commits on back-end side to handle expired token should be backport

Already part of the release

```
311057fb [FCM] Set alert for the APN message
b224a401 fixup! ISSUE-870 Enable mutable-content for APNS notification
a4608b7e ISSUE-870 Enable mutable-content for APNS notification
40f7de5c ISSUE-870 FirebaseSubscription/get should return expired subscriptions (#872)
```

### Comment by chibenwa at 2024-02-02T14:25:00Z

I deployed v0.11.3-patch5 on prod. 

Still not working

### Comment by hoangdat at 2024-02-02T15:25:13Z

ok, let us test, firebase token not easy to regenerate.

### Comment by QuangHoang1210 at 2024-02-20T12:34:02Z

**Not yet passed on tmail.linagora.com & canary-tmail.linagora.com 0.11.3**

https://github.com/linagora/tmail-flutter/assets/124866146/db09eec1-c9cd-461d-ade5-179ff83b8bf3

### Comment by hoangdat at 2024-03-12T02:32:13Z

### Desc:
- customer app work well in the case web app in foreground (active tab)
- customer app not have realtime update in the case web app in background (still open tmail tab, but focus on other tab)

### Comment by hoangdat at 2024-06-14T09:00:27Z

- [x] Work well for `v0.11.3-patch4-16`: https://github.com/linagora/tmail-flutter/releases/tag/v0.11.3416 in Chrome, Edge, Firefox

### Comment by hoangdat at 2024-06-14T09:02:14Z

Not have realtime update in safari https://github.com/linagora/tmail-flutter/releases/tag/v0.11.3416 
(But in latest branch - v0.11.4003, still work )

<img width="546" alt="image" src="https://github.com/linagora/tmail-flutter/assets/6462404/a84272e2-98f8-4c27-9579-b3caa32b9db2">

### Comment by chibenwa at 2024-06-14T09:13:24Z

Still no realtime updates for me on tmail.linagora.com 

```
{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "FirebaseRegistration/set",
            {
                "notCreated": {
                    "d9b95bca-0ad1-4135-bebd-1d6cacbbd54b": {
                        "type": "invalidArguments",
                        "description": "Token is not valid",
                        "properties": [
                            "token"
                        ]
                    }
                }
            },
            "c0"
        ]
    ]
}
```

Stilll...

### Comment by hoangdat at 2024-06-14T09:24:43Z

> Still no realtime updates for me on tmail.linagora.com

Can you share me a little console log on it?

Btw, not work for `tmail linagora` but still work for ` preprod` in your browser?

### Comment by chibenwa at 2024-06-14T09:48:54Z

> Btw, not work for tmail linagora but still work for  preprod in your browser?

Yes

### Comment by chibenwa at 2024-06-14T09:50:07Z

![image](https://github.com/linagora/tmail-flutter/assets/6928740/af3dcb09-67d2-453d-9e49-2e74114afcbc)

Not much: it's just about the client recognising the token is not valid and clearing the cache!

### Comment by chibenwa at 2024-06-14T09:57:35Z

Can we get a separate issue for Safaru?

This looks like another issue...
