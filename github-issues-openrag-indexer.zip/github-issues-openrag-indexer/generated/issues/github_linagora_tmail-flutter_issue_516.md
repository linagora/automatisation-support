# GitHub issue #516: [Story] As a Tmail user, I want to use auto complete feature when compose/reply/forward an email 

## Metadata

Repository: linagora/tmail-flutter
Issue number: 516
State: closed
Author: dieptran88
Created at: 2022-04-26T10:45:15Z
Updated at: 2022-10-31T03:34:52Z
Closed at: 2022-10-31T03:34:52Z
Labels: 
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/516

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition
**UC1. Automatically save new contact when sending email**

- Given that I am a Tmail user
- I have logged-in successfully to Tmail mobile/tablet/web 
- I sent an email to an email address that I have not sent before  
- Then the email address will be saved automatically as my personal contact so that it can be used for auto-completion.

**UC2. As a user, I can see auto-completion from personal contacts when compose/reply/forward an email**

- Given that I am a Tmail user
- I have logged-in successfully to Tmail mobile/tablet/web 
- When I click button create a new email or reply or forward an email, a new composer is opened.
- On the field From, when I start typing some characters, the system will search from server with inputted text, then display a suggestion list of contacts that matched 
- I can select one contact from the list, the contact will be displayed as a recipient 
- The inputted text will be search in First name/Last name and email address of my personal contacts 

**UC3. As a user, I can see auto-completion from device contact when compose/reply/forward email from mobile/Tablet**

- Given that I am a Tmail user
- I have logged-in successfully to Tmail mobile/tablet/web 
- Given that I granted permission for Tmail to access device contacts
- When I click button create a new email or reply or forward an email, a new composer is opened.
-  On the field From, when I start typing some characters, the system will search the keyword and suggest recipients from 2 sources :
   ◦ From my personal contacts from Tmail server.
   ◦ From the device contact: The suggested recipients are contacts that have name/email containing inputted keyword.
- If a contact contains more than 1 email, all the emails are shown with a Name, and I can choose an email to share document.



[Back to Summary](#summary)

## Screenshots

None

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by chibenwa at 2022-04-27T01:39:27Z

Upcoming backend doc https://github.com/linagora/tmail-backend/pull/408

To be clear, we can still keep contact app auto-completion in complement of backend autocomplete on mobile.

### Comment by dieptran88 at 2022-04-27T07:13:33Z

Do you mean that user can get auto-completion from contact app on mobile  ?

### Comment by chibenwa at 2022-04-28T03:00:38Z

> Do you mean that user can get auto-completion from contact app on mobile ?

Yes, this should be the case today...

### Comment by hoangdat at 2022-05-05T03:36:13Z

@dab246 @johnnguyenit39
doc: https://github.com/linagora/tmail-backend/blob/master/docs/modules/ROOT/pages/tmail-backend/jmap-extensions/contactAutocomplete.adoc

### Comment by Arsnael at 2022-05-05T07:07:13Z

> Yes, this should be the case today...

Well after we make a proper release of it next sprint... :)

### Comment by dab246 at 2022-05-09T03:50:50Z

According to the above documentation, I only see how to get email from `TMailContact/autocomplete` method of `JMAP` but don't understand how to save an email using `JMAP`. If possible, please also give me `request` and its `response`.

### Comment by hoangdat at 2022-05-09T04:24:06Z

As I understand, email will be saved internally by back-end whenever mail is sent

### Comment by dab246 at 2022-05-09T04:27:25Z

Ok. I understand.

### Comment by chibenwa at 2022-05-10T01:44:52Z

> but don't understand how to save an email using JMAP

You don't need to.

Tmail creates the auto-complete entries...
 - based on emails you send
 - uses LSC scripts to discover people from your organisation
 - and finally have AMQP exchanges to be connected with a contact application.

### Comment by dab246 at 2022-05-10T11:31:59Z

Can I ask you something:
- Is the `TMailContact/autocomplete` working now? And on which server does it work?
- I checked on `dev.open-paas.org` and `jmap.linagora.com` but there is no `com:linagora:params:jmap:contact:autocomplete` in the capabilities returned from session

### Comment by hoangdat at 2022-05-10T13:56:17Z

> Can I ask you something:
> 
> * Is the `TMailContact/autocomplete` working now? And on which server does it work?
> * I checked on `dev.open-paas.org` and `jmap.linagora.com` but there is no `com:linagora:params:jmap:contact:autocomplete` in the capabilities returned from session

@dab246 don't forget the ticket to enable/disable `auto complete` function after we get the session.

### Comment by hoangdat at 2022-05-13T10:07:42Z

> > Yes, this should be the case today...
> 
> Well after we make a proper release of it next sprint... :)

that means: we don't have any platform have `autoComplete` at the moment?

### Comment by dab246 at 2022-05-16T09:21:50Z

> 

@chibenwa  @Arsnael  @hoangdat 

As I know you guys have deployed `AutoComplete` on `jmap.upn.integration-open-paas.org` so I tried sending an email on it and it was successful. But when I use `TMailContact/autocomplete` to get list of email addresses it always returns empty. Watch the video below.

Please explain this to me.

https://user-images.githubusercontent.com/80730648/168560879-b8c031ef-3a8f-4638-a27e-55f310df6638.mov

### Comment by hoangdat at 2022-05-17T09:01:29Z

> > 
> 
> @chibenwa @Arsnael @hoangdat
> 
> As I know you guys have deployed `AutoComplete` on `jmap.upn.integration-open-paas.org` so I tried sending an email on it and it was successful. But when I use `TMailContact/autocomplete` to get list of email addresses it always returns empty. Watch the video below.
> 
> Please explain this to me.
> 
>  Screen.Recording.2022-05-16.at.16.09.09.mov

Hi @chibenwa @Arsnael Do you have any update on it?

### Comment by chibenwa at 2022-05-17T10:33:10Z

@Arsnael 

 -> Deploy the collector mailet
 
  -> Do a LSC run.

### Comment by chibenwa at 2022-05-17T10:43:19Z

Quan is doing this.

### Comment by hoangdat at 2022-05-23T08:15:09Z

> Quan is doing this.

Any update for this task @chibenwa
