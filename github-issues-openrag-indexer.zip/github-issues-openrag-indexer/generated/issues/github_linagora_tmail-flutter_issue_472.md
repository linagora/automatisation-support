# GitHub issue #472: [EPIC] OIDC

## Metadata

Repository: linagora/tmail-flutter
Issue number: 472
State: closed
Author: hoangdat
Created at: 2022-04-07T08:57:05Z
Updated at: 2022-12-12T06:07:59Z
Closed at: 2022-12-12T06:07:59Z
Labels: Epic
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/472

## Issue body

All the stories and technical tasks related to OIDC

## Comments

### Comment by hoangdat at 2022-04-07T08:58:24Z

Hi @chibenwa and @Arsnael, can you share with us the `well-know` endpoint we can work with OIDC.

### Comment by chibenwa at 2022-04-07T11:21:55Z

URL of OIDC config: https://auth.upn.integration-open-paas.org/auth/realms/upn/.well-known/openid-configuration

This can be discovered by calling Webfinger well known endoint.

A fix for webfinger is on its way: https://github.com/linagora/tmail-backend/pull/395

We will tell you when it is ready.

### Comment by chibenwa at 2022-04-19T07:46:49Z

Sorry this was a bit long.

Base URL: `https://gateway.upn.integration-open-paas.org/oidc`

curl call for discovering OIDC endpoints:

```
curl -XGET  "https://gateway.upn.integration-open-paas.org/oidc/.well-known/webfinger?resource=https://gateway.upn.integration-open-paas.org&rel=http://openid.net/specs/connect/1.0/issuer" -H "Accept: application/json; jmapVersion=rfc-8621"
```

-> If it returns an error then fallback to basic auth
-> else authenticate


Then curl call to get the JMAP session:

```
curl -XGET  "https://gateway.upn.integration-open-paas.org/oidc/.well-known/jmap" -H "Accept: application/json; jmapVersion=rfc-8621"
```

### Comment by hoangdat at 2022-05-16T03:22:51Z

@chibenwa we use Keycloak provider for OIDC, am I right?

### Comment by hoangdat at 2022-05-16T03:23:55Z

Propose for implementation:
- for mobile: https://pub.dev/packages/flutter_appauth
- for web: https://pub.dev/packages/keycloak_flutter

or: 

- https://pub.dev/packages/openid_client

### Comment by chibenwa at 2022-05-16T03:34:06Z

> for web: https://pub.dev/packages/keycloak_flutter

Careful, we might not want to blindly hard-code the keycloak choice... We have a standard here (OIDC) and we likely should stick to it, in order to increase inter-operability.

The implementation, keycloack, is an implementation detail and we should likely be able to handle any technology speaking the OIDC standard.

Cc @atan-linagora

### Comment by tanandy at 2022-05-16T05:38:19Z

indeed, AppAuth is a good choice for interoperability. forget about keycloak

### Comment by dab246 at 2022-05-20T09:34:12Z

@chibenwa @hoangdat  

I try to get session by token but no success. Specifically, I do the following:
1. After user authentication on `https://auth.upn.integration-open-paas.org/auth/realms/oidc` I got `token`
2. I use the obtained `token` to get `session`

Request
```
URL: https://gateway.upn.integration-open-paas.org/.well-known/jmap
HEADER:
Accept: application/json; jmapVersion=rfc-8621
Authorization: Bearer {{token}}
METHOD: GET
```
Response
```json
{
     "type": "about:blank",
     "status": 401,
     "detail": "Failed Jwt verification"
}
```

### Comment by chibenwa at 2022-05-20T09:49:22Z

@dab246 can you set up a debugging session with @Arsnael  ?

### Comment by hoangdat at 2022-05-20T10:03:25Z

@dab246 IMO you are wrong in the auth server and the resource server. 
Auth console for `https://gateway.upn.integration-open-paas.org/.well-known/jmap` in `https://auth.upn.integration-open-paas.org/auth/admin/master/console/#/`. Am I right? @chibenwa

### Comment by chibenwa at 2022-05-20T10:31:20Z

Yes James uses a different OIDC server than OpenPaaS.

### Comment by hoangdat at 2022-05-20T10:36:49Z

Hi @dab246 please config the app to work with `https://auth.upn.integration-open-paas.org/auth/admin/master/console/#/` and `https://gateway.upn.integration-open-paas.org/.well-known/jmap`.

### Comment by dab246 at 2022-05-20T11:07:02Z

@hoangdat I tried but still get the above error

### Comment by tanandy at 2022-05-20T12:05:27Z

> Yes James uses a different OIDC server than OpenPaaS.

Interesting, What is the OIDC server you are using now ? are you mentionning instead that OpenPaas doesnt user API GTW yet (like krakend) ? or you have keycloak+krakend somewhere else ?

### Comment by chibenwa at 2022-05-20T14:50:54Z

Keykloack cas federation used is OpenPaaS setup bringed in limitations. SLO don't work at all on that set up.

Its not a setup we would target in the future so we installed a keycloack for testing keycloack + oidc for james.

Btw we reach some krakend limitations (websockets) so we might reconsider our oidc implementation strayegy.

### Comment by hoangdat at 2022-05-23T08:12:07Z

@dab246 @chibenwa I got 400

```
curl -XGET  "https://gateway.upn.integration-open-paas.org/oidc/.well-known/webfinger?resource=https://gateway.upn.integration-open-paas.org&rel=http://openid.net/specs/connect/1.0/issuer" -H "Accept: application/json; jmapVersion=rfc-8621"
```

```
{"type":"about:blank","status":400,"detail":"'rel' supports only 'http://openid.net/specs/connect/1.0/issuer' (URL encoded: http%3A%2F%2Fopenid.net%2Fspecs%2Fconnect%2F1.0%2Fissuer)"}%    
```

### Comment by chibenwa at 2022-05-23T08:29:50Z

@Arsnael is currently doing some performance tests,he is doing a run on old 0.5.0 (buggy) but will soon revert to 0.6.0 (not buggy)

### Comment by Arsnael at 2022-05-23T10:43:13Z

Back to 0.6.0

### Comment by hoangdat at 2022-05-25T11:37:05Z

> @chibenwa @hoangdat
> 
> I try to get session by token but no success. Specifically, I do the following:
> 
> 1. After user authentication on `https://auth-dev.upn.integration-open-paas.org/auth/realms/oidc` I got `token`
> 2. I use the obtained `token` to get `session`
> 
> Request
> 
> ```
> URL: https://gateway.upn.integration-open-paas.org/.well-known/jmap
> HEADER:
> Accept: application/json; jmapVersion=rfc-8621
> Authorization: Bearer {{token}}
> METHOD: GET
> ```
> 
> Response
> 
> ```json
> {
>      "type": "about:blank",
>      "status": 401,
>      "detail": "Failed Jwt verification"
> }
> ```

hi @chibenwa what user we can use with this keycloak server? Can I add it manually to test?

<img width="995" alt="image" src="https://user-images.githubusercontent.com/6462404/170252967-1413fb74-6714-4c24-9ba0-4026a7db0952.png">

### Comment by chibenwa at 2022-05-25T11:44:50Z

>  hi @chibenwa what user we can use with this keycloak server? Can I add it manually to test?

No please.

Please use the same creds than those for PREPROD

### Comment by chibenwa at 2022-05-25T11:45:19Z

@Arsnael can you please tomorrow check the OIDC workflow?

### Comment by chibenwa at 2022-05-25T11:48:46Z

Have you tried `GET https://gateway.upn.integration-open-paas.org/oidc/.well-known/jmap`

(URL input of the user + `.well-known/webfinger...` to get the OIDC conf then URL input of the user + `.well-known/jmap` to get the session)

We collocate a OIDC compatible and an OpenPaaS compatible configuration on the same James server hence we have 2 endpoints to differenciate those.

### Comment by hoangdat at 2022-05-25T13:02:56Z

> Have you tried `GET https://gateway.upn.integration-open-paas.org/oidc/.well-known/jmap`

oh, it is okie. So, the base URL must be: `https://gateway.upn.integration-open-paas.org/oidc`? It seems complicated to user when set up the server. Do we have more simple way?

### Comment by hoangdat at 2022-05-25T13:05:05Z

all other JMAP request must be in : `https://gateway.upn.integration-open-paas.org/oidc/jmap`?

### Comment by hoangdat at 2022-05-25T13:07:11Z

btw, with OIDC, do we have any way to get current user?

<img width="348" alt="image" src="https://user-images.githubusercontent.com/6462404/170268979-11cfbb98-5fe3-4e5c-836a-9361e1f9cfab.png">

### Comment by hoangdat at 2022-05-25T14:30:39Z

> Sorry this was a bit long.
> 
> Base URL: `https://gateway.upn.integration-open-paas.org/oidc`
> 
> curl call for discovering OIDC endpoints:
> 
> ```
> curl -XGET  "https://gateway.upn.integration-open-paas.org/oidc/.well-known/webfinger?resource=https://gateway.upn.integration-open-paas.org&rel=http://openid.net/specs/connect/1.0/issuer" -H "Accept: application/json; jmapVersion=rfc-8621"
> ```
> 
> -> If it returns an error then fallback to basic auth -> else authenticate
> 
> Then curl call to get the JMAP session:
> 
> ```
> curl -XGET  "https://gateway.upn.integration-open-paas.org/oidc/.well-known/jmap" -H "Accept: application/json; jmapVersion=rfc-8621"
> ```

I need to simplify that:

1. User need to input what URL?
2. With the only information: base URL, how we can request to `webfinger`? What is parameters?
* resource = baseUrl?
* rel = http://openid.net/specs/connect/1.0/issuer? Is it fixed
3. Please explain me about the object
```
{
    "subject": "https://gateway.upn.integration-open-paas.org",
    "links": [
        {
            "rel": "http://openid.net/specs/connect/1.0/issuer",
            "href": "https://auth-dev.upn.integration-open-paas.org/auth/realms/oidc"
        }
    ]
}
```
We get `href` and execute OIDC with it?

4. After get token? How we connect to JMAP server?

### Comment by chibenwa at 2022-05-26T01:50:49Z

1./ When you login on mobile, you need to tell where your JMAP server is.

On WEB this base URL is provided by the static assets.

2. 

> resource = baseUrl?

Yes

> rel = http://openid.net/specs/connect/1.0/issuer? Is it fixed

Yes

3.

> We get href and execute OIDC with it?

4. 

`GET $BASE_URL/.well-known/jmap` here with base URL = `https://gateway.upn.integration-open-paas.org/oidc` so this is `GET https://gateway.upn.integration-open-paas.org/oidc/.well-known/jmap`

> oh, it is okie. So, the base URL must be: https://gateway.upn.integration-open-paas.org/oidc? It seems complicated to user when set up the server. Do we have more simple way?

The /oidc stuff is a deployment detail here (preprod collocates an OpenPaaS deployment and an OIDC deployment). This will not be the case for a real world deployment. No problem!

### Comment by chibenwa at 2022-05-26T01:51:17Z

> btw, with OIDC, do we have any way to get current user?

I do not understand

### Comment by hoangdat at 2022-05-26T08:08:00Z

As current status, we always show the current account like this

<img width="535" alt="image" src="https://user-images.githubusercontent.com/6462404/170445962-ae5292dd-f3b6-4658-bf57-a1a8d374229d.png">

But right now, in the case of OIDC, how about we get current user info via OIDC endpoint?

### Comment by chibenwa at 2022-05-26T08:31:07Z

> But right now, in the case of OIDC, how about we get current user info via OIDC endpoint?

You need to get the OIDC endpoint configuration: https://auth-dev.upn.integration-open-paas.org/auth/realms/oidc/.well-known/openid-configuration (Append `.well-known/openid-configuration` to the endpoint return by webfinger)

Then it gives you the userinfo endpoint: https://auth-dev.upn.integration-open-paas.org/auth/realms/oidc/protocol/openid-connect/userinfo

--------------------

Alternative: get the name from the session: https://github.com/apache/james-project/blob/b145cdc8c040280cd379fd514804fdd41ae3f918/server/protocols/jmap-rfc-8621/src/test/scala/org/apache/james/jmap/routes/SessionRoutesTest.scala#L158

Account name. Easy. No beahviour divergence between basic auth and OIDC ;-)

That will lead to cleaner code on your side ;-)

### Comment by hoangdat at 2022-06-28T05:23:24Z

## Discussion on the preprod env:

### Context:
1. Web version:

- We should config the URL for JMAP server when deploying web app. In this case of `Preprod` we define: 
```
SERVER_URL=https://jmap.upn.integration-open-paas.org
DOMAIN_REDIRECT_URL=https://tmail.upn.integration-open-paas.org/
WEB_OIDC_CLIENT_ID=teammail-web
```
- when user open web app, app request to (please notice the URL) to detect this server support OIDC or not. `[Please notice this point]`
```
https://jmap.upn.integration-open-paas.org/.well-known/webfinger?resource=https://jmap.upn.integration-open-paas.org&rel=http://openid.net/specs/connect/1.0/issuer
```
Response
```
{
  "subject": "https://jmap.upn.integration-open-paas.org",
  "links": [
    {
      "rel": "http://openid.net/specs/connect/1.0/issuer",
      "href": "https://auth-dev.upn.integration-open-paas.org/auth/realms/oidc"
    }
  ]
}
```
This make our app think that we can work with OIDC with `https://jmap.upn.integration-open-paas.org` but the fact that, after we got the `token` from `auth-dev` server, we can not get the `session`:

<img width="451" alt="image" src="https://user-images.githubusercontent.com/6462404/176104599-406aafb8-54f6-4010-bac2-7d595be84252.png">

```
{"type":"about:blank","status":401,"detail":"Failed Jwt verification"}
```

### My understanding
- `https://jmap.upn.integration-open-paas.org` is not supported to work with OIDC
- only: `https://gateway.upn.integration-open-paas.org/oidc` can work with `token` from OIDC

### What I need if my understanding is correct
-  please return 404 or any error when I request to 
```
https://jmap.upn.integration-open-paas.org/.well-known/webfinger?resource=https://jmap.upn.integration-open-paas.org&rel=http://openid.net/specs/connect/1.0/issuer
```

### Comment by Arsnael at 2022-06-28T07:14:12Z

> ### My understanding
> 
>     * `https://jmap.upn.integration-open-paas.org` is not supported to work with OIDC
> 
>     * only: `https://gateway.upn.integration-open-paas.org/oidc` can work with `token` from OIDC

Correct. Because james does not deal with OIDC directly on the jmap endpoint, we delegated that to the api gateway (made our implem easier and faster). The api gateway is the `https://gateway.upn.integration-open-paas.org` one. You can access through it:

- jmap with normal auth: `https://gateway.upn.integration-open-paas.org/jmap`
- jmap with oidc: `https://gateway.upn.integration-open-paas.org/oidc/jmap`

> ### What I need if my understanding is correct
> 
>     * please return 404 or any error when I request to
> 
> 
> ```
> https://jmap.upn.integration-open-paas.org/.well-known/webfinger?resource=https://jmap.upn.integration-open-paas.org&rel=http://openid.net/specs/connect/1.0/issuer
> ```

No not that easy. We only have one endpoint for webfinger in James. James has no notion of the api gateway. If I disable it in James, it will be disable for any url you use (as James just say hey I can serve oidc... the rest is not its problem I think)

The trick is with our api gateway. If you point your app to :
- `https://gateway.upn.integration-open-paas.org` => the webfinger is not declared for the normal jmap route so that will likely return you your 404
- `https://gateway.upn.integration-open-paas.org/oidc` => the webfinger route is declared on the api gateway for the oidc path so this will work.

So in fact should not use `https://jmap.upn.integration-open-paas.org` at all. I know it maybe sounds confusing but actually that route should not even be exposed anymore. Just we still had it for perf tests. But now that we have an other env for that we might just stop to expose it when we have time.

Just use the gateway url from now on please and it should work as you expect I believe :)

Regarding tmail-web I know we need to make the change as we manage the helm chart on k8s. 

Do you want your tmail-web to point to oidc or normal login for now?

### Comment by hoangdat at 2022-06-28T07:24:22Z

> Do you want your tmail-web to point to oidc or normal login for now?

Please re-deployed the `tmail-web(preprod)` with OIDC.
Our developers have the way to bypass it with `BasicAuth`.

### Comment by Arsnael at 2022-06-28T07:50:43Z

Done.

However I spotted an other issue that might be related to some recent changes... a 500 from `GET https://gateway.upn.integration-open-paas.org/oidc/.well-known/jmap` will investigate (something blocking in the reactive pipeline...)

### Comment by hoangdat at 2022-06-28T08:13:27Z

no problem when I assign this https://github.com/linagora/tmail-flutter/issues/671 to you?

### Comment by chibenwa at 2022-12-12T04:34:25Z

Is this done, @hoangdat ?
