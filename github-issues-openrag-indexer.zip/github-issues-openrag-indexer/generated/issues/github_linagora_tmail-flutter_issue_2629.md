# GitHub issue #2629: Display glitch

## Metadata

Repository: linagora/tmail-flutter
Issue number: 2629
State: closed
Author: Arsnael
Created at: 2024-02-22T03:06:32Z
Updated at: 2025-05-07T20:18:05Z
Closed at: 2024-10-28T06:39:16Z
Labels: bug
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/2629

## Issue body

From https://github.com/linagora/tmail-backend/issues/931 reported by @chibenwa 

 prod: linagora/tmail-web:v0.11.3-patch4-3

![306655246-8322da02-1fd9-4149-8fb6-1c5499a27b93](https://github.com/linagora/tmail-flutter/assets/9005025/38fb7f3a-fc87-40d9-be89-6c2a37c90645)

The guy used chome. Waiting for OS and screen settings.

I tried on my side:

![306667816-cf4893b7-333a-484c-8877-24631a6e25d7](https://github.com/linagora/tmail-flutter/assets/9005025/adeb8f52-9301-463d-a668-2bf2ddb5acf7)

Was ok on chromium.

![306659225-794f165c-9c33-447c-ab54-0bc3256d9997](https://github.com/linagora/tmail-flutter/assets/9005025/065af917-a4a6-4e7f-94f2-949db280bc69)

Truncated text.

Set "french" and activate vacation responder.

Chromium on ubuntu

@QuangHoang1210 please have a look.

## Comments

### Comment by QuangHoang1210 at 2024-02-22T19:50:04Z

Working normal on my side 
**OS**
<img width="1512" alt="Screenshot 2024-02-22 at 11 48 43 PM" src="https://github.com/linagora/tmail-flutter/assets/124866146/8d46f3b6-e3c4-4b0f-a146-e842df5786e3">

<img width="1511" alt="Screenshot 2024-02-22 at 11 54 29 PM" src="https://github.com/linagora/tmail-flutter/assets/124866146/abc562a9-abd9-4494-97b4-781ab9396f51">

**Windows**

![telegram-cloud-photo-size-5-6251529297277860463-w](https://github.com/linagora/tmail-flutter/assets/124866146/9b03359b-318d-4028-9524-13c4d3f36b36)

![telegram-cloud-photo-size-5-6251529297277860464-w](https://github.com/linagora/tmail-flutter/assets/124866146/56b588ee-f62b-4878-a183-a77e138e1811)

### Comment by chibenwa at 2024-02-22T19:55:59Z

Have you tried with a chrome on windows?

### Comment by QuangHoang1210 at 2024-02-22T20:02:54Z

@chibenwa I have tried both OS and Windows

### Comment by chibenwa at 2024-02-22T20:08:33Z

Weird then...

### Comment by chibenwa at 2024-02-22T20:08:54Z

chrome on tablet maybe?

### Comment by hoangdat at 2024-02-23T01:38:46Z

We still not reproduce the same as user. But we found that `version name` also truncated. 

![306841179-38fb7f3a-fc87-40d9-be89-6c2a37c90645](https://github.com/linagora/tmail-flutter/assets/6462404/f41c77a6-d4cd-423a-9621-dd3f397138f1)

So, please ask the user on the screen solution and the platform which user use.

### Comment by chibenwa at 2024-02-23T07:38:40Z

> So, please ask the user on the screen solution and the platform which user use.

Already...

### Comment by hoangdat at 2024-10-28T06:39:16Z

Fixed truncated, and move down the app version.
