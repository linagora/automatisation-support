# GitHub issue #1604: [TeamMailboxes] Email unread counter is not correctly

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1604
State: closed
Author: QuangHoang1210
Created at: 2023-03-15T06:43:06Z
Updated at: 2023-03-29T19:28:02Z
Closed at: 2023-03-29T19:28:02Z
Labels: bug
Assignees: nqhhdev
URL: https://github.com/linagora/tmail-flutter/issues/1604

## Issue body

OS: Window / Android 
Device: Laptop / Mobile
TMail version: 0.7.4

*Precondition: 

User already loggin sucessfully / Email account already in teamailboxes

*Reproduce Step:
1, User click to view teamailboxes hiring

Actual: There is no email existed but unread counters still display as 2
Expected: Email unread counter is displayed correctly value as the total unread emails in teammailboxes

https://user-images.githubusercontent.com/124866146/225227431-cd245468-5057-4546-ac78-97cca6a5c366.mp4

## Comments

### Comment by chibenwa at 2023-03-15T06:55:39Z

JMAP request when refreshing the mailbox list, please?

### Comment by QuangHoang1210 at 2023-03-15T18:49:37Z

**Request payload:**
```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail"
  ],
  "methodCalls": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "filter": {
          "inMailbox": "e999e020-64b4-11ed-88c0-338bebbdf582"
        },
        "sort": [
          {
            "isAscending": false,
            "property": "receivedAt"
          }
        ],
        "limit": 20
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "#ids": {
          "resultOf": "c0",
          "name": "Email/query",
          "path": "/ids/*"
        },
        "properties": [
          "id",
          "subject",
          "from",
          "to",
          "cc",
          "bcc",
          "keywords",
          "size",
          "receivedAt",
          "sentAt",
          "preview",
          "hasAttachment",
          "replyTo",
          "mailboxIds"
        ]
      },
      "c1"
    ]
  ]
}
```

**Response payload:**
```
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Email/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "queryState": "00000000",
        "canCalculateChanges": false,
        "ids": [],
        "position": 0
      },
      "c0"
    ],
    [
      "Email/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "9de3cd90-c322-11ed-8a14-a7f3fbfdb520",
        "list": []
      },
      "c1"
    ]
  ]
}
```

### Comment by chibenwa at 2023-03-16T01:59:51Z

Mailbox/get please?

### Comment by chibenwa at 2023-03-16T02:00:14Z

(F5?)

### Comment by QuangHoang1210 at 2023-03-16T03:10:13Z

**Request payload:**
```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail"
  ],
  "methodCalls": [
    [
      "Mailbox/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "filter": {
          "role": "Spam"
        },
        "limit": 1
      },
      "c0"
    ],
    [
      "Mailbox/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "#ids": {
          "resultOf": "c0",
          "name": "Mailbox/query",
          "path": "/ids/*"
        }
      },
      "c1"
    ]
  ]
}
```

**Response payload:**
```
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Mailbox/query",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "queryState": "b7a9a4b5",
        "canCalculateChanges": false,
        "ids": [
          "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a"
        ],
        "position": 0,
        "limit": 256
      },
      "c0"
    ],
    [
      "Mailbox/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "2d94a100-c362-11ed-8a14-a7f3fbfdb520",
        "list": [
          {
            "totalThreads": 62,
            "name": "Spam",
            "isSubscribed": true,
            "role": "spam",
            "totalEmails": 62,
            "unreadThreads": 46,
            "unreadEmails": 46,
            "sortOrder": 70,
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a"
          }
        ]
      },
      "c1"
    ]
  ]
}
```

### Comment by chibenwa at 2023-03-16T07:24:39Z

No thats not the right one this one is only spam report

### Comment by QuangHoang1210 at 2023-03-16T09:12:42Z

**Request payload:**

```
{
  "using": [
    "urn:ietf:params:jmap:core",
    "urn:ietf:params:jmap:mail",
    "urn:apache:james:params:jmap:mail:shares"
  ],
  "methodCalls": [
    [
      "Mailbox/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b"
      },
      "c0"
    ]
  ]
}
```

**Response payload:**
```
{
  "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
  "methodResponses": [
    [
      "Mailbox/get",
      {
        "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
        "notFound": [],
        "state": "2d94a100-c362-11ed-8a14-a7f3fbfdb520",
        "list": [
          {
            "totalThreads": 7320,
            "name": "INBOX",
            "isSubscribed": true,
            "role": "inbox",
            "totalEmails": 7320,
            "unreadThreads": 3642,
            "unreadEmails": 3642,
            "sortOrder": 10,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "fff9f670-30a9-11eb-9a8d-254ee97830fe"
          },
          {
            "totalThreads": 356,
            "name": "Drafts",
            "isSubscribed": true,
            "role": "drafts",
            "totalEmails": 356,
            "unreadThreads": 49,
            "unreadEmails": 49,
            "sortOrder": 30,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9d0a0230-32cf-11eb-995c-a3ae66e9f96a"
          },
          {
            "totalThreads": 106,
            "name": "Outbox",
            "isSubscribed": true,
            "role": "outbox",
            "totalEmails": 106,
            "unreadThreads": 74,
            "unreadEmails": 74,
            "sortOrder": 40,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9cf7d9c0-32cf-11eb-995c-a3ae66e9f96a"
          },
          {
            "totalThreads": 8121,
            "name": "Sent",
            "isSubscribed": true,
            "role": "sent",
            "totalEmails": 8121,
            "unreadThreads": 3,
            "unreadEmails": 3,
            "sortOrder": 50,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a"
          },
          {
            "totalThreads": 0,
            "name": "Trash",
            "isSubscribed": true,
            "role": "trash",
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 60,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9d05e380-32cf-11eb-995c-a3ae66e9f96a"
          },
          {
            "totalThreads": 62,
            "name": "Spam",
            "isSubscribed": true,
            "role": "spam",
            "totalEmails": 62,
            "unreadThreads": 46,
            "unreadEmails": 46,
            "sortOrder": 70,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9d0dd2c0-32cf-11eb-995c-a3ae66e9f96a"
          },
          {
            "totalThreads": 0,
            "name": "mailbox162",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "32025291-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox245",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31fbc2e0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox76",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "317c80c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox232",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31d83550-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox95",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312e12a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox33",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "313dca10-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox73",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30d98a00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox134",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318a1552-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox46",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318a1551-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox57",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3102bce0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox88",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30db37b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox164",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b25dd0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox85",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30fe01f0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox218",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ba9b30-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 9,
            "name": "mailbox16",
            "isSubscribed": false,
            "totalEmails": 9,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a59272f0-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 12,
            "name": "mailbox11",
            "isSubscribed": false,
            "totalEmails": 12,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a3a45e90-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 13,
            "name": "mailbox20",
            "isSubscribed": false,
            "totalEmails": 13,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a7203ee0-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 1,
            "name": "mailbox227",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31e29590-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox223",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31efdc00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox155",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31a2a660-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox202",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b9fef0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 15,
            "name": "mailbox9",
            "isSubscribed": false,
            "totalEmails": 15,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a2d96d70-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 1,
            "name": "mailbox190",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318b26c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 3,
            "name": "mailbox99",
            "isSubscribed": false,
            "totalEmails": 3,
            "unreadThreads": 3,
            "unreadEmails": 3,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310ad331-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox83",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "308a5890-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox42",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30e91a60-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox48",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30e9b6a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 3,
            "name": "mailbox19",
            "isSubscribed": false,
            "totalEmails": 3,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a6bb6290-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox98",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30bd9d90-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "Sent",
            "isSubscribed": true,
            "totalEmails": 2,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "parentId": "e996d2e0-64b4-11ed-88c0-338bebbdf582",
            "namespace": "TeamMailbox[hiring@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "e9a13320-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 0,
            "name": "mailbox212",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31c4ad50-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox226",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ff9370-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox150",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f81960-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox120",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3161f3e0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox32",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "307f0df0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 11,
            "name": "mailbox6",
            "isSubscribed": false,
            "totalEmails": 11,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a1aa1530-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox100",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30aa1590-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox140",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31aabcb0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox166",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31648bf0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox153",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318cad60-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox219",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f2c230-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox112",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310702a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox118",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3128bb70-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox204",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31fef730-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox122",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30dd0c70-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 8,
            "name": "mailbox3",
            "isSubscribed": false,
            "totalEmails": 8,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a085b970-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox87",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "317de050-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox115",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30edd550-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox130",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31563410-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox228",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ede030-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox109",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30c8e830-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox169",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31c6f740-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox108",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30bd9d91-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox177",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31aeb450-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox242",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31897910-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox93",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310072f0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox156",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "315c9cb0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox78",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30830590-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox189",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3161f3e1-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "Sent",
            "isSubscribed": true,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "parentId": "ca28b630-64b4-11ed-88c0-338bebbdf582",
            "namespace": "TeamMailbox[sales@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "ca2fbb10-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 0,
            "name": "mailbox66",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3108d760-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox113",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31161dd0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox26",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "309247d0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "INBOX",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "parentId": "e3f63dd0-64b4-11ed-88c0-338bebbdf582",
            "namespace": "TeamMailbox[human-resources@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "e3f9e750-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 1,
            "name": "mailbox71",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30952e00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox25",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31202ff0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox178",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "316a5850-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 9,
            "name": "mailbox14",
            "isSubscribed": false,
            "totalEmails": 9,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a4d11ec0-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 1,
            "name": "mailbox244",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "317f8e00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox104",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310777d0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 3,
            "name": "mailbox52",
            "isSubscribed": false,
            "totalEmails": 3,
            "unreadThreads": 3,
            "unreadEmails": 3,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30a61df0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "quanng dep zai hâhhahhaa",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "adf85190-bd57-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 0,
            "name": "mailbox91",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31155a80-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox229",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "32069852-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox82",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "317f3fe0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox55",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31004be0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 10,
            "name": "mailbox15",
            "isSubscribed": false,
            "totalEmails": 10,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a5344d60-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox30",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312eaee0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox105",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312782f0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "7df82e40-bd55-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 2,
            "name": "INBOX",
            "isSubscribed": true,
            "totalEmails": 2,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "parentId": "ca28b630-64b4-11ed-88c0-338bebbdf582",
            "namespace": "TeamMailbox[sales@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "ca2cd4e0-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 1,
            "name": "mailbox117",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3117f290-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox103",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "319d2820-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox144",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31dbded0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox75",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310295d0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox248",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cd11c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox208",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b54400-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox31",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30da4d50-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai 2",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "6e67bc50-bd57-11ed-be37-619ed00620a1",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "80fb4a30-bd57-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 11,
            "name": "mailbox18",
            "isSubscribed": false,
            "totalEmails": 11,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a6554dc0-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox138",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "8d065740-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 15,
            "name": "mailbox12",
            "isSubscribed": true,
            "totalEmails": 15,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "7df82e40-bd55-11ed-be37-619ed00620a1",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a3fda220-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 1,
            "name": "mailbox126",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312f2410-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox243",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cb15f0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox77",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30a9a060-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox180",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "316416c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox63",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30880ea0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox198",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31c98f50-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox143",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cff7f0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox165",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "316b1ba0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox167",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "319f4b00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox221",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b39650-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox250",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "317f3fe2-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox161",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30eee6c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox147",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30d5b970-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox152",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "314b5ea0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 10,
            "name": "mailbox111",
            "isSubscribed": false,
            "totalEmails": 10,
            "unreadThreads": 6,
            "unreadEmails": 6,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312befc0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox28",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30b58740-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 4,
            "name": "hiring",
            "isSubscribed": true,
            "totalEmails": 4,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "namespace": "TeamMailbox[hiring@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "e996d2e0-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 0,
            "name": "mailbox47",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30c95d60-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox182",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3142fa30-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox174",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "319a6900-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox92",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3110edb0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox50",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30bc8c20-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox199",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "315570c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox231",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cdae00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox222",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31eb9640-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox247",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31db1b80-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox163",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31a98430-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox172",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3191b670-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox89",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310ad330-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox34",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "313f9ed0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox235",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31c856d0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 8,
            "name": "mailbox17",
            "isSubscribed": false,
            "totalEmails": 8,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a5f55370-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 1,
            "name": "mailbox136",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31403b10-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 6,
            "name": "mailbox2",
            "isSubscribed": false,
            "totalEmails": 6,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a025e630-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 5,
            "name": "mailbox116",
            "isSubscribed": true,
            "totalEmails": 5,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312a9030-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox94",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30dac280-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox54",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "310b2150-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox123",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30bd2860-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox38",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "316946e0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox175",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31d96dd0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 10,
            "name": "mailbox4",
            "isSubscribed": false,
            "totalEmails": 10,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a0e78880-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox214",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ed9210-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox159",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3156d050-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox210",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cebf70-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox53",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "311a8aa0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox171",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31eb4820-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox27",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31068d70-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "@",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a621aa90-af1d-11ed-8e2c-f549e2a24cfd"
          },
          {
            "totalThreads": 1,
            "name": "mailbox35",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3126bfa0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox179",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31a5b3a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox224",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "32108360-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox146",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30f8aac1-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox183",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31a6c510-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox39",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3082b770-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox133",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318d2290-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox216",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31a56580-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox44",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30fa7f80-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai qua di abc xyz def 123345",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "6e67bc50-bd57-11ed-be37-619ed00620a1",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "8f9c4120-bd57-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 0,
            "name": "mailbox193",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30fdb3d0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox213",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f72f00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox186",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31523c70-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox135",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "313cdfb0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox238",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31bce520-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox205",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318a1550-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox141",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "8d62a810-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox207",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ee5560-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox196",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f7a431-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox67",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3100c110-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 11,
            "name": "mailbox13",
            "isSubscribed": false,
            "totalEmails": 11,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a46b09f0-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai 2",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "91125140-bd55-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 0,
            "name": "Sent",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "parentId": "e3f63dd0-64b4-11ed-88c0-338bebbdf582",
            "namespace": "TeamMailbox[human-resources@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "e3fca670-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 16,
            "name": "mailbox10",
            "isSubscribed": false,
            "totalEmails": 16,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a3404590-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox80",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30ce8d80-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox239",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31c74560-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox187",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "32025290-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox230",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f09f50-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox236",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b3bd60-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox148",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3136c530-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 5,
            "name": "mailbox7",
            "isSubscribed": false,
            "totalEmails": 5,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a20f1890-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox41",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30e7bad0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox69",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30fd65b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox203",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31fc3810-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox211",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f88e90-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox200",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31918f60-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox70",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "308aa6b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox96",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30dd3380-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox184",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31582fe0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox68",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "317b9660-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox246",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f53330-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox36",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31425df0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox97",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "309443a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 11,
            "name": "mailbox8",
            "isSubscribed": false,
            "totalEmails": 11,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a274df40-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox220",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3204eaa1-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox149",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b962b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 9,
            "name": "mailbox5",
            "isSubscribed": false,
            "totalEmails": 9,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a14d7640-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 2,
            "name": "sales",
            "isSubscribed": true,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "namespace": "TeamMailbox[sales@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "ca28b630-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 1,
            "name": "mailbox127",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "313d06c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 12,
            "name": "mailbox1",
            "isSubscribed": false,
            "totalEmails": 12,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "9fbe23b0-3074-11eb-81f4-31a5ab4895e4"
          },
          {
            "totalThreads": 0,
            "name": "mailbox101",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312b7a90-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "human-resources",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "namespace": "TeamMailbox[human-resources@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "e3f63dd0-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 0,
            "name": "mailbox168",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31a20a20-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox215",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31bcbe10-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox43",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30ac5f80-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox121",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31805150-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox173",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31986d30-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox217",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cf0d90-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox192",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f6e0e1-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox74",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30c2cdb0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox237",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3207a9c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox72",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3087e790-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox45",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31367710-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox131",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "320538c0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox64",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30f8aac0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox240",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f77d20-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox160",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31425df1-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox125",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3117a470-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox107",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30d80360-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox61",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30809490-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox62",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30ea2bd0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox86",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3137d6a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox170",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31d1a5a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox79",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30a69320-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox209",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ab31e0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox132",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3154ad70-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox151",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31414c81-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox194",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31d80e40-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox90",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3081f420-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox176",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31df8850-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox129",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "315549b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox195",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "318bc300-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox188",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "316157a0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox60",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30eac810-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox58",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31cc7580-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox191",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ef3fc0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox157",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "32069850-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox56",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30b909b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox59",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31db1b81-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox139",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "315b6430-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox249",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31d17e90-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai hahhaa",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "a19ae200-bd57-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 0,
            "name": "mailbox128",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30f17ed0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox37",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31044380-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox145",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "311d22b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox51",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "8cee1450-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox81",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "309cf630-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox110",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3120a520-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox206",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31ef18b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox158",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3151ee50-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox114",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3118dcf0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox154",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31e1d240-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox233",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31bd3340-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox84",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31365000-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox40",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30f130b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 2,
            "name": "mailbox102",
            "isSubscribed": false,
            "totalEmails": 2,
            "unreadThreads": 2,
            "unreadEmails": 2,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "312f9940-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox197",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31f6e0e0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox65",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30979f00-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox225",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31e04ba0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 6,
            "name": "INBOX",
            "isSubscribed": true,
            "totalEmails": 6,
            "unreadThreads": 3,
            "unreadEmails": 3,
            "sortOrder": 1000,
            "rights": {
              "firstname31.surname31@upn.integration-open-paas.org": [
                "i",
                "l",
                "r",
                "s",
                "t",
                "w"
              ]
            },
            "parentId": "e996d2e0-64b4-11ed-88c0-338bebbdf582",
            "namespace": "TeamMailbox[hiring@upn.integration-open-paas.org]",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": false,
              "mayRename": false,
              "mayDelete": false,
              "maySubmit": false
            },
            "id": "e999e020-64b4-11ed-88c0-338bebbdf582"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai 1",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "6e67bc50-bd57-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 0,
            "name": "mailbox201",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31b9b0d0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 1,
            "name": "mailbox49",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "30deba20-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox29",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "3080e2b0-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "quang dep zai 1",
            "isSubscribed": true,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "parentId": "9cfcbbc0-32cf-11eb-995c-a3ae66e9f96a",
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "887963c0-bd55-11ed-be37-619ed00620a1"
          },
          {
            "totalThreads": 1,
            "name": "mailbox142",
            "isSubscribed": false,
            "totalEmails": 1,
            "unreadThreads": 1,
            "unreadEmails": 1,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "314f5640-3f62-11eb-bf20-f1a8da6866c8"
          },
          {
            "totalThreads": 0,
            "name": "mailbox181",
            "isSubscribed": false,
            "totalEmails": 0,
            "unreadThreads": 0,
            "unreadEmails": 0,
            "sortOrder": 1000,
            "rights": {},
            "namespace": "Personal",
            "myRights": {
              "mayReadItems": true,
              "mayAddItems": true,
              "mayRemoveItems": true,
              "maySetSeen": true,
              "maySetKeywords": true,
              "mayCreateChild": true,
              "mayRename": true,
              "mayDelete": true,
              "maySubmit": true
            },
            "id": "31975bc0-3f62-11eb-bf20-f1a8da6866c8"
          }
        ]
      },
      "c0"
    ]
  ]
}
```

### Comment by Arsnael at 2023-03-16T09:43:50Z

Reason: the frontend team forgot to add ""urn:apache:james:params:jmap:mail:shares"" capability when calling Email/query, thus why you don't see any emails even if some are present (and I'm pretty sure I reported that same thing a while ago I forgot where...)

With my postman, seeing that the inbox of sales team mailbox id is `ca2cd4e0-64b4-11ed-88c0-338bebbdf582`, for user 31:

-> your initial request:

```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail"
    ],
    "methodCalls": [
        [
            "Email/query",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "limit": 20,
                "filter": {
                    "inMailbox": "ca2cd4e0-64b4-11ed-88c0-338bebbdf582"
                },
                "sort": [{
                  "property":"sentAt",
                  "isAscending": false
                }],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "properties": [
                    "subject",
                    "from",
                    "receivedAt",
                    "sentAt",
                    "preview",
                    "hasAttachment"
                ],
                "#ids": {
                    "resultOf": "c2",
                    "name": "Email/query",
                    "path": "ids/*"
                }
            },
            "c3"
        ]
    ]
}

Gives the empty following response:

{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/query",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "queryState": "00000000",
                "canCalculateChanges": false,
                "ids": [],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "notFound": [],
                "state": "2d9479f0-c362-11ed-8a14-a7f3fbfdb520",
                "list": []
            },
            "c3"
        ]
    ]
}
```

The same request by adding the shares capability:

```
{
    "using": [
        "urn:ietf:params:jmap:core",
        "urn:ietf:params:jmap:mail",
        "urn:apache:james:params:jmap:mail:shares"
    ],
    "methodCalls": [
        [
            "Email/query",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "limit": 20,
                "filter": {
                    "inMailbox": "ca2cd4e0-64b4-11ed-88c0-338bebbdf582"
                },
                "sort": [{
                  "property":"sentAt",
                  "isAscending": false
                }],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "properties": [
                    "subject",
                    "from",
                    "receivedAt",
                    "sentAt",
                    "preview",
                    "hasAttachment"
                ],
                "#ids": {
                    "resultOf": "c2",
                    "name": "Email/query",
                    "path": "ids/*"
                }
            },
            "c3"
        ]
    ]
}

Gives the following response:

{
    "sessionState": "2c9f1b12-b35a-43e6-9af2-0106fb53a943",
    "methodResponses": [
        [
            "Email/query",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "queryState": "7b7da8ef",
                "canCalculateChanges": false,
                "ids": [
                    "7e94d4a0-ad08-11ed-8fcc-bdd4efb538b5",
                    "cdfde0f0-b40f-11ed-acb8-2f989b3f0bd9"
                ],
                "position": 0
            },
            "c2"
        ],
        [
            "Email/get",
            {
                "accountId": "e3fc02996cba903c1d614de5cde5e093eeb488edb5e40dd81c476fe42fdfc92b",
                "notFound": [],
                "state": "2d9479f0-c362-11ed-8a14-a7f3fbfdb520",
                "list": [
                    {
                        "subject": "test subject",
                        "preview": "Dear firstname29.surname29@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
                        "id": "7e94d4a0-ad08-11ed-8fcc-bdd4efb538b5",
                        "from": [
                            {
                                "name": "Tuan PHAM",
                                "email": "expeditor@linagora.com"
                            }
                        ],
                        "receivedAt": "2023-02-15T08:12:31Z",
                        "sentAt": "2022-04-26T02:27:54Z",
                        "hasAttachment": false
                    },
                    {
                        "subject": "test subject",
                        "preview": "Dear firstname31.surname31@upn.integration-open-paas.org, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nunc sem, dignissim eu gravida in, ornare ac lectus. Nunc porta tristique eros, non rhoncus felis euismod non. Aenean ut pulvinar ",
                        "id": "cdfde0f0-b40f-11ed-acb8-2f989b3f0bd9",
                        "from": [
                            {
                                "name": "Tuan PHAM",
                                "email": "expeditor@linagora.com"
                            }
                        ],
                        "receivedAt": "2023-02-24T06:52:29Z",
                        "sentAt": "2022-04-26T02:27:54Z",
                        "hasAttachment": false
                    }
                ]
            },
            "c3"
        ]
    ]
}
```
Magic! Please frontend team, add the missing capability on those email jmap method calls, that will help you showing the emails present in a team mailbox that the user has access to :)

### Comment by chibenwa at 2023-03-16T10:07:25Z

Good diagnostic @Arsnael  <3

### Comment by dab246 at 2023-03-17T02:53:31Z

As far as I know, the `urn:apache:james:params:jmap:mail:shares` capability says `Team-Mailbox` is supported. 
So in addition to `Email/query` need to add this capability. Do other methods like `Get/Set` of email need to add it?

### Comment by Arsnael at 2023-03-17T03:02:14Z

> As far as I know, the `urn:apache:james:params:jmap:mail:shares` capability says `Team-Mailbox` is supported. So in addition to `Email/query` need to add this capability. Do other methods like `Get/Set` of email need to add it?

It should yes: Get/Set/Query/Changes for Mailbox and Email I would say.

I agree though that the documentation isn't really clear about this and will create a ticket to correct that, thanks for the feedback

### Comment by Arsnael at 2023-03-17T03:21:57Z

EDIT: my bad, actually it is: https://github.com/apache/james-project/blob/master/server/protocols/jmap-rfc-8621/doc/specs/spec/mail/rights.mdown#behavioral-changes

Notice that shares capability should be necessary for shared mailboxes as well, my guess is you have likely the same issue with those
