# GitHub issue #4022: Release new version 0.19.0

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4022
State: closed
Author: hoangdat
Created at: 2025-09-17T08:44:51Z
Updated at: 2025-10-03T08:29:11Z
Closed at: 2025-10-03T08:29:11Z
Labels: releasing
Assignees: hoangdat, dab246
URL: https://github.com/linagora/tmail-flutter/issues/4022

## Issue body

### DoD:
- [x] Request translating in weblate and merge to branch
- [x] Test in all platforms base on the check-list case: [tnr-tmail-template_20Mar.ods](https://github.com/user-attachments/files/19358057/tnr-tmail-template_20Mar.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [x] Memory leak verifycation
  - View emails with heavy inline
  - Send multiple emails with heavy inline image and attachment
  - Create identity with heavy image
- [x] Tag new version
- [x] Push new docker image
- [x] iOS - Release app in Test Flight
- [x] Android - Release app in Internal Test

## Comments

### Comment by dab246 at 2025-09-18T03:24:15Z

@dab246 
- [x] iOS
- [x] Safari
- [x] Chrome

[tnr-tmail-v0.19.0-chrome-safari-ios.ods](https://github.com/user-attachments/files/22419174/tnr-tmail-v0.19.0-chrome-safari-ios.ods)

@tddang-linagora 
- [x] Firefox
- [x] Memory leak verifycation

[firefox-0.19.0.ods](https://github.com/user-attachments/files/22404180/firefox-0.19.0.ods)

@hoangdat 
- [x] Android

[firefox-android-0.19.1.ods](https://github.com/user-attachments/files/22492567/firefox-android-0.19.1.ods)

- [ ] Edge

### Comment by dab246 at 2025-09-18T04:13:23Z

- [x] Cannot send email after close attachment reminder dialog

https://github.com/user-attachments/assets/ab0d73c0-cedd-4d13-8b6e-2fd559a4254a

### Comment by tddang-linagora at 2025-09-18T04:38:07Z

### Memory leak verification
- View emails with heavy inline

<img width="1341" height="850" alt="Image" src="https://github.com/user-attachments/assets/501c02e9-b923-40f6-be91-b4c6003503d9" />

- Send multiple emails with heavy inline image and attachment

<img width="1341" height="850" alt="Image" src="https://github.com/user-attachments/assets/aebe3e99-a72b-4a5a-bf96-7278c616c0f1" />

- Create identity with heavy image

<img width="1341" height="850" alt="Image" src="https://github.com/user-attachments/assets/5655dde8-8e6e-4273-8c4a-7c9fcfb44494" />

### Comment by tddang-linagora at 2025-09-18T04:59:32Z

- [x] Cannot next/previous email on web

https://github.com/user-attachments/assets/4bd4f6b5-ab0d-4d84-9820-d0d6913b57f7

### Comment by tddang-linagora at 2025-09-18T07:40:13Z

- [x] Composer - Open draft email with cc/bcc, click twice on the signature collapse button to view signature

https://github.com/user-attachments/assets/fdc5c27c-e6e9-4e9d-a27b-9b9e93dd5882

### Comment by tddang-linagora at 2025-09-18T07:52:54Z

- [x] When open composer, open code view and focus on code view, the popup menu cannot be opened, and none of the recipients or the subject field can be focused

https://github.com/user-attachments/assets/19dada4a-f1c2-44de-853a-ebdb78850c3e

### Comment by tddang-linagora at 2025-09-18T08:34:37Z

- [x] Click outside attachment warning dialog, cannot click send button

https://github.com/user-attachments/assets/4f623dd6-0f36-4679-8090-e3878da72f8e

### Comment by dab246 at 2025-09-18T08:42:01Z

> * [x]  Click outside attachment warning dialog, cannot click send button
> 
 Same with https://github.com/linagora/tmail-flutter/issues/4022#issuecomment-3305357661
