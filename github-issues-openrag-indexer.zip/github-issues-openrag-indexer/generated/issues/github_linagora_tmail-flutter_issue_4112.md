# GitHub issue #4112: Release new version v0.20.0

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4112
State: closed
Author: dab246
Created at: 2025-10-17T09:16:28Z
Updated at: 2025-11-18T09:28:47Z
Closed at: 2025-11-18T09:28:47Z
Labels: releasing
Assignees: hoangdat, dab246, tddang-linagora
URL: https://github.com/linagora/tmail-flutter/issues/4112

## Issue body

### DoD:
- [x] Request translating in weblate and merge to branch
- [x] Test in all platforms base on the check-list case: [tnr-tmail-template_20Mar.ods](https://github.com/user-attachments/files/19358057/tnr-tmail-template_20Mar.ods)
  - Chrome
  - Firefox
  - Edge
  - Safari
  - Android
  - iOS
  - Opera
- [x] Memory leak verifycation
  - View emails with heavy inline
  - Send multiple emails with heavy inline image and attachment
  - Create identity with heavy image
- [x] Tag new version
- [x] Push new docker image
- [x] iOS - Release app in Test Flight
- [x] Android - Release app in Internal Test

## Comments

### Comment by dab246 at 2025-10-20T02:32:13Z

- [x] @dab246 iOS, Chrome: 

[tnr-tmail-v0.20.0-chrome-ios.ods](https://github.com/user-attachments/files/23013462/tnr-tmail-v0.20.0-chrome-ios.ods)

- [x] @hoangdat Firefox, Edge
- [ ] @tddang-linagora Android, Safari

### Comment by dab246 at 2025-10-20T03:34:03Z

- [x] We should hide `Storage` in menu settings when quota is empty

https://github.com/user-attachments/assets/c050b8d9-228b-4350-9f51-7de4b30d9895

### Comment by hoangdat at 2025-10-20T10:44:05Z

- [x] firefox 
- [x] edge  

[release_v0.20.x.ods](https://github.com/user-attachments/files/23014976/release_v0.20.x.ods)

### Comment by tddang-linagora at 2025-10-21T03:15:59Z

>View emails with heavy inline

<img width="179" height="102" alt="Image" src="https://github.com/user-attachments/assets/35b76497-930f-453a-950a-c2b6fda80883" />

>Send multiple emails with heavy inline image and attachment

<img width="176" height="107" alt="Image" src="https://github.com/user-attachments/assets/3288a037-4d11-4823-9abd-7f09a250b403" />

>Create identity with heavy image

<img width="197" height="113" alt="Image" src="https://github.com/user-attachments/assets/c18e5e4b-53e8-47a5-8bf8-aaa1b4490a3d" />

### Comment by tddang-linagora at 2025-10-21T08:51:06Z

```console
Test summary:
📝 Total: 71
✅ Successful: 68
❌ Failed: 3
  - Should see attachment list in email view after forward email successfully (integration_test/tests/email_detailed/forwarding_email_lost_attachments_test.dart)
  - Should empty and recover spam by long press mailbox successfully (integration_test/tests/mailbox/long_press_empty_and_recover_spam_test.dart)
  - Should see mailbox unread count update real time (integration_test/tests/mailbox/mailbox_count_real_time_update_test.dart)
⏩ Skipped: 0
📊 Report: file:///Users/dangdat/Desktop/dev/linagora-master/tmail-flutter/build/app/reports/androidTests/connected/index.html
⏱️  Duration: 3577s
```

### Comment by tddang-linagora at 2025-10-21T08:54:55Z

Android: 

[android-0.20.0.ods](https://github.com/user-attachments/files/23017001/android-0.20.0.ods)

### Comment by dab246 at 2025-10-22T02:51:37Z

> Android:
> 
> [android-0.20.0.ods](https://github.com/user-attachments/files/23017001/android-0.20.0.ods)

Please test Safari too @tddang-linagora

### Comment by dab246 at 2025-10-22T08:23:21Z

> * [x]  We should hide `Storage` in menu settings when quota is empty
> 


Fixed at https://github.com/linagora/tmail-flutter/pull/4116

### Comment by tddang-linagora at 2025-10-22T09:20:25Z

Safari

[safari-0.20.0.ods](https://github.com/user-attachments/files/23050393/safari-0.20.0.ods)

### Comment by tddang-linagora at 2025-10-23T02:40:05Z

- https://github.com/linagora/tmail-flutter/pull/4119
