# GitHub issue #1127: [Story] As a user, I want to read message in my team-mailbox

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1127
State: closed
Author: dieptran88
Created at: 2022-10-28T07:50:03Z
Updated at: 2024-02-27T08:58:46Z
Closed at: 2024-02-27T08:58:46Z
Labels: 
Assignees: QuangHoang1210
URL: https://github.com/linagora/tmail-flutter/issues/1127

## Issue body

# Summary

* [Related EPIC](#related-epic)
* [Definition](#definition)
* [Screenshots](#screenshots)
* [Misc](#misc)

## Related EPIC

* TODO: {link}

## Definition

- Given that I am a TMail user and I am a member of team-mailbox A 
- When I logged-in to my account, I can see the team-mailbox A under the Team-mailbox list 
- I select team-mailbox A, the folders of that team-mailbox A is shown, including: Inbox, Drafts, outbox, Sent, Trash 
- In each mailbox, user can filter messages with attachments, star, unread as other mailbox 
- The actions  "Move message" and "Mark as spam" will be hidden in team-mailbox. 

- I open a message and read it and back to thread-view
- That message is marked as unread for all other members having access to this team-mailbox 

[Back to Summary](#summary)

## Screenshots

None

[Back to Summary](#summary)

## Misc

None

[Back to Summary](#summary)

## Comments

### Comment by hoangdat at 2022-11-08T04:19:01Z

which identity will be used to send Read receipt?

### Comment by hoangdat at 2022-11-08T04:20:39Z

how about when move(+ drag/drop) messages from personal mailbox to team mailboxes? @chibenwa

### Comment by dieptran88 at 2022-11-08T04:28:08Z

Move message:
- inside team-mailbox
- from personal mailbox= >team-mailbox
- from team-mailbox => personal mailbox

### Comment by hoangdat at 2022-12-15T22:24:37Z

- read email without send ReadRecipient: what problem when receive email with ReadRecipient?

- read email with and send ReadRecipient?

@ManhNTX please consider the story with identity for Team Mailbox first?

### Comment by ManhNTX at 2022-12-17T12:26:51Z

@hoangdat yes i will skip working with this story and working with the story of identity for Team Mailbox first

### Comment by hoangdat at 2022-12-19T04:21:46Z

for the case of read recipient: identity default of this team mailbox will be used

### Comment by chibenwa at 2023-04-05T02:08:44Z

Is this done?

### Comment by hoangdat at 2023-04-05T02:26:02Z

Moved to QA column

### Comment by QuangHoang1210 at 2024-01-16T02:45:02Z

@hoangdat
