# GitHub issue #1708: [UI] [Change languages] Translating system mailboxes (INBOX, etc…)

## Metadata

Repository: linagora/tmail-flutter
Issue number: 1708
State: closed
Author: QuangHoang1210
Created at: 2023-04-04T05:20:41Z
Updated at: 2023-07-31T20:12:57Z
Closed at: 2023-07-31T20:12:57Z
Labels: improvement, costrat, customer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/1708

## Issue body

OS: WINDOW
Device: Laptop
TMail version: 0.7.6

*Precondition: 
- User already login successfully
*Data: Using account firstname31.surname31@upn.integration-open-paas.org

### *Reproduce Step:
1, User change other languages in Accout Manage / **'Languages and Region'** 
2, User go back to home page

### **Actual:** 
System mailboxes (INBOX, OUTBOX, SENT, DRAFTS, TRASH, SPAM) not translated .

![Image](https://user-images.githubusercontent.com/124866146/229694088-a64378ec-cecd-498c-9fbb-85b9c21b200e.png)


![Image](https://user-images.githubusercontent.com/124866146/229693885-d594659c-a4f7-4a98-bfe2-e517f1acfef8.png)


### **Expected:** 
It should be translated

## Comments

### Comment by hoangdat at 2023-07-06T07:12:57Z

duplicated #1979

### Comment by QuangHoang1210 at 2023-07-20T18:29:41Z

Failed -> System folder is not yet translated



https://github.com/linagora/tmail-flutter/assets/124866146/745be8f9-a7a2-4aef-841d-95c58d99d476

### Comment by hoangdat at 2023-07-20T22:16:16Z

Thank Quang, I will encourage people to contribute on it.

### Comment by QuangHoang1210 at 2023-07-29T17:27:00Z

@dab246  cc @hoangdat 

Not yet translate system folder mailboxes on v0.8.8



![Image](https://github.com/linagora/tmail-flutter/assets/124866146/df3ff37b-45a6-4f17-a8b0-287a7bf8940f)

### Comment by chibenwa at 2023-07-30T03:42:49Z

Are fr translations up to date? Cc @Arsnael

### Comment by Arsnael at 2023-07-31T02:55:27Z

@hoangdat how are translations handled for TMail already? I could have a peek if you help me navigating there

### Comment by chibenwa at 2023-07-31T03:57:43Z

Translation are handled by weblate.

Cc @hoangdat

### Comment by hoangdat at 2023-07-31T04:28:40Z

can you contribute here https://hosted.weblate.org/projects/linagora/teammail/fr/? @Arsnael

### Comment by Arsnael at 2023-07-31T10:31:20Z

Translated everything missing... Mind that some stuff might not work with your messages cut in multiple parts, different order of words between french and english in some cases

System mailboxes have been translated though

### Comment by hoangdat at 2023-07-31T13:54:58Z

`v0.8.9`

### Comment by QuangHoang1210 at 2023-07-31T20:12:57Z

Passed on 0.8.9


![Image](https://github.com/linagora/tmail-flutter/assets/124866146/dd0a2884-51e0-4ebf-82bb-11765cc643da)



![Image](https://github.com/linagora/tmail-flutter/assets/124866146/fa2fb1ef-519e-487e-9003-95e54c64ad76)
