# GitHub issue #3752: [Bug] recipient is not listed in the recipient list after adding

## Metadata

Repository: linagora/tmail-flutter
Issue number: 3752
State: closed
Author: thuyenh1081
Created at: 2025-05-26T04:28:46Z
Updated at: 2025-07-31T02:27:25Z
Closed at: 2025-07-31T02:21:11Z
Labels: bug
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/3752

## Issue body

### Environment:
Stating: version 0.15.4, browser: Chrome, Edge
App: version 0.15.4  device iphone11, IOS: 18.3.1

#### Reproduction Steps
1. Try to login by account A
2. Go to Account setting
3. Try to add an account( ex: account C) in to Preference session
4. See that after adding, the recipient is not listed in the recipient list
5. Try to send a mail by account B to account A. See that account C doesn't receive the email

### Expected result
After step2, the recipient is listed in the recipient list
After step5, the recipient in the list will receive the mail that account A received

### attached file for reference:
https://github.com/user-attachments/assets/ad2f91cd-5452-4a4f-b7bf-e318e1c74a62
https://github.com/user-attachments/assets/3948fcf6-3ced-48c3-b283-d0cf55fbec09

## Comments

### Comment by hoangdat at 2025-05-26T04:40:16Z

hi @Arsnael @quantranhong1999 

When trying to add forwarding:
```
"error",
{
    "type": "forbidden",
    "description": "Access to other accounts settings is forbidden"
},
"c0"
```

### Comment by quantranhong1999 at 2025-05-26T04:52:29Z

I can reproduce this on tmail.linagora.com too. Maybe it is related to the latest release.

@Arsnael, I remember we did not have a change on JMAP, right?

### Comment by Arsnael at 2025-05-26T05:35:11Z

Indeed, can reproduce it too. I can't look at it atm, do you mind having a look @quantranhong1999 ?

> I remember we did not have a change on JMAP, right?

I don't think so, not around this part at least. Can't seem to see anything relevant in logs either after a quick check.

### Comment by quantranhong1999 at 2025-05-26T05:35:40Z

>  can't look at it atm, do you mind having a look @quantranhong1999 ?

Yes, I will have a look.

### Comment by quantranhong1999 at 2025-05-26T09:05:16Z

Thanks for your report. It is a backend bug.
We are working on a fix and a release retag with it: https://github.com/linagora/tmail-backend/pull/1768

### Comment by quantranhong1999 at 2025-05-27T10:11:02Z

Hello,
It should be fine now for TWP stg/dev.
Please double check on your side.

### Comment by thuyenh1081 at 2025-07-31T01:53:39Z

I see it happen again when I check it on web ( tested with chrome, edge) with version 0.17.2 on staging evn. 

https://github.com/user-attachments/assets/4ed50a13-0ec6-46bf-9193-a0a5763c56f8

### Comment by Arsnael at 2025-07-31T02:16:27Z

https://github.com/user-attachments/assets/1452ce33-4e3f-4ab3-865c-bd6b5896b2a4

Looks fine to me :)

### Comment by thuyenh1081 at 2025-07-31T02:21:11Z

Ah, I have found that it happen in this scenario
- user A successfully add eduser B into list of recipient
- user B tried to add user A into list >>> will see this issue
I think this scenario should handle at other fix. So, I would like to close this issue

### Comment by Arsnael at 2025-07-31T02:23:56Z

> user B tried to add user A into list >>> will see this issue

And backend is likely right to refuse that... Forwarding loops are wrong

### Comment by quantranhong1999 at 2025-07-31T02:27:25Z

> And backend is likely right to refuse that... Forwarding loops are wrong

Yes. But the problem is that the backend returns a success response when `Forward/set` the loop, so the user thought they succeeded in doing that. We should reject the loop within `notUpdated` instead. I will have a look at that.
