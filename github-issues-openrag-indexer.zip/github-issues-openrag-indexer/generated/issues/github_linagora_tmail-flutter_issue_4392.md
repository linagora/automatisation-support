# GitHub issue #4392: Team mailbox system folder management

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4392
State: closed
Author: chibenwa
Created at: 2026-03-19T18:06:36Z
Updated at: 2026-04-06T07:56:32Z
Closed at: 2026-04-06T07:56:32Z
Labels: bug, Critical, customer
Assignees: dab246
URL: https://github.com/linagora/tmail-flutter/issues/4392

## Issue body

User story 1

```
AS a team mailbox member
WHEN I click on the delete icon of an email within the team mailbox
THEN the mail goes into the team mailbox trash
```

User story 2

```
AS a team mailbox member
GIVEN I edit an email with a team mailbox member identity
WHEN I close my composer
THEN it is saved in the team mailbox Draft folder
```

User story 3

```
AS a team mailbox member
I can delete emails within the team mailbox trash
I can empty the team mailbox trash
````

User story 4

```
AS a team mailbox member
WHEN I open an email in the Template folder
THEN I edit it as new in the composer
```

User story 5

```
As a team mailbox member 
I can create subfolder
I can delete / rename those folder within the team mailbox
```

## Comments

### Comment by hoangdat at 2026-03-31T03:04:51Z

### Analyze
Test with new TeamMailbox

### Use cases:

#### WORK ✅ 
```
AS a team mailbox member
WHEN I click on the delete icon of an email within the team mailbox
THEN the mail goes into the team mailbox trash
```

#### WORK ✅ 
```
AS a team mailbox member
GIVEN I edit an email with a team mailbox member identity
WHEN I close my composer
THEN it is saved in the team mailbox Draft folder
```

#### WORK ✅ 
```
AS a team mailbox member
I can delete emails within the team mailbox trash
I can empty the team mailbox trash
```

🔴  when go to Trash of TeamMailbox, Restore still restore of primary account

#### Worked but still use default identity 
```
AS a team mailbox member
WHEN I open an email in the Template folder
THEN I edit it as new in the composer
```
Still use default identity when open email in template of teammailbox

#### Cannot save as template as a member of teammailbox 🔴

#### Use case 5
Cannot create folder or subfolder 


@chibenwa @poupotte

### Comment by hoangdat at 2026-03-31T06:32:49Z

@chibenwa I updated the test of teammailbox. https://github.com/linagora/tmail-flutter/issues/4392#issuecomment-4159533233

### Comment by chibenwa at 2026-03-31T11:24:23Z

> when go to Trash of TeamMailbox, Restore still restore of primary account

You mean when I delete a team mail
Then it goes in team mailbox trash (ok)
And when this mail is restored
Then it does in main account (not ok)

Right?

Also that is a front bug that needs to be fixed. Right?

### Comment by chibenwa at 2026-03-31T11:25:50Z

> Still use default identity when open email in template of teammailbox

Acceptable in a v0 work IMO and we can plan a follow up issue on this to sort identity differently in team mailbox context.

### Comment by chibenwa at 2026-03-31T11:27:10Z

> Cannot save as template as a member of teammailbox 🔴

Why?

> Cannot create folder or subfolder

Why? Do we have a server error? 🤔

### Comment by hoangdat at 2026-03-31T11:54:45Z

Btw, I deployed v0.27.1-rc01 on canary. I will more detail tmr

### Comment by chibenwa at 2026-03-31T12:29:23Z

Also `Archive action` moves to personal archive and not in team mailbox archive.

(can be a follow up issue)

Archive button must be disabled if the team mailbox `Archive` folder do not exist and the current user do not have the right to create it.

### Comment by chibenwa at 2026-03-31T12:51:26Z

Regarding create (rename delete) mailbox

CF https://github.com/linagora/tmail-backend/issues/2299#issuecomment-4162422291 

(thanks apparently I missed this)

### Comment by chibenwa at 2026-03-31T13:02:38Z

I do not find `save as template` action

I do not find `restore` action

<img width="1836" height="632" alt="Image" src="https://github.com/user-attachments/assets/6dfb7c8a-eb4c-4d55-85f6-0953f899b434" />

### Comment by chibenwa at 2026-03-31T13:03:26Z

I propose to merge anyway as it improves current situation and track following issue (open subtickets and track it for potential customer projects)

Ok?
