# GitHub issue #868: Unread/new emails are not loaded when opening folder

## Metadata

Repository: linagora/tmail-flutter
Issue number: 868
State: closed
Author: tuanlc
Created at: 2022-08-22T04:15:03Z
Updated at: 2022-10-03T14:50:15Z
Closed at: 2022-10-03T14:50:15Z
Labels: bug, 0, Critical
Assignees: ManhNTX
URL: https://github.com/linagora/tmail-flutter/issues/868

## Issue body

### Description
- I have a filter that direct emails from Gitlab.com to my `Gitlab` folder
- As you can see in the demo, the unread indicator is 7 for the folder but there is no unread/new emails in the list even I refresh the page
  
https://user-images.githubusercontent.com/7950991/185837959-ad156c4d-d27e-4232-a89f-88a6c818da7b.mp4

- I used Thunderbird to check and they are there
![image](https://user-images.githubusercontent.com/7950991/185838111-cf029a31-d68f-4d3d-a018-e85a3a7fb716.png)

- When using filter to list only unread messages, they are displayed

https://user-images.githubusercontent.com/7950991/185838360-597b232a-a716-47e6-9d0e-a4a341eb4ec4.mp4

### Expected result
- The unread messages should be displayed in the list
- The number of unread (indicator) should be consistent with the list

### Context

- Devices: Desktop (web)
- Browser: Firefox

## Comments

### Comment by hoangdat at 2022-08-22T06:59:06Z

Hi @tuanlc, that filter (which move email to Gitlab) is set up when? or someday ago?

### Comment by tuanlc at 2022-08-22T12:50:26Z

It was configured few years ago :wink:

### Comment by dab246 at 2022-08-24T11:03:17Z

@tuanlc  
- Temporarily you can clear `cache` then `logout` and log back in to see if the same happens?
- Currently I can't reproduce to find your error. But I think it's because of saving the new `state`.

### Comment by hoangdat at 2022-08-26T16:28:42Z

Reproduce (MAYBE) another case related to state in v0.3.13. 
Frequently: Always
Reason: Wrong logic in `ThreadRepository::getAllEmail` in the case caches email (>20) for one mailbox are filtered last time

https://user-images.githubusercontent.com/6462404/186950080-3f4843f7-c883-4573-8ba9-d24593c3ee86.mov

### Comment by dab246 at 2022-09-06T02:56:35Z

1 HD

### Comment by dab246 at 2022-09-07T02:32:59Z

2 HD

### Comment by dab246 at 2022-09-08T02:37:02Z

1 HD

### Comment by dab246 at 2022-09-09T02:31:36Z

1 HD

### Comment by dab246 at 2022-09-12T02:39:33Z

1 HD

### Comment by dab246 at 2022-09-14T07:48:47Z

1 HD
