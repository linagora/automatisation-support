# GitHub issue #4634: Translate Twake mail in Mongolian

## Metadata

Repository: linagora/tmail-flutter
Issue number: 4634
State: closed
Author: chibenwa
Created at: 2026-06-26T06:57:04Z
Updated at: 2026-06-29T05:00:27Z
Closed at: 2026-06-29T05:00:27Z
Labels: 
Assignees: 
URL: https://github.com/linagora/tmail-flutter/issues/4634

## Issue body

Have a Twake mail translation in Mongolian

## Comments

### Comment by coderabbitai[bot] at 2026-06-26T06:57:29Z

<!-- This is an auto-generated issue plan by CodeRabbit -->

<details>
<summary>⚠️ Possible Duplicate Issue(s)</summary>

- https://github.com/linagora/tmail-flutter/issues/4621
</details>

---
<details>
<summary>📝 Issue Planner</summary>

<sub>Check the box below or use the `@coderabbitai plan` command to generate an implementation plan and prompts that you can use with your favorite coding assistant.</sub>

- [ ] <!-- {"checkboxId": "8d4f2b9c-3e1a-4f7c-a9b2-d5e8f1c4a7b9"} --> Create Plan
</details>


---
<details>
<summary> 🧪 Issue enrichment is currently in open beta.</summary>


You can configure auto-planning by selecting labels in the issue_enrichment configuration.

To disable automatic issue enrichment, add the following to your `.coderabbit.yaml`:
```yaml
issue_enrichment:
  auto_enrich:
    enabled: false
```
</details>

💬 Have feedback or questions? Drop into our [discord](https://discord.gg/coderabbit)!

### Comment by chibenwa at 2026-06-26T07:09:02Z

Hi 👋 I looked into what it would take to ship Mongolian (`mn`) support.

**Code wiring needed** (straightforward, I can do this):
- `LanguageCodeConstants`: add `mongolian = 'mn'`
- `LocalizationService`: add `mn` to `supportedLanguageCodes` and a `Locale('mn', 'MN')` to `supportedLocales`
- `app_localizations.dart`: add a `languageMongolian` getter
- `locale_extension.dart`: add the localized + native display name (e.g. `Монгол`)

**The blocker is the translation content itself.** There is currently no Mongolian arb file anywhere, and full support actually requires translating ~3 modules:
- `lib/l10n/intl_mn.arb` (~520 keys)
- `scribe/lib/scribe/ai/l10n/intl_mn.arb`
- `workplace/lib/l10n/app_mn.arb`

Looking at git history, languages are translated by humans through Weblate ("Translated using Weblate (…)" commits) and only get added to `supportedLocales` once the translation is sufficiently complete (the 7 enabled languages all have full arb files; the other ~40 Weblate-configured languages stay as empty `{}` placeholders and are intentionally **not** activated). Activating `mn` with no translations would just show English fallback to users.

Before opening a PR, could you confirm the intended path?

1. Should Mongolian first be added as a component/language in **Weblate** so it can be translated by the community, the same way the other languages were? (That config lives outside this repo — I can't do it from here.)
2. Or do you want me to commit the **code wiring now** plus an initial machine-translated `intl_mn.arb` (across the 3 modules) as a starting point for translators to refine? I can do this, but I'd want explicit sign-off since the project's convention is human/Weblate-sourced translations and I can't guarantee the quality of an auto-generated initial pass.
3. Region/display details to confirm: locale `mn_MN`, native name `Монгол` (Cyrillic script) — correct for your audience?

Happy to proceed as soon as you point me at the preferred option. Also note this overlaps with #4621.

### Comment by chibenwa at 2026-06-26T07:09:33Z

<details><summary>🤖 Session stats</summary>

55 turns | in=3184 out=18878 cache_read=1351191 cache_write=36158 | cost=n/a

</details>

### Comment by chibenwa at 2026-06-26T07:11:32Z

1. yes but we can do 2. for now

3. confirmed

### Comment by chibenwa at 2026-06-26T07:19:36Z

Hi 👋 — I looked into adding Mongolian and a few things need a decision before I open a PR, because the translation workflow here isn't a pure code change.

**What I found**

- Translations are managed on **Weblate** (`README.md` → https://hosted.weblate.org/projects/linagora/teammail/). The `lib/l10n/intl_<lang>.arb` files are seeded/maintained there — some are fully translated (`intl_uk.arb`, `intl_zh_Hans.arb`, `intl_es.arb`), many are empty `{}` stubs (`intl_ca.arb`, `intl_cs.arb`, `intl_ja.arb`, `intl_bo.arb`, …).
- There is currently **no `intl_mn.arb`** → Mongolian doesn't exist in the Weblate project yet, so there's no translation content to ship.
- A language only becomes selectable in the app once it's added in code to `LocalizationService.supportedLanguageCodes` + `supportedLocales`, with a display name in `locale_extension.dart` and a `languageMongolian` source string. Only 7 languages are activated (fr/en/vi/ru/ar/it/de); others (e.g. `ja`, `cs`, `ca`) have arb files but are intentionally **not** activated because they're untranslated.

**Questions**

1. **Where should the Mongolian strings come from?** The established path is Weblate (add Mongolian to the Weblate project → translators fill it → arb syncs back). Do you want me instead to hand-author `intl_mn.arb` directly in a PR? If so, that bypasses Weblate and the translation would be machine-assisted rather than reviewed by a native speaker.
2. **Activate now or after coverage?** Activating `mn` in the app before there are translations means the whole UI falls back to English under a "Mongolian" entry — which appears to be why `ja`/`cs`/`ca` aren't activated yet. Should activation wait until Weblate coverage is sufficient?
3. **Script / locale code:** Cyrillic Mongolian (`mn`, as used in Mongolia) or traditional Mongolian script (`mn-Mong`)? This determines the arb filename and locale.

If you confirm option (1) "author it in a PR + activate now", I'm happy to do the full wiring (`LanguageCodeConstants`, `LocalizationService`, `locale_extension`, `languageMongolian` string) plus `intl_mn.arb` in one go. Just let me know which direction you prefer.

### Comment by chibenwa at 2026-06-26T07:19:50Z

<details><summary>🤖 Session stats</summary>

57 turns | in=3172 out=20912 cache_read=1390470 cache_write=39475 | cost=n/a

</details>

### Comment by chibenwa at 2026-06-26T07:38:35Z

> 1. Where should the Mongolian strings come from?

Translate it yourself

author it in a PR + activate now

2. Activate now as you would provide full coverage 

3. mn

### Comment by chibenwa at 2026-06-26T08:09:25Z

<details><summary>🤖 Session stats</summary>

96 turns | in=3861 out=121722 cache_read=8163306 cache_write=205413 | cost=n/a

</details>
